
| 🏚️ **Homepage**                | Alt + H          |
| ------------------------------- | ---------------- |
| 🎛️ **Paleta de comandos**      | Ctrl + P         |
| ➡️ **Acessar Nota**             | Ctrl + Shift + P |
| 🗓️ **Nota Diária**             | Ctrl + Shift + D |
| ➕ **Nova Nota**                 | Ctrl + N         |
| 📜 **Inserir Snippet Template** | Alt + T          |
| 📑 **Mostrar Favoritos**        | Ctrl + Shift + B |
| ⭐ **Favoritar Todas as Abas**   | Alt + B          |
| 🗂️ **Explorador de Arquivos**  | Ctrl + Shift + P |
| 📦 **Mover Arquivo**            | Alt + M          |
| 🔍 **Pesquisar**                | Ctrl + Shift + O |
| 🚪 **Fechar Aba**               | Alt + W          |
| 🗑️ **Excluir Arquivo**         | Ctrl + Shift + - |

