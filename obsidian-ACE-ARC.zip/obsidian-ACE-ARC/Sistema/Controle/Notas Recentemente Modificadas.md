---
up:
  - "[[Home Pro Básico]]"
collection:
  - "[[Mapas]]"
  - "[[Visualizações]]"
related:
  - "[[Recentemente Modificado]]"
created:
  - 2023-11-14
cssclasses:
  - wide-page
---
 
### Últimas `50` notas modificadas

~~~~note-gallery     #           padrão | opções
path: /           # opcional: pasta da nota atual | caminho/para/pasta
limit: 50            # opcional: 0 | qualquer número
recursive: true      # opcional: true | false
sort: desc           # opcional: desc | asc
sortby: mtime        # opcional: mtime | ctime | nome
fontsize: 6pt        # opcional: 6pt | NÚMEROpt | NÚMEROps
~~~~