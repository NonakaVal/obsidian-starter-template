---
created:
  - '[[<% tp.date.now("YYYY-MM-DD") %>]]'
up:
---
 `Coleção` | `INPUT[suggester(optionQuery("Sistema/Coleções")):collection]`   | `Relacionados` | `INPUT[inlineListSuggester(optionQuery(""), option(something, other),  useLinks(true), showcase):related]`  |

---

# [[<% tp.file.title %>]] 

