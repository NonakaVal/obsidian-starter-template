--- start-multi-column: ExampleRegion3

\# Column 1

\--- end-column ---

\# Column 2

--- end-multi-column

