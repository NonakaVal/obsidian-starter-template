````tabs
tab: <% tp.system.prompt("tab 1")%>

tab: <% tp.system.prompt("tab 2")%>

````