 INPUT[inlineSelect(option('1'), option('2'), option('3')):]` 
 