---
created:
  - "[[2025-09-17]]"
up: "[[Curso 1|Curso 1]]"
collection: "[[SISTEMA/COLEÇÕES/Estudos.md|Estudos]]"
related:
  - "[[Aula 1|Aula 1]]"
---
| `Up` | `INPUT[suggester(optionQuery("")):up]`    | `Coleção` | `INPUT[suggester(optionQuery("SISTEMA/COLEÇÕES")):collection]`   | `Relacionados` | `INPUT[inlineListSuggester(optionQuery(""), option(something, other),  useLinks(true), showcase):related]`  |

---

# [[Segunda Aula]] 

Conteúdo segunda aula