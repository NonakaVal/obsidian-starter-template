---
up:
  - "[[Calendário]]"
collection:
  - "[[Mapas]]"
  - "[[Visualizações]]"
related:
created: 2025-04-07 19:27
cssclasses:
  - wide-page
---

```dataview
TABLE WITHOUT ID
file.link as Nota , file.inlinks AS inlins, length(file.inlinks) as Total 
FROM "CALENDÁRIO/DIAS"
sort file.ctime desc
```

