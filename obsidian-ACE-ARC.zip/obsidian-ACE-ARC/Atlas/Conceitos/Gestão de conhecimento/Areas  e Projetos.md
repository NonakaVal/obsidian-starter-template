---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
tags:
---
Pelo botão : `BUTTON[Área]`     ou nas opções de `ctrl + N` 

> [!VIDEO]- Criando Notas para Areas e Projetos
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://drive.google.com/file/d/1cpyU7YMr7ndQGRynHTqMEGY7RAJky9VM/preview" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="Ideaverse Pro Hangar"></iframe></div>

```meta-bind-button
label: Nova Área ou Projeto
hidden: true
icon: plus
class: ""
id: Área
style: default
actions:
  - type: command
    command: quickadd:choice:ebc3941c-ed51-4da4-abb4-bf15c72eb683
```

