---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
Esta nota coleta todas as notas onde a propriedade `collection` diz **Concepts**.  
Observe a propriedade **"Says"**.  

Uma das práticas mais subestimadas e semelhantes ao método LYT que você pode adotar é **personificar qualquer conceito** que encontrar.  
Se ele pudesse pronunciar uma única frase, o que diria?  

Os conceitos a seguir estão ordenados por classificação (**rank**).  
