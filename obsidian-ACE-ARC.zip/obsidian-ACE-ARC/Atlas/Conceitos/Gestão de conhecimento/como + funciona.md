---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
Quando um **flash de inspiração** surge, você consegue capturar a faísca? É para isso que serve a pasta `+`. Sempre que você cria uma nova nota, ela é adicionada lá. Você não precisa se preocupar em organizá-la de imediato.

Depois, quando estiver pronto, basta abrir a pasta `+` e começar a processar as notas que encontrar. Ou, se preferir, pode ir até a nota [[Adicionar]], que classifica para você as notas mais recentes.

Para adicionar uma nova nota, basta usar o comando universal `cmd-n` no Mac (ou `ctrl-n` no Windows).