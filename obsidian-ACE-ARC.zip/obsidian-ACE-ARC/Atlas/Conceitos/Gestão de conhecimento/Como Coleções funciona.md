---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---

**Coleções** se referem a notas especiais que possuem "buscas salvas" (queries) que permanecem sempre atualizadas (alguns dizem "automágicas"). Elas também podem ser chamadas de "dashboards dinâmicos". Exemplos comuns incluem:

- Mapas
- Coisas, Conceitos, Pessoas
- Declarações, Perguntas, Citações
- Livros, Filmes, Séries
- Reuniões, Entidades
- Esforços