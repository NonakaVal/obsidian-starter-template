---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
Para criar uma nova coleção, selecione 📁 Nova Coleção na criação de notas `ctrl + N` ou com `Alt + C` diretamente.

[[Coleções]]