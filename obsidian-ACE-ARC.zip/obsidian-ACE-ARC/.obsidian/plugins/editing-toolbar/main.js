"use strict";
var t = require("obsidian");
function e(t, e, i, n) {
    return new (i || (i = Promise))(function (o, s) {
        function r(t) {
            try {
                a(n.next(t));
            } catch (t) {
                s(t);
            }
        }
        function l(t) {
            try {
                a(n.throw(t));
            } catch (t) {
                s(t);
            }
        }
        function a(t) {
            var e;
            t.done
                ? o(t.value)
                : ((e = t.value),
                    e instanceof i
                        ? e
                        : new i(function (t) {
                            t(e);
                        })).then(r, l);
        }
        a((n = n.apply(t, e || [])).next());
    });
}
"function" == typeof SuppressedError && SuppressedError;
const i = [
    "Custom",
    "editingToolbar",
    "editingToolbarSub",
    "editingToolbarAdd",
    "editingToolbarDelete",
    "editingToolbarReload",
    "codeblock-glyph",
    "underline-glyph",
    "superscript-glyph",
    "subscript-glyph",
    "bot-glyph",
    "header-1",
    "header-2",
    "header-3",
    "header-4",
    "header-5",
    "header-6",
    "header-n",
    "obsidian",
    "obsidian-new",
    "accessibility",
    "activity",
    "air-vent",
    "airplay",
    "alarm-check",
    "alarm-clock-off",
    "alarm-clock",
    "alarm-minus",
    "alarm-plus",
    "album",
    "alert-circle",
    "alert-octagon",
    "alert-triangle",
    "align-center-horizontal",
    "align-center-vertical",
    "align-center",
    "align-end-horizontal",
    "align-end-vertical",
    "align-horizontal-distribute-center",
    "align-horizontal-distribute-end",
    "align-horizontal-distribute-start",
    "align-horizontal-justify-center",
    "align-ho xrizontal-justify-end",
    "align-horizontal-justify-start",
    "align-horizontal-space-around",
    "align-horizontal-space-between",
    "align-justify",
    "align-left",
    "align-right",
    "align-start-horizontal",
    "align-start-vertical",
    "align-vertical-distribute-center",
    "align-vertical-distribute-end",
    "align-vertical-distribute-start",
    "align-vertical-justify-center",
    "align-vertical-justify-end",
    "align-vertical-justify-start",
    "align-vertical-space-around",
    "align-vertical-space-between",
    "anchor",
    "angry",
    "annoyed",
    "aperture",
    "apple",
    "archive-restore",
    "archive",
    "armchair",
    "arrow-big-down",
    "arrow-big-left",
    "arrow-big-right",
    "arrow-big-up",
    "arrow-down-circle",
    "arrow-down-left",
    "arrow-down-right",
    "arrow-down",
    "arrow-left-circle",
    "arrow-left-right",
    "arrow-left",
    "arrow-right-circle",
    "arrow-right",
    "arrow-up-circle",
    "arrow-up-left",
    "arrow-up-right",
    "arrow-up",
    "asterisk",
    "at-sign",
    "award",
    "axe",
    "axis-3d",
    "baby",
    "backpack",
    "baggage-claim",
    "banana",
    "banknote",
    "bar-chart-2",
    "bar-chart-3",
    "bar-chart-4",
    "bar-chart-horizontal",
    "bar-chart",
    "baseline",
    "bath",
    "battery-charging",
    "battery-full",
    "battery-low",
    "battery-medium",
    "battery",
    "beaker",
    "bed-double",
    "bed-single",
    "bed",
    "beer",
    "bell-minus",
    "bell-off",
    "bell-plus",
    "bell-ring",
    "bell",
    "bike",
    "binary",
    "bitcoin",
    "bluetooth-connected",
    "bluetooth-off",
    "bluetooth-searching",
    "bluetooth",
    "bold",
    "bomb",
    "bone",
    "book-open",
    "book",
    "bookmark-minus",
    "bookmark-plus",
    "bookmark",
    "bot",
    "box-select",
    "box",
    "boxes",
    "briefcase",
    "brush",
    "bug",
    "building-2",
    "building",
    "bus",
    "cake",
    "calculator",
    "calendar-check-2",
    "calendar-check",
    "calendar-clock",
    "calendar-days",
    "calendar-heart",
    "calendar-minus",
    "calendar-off",
    "calendar-plus",
    "calendar-range",
    "calendar-search",
    "calendar-x2",
    "calendar-x",
    "calendar",
    "camera-off",
    "camera",
    "car",
    "carrot",
    "cast",
    "check-circle-2",
    "check-circle",
    "check-square",
    "check",
    "chef-hat",
    "cherry",
    "chevron-down",
    "chevron-first",
    "chevron-last",
    "chevron-left",
    "chevron-right",
    "chevron-up",
    "chevrons-down-up",
    "chevrons-down",
    "chevrons-left-right",
    "chevrons-left",
    "chevrons-right-left",
    "chevrons-right",
    "chevrons-up-down",
    "chevrons-up",
    "chrome",
    "cigarette-off",
    "cigarette",
    "circle-dot",
    "circle-ellipsis",
    "circle-slashed",
    "circle",
    "citrus",
    "clapperboard",
    "clipboard-check",
    "clipboard-copy",
    "clipboard-edit",
    "clipboard-list",
    "clipboard-signature",
    "clipboard-type",
    "clipboard-x",
    "clipboard",
    "clock-1",
    "clock-10",
    "clock-11",
    "clock-12",
    "clock-2",
    "clock-3",
    "clock-4",
    "clock-5",
    "clock-6",
    "clock-7",
    "clock-8",
    "clock-9",
    "clock",
    "cloud-cog",
    "cloud-drizzle",
    "cloud-fog",
    "cloud-hail",
    "cloud-lightning",
    "cloud-moon-rain",
    "cloud-moon",
    "cloud-off",
    "cloud-rain-wind",
    "cloud-rain",
    "cloud-snow",
    "cloud-sun-rain",
    "cloud-sun",
    "cloud",
    "cloudy",
    "clover",
    "code-2",
    "code",
    "codepen",
    "codesandbox",
    "coffee",
    "cog",
    "coins",
    "columns",
    "command",
    "compass",
    "component",
    "contact",
    "contrast",
    "cookie",
    "copy",
    "copyleft",
    "copyright",
    "corner-down-left",
    "corner-down-right",
    "corner-left-down",
    "corner-left-up",
    "corner-right-down",
    "corner-right-up",
    "corner-up-left",
    "corner-up-right",
    "cpu",
    "credit-card",
    "croissant",
    "crop",
    "cross",
    "crosshair",
    "crown",
    "cup-soda",
    "curly-braces",
    "currency",
    "database",
    "delete",
    "diamond",
    "dice-1",
    "dice-2",
    "dice-3",
    "dice-4",
    "dice-5",
    "dice-6",
    "dices",
    "diff",
    "disc",
    "divide-circle",
    "divide-square",
    "divide",
    "dollar-sign",
    "download-cloud",
    "download",
    "dribbble",
    "droplet",
    "droplets",
    "drumstick",
    "edit-2",
    "edit-3",
    "edit",
    "egg-fried",
    "egg",
    "equal-not",
    "equal",
    "eraser",
    "euro",
    "expand",
    "external-link",
    "eye-off",
    "eye",
    "facebook",
    "factory",
    "fast-forward",
    "feather",
    "figma",
    "file-archive",
    "file-audio-2",
    "file-audio",
    "file-axis-3d",
    "file-badge-2",
    "file-badge",
    "file-bar-chart-2",
    "file-bar-chart",
    "file-box",
    "file-check-2",
    "file-check",
    "file-clock",
    "file-code",
    "file-cog-2",
    "file-cog",
    "file-diff",
    "file-digit",
    "file-down",
    "file-edit",
    "file-heart",
    "file-image",
    "file-input",
    "file-json-2",
    "file-json",
    "file-key-2",
    "file-key",
    "file-line-chart",
    "file-lock-2",
    "file-lock",
    "file-minus-2",
    "file-minus",
    "file-output",
    "file-pie-chart",
    "file-plus-2",
    "file-plus",
    "file-question",
    "file-scan",
    "file-search-2",
    "file-search",
    "file-signature",
    "file-spreadsheet",
    "file-symlink",
    "file-terminal",
    "file-text",
    "file-type-2",
    "file-type",
    "file-up",
    "file-video-2",
    "file-video",
    "file-volume-2",
    "file-volume",
    "file-warning",
    "file-x2",
    "file-x",
    "file",
    "files",
    "film",
    "filter",
    "fingerprint",
    "flag-off",
    "flag-triangle-left",
    "flag-triangle-right",
    "flag",
    "flame",
    "flashlight-off",
    "flashlight",
    "flask-conical",
    "flask-round",
    "flip-horizontal-2",
    "flip-horizontal",
    "flip-vertical-2",
    "flip-vertical",
    "flower-2",
    "flower",
    "focus",
    "folder-archive",
    "folder-check",
    "folder-clock",
    "folder-closed",
    "folder-cog-2",
    "folder-cog",
    "folder-down",
    "folder-edit",
    "folder-heart",
    "folder-input",
    "folder-key",
    "folder-lock",
    "folder-minus",
    "folder-open",
    "folder-output",
    "folder-plus",
    "folder-search-2",
    "folder-search",
    "folder-symlink",
    "folder-tree",
    "folder-up",
    "folder-x",
    "folder",
    "folders",
    "form-input",
    "forward",
    "frame",
    "framer",
    "frown",
    "fuel",
    "function-square",
    "gamepad-2",
    "gamepad",
    "gauge",
    "gavel",
    "gem",
    "ghost",
    "gift",
    "git-branch-plus",
    "git-branch",
    "git-commit",
    "git-compare",
    "git-fork",
    "git-merge",
    "git-pull-request-closed",
    "git-pull-request-draft",
    "git-pull-request",
    "github",
    "gitlab",
    "glass-water",
    "glasses",
    "globe-2",
    "globe",
    "grab",
    "graduation-cap",
    "grape",
    "grid",
    "grip-horizontal",
    "grip-vertical",
    "hammer",
    "hand-metal",
    "hand",
    "hard-drive",
    "hard-hat",
    "hash",
    "haze",
    "headphones",
    "heart-crack",
    "heart-handshake",
    "heart-off",
    "heart-pulse",
    "heart",
    "help-circle",
    "hexagon",
    "highlighter",
    "history",
    "home",
    "hourglass",
    "ice-cream",
    "image-minus",
    "image-off",
    "image-plus",
    "image",
    "import",
    "inbox",
    "indent",
    "indian-rupee",
    "infinity",
    "info",
    "inspect",
    "instagram",
    "italic",
    "japanese-yen",
    "joystick",
    "key",
    "keyboard",
    "lamp-ceiling",
    "lamp-desk",
    "lamp-floor",
    "lamp-wall-down",
    "lamp-wall-up",
    "lamp",
    "landmark",
    "languages",
    "laptop-2",
    "laptop",
    "lasso-select",
    "lasso",
    "laugh",
    "layers",
    "layout-dashboard",
    "layout-grid",
    "layout-list",
    "layout-template",
    "layout",
    "leaf",
    "library",
    "life-buoy",
    "lightbulb-off",
    "lightbulb",
    "line-chart",
    "link-2off",
    "link-2",
    "link",
    "linkedin",
    "list-checks",
    "list-end",
    "list-minus",
    "list-music",
    "list-ordered",
    "list-plus",
    "list-start",
    "list-video",
    "list-x",
    "list",
    "loader-2",
    "loader",
    "locate-fixed",
    "locate-off",
    "locate",
    "lock",
    "log-in",
    "log-out",
    "luggage",
    "magnet",
    "mail-check",
    "mail-minus",
    "mail-open",
    "mail-plus",
    "mail-question",
    "mail-search",
    "mail-warning",
    "mail-x",
    "mail",
    "mails",
    "map-pin-off",
    "map-pin",
    "map",
    "martini",
    "maximize-2",
    "maximize",
    "medal",
    "megaphone-off",
    "megaphone",
    "meh",
    "menu",
    "message-circle",
    "message-square",
    "mic-2",
    "mic-off",
    "mic",
    "microscope",
    "milestone",
    "minimize-2",
    "minimize",
    "minus-circle",
    "minus-square",
    "minus",
    "monitor-off",
    "monitor-speaker",
    "monitor",
    "moon",
    "more-horizontal",
    "more-vertical",
    "mountain-snow",
    "mountain",
    "mouse-pointer-2",
    "mouse-pointer-click",
    "mouse-pointer",
    "mouse",
    "move-3d",
    "move-diagonal-2",
    "move-diagonal",
    "move-horizontal",
    "move-vertical",
    "move",
    "music-2",
    "music-3",
    "music-4",
    "music",
    "navigation-2off",
    "navigation-2",
    "navigation-off",
    "navigation",
    "network",
    "newspaper",
    "octagon",
    "option",
    "outdent",
    "package-2",
    "package-check",
    "package-minus",
    "package-open",
    "package-plus",
    "package-search",
    "package-x",
    "package",
    "paint-bucket",
    "paintbrush-2",
    "paintbrush",
    "palette",
    "palmtree",
    "paperclip",
    "party-popper",
    "pause-circle",
    "pause-octagon",
    "pause",
    "pen-tool",
    "pencil",
    "percent",
    "person-standing",
    "phone-call",
    "phone-forwarded",
    "phone-incoming",
    "phone-missed",
    "phone-off",
    "phone-outgoing",
    "phone",
    "pie-chart",
    "piggy-bank",
    "pin-off",
    "pin",
    "pipette",
    "pizza",
    "plane",
    "play-circle",
    "play",
    "plug-zap",
    "plus-circle",
    "plus-square",
    "plus",
    "pocket",
    "podcast",
    "pointer",
    "pound-sterling",
    "power-off",
    "power",
    "printer",
    "puzzle",
    "qr-code",
    "quote",
    "radio-receiver",
    "radio",
    "recycle",
    "redo-2",
    "redo",
    "refresh-ccw",
    "refresh-cw",
    "regex",
    "repeat-1",
    "repeat",
    "reply-all",
    "reply",
    "rewind",
    "rocket",
    "rocking-chair",
    "rotate-3d",
    "rotate-ccw",
    "rotate-cw",
    "rss",
    "ruler",
    "russian-ruble",
    "save",
    "scale-3d",
    "scale",
    "scaling",
    "scan-face",
    "scan-line",
    "scan",
    "scissors",
    "screen-share-off",
    "screen-share",
    "scroll",
    "search",
    "send",
    "separator-horizontal",
    "separator-vertical",
    "server-cog",
    "server-crash",
    "server-off",
    "server",
    "settings-2",
    "settings",
    "share-2",
    "share",
    "sheet",
    "shield-alert",
    "shield-check",
    "shield-close",
    "shield-off",
    "shield",
    "shirt",
    "shopping-bag",
    "shopping-cart",
    "shovel",
    "shrink",
    "shrub",
    "shuffle",
    "sidebar-close",
    "sidebar-open",
    "sidebar",
    "sigma",
    "signal-high",
    "signal-low",
    "signal-medium",
    "signal-zero",
    "signal",
    "siren",
    "skip-back",
    "skip-forward",
    "skull",
    "slack",
    "slash",
    "slice",
    "sliders-horizontal",
    "sliders",
    "smartphone-charging",
    "smartphone",
    "smile-plus",
    "smile",
    "snowflake",
    "sofa",
    "sort-asc",
    "sort-desc",
    "speaker",
    "sprout",
    "square",
    "star-half",
    "star-off",
    "star",
    "stethoscope",
    "sticker",
    "sticky-note",
    "stop-circle",
    "stretch-horizontal",
    "stretch-vertical",
    "strikethrough",
    "subscript",
    "sun-dim",
    "sun-medium",
    "sun-moon",
    "sun-snow",
    "sun",
    "sunrise",
    "sunset",
    "superscript",
    "swiss-franc",
    "switch-camera",
    "sword",
    "swords",
    "syringe",
    "table-2",
    "table",
    "tablet",
    "tag",
    "tags",
    "target",
    "tent",
    "terminal-square",
    "terminal",
    "text-cursor-input",
    "text-cursor",
    "thermometer-snowflake",
    "thermometer-sun",
    "thermometer",
    "thumbs-down",
    "thumbs-up",
    "ticket",
    "timer-off",
    "timer-reset",
    "timer",
    "toggle-left",
    "toggle-right",
    "tornado",
    "toy-brick",
    "train",
    "trash-2",
    "trash",
    "tree-deciduous",
    "tree-pine",
    "trees",
    "trello",
    "trending-down",
    "trending-up",
    "triangle",
    "trophy",
    "truck",
    "tv-2",
    "tv",
    "twitch",
    "twitter",
    "type",
    "umbrella",
    "underline",
    "undo-2",
    "undo",
    "unlink-2",
    "unlink",
    "unlock",
    "upload-cloud",
    "upload",
    "usb",
    "user-check",
    "user-cog",
    "user-minus",
    "user-plus",
    "user-x",
    "user",
    "users",
    "utensils-crossed",
    "utensils",
    "venetian-mask",
    "verified",
    "vibrate-off",
    "vibrate",
    "video-off",
    "video",
    "view",
    "voicemail",
    "volume-1",
    "volume-2",
    "volume-x",
    "volume",
    "wallet",
    "wand-2",
    "wand",
    "watch",
    "waves",
    "webcam",
    "webhook",
    "wifi-off",
    "wifi",
    "wind",
    "wine",
    "wrap-text",
    "wrench",
    "x-circle",
    "x-octagon",
    "x-square",
    "x",
    "youtube",
    "zap-off",
    "zap",
    "zoom-in",
    "zoom-out",
    "create-new",
    "trash",
    "search",
    "right-triangle",
    "document",
    "folder",
    "pencil",
    "left-arrow",
    "right-arrow",
    "three-horizontal-bars",
    "dot-network",
    "audio-file",
    "image-file",
    "pdf-file",
    "gear",
    "documents",
    "blocks",
    "go-to-file",
    "presentation",
    "cross-in-box",
    "microphone",
    "microphone-filled",
    "two-columns",
    "link",
    "popup-open",
    "checkmark",
    "hashtag",
    "left-arrow-with-tail",
    "right-arrow-with-tail",
    "up-arrow-with-tail",
    "down-arrow-with-tail",
    "lines-of-text",
    "vertical-three-dots",
    "pin",
    "magnifying-glass",
    "info",
    "horizontal-split",
    "vertical-split",
    "calendar-with-checkmark",
    "folder-minus",
    "sheets-in-box",
    "up-and-down-arrows",
    "broken-link",
    "cross",
    "any-key",
    "reset",
    "star",
    "crossed-star",
    "dice",
    "filled-pin",
    "enter",
    "help",
    "vault",
    "open-vault",
    "paper-plane",
    "bullet-list",
    "uppercase-lowercase-a",
    "star-list",
    "expand-vertically",
    "languages",
    "switch",
    "pane-layout",
    "install",
    "sync",
    "check-in-circle",
    "sync-small",
    "check-small",
    "paused",
    "forward-arrow",
    "stacked-levels",
    "bracket-glyph",
    "note-glyph",
    "tag-glyph",
    "price-tag-glyph",
    "heading-glyph",
    "bold-glyph",
    "italic-glyph",
    "strikethrough-glyph",
    "highlight-glyph",
    "code-glyph",
    "quote-glyph",
    "link-glyph",
    "bullet-list-glyph",
    "number-list-glyph",
    "checkbox-glyph",
    "undo-glyph",
    "redo-glyph",
    "up-chevron-glyph",
    "down-chevron-glyph",
    "left-chevron-glyph",
    "right-chevron-glyph",
    "percent-sign-glyph",
    "keyboard-glyph",
    "double-up-arrow-glyph",
    "double-down-arrow-glyph",
    "image-glyph",
    "wrench-screwdriver-glyph",
    "clock",
    "plus-with-circle",
    "minus-with-circle",
    "indent-glyph",
    "unindent-glyph",
    "fullscreen",
    "exit-fullscreen",
    "cloud",
    "run-command",
    "compress-glyph",
    "enlarge-glyph",
    "scissors-glyph",
    "up-curly-arrow-glyph",
    "down-curly-arrow-glyph",
    "plus-minus-glyph",
    "links-going-out",
    "links-coming-in",
    "add-note-glyph",
    "duplicate-glyph",
    "clock-glyph",
    "calendar-glyph",
    "command-glyph",
    "dice-glyph",
    "file-explorer-glyph",
    "graph-glyph",
    "import-glyph",
    "navigate-glyph",
    "open-elsewhere-glyph",
    "presentation-glyph",
    "paper-plane-glyph",
    "question-mark-glyph",
    "restore-file-glyph",
    "search-glyph",
    "star-glyph",
    "play-audio-glyph",
    "stop-audio-glyph",
    "tomorrow-glyph",
    "wand-glyph",
    "workspace-glyph",
    "yesterday-glyph",
    "box-glyph",
    "merge-files-glyph",
    "merge-files",
    "two-blank-pages",
    "scissors",
    "paste",
    "paste-text",
    "split",
    "select-all-text",
    "wand",
    "github-glyph",
    "reading-glasses",
    "user-manual-filled",
    "discord-filled",
    "chat-bubbles-filled",
    "experiment-filled",
    "bracket-glyph",
    "box-glyph",
    "check-small",
    "dice-glyph",
    "dice",
    "discord",
    "right-triangle",
    "heading-glyph",
    "help",
    "keyboard-toggle",
    "broken-link",
    "experiment",
    "left-arrow",
    "link",
    "link-glyph",
    "links-coming-in",
    "links-going-out",
    "open-vault",
    "paused",
    "question-mark-glyph",
    "right-arrow",
    "sidebar-left",
    "sidebar-right",
    "sheets-in-box",
    "star-list",
    "sync-small",
    "tabs",
    "uppercase-lowercase-a",
    "vault",
    "stack-horizontal",
    "stack-vertical",
    "stretch-horizontal",
    "stretch-vertical",
    "distribute-space-horizontal",
    "distribute-space-vertical",
],
    n = 1024;
let o = 0;
class s {
    constructor(t, e) {
        (this.from = t), (this.to = e);
    }
}
class r {
    constructor(t = {}) {
        (this.id = o++),
            (this.perNode = !!t.perNode),
            (this.deserialize =
                t.deserialize ||
                (() => {
                    throw new Error("This node type doesn't define a deserialize function");
                }));
    }
    add(t) {
        if (this.perNode) throw new RangeError("Can't add per-node props to node types");
        return (
            "function" != typeof t && (t = c.match(t)),
            (e) => {
                let i = t(e);
                return void 0 === i ? null : [this, i];
            }
        );
    }
}
(r.closedBy = new r({ deserialize: (t) => t.split(" ") })),
    (r.openedBy = new r({ deserialize: (t) => t.split(" ") })),
    (r.group = new r({ deserialize: (t) => t.split(" ") })),
    (r.isolate = new r({
        deserialize: (t) => {
            if (t && "rtl" != t && "ltr" != t && "auto" != t) throw new RangeError("Invalid value for isolate: " + t);
            return t || "auto";
        },
    })),
    (r.contextHash = new r({ perNode: !0 })),
    (r.lookAhead = new r({ perNode: !0 })),
    (r.mounted = new r({ perNode: !0 }));
class l {
    constructor(t, e, i) {
        (this.tree = t), (this.overlay = e), (this.parser = i);
    }
    static get(t) {
        return t && t.props && t.props[r.mounted.id];
    }
}
const a = Object.create(null);
class c {
    constructor(t, e, i, n = 0) {
        (this.name = t), (this.props = e), (this.id = i), (this.flags = n);
    }
    static define(t) {
        let e = t.props && t.props.length ? Object.create(null) : a,
            i = (t.top ? 1 : 0) | (t.skipped ? 2 : 0) | (t.error ? 4 : 0) | (null == t.name ? 8 : 0),
            n = new c(t.name || "", e, t.id, i);
        if (t.props)
            for (let i of t.props)
                if ((Array.isArray(i) || (i = i(n)), i)) {
                    if (i[0].perNode) throw new RangeError("Can't store a per-node prop on a node type");
                    e[i[0].id] = i[1];
                }
        return n;
    }
    prop(t) {
        return this.props[t.id];
    }
    get isTop() {
        return (1 & this.flags) > 0;
    }
    get isSkipped() {
        return (2 & this.flags) > 0;
    }
    get isError() {
        return (4 & this.flags) > 0;
    }
    get isAnonymous() {
        return (8 & this.flags) > 0;
    }
    is(t) {
        if ("string" == typeof t) {
            if (this.name == t) return !0;
            let e = this.prop(r.group);
            return !!e && e.indexOf(t) > -1;
        }
        return this.id == t;
    }
    static match(t) {
        let e = Object.create(null);
        for (let i in t) for (let n of i.split(" ")) e[n] = t[i];
        return (t) => {
            for (let i = t.prop(r.group), n = -1; n < (i ? i.length : 0); n++) {
                let o = e[n < 0 ? t.name : i[n]];
                if (o) return o;
            }
        };
    }
}
c.none = new c("", Object.create(null), 0, 8);
const h = new WeakMap(),
    d = new WeakMap();
var u;
!(function (t) {
    (t[(t.ExcludeBuffers = 1)] = "ExcludeBuffers"), (t[(t.IncludeAnonymous = 2)] = "IncludeAnonymous"), (t[(t.IgnoreMounts = 4)] = "IgnoreMounts"), (t[(t.IgnoreOverlays = 8)] = "IgnoreOverlays");
})(u || (u = {}));
class p {
    constructor(t, e, i, n, o) {
        if (((this.type = t), (this.children = e), (this.positions = i), (this.length = n), (this.props = null), o && o.length)) {
            this.props = Object.create(null);
            for (let [t, e] of o) this.props["number" == typeof t ? t : t.id] = e;
        }
    }
    toString() {
        let t = l.get(this);
        if (t && !t.overlay) return t.tree.toString();
        let e = "";
        for (let t of this.children) {
            let i = t.toString();
            i && (e && (e += ","), (e += i));
        }
        return this.type.name ? (/\W/.test(this.type.name) && !this.type.isError ? JSON.stringify(this.type.name) : this.type.name) + (e.length ? "(" + e + ")" : "") : e;
    }
    cursor(t = 0) {
        return new E(this.topNode, t);
    }
    cursorAt(t, e = 0, i = 0) {
        let n = h.get(this) || this.topNode,
            o = new E(n);
        return o.moveTo(t, e), h.set(this, o._tree), o;
    }
    get topNode() {
        return new y(this, 0, 0, null);
    }
    resolve(t, e = 0) {
        let i = b(h.get(this) || this.topNode, t, e, !1);
        return h.set(this, i), i;
    }
    resolveInner(t, e = 0) {
        let i = b(d.get(this) || this.topNode, t, e, !0);
        return d.set(this, i), i;
    }
    resolveStack(t, e = 0) {
        return (function (t, e, i) {
            let n = t.resolveInner(e, i),
                o = null;
            for (let t = n instanceof y ? n : n.context.parent; t; t = t.parent)
                if (t.index < 0) {
                    let s = t.parent;
                    (o || (o = [n])).push(s.resolve(e, i)), (t = s);
                } else {
                    let s = l.get(t.tree);
                    if (s && s.overlay && s.overlay[0].from <= e && s.overlay[s.overlay.length - 1].to >= e) {
                        let r = new y(s.tree, s.overlay[0].from + t.from, -1, t);
                        (o || (o = [n])).push(b(r, e, i, !1));
                    }
                }
            return o ? S(o) : n;
        })(this, t, e);
    }
    iterate(t) {
        let { enter: e, leave: i, from: n = 0, to: o = this.length } = t,
            s = t.mode || 0,
            r = (s & u.IncludeAnonymous) > 0;
        for (let t = this.cursor(s | u.IncludeAnonymous); ;) {
            let s = !1;
            if (t.from <= o && t.to >= n && ((!r && t.type.isAnonymous) || !1 !== e(t))) {
                if (t.firstChild()) continue;
                s = !0;
            }
            for (; s && i && (r || !t.type.isAnonymous) && i(t), !t.nextSibling();) {
                if (!t.parent()) return;
                s = !0;
            }
        }
    }
    prop(t) {
        return t.perNode ? (this.props ? this.props[t.id] : void 0) : this.type.prop(t);
    }
    get propValues() {
        let t = [];
        if (this.props) for (let e in this.props) t.push([+e, this.props[e]]);
        return t;
    }
    balance(t = {}) {
        return this.children.length <= 8
            ? this
            : I(c.none, this.children, this.positions, 0, this.children.length, 0, this.length, (t, e, i) => new p(this.type, t, e, i, this.propValues), t.makeTree || ((t, e, i) => new p(c.none, t, e, i)));
    }
    static build(t) {
        return (function (t) {
            var e;
            let { buffer: i, nodeSet: o, maxBufferLength: s = n, reused: l = [], minRepeatType: a = o.types.length } = t,
                c = Array.isArray(i) ? new m(i, i.length) : i,
                h = o.types,
                d = 0,
                u = 0;
            function f(t, e, i, n, r, p) {
                let { id: m, start: x, end: k, size: S } = c,
                    T = u,
                    E = d;
                for (; S < 0;) {
                    if ((c.next(), -1 == S)) {
                        let e = l[m];
                        return i.push(e), void n.push(x - t);
                    }
                    if (-3 == S) return void (d = m);
                    if (-4 == S) return void (u = m);
                    throw new RangeError(`Unrecognized record size: ${S}`);
                }
                let M,
                    A,
                    D = h[m],
                    O = x - t;
                if (
                    k - x <= s &&
                    (A = (function (t, e) {
                        let i = c.fork(),
                            n = 0,
                            o = 0,
                            r = 0,
                            l = i.end - s,
                            h = { size: 0, start: 0, skip: 0 };
                        t: for (let s = i.pos - t; i.pos > s;) {
                            let t = i.size;
                            if (i.id == e && t >= 0) {
                                (h.size = n), (h.start = o), (h.skip = r), (r += 4), (n += 4), i.next();
                                continue;
                            }
                            let c = i.pos - t;
                            if (t < 0 || c < s || i.start < l) break;
                            let d = i.id >= a ? 4 : 0,
                                u = i.start;
                            for (i.next(); i.pos > c;) {
                                if (i.size < 0) {
                                    if (-3 != i.size) break t;
                                    d += 4;
                                } else i.id >= a && (d += 4);
                                i.next();
                            }
                            (o = u), (n += t), (r += d);
                        }
                        return (e < 0 || n == t) && ((h.size = n), (h.start = o), (h.skip = r)), h.size > 4 ? h : void 0;
                    })(c.pos - e, r))
                ) {
                    let e = new Uint16Array(A.size - A.skip),
                        i = c.pos - A.size,
                        n = e.length;
                    for (; c.pos > i;) n = C(A.start, e, n);
                    (M = new g(e, k - A.start, o)), (O = A.start - t);
                } else {
                    let t = c.pos - S;
                    c.next();
                    let e = [],
                        i = [],
                        n = m >= a ? m : -1,
                        o = 0,
                        r = k;
                    for (; c.pos > t;) n >= 0 && c.id == n && c.size >= 0 ? (c.end <= r - s && (y(e, i, x, o, c.end, r, n, T, E), (o = e.length), (r = c.end)), c.next()) : p > 2500 ? b(x, t, e, i) : f(x, t, e, i, n, p + 1);
                    if ((n >= 0 && o > 0 && o < e.length && y(e, i, x, o, x, r, n, T, E), e.reverse(), i.reverse(), n > -1 && o > 0)) {
                        let t = v(D, E);
                        M = I(D, e, i, 0, e.length, 0, k - x, t, t);
                    } else M = w(D, e, i, k - x, T - k, E);
                }
                i.push(M), n.push(O);
            }
            function b(t, e, i, n) {
                let r = [],
                    l = 0,
                    a = -1;
                for (; c.pos > e;) {
                    let { id: t, start: e, end: i, size: n } = c;
                    if (n > 4) c.next();
                    else {
                        if (a > -1 && e < a) break;
                        a < 0 && (a = i - s), r.push(t, e, i), l++, c.next();
                    }
                }
                if (l) {
                    let e = new Uint16Array(4 * l),
                        s = r[r.length - 2];
                    for (let t = r.length - 3, i = 0; t >= 0; t -= 3) (e[i++] = r[t]), (e[i++] = r[t + 1] - s), (e[i++] = r[t + 2] - s), (e[i++] = i);
                    i.push(new g(e, r[2] - s, o)), n.push(s - t);
                }
            }
            function v(t, e) {
                return (i, n, o) => {
                    let s,
                        l,
                        a = 0,
                        c = i.length - 1;
                    if (c >= 0 && (s = i[c]) instanceof p) {
                        if (!c && s.type == t && s.length == o) return s;
                        (l = s.prop(r.lookAhead)) && (a = n[c] + s.length + l);
                    }
                    return w(t, i, n, o, a, e);
                };
            }
            function y(t, e, i, n, s, r, l, a, c) {
                let h = [],
                    d = [];
                for (; t.length > n;) h.push(t.pop()), d.push(e.pop() + i - s);
                t.push(w(o.types[l], h, d, r - s, a - r, c)), e.push(s - i);
            }
            function w(t, e, i, n, o, s, l) {
                if (s) {
                    let t = [r.contextHash, s];
                    l = l ? [t].concat(l) : [t];
                }
                if (o > 25) {
                    let t = [r.lookAhead, o];
                    l = l ? [t].concat(l) : [t];
                }
                return new p(t, e, i, n, l);
            }
            function C(t, e, i) {
                let { id: n, start: o, end: s, size: r } = c;
                if ((c.next(), r >= 0 && n < a)) {
                    let l = i;
                    if (r > 4) {
                        let n = c.pos - (r - 4);
                        for (; c.pos > n;) i = C(t, e, i);
                    }
                    (e[--i] = l), (e[--i] = s - t), (e[--i] = o - t), (e[--i] = n);
                } else -3 == r ? (d = n) : -4 == r && (u = n);
                return i;
            }
            let x = [],
                k = [];
            for (; c.pos > 0;) f(t.start || 0, t.bufferStart || 0, x, k, -1, 0);
            let S = null !== (e = t.length) && void 0 !== e ? e : x.length ? k[0] + x[0].length : 0;
            return new p(h[t.topID], x.reverse(), k.reverse(), S);
        })(t);
    }
}
p.empty = new p(c.none, [], [], 0);
class m {
    constructor(t, e) {
        (this.buffer = t), (this.index = e);
    }
    get id() {
        return this.buffer[this.index - 4];
    }
    get start() {
        return this.buffer[this.index - 3];
    }
    get end() {
        return this.buffer[this.index - 2];
    }
    get size() {
        return this.buffer[this.index - 1];
    }
    get pos() {
        return this.index;
    }
    next() {
        this.index -= 4;
    }
    fork() {
        return new m(this.buffer, this.index);
    }
}
class g {
    constructor(t, e, i) {
        (this.buffer = t), (this.length = e), (this.set = i);
    }
    get type() {
        return c.none;
    }
    toString() {
        let t = [];
        for (let e = 0; e < this.buffer.length;) t.push(this.childString(e)), (e = this.buffer[e + 3]);
        return t.join(",");
    }
    childString(t) {
        let e = this.buffer[t],
            i = this.buffer[t + 3],
            n = this.set.types[e],
            o = n.name;
        if ((/\W/.test(o) && !n.isError && (o = JSON.stringify(o)), i == (t += 4))) return o;
        let s = [];
        for (; t < i;) s.push(this.childString(t)), (t = this.buffer[t + 3]);
        return o + "(" + s.join(",") + ")";
    }
    findChild(t, e, i, n, o) {
        let { buffer: s } = this,
            r = -1;
        for (let l = t; l != e && !(f(o, n, s[l + 1], s[l + 2]) && ((r = l), i > 0)); l = s[l + 3]);
        return r;
    }
    slice(t, e, i) {
        let n = this.buffer,
            o = new Uint16Array(e - t),
            s = 0;
        for (let r = t, l = 0; r < e;) {
            (o[l++] = n[r++]), (o[l++] = n[r++] - i);
            let e = (o[l++] = n[r++] - i);
            (o[l++] = n[r++] - t), (s = Math.max(s, e));
        }
        return new g(o, s, this.set);
    }
}
function f(t, e, i, n) {
    switch (t) {
        case -2:
            return i < e;
        case -1:
            return n >= e && i < e;
        case 0:
            return i < e && n > e;
        case 1:
            return i <= e && n > e;
        case 2:
            return n > e;
        case 4:
            return !0;
    }
}
function b(t, e, i, n) {
    for (var o; t.from == t.to || (i < 1 ? t.from >= e : t.from > e) || (i > -1 ? t.to <= e : t.to < e);) {
        let e = !n && t instanceof y && t.index < 0 ? null : t.parent;
        if (!e) return t;
        t = e;
    }
    let s = n ? 0 : u.IgnoreOverlays;
    if (n) for (let n = t, r = n.parent; r; n = r, r = n.parent) n instanceof y && n.index < 0 && (null === (o = r.enter(e, i, s)) || void 0 === o ? void 0 : o.from) != n.from && (t = r);
    for (; ;) {
        let n = t.enter(e, i, s);
        if (!n) return t;
        t = n;
    }
}
class v {
    cursor(t = 0) {
        return new E(this, t);
    }
    getChild(t, e = null, i = null) {
        let n = w(this, t, e, i);
        return n.length ? n[0] : null;
    }
    getChildren(t, e = null, i = null) {
        return w(this, t, e, i);
    }
    resolve(t, e = 0) {
        return b(this, t, e, !1);
    }
    resolveInner(t, e = 0) {
        return b(this, t, e, !0);
    }
    matchContext(t) {
        return x(this.parent, t);
    }
    enterUnfinishedNodesBefore(t) {
        let e = this.childBefore(t),
            i = this;
        for (; e;) {
            let t = e.lastChild;
            if (!t || t.to != e.to) break;
            t.type.isError && t.from == t.to ? ((i = e), (e = t.prevSibling)) : (e = t);
        }
        return i;
    }
    get node() {
        return this;
    }
    get next() {
        return this.parent;
    }
}
class y extends v {
    constructor(t, e, i, n) {
        super(), (this._tree = t), (this.from = e), (this.index = i), (this._parent = n);
    }
    get type() {
        return this._tree.type;
    }
    get name() {
        return this._tree.type.name;
    }
    get to() {
        return this.from + this._tree.length;
    }
    nextChild(t, e, i, n, o = 0) {
        for (let s = this; ;) {
            for (let { children: r, positions: a } = s._tree, c = e > 0 ? r.length : -1; t != c; t += e) {
                let c = r[t],
                    h = a[t] + s.from;
                if (f(n, i, h, h + c.length))
                    if (c instanceof g) {
                        if (o & u.ExcludeBuffers) continue;
                        let r = c.findChild(0, c.buffer.length, e, i - h, n);
                        if (r > -1) return new k(new C(s, c, t, h), null, r);
                    } else if (o & u.IncludeAnonymous || !c.type.isAnonymous || M(c)) {
                        let r;
                        if (!(o & u.IgnoreMounts) && (r = l.get(c)) && !r.overlay) return new y(r.tree, h, t, s);
                        let a = new y(c, h, t, s);
                        return o & u.IncludeAnonymous || !a.type.isAnonymous ? a : a.nextChild(e < 0 ? c.children.length - 1 : 0, e, i, n);
                    }
            }
            if (o & u.IncludeAnonymous || !s.type.isAnonymous) return null;
            if (((t = s.index >= 0 ? s.index + e : e < 0 ? -1 : s._parent._tree.children.length), (s = s._parent), !s)) return null;
        }
    }
    get firstChild() {
        return this.nextChild(0, 1, 0, 4);
    }
    get lastChild() {
        return this.nextChild(this._tree.children.length - 1, -1, 0, 4);
    }
    childAfter(t) {
        return this.nextChild(0, 1, t, 2);
    }
    childBefore(t) {
        return this.nextChild(this._tree.children.length - 1, -1, t, -2);
    }
    enter(t, e, i = 0) {
        let n;
        if (!(i & u.IgnoreOverlays) && (n = l.get(this._tree)) && n.overlay) {
            let i = t - this.from;
            for (let { from: t, to: o } of n.overlay) if ((e > 0 ? t <= i : t < i) && (e < 0 ? o >= i : o > i)) return new y(n.tree, n.overlay[0].from + this.from, -1, this);
        }
        return this.nextChild(0, 1, t, e, i);
    }
    nextSignificantParent() {
        let t = this;
        for (; t.type.isAnonymous && t._parent;) t = t._parent;
        return t;
    }
    get parent() {
        return this._parent ? this._parent.nextSignificantParent() : null;
    }
    get nextSibling() {
        return this._parent && this.index >= 0 ? this._parent.nextChild(this.index + 1, 1, 0, 4) : null;
    }
    get prevSibling() {
        return this._parent && this.index >= 0 ? this._parent.nextChild(this.index - 1, -1, 0, 4) : null;
    }
    get tree() {
        return this._tree;
    }
    toTree() {
        return this._tree;
    }
    toString() {
        return this._tree.toString();
    }
}
function w(t, e, i, n) {
    let o = t.cursor(),
        s = [];
    if (!o.firstChild()) return s;
    if (null != i) for (let t = !1; !t;) if (((t = o.type.is(i)), !o.nextSibling())) return s;
    for (; ;) {
        if (null != n && o.type.is(n)) return s;
        if ((o.type.is(e) && s.push(o.node), !o.nextSibling())) return null == n ? s : [];
    }
}
function x(t, e, i = e.length - 1) {
    for (let n = t; i >= 0; n = n.parent) {
        if (!n) return !1;
        if (!n.type.isAnonymous) {
            if (e[i] && e[i] != n.name) return !1;
            i--;
        }
    }
    return !0;
}
class C {
    constructor(t, e, i, n) {
        (this.parent = t), (this.buffer = e), (this.index = i), (this.start = n);
    }
}
class k extends v {
    get name() {
        return this.type.name;
    }
    get from() {
        return this.context.start + this.context.buffer.buffer[this.index + 1];
    }
    get to() {
        return this.context.start + this.context.buffer.buffer[this.index + 2];
    }
    constructor(t, e, i) {
        super(), (this.context = t), (this._parent = e), (this.index = i), (this.type = t.buffer.set.types[t.buffer.buffer[i]]);
    }
    child(t, e, i) {
        let { buffer: n } = this.context,
            o = n.findChild(this.index + 4, n.buffer[this.index + 3], t, e - this.context.start, i);
        return o < 0 ? null : new k(this.context, this, o);
    }
    get firstChild() {
        return this.child(1, 0, 4);
    }
    get lastChild() {
        return this.child(-1, 0, 4);
    }
    childAfter(t) {
        return this.child(1, t, 2);
    }
    childBefore(t) {
        return this.child(-1, t, -2);
    }
    enter(t, e, i = 0) {
        if (i & u.ExcludeBuffers) return null;
        let { buffer: n } = this.context,
            o = n.findChild(this.index + 4, n.buffer[this.index + 3], e > 0 ? 1 : -1, t - this.context.start, e);
        return o < 0 ? null : new k(this.context, this, o);
    }
    get parent() {
        return this._parent || this.context.parent.nextSignificantParent();
    }
    externalSibling(t) {
        return this._parent ? null : this.context.parent.nextChild(this.context.index + t, t, 0, 4);
    }
    get nextSibling() {
        let { buffer: t } = this.context,
            e = t.buffer[this.index + 3];
        return e < (this._parent ? t.buffer[this._parent.index + 3] : t.buffer.length) ? new k(this.context, this._parent, e) : this.externalSibling(1);
    }
    get prevSibling() {
        let { buffer: t } = this.context,
            e = this._parent ? this._parent.index + 4 : 0;
        return this.index == e ? this.externalSibling(-1) : new k(this.context, this._parent, t.findChild(e, this.index, -1, 0, 4));
    }
    get tree() {
        return null;
    }
    toTree() {
        let t = [],
            e = [],
            { buffer: i } = this.context,
            n = this.index + 4,
            o = i.buffer[this.index + 3];
        if (o > n) {
            let s = i.buffer[this.index + 1];
            t.push(i.slice(n, o, s)), e.push(0);
        }
        return new p(this.type, t, e, this.to - this.from);
    }
    toString() {
        return this.context.buffer.childString(this.index);
    }
}
function S(t) {
    if (!t.length) return null;
    let e = 0,
        i = t[0];
    for (let n = 1; n < t.length; n++) {
        let o = t[n];
        (o.from > i.from || o.to < i.to) && ((i = o), (e = n));
    }
    let n = i instanceof y && i.index < 0 ? null : i.parent,
        o = t.slice();
    return n ? (o[e] = n) : o.splice(e, 1), new T(o, i);
}
class T {
    constructor(t, e) {
        (this.heads = t), (this.node = e);
    }
    get next() {
        return S(this.heads);
    }
}
class E {
    get name() {
        return this.type.name;
    }
    constructor(t, e = 0) {
        if (((this.mode = e), (this.buffer = null), (this.stack = []), (this.index = 0), (this.bufferNode = null), t instanceof y)) this.yieldNode(t);
        else {
            (this._tree = t.context.parent), (this.buffer = t.context);
            for (let e = t._parent; e; e = e._parent) this.stack.unshift(e.index);
            (this.bufferNode = t), this.yieldBuf(t.index);
        }
    }
    yieldNode(t) {
        return !!t && ((this._tree = t), (this.type = t.type), (this.from = t.from), (this.to = t.to), !0);
    }
    yieldBuf(t, e) {
        this.index = t;
        let { start: i, buffer: n } = this.buffer;
        return (this.type = e || n.set.types[n.buffer[t]]), (this.from = i + n.buffer[t + 1]), (this.to = i + n.buffer[t + 2]), !0;
    }
    yield(t) {
        return !!t && (t instanceof y ? ((this.buffer = null), this.yieldNode(t)) : ((this.buffer = t.context), this.yieldBuf(t.index, t.type)));
    }
    toString() {
        return this.buffer ? this.buffer.buffer.childString(this.index) : this._tree.toString();
    }
    enterChild(t, e, i) {
        if (!this.buffer) return this.yield(this._tree.nextChild(t < 0 ? this._tree._tree.children.length - 1 : 0, t, e, i, this.mode));
        let { buffer: n } = this.buffer,
            o = n.findChild(this.index + 4, n.buffer[this.index + 3], t, e - this.buffer.start, i);
        return !(o < 0) && (this.stack.push(this.index), this.yieldBuf(o));
    }
    firstChild() {
        return this.enterChild(1, 0, 4);
    }
    lastChild() {
        return this.enterChild(-1, 0, 4);
    }
    childAfter(t) {
        return this.enterChild(1, t, 2);
    }
    childBefore(t) {
        return this.enterChild(-1, t, -2);
    }
    enter(t, e, i = this.mode) {
        return this.buffer ? !(i & u.ExcludeBuffers) && this.enterChild(1, t, e) : this.yield(this._tree.enter(t, e, i));
    }
    parent() {
        if (!this.buffer) return this.yieldNode(this.mode & u.IncludeAnonymous ? this._tree._parent : this._tree.parent);
        if (this.stack.length) return this.yieldBuf(this.stack.pop());
        let t = this.mode & u.IncludeAnonymous ? this.buffer.parent : this.buffer.parent.nextSignificantParent();
        return (this.buffer = null), this.yieldNode(t);
    }
    sibling(t) {
        if (!this.buffer) return !!this._tree._parent && this.yield(this._tree.index < 0 ? null : this._tree._parent.nextChild(this._tree.index + t, t, 0, 4, this.mode));
        let { buffer: e } = this.buffer,
            i = this.stack.length - 1;
        if (t < 0) {
            let t = i < 0 ? 0 : this.stack[i] + 4;
            if (this.index != t) return this.yieldBuf(e.findChild(t, this.index, -1, 0, 4));
        } else {
            let t = e.buffer[this.index + 3];
            if (t < (i < 0 ? e.buffer.length : e.buffer[this.stack[i] + 3])) return this.yieldBuf(t);
        }
        return i < 0 && this.yield(this.buffer.parent.nextChild(this.buffer.index + t, t, 0, 4, this.mode));
    }
    nextSibling() {
        return this.sibling(1);
    }
    prevSibling() {
        return this.sibling(-1);
    }
    atLastNode(t) {
        let e,
            i,
            { buffer: n } = this;
        if (n) {
            if (t > 0) {
                if (this.index < n.buffer.buffer.length) return !1;
            } else for (let t = 0; t < this.index; t++) if (n.buffer.buffer[t + 3] < this.index) return !1;
            ({ index: e, parent: i } = n);
        } else ({ index: e, _parent: i } = this._tree);
        for (; i; { index: e, _parent: i } = i)
            if (e > -1)
                for (let n = e + t, o = t < 0 ? -1 : i._tree.children.length; n != o; n += t) {
                    let t = i._tree.children[n];
                    if (this.mode & u.IncludeAnonymous || t instanceof g || !t.type.isAnonymous || M(t)) return !1;
                }
        return !0;
    }
    move(t, e) {
        if (e && this.enterChild(t, 0, 4)) return !0;
        for (; ;) {
            if (this.sibling(t)) return !0;
            if (this.atLastNode(t) || !this.parent()) return !1;
        }
    }
    next(t = !0) {
        return this.move(1, t);
    }
    prev(t = !0) {
        return this.move(-1, t);
    }
    moveTo(t, e = 0) {
        for (; (this.from == this.to || (e < 1 ? this.from >= t : this.from > t) || (e > -1 ? this.to <= t : this.to < t)) && this.parent(););
        for (; this.enterChild(1, t, e););
        return this;
    }
    get node() {
        if (!this.buffer) return this._tree;
        let t = this.bufferNode,
            e = null,
            i = 0;
        if (t && t.context == this.buffer)
            t: for (let n = this.index, o = this.stack.length; o >= 0;) {
                for (let s = t; s; s = s._parent)
                    if (s.index == n) {
                        if (n == this.index) return s;
                        (e = s), (i = o + 1);
                        break t;
                    }
                n = this.stack[--o];
            }
        for (let t = i; t < this.stack.length; t++) e = new k(this.buffer, e, this.stack[t]);
        return (this.bufferNode = new k(this.buffer, e, this.index));
    }
    get tree() {
        return this.buffer ? null : this._tree._tree;
    }
    iterate(t, e) {
        for (let i = 0; ;) {
            let n = !1;
            if (this.type.isAnonymous || !1 !== t(this)) {
                if (this.firstChild()) {
                    i++;
                    continue;
                }
                this.type.isAnonymous || (n = !0);
            }
            for (; ;) {
                if ((n && e && e(this), (n = this.type.isAnonymous), !i)) return;
                if (this.nextSibling()) break;
                this.parent(), i--, (n = !0);
            }
        }
    }
    matchContext(t) {
        if (!this.buffer) return x(this.node.parent, t);
        let { buffer: e } = this.buffer,
            { types: i } = e.set;
        for (let n = t.length - 1, o = this.stack.length - 1; n >= 0; o--) {
            if (o < 0) return x(this._tree, t, n);
            let s = i[e.buffer[this.stack[o]]];
            if (!s.isAnonymous) {
                if (t[n] && t[n] != s.name) return !1;
                n--;
            }
        }
        return !0;
    }
}
function M(t) {
    return t.children.some((t) => t instanceof g || !t.type.isAnonymous || M(t));
}
const A = new WeakMap();
function D(t, e) {
    if (!t.isAnonymous || e instanceof g || e.type != t) return 1;
    let i = A.get(e);
    if (null == i) {
        i = 1;
        for (let n of e.children) {
            if (n.type != t || !(n instanceof p)) {
                i = 1;
                break;
            }
            i += D(t, n);
        }
        A.set(e, i);
    }
    return i;
}
function I(t, e, i, n, o, s, r, l, a) {
    let c = 0;
    for (let i = n; i < o; i++) c += D(t, e[i]);
    let h = Math.ceil((1.5 * c) / 8),
        d = [],
        u = [];
    return (
        (function e(i, n, o, r, l) {
            for (let c = o; c < r;) {
                let o = c,
                    p = n[c],
                    m = D(t, i[c]);
                for (c++; c < r; c++) {
                    let e = D(t, i[c]);
                    if (m + e >= h) break;
                    m += e;
                }
                if (c == o + 1) {
                    if (m > h) {
                        let t = i[o];
                        e(t.children, t.positions, 0, t.children.length, n[o] + l);
                        continue;
                    }
                    d.push(i[o]);
                } else {
                    let e = n[c - 1] + i[c - 1].length - p;
                    d.push(I(t, i, n, o, c, p, e, null, a));
                }
                u.push(p + l - s);
            }
        })(e, i, n, o, 0),
        (l || a)(d, u, r)
    );
}
class O {
    constructor(t, e, i, n, o = !1, s = !1) {
        (this.from = t), (this.to = e), (this.tree = i), (this.offset = n), (this.open = (o ? 1 : 0) | (s ? 2 : 0));
    }
    get openStart() {
        return (1 & this.open) > 0;
    }
    get openEnd() {
        return (2 & this.open) > 0;
    }
    static addTree(t, e = [], i = !1) {
        let n = [new O(0, t.length, t, 0, !1, i)];
        for (let i of e) i.to > t.length && n.push(i);
        return n;
    }
    static applyChanges(t, e, i = 128) {
        if (!e.length) return t;
        let n = [],
            o = 1,
            s = t.length ? t[0] : null;
        for (let r = 0, l = 0, a = 0; ; r++) {
            let c = r < e.length ? e[r] : null,
                h = c ? c.fromA : 1e9;
            if (h - l >= i)
                for (; s && s.from < h;) {
                    let e = s;
                    if (l >= e.from || h <= e.to || a) {
                        let t = Math.max(e.from, l) - a,
                            i = Math.min(e.to, h) - a;
                        e = t >= i ? null : new O(t, i, e.tree, e.offset + a, r > 0, !!c);
                    }
                    if ((e && n.push(e), s.to > h)) break;
                    s = o < t.length ? t[o++] : null;
                }
            if (!c) break;
            (l = c.toA), (a = c.toA - c.toB);
        }
        return n;
    }
}
class B {
    startParse(t, e, i) {
        return "string" == typeof t && (t = new q(t)), (i = i ? (i.length ? i.map((t) => new s(t.from, t.to)) : [new s(0, 0)]) : [new s(0, t.length)]), this.createParse(t, e || [], i);
    }
    parse(t, e, i) {
        let n = this.startParse(t, e, i);
        for (; ;) {
            let t = n.advance();
            if (t) return t;
        }
    }
}
class q {
    constructor(t) {
        this.string = t;
    }
    get length() {
        return this.string.length;
    }
    chunk(t) {
        return this.string.slice(t);
    }
    get lineChunks() {
        return !1;
    }
    read(t, e) {
        return this.string.slice(t, e);
    }
}
new r({ perNode: !0 });
let N = [],
    L = [];
function R(t) {
    if (t < 768) return !1;
    for (let e = 0, i = N.length; ;) {
        let n = (e + i) >> 1;
        if (t < N[n]) i = n;
        else {
            if (!(t >= L[n])) return !0;
            e = n + 1;
        }
        if (e == i) return !1;
    }
}
function P(t) {
    return t >= 127462 && t <= 127487;
}
function _(t, e, i = !0, n = !0) {
    return (i ? F : V)(t, e, n);
}
function F(t, e, i) {
    if (e == t.length) return e;
    e && z(t.charCodeAt(e)) && $(t.charCodeAt(e - 1)) && e--;
    let n = H(t, e);
    for (e += W(n); e < t.length;) {
        let o = H(t, e);
        if (8205 == n || 8205 == o || (i && R(o))) (e += W(o)), (n = o);
        else {
            if (!P(o)) break;
            {
                let i = 0,
                    n = e - 2;
                for (; n >= 0 && P(H(t, n));) i++, (n -= 2);
                if (i % 2 == 0) break;
                e += 2;
            }
        }
    }
    return e;
}
function V(t, e, i) {
    for (; e > 0;) {
        let n = F(t, e - 2, i);
        if (n < e) return n;
        e--;
    }
    return 0;
}
function H(t, e) {
    let i = t.charCodeAt(e);
    if (!$(i) || e + 1 == t.length) return i;
    let n = t.charCodeAt(e + 1);
    return z(n) ? n - 56320 + ((i - 55296) << 10) + 65536 : i;
}
function z(t) {
    return t >= 56320 && t < 57344;
}
function $(t) {
    return t >= 55296 && t < 56320;
}
function W(t) {
    return t < 65536 ? 1 : 2;
}
(() => {
    let t = "lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,3b,f,,w,1j,,,,4,8,4,,3,7,a,2,t,,1m,,,,2,4,8,,9,,a,2,q,,2,2,1l,,4,2,4,2,2,3,3,,u,2,3,,b,2,1l,,4,5,,2,4,,k,2,m,6,,,1m,,,2,,4,8,,7,3,a,2,u,,1n,,,,c,,9,,14,,3,,1l,3,5,3,,4,7,2,b,2,t,,1m,,2,,2,,3,,5,2,7,2,b,2,s,2,1l,2,,,2,4,8,,9,,a,2,t,,20,,4,,2,3,,,8,,29,,2,7,c,8,2q,,2,9,b,6,22,2,r,,,,,,1j,e,,5,,2,5,b,,10,9,,2u,4,,6,,2,2,2,p,2,4,3,g,4,d,,2,2,6,,f,,jj,3,qa,3,t,3,t,2,u,2,1s,2,,7,8,,2,b,9,,19,3,3b,2,y,,3a,3,4,2,9,,6,3,63,2,2,,1m,,,7,,,,,2,8,6,a,2,,1c,h,1r,4,1c,7,,,5,,14,9,c,2,w,4,2,2,,3,1k,,,2,3,,,3,1m,8,2,2,48,3,,d,,7,4,,6,,3,2,5i,1m,,5,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,p,2,5,,47,2,q,i,d,,12,8,p,b,1a,3,1c,,2,4,2,2,13,,1v,6,2,2,2,2,c,,8,,1b,,1f,,,3,2,2,5,2,,,16,2,8,,6m,,2,,4,,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,ar,2,49,b,4w,,1i,f,1k,3,1d,4,2,2,1x,3,10,5,,8,1q,,c,2,1g,9,a,4,2,,2n,3,2,,,2,6,,4g,,3,8,l,2,1l,2,,,,,m,,e,7,3,5,5f,8,2,3,,,n,,29,,2,6,,,2,,,2,,2,6j,,2,4,6,2,,2,r,2,2d,8,2,,,2,2y,,,,2,6,,,2t,3,2,4,,5,77,9,,2,6t,,a,2,,,4,,40,4,2,2,4,,w,a,14,6,2,4,8,,9,6,2,3,1a,d,,2,ba,7,,6,,,2a,m,2,7,,2,,2,3e,6,3,,,2,,7,,,20,2,3,,,,9n,2,f0b,5,1n,7,t4,,1r,4,29,,f5k,2,43q,,,3,4,5,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,79,7,c5,4,15s,7,31,7,240,5,gx7k,2o,3k,6o"
        .split(",")
        .map((t) => (t ? parseInt(t, 36) : 1));
    for (let e = 0, i = 0; e < t.length; e++) (e % 2 ? L : N).push((i += t[e]));
})();
class U {
    lineAt(t) {
        if (t < 0 || t > this.length) throw new RangeError(`Invalid position ${t} in document of length ${this.length}`);
        return this.lineInner(t, !1, 1, 0);
    }
    line(t) {
        if (t < 1 || t > this.lines) throw new RangeError(`Invalid line number ${t} in ${this.lines}-line document`);
        return this.lineInner(t, !0, 1, 0);
    }
    replace(t, e, i) {
        [t, e] = tt(this, t, e);
        let n = [];
        return this.decompose(0, t, n, 2), i.length && i.decompose(0, i.length, n, 3), this.decompose(e, this.length, n, 1), Y.from(n, this.length - (e - t) + i.length);
    }
    append(t) {
        return this.replace(this.length, this.length, t);
    }
    slice(t, e = this.length) {
        [t, e] = tt(this, t, e);
        let i = [];
        return this.decompose(t, e, i, 0), Y.from(i, e - t);
    }
    eq(t) {
        if (t == this) return !0;
        if (t.length != this.length || t.lines != this.lines) return !1;
        let e = this.scanIdentical(t, 1),
            i = this.length - this.scanIdentical(t, -1),
            n = new K(this),
            o = new K(t);
        for (let t = e, s = e; ;) {
            if ((n.next(t), o.next(t), (t = 0), n.lineBreak != o.lineBreak || n.done != o.done || n.value != o.value)) return !1;
            if (((s += n.value.length), n.done || s >= i)) return !0;
        }
    }
    iter(t = 1) {
        return new K(this, t);
    }
    iterRange(t, e = this.length) {
        return new X(this, t, e);
    }
    iterLines(t, e) {
        let i;
        if (null == t) i = this.iter();
        else {
            null == e && (e = this.lines + 1);
            let n = this.line(t).from;
            i = this.iterRange(n, Math.max(n, e == this.lines + 1 ? this.length : e <= 1 ? 0 : this.line(e - 1).to));
        }
        return new J(i);
    }
    toString() {
        return this.sliceString(0);
    }
    toJSON() {
        let t = [];
        return this.flatten(t), t;
    }
    constructor() { }
    static of(t) {
        if (0 == t.length) throw new RangeError("A document must have at least one line");
        return 1 != t.length || t[0] ? (t.length <= 32 ? new j(t) : Y.from(j.split(t, []))) : U.empty;
    }
}
class j extends U {
    constructor(
        t,
        e = (function (t) {
            let e = -1;
            for (let i of t) e += i.length + 1;
            return e;
        })(t)
    ) {
        super(), (this.text = t), (this.length = e);
    }
    get lines() {
        return this.text.length;
    }
    get children() {
        return null;
    }
    lineInner(t, e, i, n) {
        for (let o = 0; ; o++) {
            let s = this.text[o],
                r = n + s.length;
            if ((e ? i : r) >= t) return new Q(n, r, i, s);
            (n = r + 1), i++;
        }
    }
    decompose(t, e, i, n) {
        let o = t <= 0 && e >= this.length ? this : new j(Z(this.text, t, e), Math.min(e, this.length) - Math.max(0, t));
        if (1 & n) {
            let t = i.pop(),
                e = G(o.text, t.text.slice(), 0, o.length);
            if (e.length <= 32) i.push(new j(e, t.length + o.length));
            else {
                let t = e.length >> 1;
                i.push(new j(e.slice(0, t)), new j(e.slice(t)));
            }
        } else i.push(o);
    }
    replace(t, e, i) {
        if (!(i instanceof j)) return super.replace(t, e, i);
        [t, e] = tt(this, t, e);
        let n = G(this.text, G(i.text, Z(this.text, 0, t)), e),
            o = this.length + i.length - (e - t);
        return n.length <= 32 ? new j(n, o) : Y.from(j.split(n, []), o);
    }
    sliceString(t, e = this.length, i = "\n") {
        [t, e] = tt(this, t, e);
        let n = "";
        for (let o = 0, s = 0; o <= e && s < this.text.length; s++) {
            let r = this.text[s],
                l = o + r.length;
            o > t && s && (n += i), t < l && e > o && (n += r.slice(Math.max(0, t - o), e - o)), (o = l + 1);
        }
        return n;
    }
    flatten(t) {
        for (let e of this.text) t.push(e);
    }
    scanIdentical() {
        return 0;
    }
    static split(t, e) {
        let i = [],
            n = -1;
        for (let o of t) i.push(o), (n += o.length + 1), 32 == i.length && (e.push(new j(i, n)), (i = []), (n = -1));
        return n > -1 && e.push(new j(i, n)), e;
    }
}
class Y extends U {
    constructor(t, e) {
        super(), (this.children = t), (this.length = e), (this.lines = 0);
        for (let e of t) this.lines += e.lines;
    }
    lineInner(t, e, i, n) {
        for (let o = 0; ; o++) {
            let s = this.children[o],
                r = n + s.length,
                l = i + s.lines - 1;
            if ((e ? l : r) >= t) return s.lineInner(t, e, i, n);
            (n = r + 1), (i = l + 1);
        }
    }
    decompose(t, e, i, n) {
        for (let o = 0, s = 0; s <= e && o < this.children.length; o++) {
            let r = this.children[o],
                l = s + r.length;
            if (t <= l && e >= s) {
                let o = n & ((s <= t ? 1 : 0) | (l >= e ? 2 : 0));
                s >= t && l <= e && !o ? i.push(r) : r.decompose(t - s, e - s, i, o);
            }
            s = l + 1;
        }
    }
    replace(t, e, i) {
        if ((([t, e] = tt(this, t, e)), i.lines < this.lines))
            for (let n = 0, o = 0; n < this.children.length; n++) {
                let s = this.children[n],
                    r = o + s.length;
                if (t >= o && e <= r) {
                    let l = s.replace(t - o, e - o, i),
                        a = this.lines - s.lines + l.lines;
                    if (l.lines < a >> 4 && l.lines > a >> 6) {
                        let o = this.children.slice();
                        return (o[n] = l), new Y(o, this.length - (e - t) + i.length);
                    }
                    return super.replace(o, r, l);
                }
                o = r + 1;
            }
        return super.replace(t, e, i);
    }
    sliceString(t, e = this.length, i = "\n") {
        [t, e] = tt(this, t, e);
        let n = "";
        for (let o = 0, s = 0; o < this.children.length && s <= e; o++) {
            let r = this.children[o],
                l = s + r.length;
            s > t && o && (n += i), t < l && e > s && (n += r.sliceString(t - s, e - s, i)), (s = l + 1);
        }
        return n;
    }
    flatten(t) {
        for (let e of this.children) e.flatten(t);
    }
    scanIdentical(t, e) {
        if (!(t instanceof Y)) return 0;
        let i = 0,
            [n, o, s, r] = e > 0 ? [0, 0, this.children.length, t.children.length] : [this.children.length - 1, t.children.length - 1, -1, -1];
        for (; ; n += e, o += e) {
            if (n == s || o == r) return i;
            let l = this.children[n],
                a = t.children[o];
            if (l != a) return i + l.scanIdentical(a, e);
            i += l.length + 1;
        }
    }
    static from(t, e = t.reduce((t, e) => t + e.length + 1, -1)) {
        let i = 0;
        for (let e of t) i += e.lines;
        if (i < 32) {
            let i = [];
            for (let e of t) e.flatten(i);
            return new j(i, e);
        }
        let n = Math.max(32, i >> 5),
            o = n << 1,
            s = n >> 1,
            r = [],
            l = 0,
            a = -1,
            c = [];
        function h(t) {
            let e;
            if (t.lines > o && t instanceof Y) for (let e of t.children) h(e);
            else
                t.lines > s && (l > s || !l)
                    ? (d(), r.push(t))
                    : t instanceof j && l && (e = c[c.length - 1]) instanceof j && t.lines + e.lines <= 32
                        ? ((l += t.lines), (a += t.length + 1), (c[c.length - 1] = new j(e.text.concat(t.text), e.length + 1 + t.length)))
                        : (l + t.lines > n && d(), (l += t.lines), (a += t.length + 1), c.push(t));
        }
        function d() {
            0 != l && (r.push(1 == c.length ? c[0] : Y.from(c, a)), (a = -1), (l = c.length = 0));
        }
        for (let e of t) h(e);
        return d(), 1 == r.length ? r[0] : new Y(r, e);
    }
}
function G(t, e, i = 0, n = 1e9) {
    for (let o = 0, s = 0, r = !0; s < t.length && o <= n; s++) {
        let l = t[s],
            a = o + l.length;
        a >= i && (a > n && (l = l.slice(0, n - o)), o < i && (l = l.slice(i - o)), r ? ((e[e.length - 1] += l), (r = !1)) : e.push(l)), (o = a + 1);
    }
    return e;
}
function Z(t, e, i) {
    return G(t, [""], e, i);
}
U.empty = new j([""], 0);
class K {
    constructor(t, e = 1) {
        (this.dir = e), (this.done = !1), (this.lineBreak = !1), (this.value = ""), (this.nodes = [t]), (this.offsets = [e > 0 ? 1 : (t instanceof j ? t.text.length : t.children.length) << 1]);
    }
    nextInner(t, e) {
        for (this.done = this.lineBreak = !1; ;) {
            let i = this.nodes.length - 1,
                n = this.nodes[i],
                o = this.offsets[i],
                s = o >> 1,
                r = n instanceof j ? n.text.length : n.children.length;
            if (s == (e > 0 ? r : 0)) {
                if (0 == i) return (this.done = !0), (this.value = ""), this;
                e > 0 && this.offsets[i - 1]++, this.nodes.pop(), this.offsets.pop();
            } else if ((1 & o) == (e > 0 ? 0 : 1)) {
                if (((this.offsets[i] += e), 0 == t)) return (this.lineBreak = !0), (this.value = "\n"), this;
                t--;
            } else if (n instanceof j) {
                let o = n.text[s + (e < 0 ? -1 : 0)];
                if (((this.offsets[i] += e), o.length > Math.max(0, t))) return (this.value = 0 == t ? o : e > 0 ? o.slice(t) : o.slice(0, o.length - t)), this;
                t -= o.length;
            } else {
                let o = n.children[s + (e < 0 ? -1 : 0)];
                t > o.length ? ((t -= o.length), (this.offsets[i] += e)) : (e < 0 && this.offsets[i]--, this.nodes.push(o), this.offsets.push(e > 0 ? 1 : (o instanceof j ? o.text.length : o.children.length) << 1));
            }
        }
    }
    next(t = 0) {
        return t < 0 && (this.nextInner(-t, -this.dir), (t = this.value.length)), this.nextInner(t, this.dir);
    }
}
class X {
    constructor(t, e, i) {
        (this.value = ""), (this.done = !1), (this.cursor = new K(t, e > i ? -1 : 1)), (this.pos = e > i ? t.length : 0), (this.from = Math.min(e, i)), (this.to = Math.max(e, i));
    }
    nextInner(t, e) {
        if (e < 0 ? this.pos <= this.from : this.pos >= this.to) return (this.value = ""), (this.done = !0), this;
        t += Math.max(0, e < 0 ? this.pos - this.to : this.from - this.pos);
        let i = e < 0 ? this.pos - this.from : this.to - this.pos;
        t > i && (t = i), (i -= t);
        let { value: n } = this.cursor.next(t);
        return (this.pos += (n.length + t) * e), (this.value = n.length <= i ? n : e < 0 ? n.slice(n.length - i) : n.slice(0, i)), (this.done = !this.value), this;
    }
    next(t = 0) {
        return t < 0 ? (t = Math.max(t, this.from - this.pos)) : t > 0 && (t = Math.min(t, this.to - this.pos)), this.nextInner(t, this.cursor.dir);
    }
    get lineBreak() {
        return this.cursor.lineBreak && "" != this.value;
    }
}
class J {
    constructor(t) {
        (this.inner = t), (this.afterBreak = !0), (this.value = ""), (this.done = !1);
    }
    next(t = 0) {
        let { done: e, lineBreak: i, value: n } = this.inner.next(t);
        return (
            e && this.afterBreak
                ? ((this.value = ""), (this.afterBreak = !1))
                : e
                    ? ((this.done = !0), (this.value = ""))
                    : i
                        ? this.afterBreak
                            ? (this.value = "")
                            : ((this.afterBreak = !0), this.next())
                        : ((this.value = n), (this.afterBreak = !1)),
            this
        );
    }
    get lineBreak() {
        return !1;
    }
}
"undefined" != typeof Symbol &&
    ((U.prototype[Symbol.iterator] = function () {
        return this.iter();
    }),
        (K.prototype[Symbol.iterator] = X.prototype[Symbol.iterator] = J.prototype[Symbol.iterator] = function () {
            return this;
        }));
class Q {
    constructor(t, e, i, n) {
        (this.from = t), (this.to = e), (this.number = i), (this.text = n);
    }
    get length() {
        return this.to - this.from;
    }
}
function tt(t, e, i) {
    return [(e = Math.max(0, Math.min(t.length, e))), Math.max(e, Math.min(t.length, i))];
}
function et(t, e, i = !0, n = !0) {
    return _(t, e, i, n);
}
const it = /\r\n?|\n/;
var nt = (function (t) {
    return (t[(t.Simple = 0)] = "Simple"), (t[(t.TrackDel = 1)] = "TrackDel"), (t[(t.TrackBefore = 2)] = "TrackBefore"), (t[(t.TrackAfter = 3)] = "TrackAfter"), t;
})(nt || (nt = {}));
class ot {
    constructor(t) {
        this.sections = t;
    }
    get length() {
        let t = 0;
        for (let e = 0; e < this.sections.length; e += 2) t += this.sections[e];
        return t;
    }
    get newLength() {
        let t = 0;
        for (let e = 0; e < this.sections.length; e += 2) {
            let i = this.sections[e + 1];
            t += i < 0 ? this.sections[e] : i;
        }
        return t;
    }
    get empty() {
        return 0 == this.sections.length || (2 == this.sections.length && this.sections[1] < 0);
    }
    iterGaps(t) {
        for (let e = 0, i = 0, n = 0; e < this.sections.length;) {
            let o = this.sections[e++],
                s = this.sections[e++];
            s < 0 ? (t(i, n, o), (n += o)) : (n += s), (i += o);
        }
    }
    iterChangedRanges(t, e = !1) {
        at(this, t, e);
    }
    get invertedDesc() {
        let t = [];
        for (let e = 0; e < this.sections.length;) {
            let i = this.sections[e++],
                n = this.sections[e++];
            n < 0 ? t.push(i, n) : t.push(n, i);
        }
        return new ot(t);
    }
    composeDesc(t) {
        return this.empty ? t : t.empty ? this : ht(this, t);
    }
    mapDesc(t, e = !1) {
        return t.empty ? this : ct(this, t, e);
    }
    mapPos(t, e = -1, i = nt.Simple) {
        let n = 0,
            o = 0;
        for (let s = 0; s < this.sections.length;) {
            let r = this.sections[s++],
                l = this.sections[s++],
                a = n + r;
            if (l < 0) {
                if (a > t) return o + (t - n);
                o += r;
            } else {
                if (i != nt.Simple && a >= t && ((i == nt.TrackDel && n < t && a > t) || (i == nt.TrackBefore && n < t) || (i == nt.TrackAfter && a > t))) return null;
                if (a > t || (a == t && e < 0 && !r)) return t == n || e < 0 ? o : o + l;
                o += l;
            }
            n = a;
        }
        if (t > n) throw new RangeError(`Position ${t} is out of range for changeset of length ${n}`);
        return o;
    }
    touchesRange(t, e = t) {
        for (let i = 0, n = 0; i < this.sections.length && n <= e;) {
            let o = n + this.sections[i++];
            if (this.sections[i++] >= 0 && n <= e && o >= t) return !(n < t && o > e) || "cover";
            n = o;
        }
        return !1;
    }
    toString() {
        let t = "";
        for (let e = 0; e < this.sections.length;) {
            let i = this.sections[e++],
                n = this.sections[e++];
            t += (t ? " " : "") + i + (n >= 0 ? ":" + n : "");
        }
        return t;
    }
    toJSON() {
        return this.sections;
    }
    static fromJSON(t) {
        if (!Array.isArray(t) || t.length % 2 || t.some((t) => "number" != typeof t)) throw new RangeError("Invalid JSON representation of ChangeDesc");
        return new ot(t);
    }
    static create(t) {
        return new ot(t);
    }
}
class st extends ot {
    constructor(t, e) {
        super(t), (this.inserted = e);
    }
    apply(t) {
        if (this.length != t.length) throw new RangeError("Applying change set to a document with the wrong length");
        return at(this, (e, i, n, o, s) => (t = t.replace(n, n + (i - e), s)), !1), t;
    }
    mapDesc(t, e = !1) {
        return ct(this, t, e, !0);
    }
    invert(t) {
        let e = this.sections.slice(),
            i = [];
        for (let n = 0, o = 0; n < e.length; n += 2) {
            let s = e[n],
                r = e[n + 1];
            if (r >= 0) {
                (e[n] = r), (e[n + 1] = s);
                let l = n >> 1;
                for (; i.length < l;) i.push(U.empty);
                i.push(s ? t.slice(o, o + s) : U.empty);
            }
            o += s;
        }
        return new st(e, i);
    }
    compose(t) {
        return this.empty ? t : t.empty ? this : ht(this, t, !0);
    }
    map(t, e = !1) {
        return t.empty ? this : ct(this, t, e, !0);
    }
    iterChanges(t, e = !1) {
        at(this, t, e);
    }
    get desc() {
        return ot.create(this.sections);
    }
    filter(t) {
        let e = [],
            i = [],
            n = [],
            o = new dt(this);
        t: for (let s = 0, r = 0; ;) {
            let l = s == t.length ? 1e9 : t[s++];
            for (; r < l || (r == l && 0 == o.len);) {
                if (o.done) break t;
                let t = Math.min(o.len, l - r);
                rt(n, t, -1);
                let s = -1 == o.ins ? -1 : 0 == o.off ? o.ins : 0;
                rt(e, t, s), s > 0 && lt(i, e, o.text), o.forward(t), (r += t);
            }
            let a = t[s++];
            for (; r < a;) {
                if (o.done) break t;
                let t = Math.min(o.len, a - r);
                rt(e, t, -1), rt(n, t, -1 == o.ins ? -1 : 0 == o.off ? o.ins : 0), o.forward(t), (r += t);
            }
        }
        return { changes: new st(e, i), filtered: ot.create(n) };
    }
    toJSON() {
        let t = [];
        for (let e = 0; e < this.sections.length; e += 2) {
            let i = this.sections[e],
                n = this.sections[e + 1];
            n < 0 ? t.push(i) : 0 == n ? t.push([i]) : t.push([i].concat(this.inserted[e >> 1].toJSON()));
        }
        return t;
    }
    static of(t, e, i) {
        let n = [],
            o = [],
            s = 0,
            r = null;
        function l(t = !1) {
            if (!t && !n.length) return;
            s < e && rt(n, e - s, -1);
            let i = new st(n, o);
            (r = r ? r.compose(i.map(r)) : i), (n = []), (o = []), (s = 0);
        }
        return (
            (function t(a) {
                if (Array.isArray(a)) for (let e of a) t(e);
                else if (a instanceof st) {
                    if (a.length != e) throw new RangeError(`Mismatched change set length (got ${a.length}, expected ${e})`);
                    l(), (r = r ? r.compose(a.map(r)) : a);
                } else {
                    let { from: t, to: r = t, insert: c } = a;
                    if (t > r || t < 0 || r > e) throw new RangeError(`Invalid change range ${t} to ${r} (in doc of length ${e})`);
                    let h = c ? ("string" == typeof c ? U.of(c.split(i || it)) : c) : U.empty,
                        d = h.length;
                    if (t == r && 0 == d) return;
                    t < s && l(), t > s && rt(n, t - s, -1), rt(n, r - t, d), lt(o, n, h), (s = r);
                }
            })(t),
            l(!r),
            r
        );
    }
    static empty(t) {
        return new st(t ? [t, -1] : [], []);
    }
    static fromJSON(t) {
        if (!Array.isArray(t)) throw new RangeError("Invalid JSON representation of ChangeSet");
        let e = [],
            i = [];
        for (let n = 0; n < t.length; n++) {
            let o = t[n];
            if ("number" == typeof o) e.push(o, -1);
            else {
                if (!Array.isArray(o) || "number" != typeof o[0] || o.some((t, e) => e && "string" != typeof t)) throw new RangeError("Invalid JSON representation of ChangeSet");
                if (1 == o.length) e.push(o[0], 0);
                else {
                    for (; i.length < n;) i.push(U.empty);
                    (i[n] = U.of(o.slice(1))), e.push(o[0], i[n].length);
                }
            }
        }
        return new st(e, i);
    }
    static createSet(t, e) {
        return new st(t, e);
    }
}
function rt(t, e, i, n = !1) {
    if (0 == e && i <= 0) return;
    let o = t.length - 2;
    o >= 0 && i <= 0 && i == t[o + 1] ? (t[o] += e) : o >= 0 && 0 == e && 0 == t[o] ? (t[o + 1] += i) : n ? ((t[o] += e), (t[o + 1] += i)) : t.push(e, i);
}
function lt(t, e, i) {
    if (0 == i.length) return;
    let n = (e.length - 2) >> 1;
    if (n < t.length) t[t.length - 1] = t[t.length - 1].append(i);
    else {
        for (; t.length < n;) t.push(U.empty);
        t.push(i);
    }
}
function at(t, e, i) {
    let n = t.inserted;
    for (let o = 0, s = 0, r = 0; r < t.sections.length;) {
        let l = t.sections[r++],
            a = t.sections[r++];
        if (a < 0) (o += l), (s += l);
        else {
            let c = o,
                h = s,
                d = U.empty;
            for (; (c += l), (h += a), a && n && (d = d.append(n[(r - 2) >> 1])), !(i || r == t.sections.length || t.sections[r + 1] < 0);) (l = t.sections[r++]), (a = t.sections[r++]);
            e(o, c, s, h, d), (o = c), (s = h);
        }
    }
}
function ct(t, e, i, n = !1) {
    let o = [],
        s = n ? [] : null,
        r = new dt(t),
        l = new dt(e);
    for (let t = -1; ;) {
        if ((r.done && l.len) || (l.done && r.len)) throw new Error("Mismatched change set lengths");
        if (-1 == r.ins && -1 == l.ins) {
            let t = Math.min(r.len, l.len);
            rt(o, t, -1), r.forward(t), l.forward(t);
        } else if (l.ins >= 0 && (r.ins < 0 || t == r.i || (0 == r.off && (l.len < r.len || (l.len == r.len && !i))))) {
            let e = l.len;
            for (rt(o, l.ins, -1); e;) {
                let i = Math.min(r.len, e);
                r.ins >= 0 && t < r.i && r.len <= i && (rt(o, 0, r.ins), s && lt(s, o, r.text), (t = r.i)), r.forward(i), (e -= i);
            }
            l.next();
        } else {
            if (!(r.ins >= 0)) {
                if (r.done && l.done) return s ? st.createSet(o, s) : ot.create(o);
                throw new Error("Mismatched change set lengths");
            }
            {
                let e = 0,
                    i = r.len;
                for (; i;)
                    if (-1 == l.ins) {
                        let t = Math.min(i, l.len);
                        (e += t), (i -= t), l.forward(t);
                    } else {
                        if (!(0 == l.ins && l.len < i)) break;
                        (i -= l.len), l.next();
                    }
                rt(o, e, t < r.i ? r.ins : 0), s && t < r.i && lt(s, o, r.text), (t = r.i), r.forward(r.len - i);
            }
        }
    }
}
function ht(t, e, i = !1) {
    let n = [],
        o = i ? [] : null,
        s = new dt(t),
        r = new dt(e);
    for (let t = !1; ;) {
        if (s.done && r.done) return o ? st.createSet(n, o) : ot.create(n);
        if (0 == s.ins) rt(n, s.len, 0, t), s.next();
        else if (0 != r.len || r.done) {
            if (s.done || r.done) throw new Error("Mismatched change set lengths");
            {
                let e = Math.min(s.len2, r.len),
                    i = n.length;
                if (-1 == s.ins) {
                    let i = -1 == r.ins ? -1 : r.off ? 0 : r.ins;
                    rt(n, e, i, t), o && i && lt(o, n, r.text);
                } else -1 == r.ins ? (rt(n, s.off ? 0 : s.len, e, t), o && lt(o, n, s.textBit(e))) : (rt(n, s.off ? 0 : s.len, r.off ? 0 : r.ins, t), o && !r.off && lt(o, n, r.text));
                (t = (s.ins > e || (r.ins >= 0 && r.len > e)) && (t || n.length > i)), s.forward2(e), r.forward(e);
            }
        } else rt(n, 0, r.ins, t), o && lt(o, n, r.text), r.next();
    }
}
class dt {
    constructor(t) {
        (this.set = t), (this.i = 0), this.next();
    }
    next() {
        let { sections: t } = this.set;
        this.i < t.length ? ((this.len = t[this.i++]), (this.ins = t[this.i++])) : ((this.len = 0), (this.ins = -2)), (this.off = 0);
    }
    get done() {
        return -2 == this.ins;
    }
    get len2() {
        return this.ins < 0 ? this.len : this.ins;
    }
    get text() {
        let { inserted: t } = this.set,
            e = (this.i - 2) >> 1;
        return e >= t.length ? U.empty : t[e];
    }
    textBit(t) {
        let { inserted: e } = this.set,
            i = (this.i - 2) >> 1;
        return i >= e.length && !t ? U.empty : e[i].slice(this.off, null == t ? void 0 : this.off + t);
    }
    forward(t) {
        t == this.len ? this.next() : ((this.len -= t), (this.off += t));
    }
    forward2(t) {
        -1 == this.ins ? this.forward(t) : t == this.ins ? this.next() : ((this.ins -= t), (this.off += t));
    }
}
class ut {
    constructor(t, e, i) {
        (this.from = t), (this.to = e), (this.flags = i);
    }
    get anchor() {
        return 32 & this.flags ? this.to : this.from;
    }
    get head() {
        return 32 & this.flags ? this.from : this.to;
    }
    get empty() {
        return this.from == this.to;
    }
    get assoc() {
        return 8 & this.flags ? -1 : 16 & this.flags ? 1 : 0;
    }
    get bidiLevel() {
        let t = 7 & this.flags;
        return 7 == t ? null : t;
    }
    get goalColumn() {
        let t = this.flags >> 6;
        return 16777215 == t ? void 0 : t;
    }
    map(t, e = -1) {
        let i, n;
        return this.empty ? (i = n = t.mapPos(this.from, e)) : ((i = t.mapPos(this.from, 1)), (n = t.mapPos(this.to, -1))), i == this.from && n == this.to ? this : new ut(i, n, this.flags);
    }
    extend(t, e = t) {
        if (t <= this.anchor && e >= this.anchor) return pt.range(t, e);
        let i = Math.abs(t - this.anchor) > Math.abs(e - this.anchor) ? t : e;
        return pt.range(this.anchor, i);
    }
    eq(t, e = !1) {
        return !(this.anchor != t.anchor || this.head != t.head || (e && this.empty && this.assoc != t.assoc));
    }
    toJSON() {
        return { anchor: this.anchor, head: this.head };
    }
    static fromJSON(t) {
        if (!t || "number" != typeof t.anchor || "number" != typeof t.head) throw new RangeError("Invalid JSON representation for SelectionRange");
        return pt.range(t.anchor, t.head);
    }
    static create(t, e, i) {
        return new ut(t, e, i);
    }
}
class pt {
    constructor(t, e) {
        (this.ranges = t), (this.mainIndex = e);
    }
    map(t, e = -1) {
        return t.empty
            ? this
            : pt.create(
                this.ranges.map((i) => i.map(t, e)),
                this.mainIndex
            );
    }
    eq(t, e = !1) {
        if (this.ranges.length != t.ranges.length || this.mainIndex != t.mainIndex) return !1;
        for (let i = 0; i < this.ranges.length; i++) if (!this.ranges[i].eq(t.ranges[i], e)) return !1;
        return !0;
    }
    get main() {
        return this.ranges[this.mainIndex];
    }
    asSingle() {
        return 1 == this.ranges.length ? this : new pt([this.main], 0);
    }
    addRange(t, e = !0) {
        return pt.create([t].concat(this.ranges), e ? 0 : this.mainIndex + 1);
    }
    replaceRange(t, e = this.mainIndex) {
        let i = this.ranges.slice();
        return (i[e] = t), pt.create(i, this.mainIndex);
    }
    toJSON() {
        return { ranges: this.ranges.map((t) => t.toJSON()), main: this.mainIndex };
    }
    static fromJSON(t) {
        if (!t || !Array.isArray(t.ranges) || "number" != typeof t.main || t.main >= t.ranges.length) throw new RangeError("Invalid JSON representation for EditorSelection");
        return new pt(
            t.ranges.map((t) => ut.fromJSON(t)),
            t.main
        );
    }
    static single(t, e = t) {
        return new pt([pt.range(t, e)], 0);
    }
    static create(t, e = 0) {
        if (0 == t.length) throw new RangeError("A selection needs at least one range");
        for (let i = 0, n = 0; n < t.length; n++) {
            let o = t[n];
            if (o.empty ? o.from <= i : o.from < i) return pt.normalized(t.slice(), e);
            i = o.to;
        }
        return new pt(t, e);
    }
    static cursor(t, e = 0, i, n) {
        return ut.create(t, t, (0 == e ? 0 : e < 0 ? 8 : 16) | (null == i ? 7 : Math.min(6, i)) | ((null != n ? n : 16777215) << 6));
    }
    static range(t, e, i, n) {
        let o = ((null != i ? i : 16777215) << 6) | (null == n ? 7 : Math.min(6, n));
        return e < t ? ut.create(e, t, 48 | o) : ut.create(t, e, (e > t ? 8 : 0) | o);
    }
    static normalized(t, e = 0) {
        let i = t[e];
        t.sort((t, e) => t.from - e.from), (e = t.indexOf(i));
        for (let i = 1; i < t.length; i++) {
            let n = t[i],
                o = t[i - 1];
            if (n.empty ? n.from <= o.to : n.from < o.to) {
                let s = o.from,
                    r = Math.max(n.to, o.to);
                i <= e && e--, t.splice(--i, 2, n.anchor > n.head ? pt.range(r, s) : pt.range(s, r));
            }
        }
        return new pt(t, e);
    }
}
function mt(t, e) {
    for (let i of t.ranges) if (i.to > e) throw new RangeError("Selection points outside of document");
}
let gt = 0;
class ft {
    constructor(t, e, i, n, o) {
        (this.combine = t), (this.compareInput = e), (this.compare = i), (this.isStatic = n), (this.id = gt++), (this.default = t([])), (this.extensions = "function" == typeof o ? o(this) : o);
    }
    get reader() {
        return this;
    }
    static define(t = {}) {
        return new ft(t.combine || ((t) => t), t.compareInput || ((t, e) => t === e), t.compare || (t.combine ? (t, e) => t === e : bt), !!t.static, t.enables);
    }
    of(t) {
        return new vt([], this, 0, t);
    }
    compute(t, e) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new vt(t, this, 1, e);
    }
    computeN(t, e) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new vt(t, this, 2, e);
    }
    from(t, e) {
        return e || (e = (t) => t), this.compute([t], (i) => e(i.field(t)));
    }
}
function bt(t, e) {
    return t == e || (t.length == e.length && t.every((t, i) => t === e[i]));
}
class vt {
    constructor(t, e, i, n) {
        (this.dependencies = t), (this.facet = e), (this.type = i), (this.value = n), (this.id = gt++);
    }
    dynamicSlot(t) {
        var e;
        let i = this.value,
            n = this.facet.compareInput,
            o = this.id,
            s = t[o] >> 1,
            r = 2 == this.type,
            l = !1,
            a = !1,
            c = [];
        for (let i of this.dependencies) "doc" == i ? (l = !0) : "selection" == i ? (a = !0) : 1 & (null !== (e = t[i.id]) && void 0 !== e ? e : 1) || c.push(t[i.id]);
        return {
            create: (t) => ((t.values[s] = i(t)), 1),
            update(t, e) {
                if ((l && e.docChanged) || (a && (e.docChanged || e.selection)) || wt(t, c)) {
                    let e = i(t);
                    if (r ? !yt(e, t.values[s], n) : !n(e, t.values[s])) return (t.values[s] = e), 1;
                }
                return 0;
            },
            reconfigure: (t, e) => {
                let l,
                    a = e.config.address[o];
                if (null != a) {
                    let o = Lt(e, a);
                    if (this.dependencies.every((i) => (i instanceof ft ? e.facet(i) === t.facet(i) : !(i instanceof kt) || e.field(i, !1) == t.field(i, !1))) || (r ? yt((l = i(t)), o, n) : n((l = i(t)), o))) return (t.values[s] = o), 0;
                } else l = i(t);
                return (t.values[s] = l), 1;
            },
        };
    }
}
function yt(t, e, i) {
    if (t.length != e.length) return !1;
    for (let n = 0; n < t.length; n++) if (!i(t[n], e[n])) return !1;
    return !0;
}
function wt(t, e) {
    let i = !1;
    for (let n of e) 1 & Nt(t, n) && (i = !0);
    return i;
}
function xt(t, e, i) {
    let n = i.map((e) => t[e.id]),
        o = i.map((t) => t.type),
        s = n.filter((t) => !(1 & t)),
        r = t[e.id] >> 1;
    function l(t) {
        let i = [];
        for (let e = 0; e < n.length; e++) {
            let s = Lt(t, n[e]);
            if (2 == o[e]) for (let t of s) i.push(t);
            else i.push(s);
        }
        return e.combine(i);
    }
    return {
        create(t) {
            for (let e of n) Nt(t, e);
            return (t.values[r] = l(t)), 1;
        },
        update(t, i) {
            if (!wt(t, s)) return 0;
            let n = l(t);
            return e.compare(n, t.values[r]) ? 0 : ((t.values[r] = n), 1);
        },
        reconfigure(t, o) {
            let s = wt(t, n),
                a = o.config.facets[e.id],
                c = o.facet(e);
            if (a && !s && bt(i, a)) return (t.values[r] = c), 0;
            let h = l(t);
            return e.compare(h, c) ? ((t.values[r] = c), 0) : ((t.values[r] = h), 1);
        },
    };
}
const Ct = ft.define({ static: !0 });
class kt {
    constructor(t, e, i, n, o) {
        (this.id = t), (this.createF = e), (this.updateF = i), (this.compareF = n), (this.spec = o), (this.provides = void 0);
    }
    static define(t) {
        let e = new kt(gt++, t.create, t.update, t.compare || ((t, e) => t === e), t);
        return t.provide && (e.provides = t.provide(e)), e;
    }
    create(t) {
        let e = t.facet(Ct).find((t) => t.field == this);
        return ((null == e ? void 0 : e.create) || this.createF)(t);
    }
    slot(t) {
        let e = t[this.id] >> 1;
        return {
            create: (t) => ((t.values[e] = this.create(t)), 1),
            update: (t, i) => {
                let n = t.values[e],
                    o = this.updateF(n, i);
                return this.compareF(n, o) ? 0 : ((t.values[e] = o), 1);
            },
            reconfigure: (t, i) => {
                let n,
                    o = t.facet(Ct),
                    s = i.facet(Ct);
                return (n = o.find((t) => t.field == this)) && n != s.find((t) => t.field == this)
                    ? ((t.values[e] = n.create(t)), 1)
                    : null != i.config.address[this.id]
                        ? ((t.values[e] = i.field(this)), 0)
                        : ((t.values[e] = this.create(t)), 1);
            },
        };
    }
    init(t) {
        return [this, Ct.of({ field: this, create: t })];
    }
    get extension() {
        return this;
    }
}
const St = 4,
    Tt = 3,
    Et = 2,
    Mt = 1;
function At(t) {
    return (e) => new It(e, t);
}
const Dt = { highest: At(0), high: At(1), default: At(2), low: At(3), lowest: At(4) };
class It {
    constructor(t, e) {
        (this.inner = t), (this.prec = e);
    }
}
class Ot {
    of(t) {
        return new Bt(this, t);
    }
    reconfigure(t) {
        return Ot.reconfigure.of({ compartment: this, extension: t });
    }
    get(t) {
        return t.config.compartments.get(this);
    }
}
class Bt {
    constructor(t, e) {
        (this.compartment = t), (this.inner = e);
    }
}
class qt {
    constructor(t, e, i, n, o, s) {
        for (this.base = t, this.compartments = e, this.dynamicSlots = i, this.address = n, this.staticValues = o, this.facets = s, this.statusTemplate = []; this.statusTemplate.length < i.length;) this.statusTemplate.push(0);
    }
    staticFacet(t) {
        let e = this.address[t.id];
        return null == e ? t.default : this.staticValues[e >> 1];
    }
    static resolve(t, e, i) {
        let n = [],
            o = Object.create(null),
            s = new Map();
        for (let i of (function (t, e, i) {
            let n = [[], [], [], [], []],
                o = new Map();
            return (
                (function t(s, r) {
                    let l = o.get(s);
                    if (null != l) {
                        if (l <= r) return;
                        let t = n[l].indexOf(s);
                        t > -1 && n[l].splice(t, 1), s instanceof Bt && i.delete(s.compartment);
                    }
                    if ((o.set(s, r), Array.isArray(s))) for (let e of s) t(e, r);
                    else if (s instanceof Bt) {
                        if (i.has(s.compartment)) throw new RangeError("Duplicate use of compartment in extensions");
                        let n = e.get(s.compartment) || s.inner;
                        i.set(s.compartment, n), t(n, r);
                    } else if (s instanceof It) t(s.inner, s.prec);
                    else if (s instanceof kt) n[r].push(s), s.provides && t(s.provides, r);
                    else if (s instanceof vt) n[r].push(s), s.facet.extensions && t(s.facet.extensions, 2);
                    else {
                        let e = s.extension;
                        if (!e) throw new Error(`Unrecognized extension value in extension set (${s}). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks.`);
                        t(e, r);
                    }
                })(t, 2),
                n.reduce((t, e) => t.concat(e))
            );
        })(t, e, s))
            i instanceof kt ? n.push(i) : (o[i.facet.id] || (o[i.facet.id] = [])).push(i);
        let r = Object.create(null),
            l = [],
            a = [];
        for (let t of n) (r[t.id] = a.length << 1), a.push((e) => t.slot(e));
        let c = null == i ? void 0 : i.config.facets;
        for (let t in o) {
            let e = o[t],
                n = e[0].facet,
                s = (c && c[t]) || [];
            if (e.every((t) => 0 == t.type))
                if (((r[n.id] = (l.length << 1) | 1), bt(s, e))) l.push(i.facet(n));
                else {
                    let t = n.combine(e.map((t) => t.value));
                    l.push(i && n.compare(t, i.facet(n)) ? i.facet(n) : t);
                }
            else {
                for (let t of e) 0 == t.type ? ((r[t.id] = (l.length << 1) | 1), l.push(t.value)) : ((r[t.id] = a.length << 1), a.push((e) => t.dynamicSlot(e)));
                (r[n.id] = a.length << 1), a.push((t) => xt(t, n, e));
            }
        }
        let h = a.map((t) => t(r));
        return new qt(t, s, h, r, l, o);
    }
}
function Nt(t, e) {
    if (1 & e) return 2;
    let i = e >> 1,
        n = t.status[i];
    if (4 == n) throw new Error("Cyclic dependency between fields and/or facets");
    if (2 & n) return n;
    t.status[i] = 4;
    let o = t.computeSlot(t, t.config.dynamicSlots[i]);
    return (t.status[i] = 2 | o);
}
function Lt(t, e) {
    return 1 & e ? t.config.staticValues[e >> 1] : t.values[e >> 1];
}
const Rt = ft.define(),
    Pt = ft.define({ combine: (t) => t.some((t) => t), static: !0 }),
    _t = ft.define({ combine: (t) => (t.length ? t[0] : void 0), static: !0 }),
    Ft = ft.define(),
    Vt = ft.define(),
    Ht = ft.define(),
    zt = ft.define({ combine: (t) => !!t.length && t[0] });
class $t {
    constructor(t, e) {
        (this.type = t), (this.value = e);
    }
    static define() {
        return new Wt();
    }
}
class Wt {
    of(t) {
        return new $t(this, t);
    }
}
class Ut {
    constructor(t) {
        this.map = t;
    }
    of(t) {
        return new jt(this, t);
    }
}
class jt {
    constructor(t, e) {
        (this.type = t), (this.value = e);
    }
    map(t) {
        let e = this.type.map(this.value, t);
        return void 0 === e ? void 0 : e == this.value ? this : new jt(this.type, e);
    }
    is(t) {
        return this.type == t;
    }
    static define(t = {}) {
        return new Ut(t.map || ((t) => t));
    }
    static mapEffects(t, e) {
        if (!t.length) return t;
        let i = [];
        for (let n of t) {
            let t = n.map(e);
            t && i.push(t);
        }
        return i;
    }
}
(jt.reconfigure = jt.define()), (jt.appendConfig = jt.define());
class Yt {
    constructor(t, e, i, n, o, s) {
        (this.startState = t),
            (this.changes = e),
            (this.selection = i),
            (this.effects = n),
            (this.annotations = o),
            (this.scrollIntoView = s),
            (this._doc = null),
            (this._state = null),
            i && mt(i, e.newLength),
            o.some((t) => t.type == Yt.time) || (this.annotations = o.concat(Yt.time.of(Date.now())));
    }
    static create(t, e, i, n, o, s) {
        return new Yt(t, e, i, n, o, s);
    }
    get newDoc() {
        return this._doc || (this._doc = this.changes.apply(this.startState.doc));
    }
    get newSelection() {
        return this.selection || this.startState.selection.map(this.changes);
    }
    get state() {
        return this._state || this.startState.applyTransaction(this), this._state;
    }
    annotation(t) {
        for (let e of this.annotations) if (e.type == t) return e.value;
    }
    get docChanged() {
        return !this.changes.empty;
    }
    get reconfigured() {
        return this.startState.config != this.state.config;
    }
    isUserEvent(t) {
        let e = this.annotation(Yt.userEvent);
        return !(!e || !(e == t || (e.length > t.length && e.slice(0, t.length) == t && "." == e[t.length])));
    }
}
function Gt(t, e) {
    let i = [];
    for (let n = 0, o = 0; ;) {
        let s, r;
        if (n < t.length && (o == e.length || e[o] >= t[n])) (s = t[n++]), (r = t[n++]);
        else {
            if (!(o < e.length)) return i;
            (s = e[o++]), (r = e[o++]);
        }
        !i.length || i[i.length - 1] < s ? i.push(s, r) : i[i.length - 1] < r && (i[i.length - 1] = r);
    }
}
function Zt(t, e, i) {
    var n;
    let o, s, r;
    return (
        i ? ((o = e.changes), (s = st.empty(e.changes.length)), (r = t.changes.compose(e.changes))) : ((o = e.changes.map(t.changes)), (s = t.changes.mapDesc(e.changes, !0)), (r = t.changes.compose(o))),
        {
            changes: r,
            selection: e.selection ? e.selection.map(s) : null === (n = t.selection) || void 0 === n ? void 0 : n.map(o),
            effects: jt.mapEffects(t.effects, o).concat(jt.mapEffects(e.effects, s)),
            annotations: t.annotations.length ? t.annotations.concat(e.annotations) : e.annotations,
            scrollIntoView: t.scrollIntoView || e.scrollIntoView,
        }
    );
}
function Kt(t, e, i) {
    let n = e.selection,
        o = Qt(e.annotations);
    return (
        e.userEvent && (o = o.concat(Yt.userEvent.of(e.userEvent))),
        {
            changes: e.changes instanceof st ? e.changes : st.of(e.changes || [], i, t.facet(_t)),
            selection: n && (n instanceof pt ? n : pt.single(n.anchor, n.head)),
            effects: Qt(e.effects),
            annotations: o,
            scrollIntoView: !!e.scrollIntoView,
        }
    );
}
function Xt(t, e, i) {
    let n = Kt(t, e.length ? e[0] : {}, t.doc.length);
    e.length && !1 === e[0].filter && (i = !1);
    for (let o = 1; o < e.length; o++) {
        !1 === e[o].filter && (i = !1);
        let s = !!e[o].sequential;
        n = Zt(n, Kt(t, e[o], s ? n.changes.newLength : t.doc.length), s);
    }
    let o = Yt.create(t, n.changes, n.selection, n.effects, n.annotations, n.scrollIntoView);
    return (function (t) {
        let e = t.startState,
            i = e.facet(Ht),
            n = t;
        for (let o = i.length - 1; o >= 0; o--) {
            let s = i[o](t);
            s && Object.keys(s).length && (n = Zt(n, Kt(e, s, t.changes.newLength), !0));
        }
        return n == t ? t : Yt.create(e, t.changes, t.selection, n.effects, n.annotations, n.scrollIntoView);
    })(
        i
            ? (function (t) {
                let e = t.startState,
                    i = !0;
                for (let n of e.facet(Ft)) {
                    let e = n(t);
                    if (!1 === e) {
                        i = !1;
                        break;
                    }
                    Array.isArray(e) && (i = !0 === i ? e : Gt(i, e));
                }
                if (!0 !== i) {
                    let n, o;
                    if (!1 === i) (o = t.changes.invertedDesc), (n = st.empty(e.doc.length));
                    else {
                        let e = t.changes.filter(i);
                        (n = e.changes), (o = e.filtered.mapDesc(e.changes).invertedDesc);
                    }
                    t = Yt.create(e, n, t.selection && t.selection.map(o), jt.mapEffects(t.effects, o), t.annotations, t.scrollIntoView);
                }
                let n = e.facet(Vt);
                for (let i = n.length - 1; i >= 0; i--) {
                    let o = n[i](t);
                    t = o instanceof Yt ? o : Array.isArray(o) && 1 == o.length && o[0] instanceof Yt ? o[0] : Xt(e, Qt(o), !1);
                }
                return t;
            })(o)
            : o
    );
}
(Yt.time = $t.define()), (Yt.userEvent = $t.define()), (Yt.addToHistory = $t.define()), (Yt.remote = $t.define());
const Jt = [];
function Qt(t) {
    return null == t ? Jt : Array.isArray(t) ? t : [t];
}
var te = (function (t) {
    return (t[(t.Word = 0)] = "Word"), (t[(t.Space = 1)] = "Space"), (t[(t.Other = 2)] = "Other"), t;
})(te || (te = {}));
const ee = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
let ie;
try {
    ie = new RegExp("[\\p{Alphabetic}\\p{Number}_]", "u");
} catch (t) { }
function ne(t) {
    return (e) => {
        if (!/\S/.test(e)) return te.Space;
        if (
            (function (t) {
                if (ie) return ie.test(t);
                for (let e = 0; e < t.length; e++) {
                    let i = t[e];
                    if (/\w/.test(i) || (i > "" && (i.toUpperCase() != i.toLowerCase() || ee.test(i)))) return !0;
                }
                return !1;
            })(e)
        )
            return te.Word;
        for (let i = 0; i < t.length; i++) if (e.indexOf(t[i]) > -1) return te.Word;
        return te.Other;
    };
}
class oe {
    constructor(t, e, i, n, o, s) {
        (this.config = t), (this.doc = e), (this.selection = i), (this.values = n), (this.status = t.statusTemplate.slice()), (this.computeSlot = o), s && (s._state = this);
        for (let t = 0; t < this.config.dynamicSlots.length; t++) Nt(this, t << 1);
        this.computeSlot = null;
    }
    field(t, e = !0) {
        let i = this.config.address[t.id];
        if (null != i) return Nt(this, i), Lt(this, i);
        if (e) throw new RangeError("Field is not present in this state");
    }
    update(...t) {
        return Xt(this, t, !0);
    }
    applyTransaction(t) {
        let e,
            i = this.config,
            { base: n, compartments: o } = i;
        for (let e of t.effects)
            e.is(Ot.reconfigure)
                ? (i && ((o = new Map()), i.compartments.forEach((t, e) => o.set(e, t)), (i = null)), o.set(e.value.compartment, e.value.extension))
                : e.is(jt.reconfigure)
                    ? ((i = null), (n = e.value))
                    : e.is(jt.appendConfig) && ((i = null), (n = Qt(n).concat(e.value)));
        i
            ? (e = t.startState.values.slice())
            : ((i = qt.resolve(n, o, this)),
                (e = new oe(
                    i,
                    this.doc,
                    this.selection,
                    i.dynamicSlots.map(() => null),
                    (t, e) => e.reconfigure(t, this),
                    null
                ).values));
        let s = t.startState.facet(Pt) ? t.newSelection : t.newSelection.asSingle();
        new oe(i, t.newDoc, s, e, (e, i) => i.update(e, t), t);
    }
    replaceSelection(t) {
        return "string" == typeof t && (t = this.toText(t)), this.changeByRange((e) => ({ changes: { from: e.from, to: e.to, insert: t }, range: pt.cursor(e.from + t.length) }));
    }
    changeByRange(t) {
        let e = this.selection,
            i = t(e.ranges[0]),
            n = this.changes(i.changes),
            o = [i.range],
            s = Qt(i.effects);
        for (let i = 1; i < e.ranges.length; i++) {
            let r = t(e.ranges[i]),
                l = this.changes(r.changes),
                a = l.map(n);
            for (let t = 0; t < i; t++) o[t] = o[t].map(a);
            let c = n.mapDesc(l, !0);
            o.push(r.range.map(c)), (n = n.compose(a)), (s = jt.mapEffects(s, a).concat(jt.mapEffects(Qt(r.effects), c)));
        }
        return { changes: n, selection: pt.create(o, e.mainIndex), effects: s };
    }
    changes(t = []) {
        return t instanceof st ? t : st.of(t, this.doc.length, this.facet(oe.lineSeparator));
    }
    toText(t) {
        return U.of(t.split(this.facet(oe.lineSeparator) || it));
    }
    sliceDoc(t = 0, e = this.doc.length) {
        return this.doc.sliceString(t, e, this.lineBreak);
    }
    facet(t) {
        let e = this.config.address[t.id];
        return null == e ? t.default : (Nt(this, e), Lt(this, e));
    }
    toJSON(t) {
        let e = { doc: this.sliceDoc(), selection: this.selection.toJSON() };
        if (t)
            for (let i in t) {
                let n = t[i];
                n instanceof kt && null != this.config.address[n.id] && (e[i] = n.spec.toJSON(this.field(t[i]), this));
            }
        return e;
    }
    static fromJSON(t, e = {}, i) {
        if (!t || "string" != typeof t.doc) throw new RangeError("Invalid JSON representation for EditorState");
        let n = [];
        if (i)
            for (let e in i)
                if (Object.prototype.hasOwnProperty.call(t, e)) {
                    let o = i[e],
                        s = t[e];
                    n.push(o.init((t) => o.spec.fromJSON(s, t)));
                }
        return oe.create({ doc: t.doc, selection: pt.fromJSON(t.selection), extensions: e.extensions ? n.concat([e.extensions]) : n });
    }
    static create(t = {}) {
        let e = qt.resolve(t.extensions || [], new Map()),
            i = t.doc instanceof U ? t.doc : U.of((t.doc || "").split(e.staticFacet(oe.lineSeparator) || it)),
            n = t.selection ? (t.selection instanceof pt ? t.selection : pt.single(t.selection.anchor, t.selection.head)) : pt.single(0);
        return (
            mt(n, i.length),
            e.staticFacet(Pt) || (n = n.asSingle()),
            new oe(
                e,
                i,
                n,
                e.dynamicSlots.map(() => null),
                (t, e) => e.create(t),
                null
            )
        );
    }
    get tabSize() {
        return this.facet(oe.tabSize);
    }
    get lineBreak() {
        return this.facet(oe.lineSeparator) || "\n";
    }
    get readOnly() {
        return this.facet(zt);
    }
    phrase(t, ...e) {
        for (let e of this.facet(oe.phrases))
            if (Object.prototype.hasOwnProperty.call(e, t)) {
                t = e[t];
                break;
            }
        return (
            e.length &&
            (t = t.replace(/\$(\$|\d*)/g, (t, i) => {
                if ("$" == i) return "$";
                let n = +(i || 1);
                return !n || n > e.length ? t : e[n - 1];
            })),
            t
        );
    }
    languageDataAt(t, e, i = -1) {
        let n = [];
        for (let o of this.facet(Rt)) for (let s of o(this, e, i)) Object.prototype.hasOwnProperty.call(s, t) && n.push(s[t]);
        return n;
    }
    charCategorizer(t) {
        return ne(this.languageDataAt("wordChars", t).join(""));
    }
    wordAt(t) {
        let { text: e, from: i, length: n } = this.doc.lineAt(t),
            o = this.charCategorizer(t),
            s = t - i,
            r = t - i;
        for (; s > 0;) {
            let t = et(e, s, !1);
            if (o(e.slice(t, s)) != te.Word) break;
            s = t;
        }
        for (; r < n;) {
            let t = et(e, r);
            if (o(e.slice(r, t)) != te.Word) break;
            r = t;
        }
        return s == r ? null : pt.range(s + i, r + i);
    }
}
(oe.allowMultipleSelections = Pt),
    (oe.tabSize = ft.define({ combine: (t) => (t.length ? t[0] : 4) })),
    (oe.lineSeparator = _t),
    (oe.readOnly = zt),
    (oe.phrases = ft.define({
        compare(t, e) {
            let i = Object.keys(t),
                n = Object.keys(e);
            return i.length == n.length && i.every((i) => t[i] == e[i]);
        },
    })),
    (oe.languageData = Rt),
    (oe.changeFilter = Ft),
    (oe.transactionFilter = Vt),
    (oe.transactionExtender = Ht),
    (Ot.reconfigure = jt.define());
class se {
    eq(t) {
        return this == t;
    }
    range(t, e = t) {
        return re.create(t, e, this);
    }
}
(se.prototype.startSide = se.prototype.endSide = 0), (se.prototype.point = !1), (se.prototype.mapMode = nt.TrackDel);
class re {
    constructor(t, e, i) {
        (this.from = t), (this.to = e), (this.value = i);
    }
    static create(t, e, i) {
        return new re(t, e, i);
    }
}
function le(t, e) {
    return t.from - e.from || t.value.startSide - e.value.startSide;
}
class ae {
    constructor(t, e, i, n) {
        (this.from = t), (this.to = e), (this.value = i), (this.maxPoint = n);
    }
    get length() {
        return this.to[this.to.length - 1];
    }
    findIndex(t, e, i, n = 0) {
        let o = i ? this.to : this.from;
        for (let s = n, r = o.length; ;) {
            if (s == r) return s;
            let n = (s + r) >> 1,
                l = o[n] - t || (i ? this.value[n].endSide : this.value[n].startSide) - e;
            if (n == s) return l >= 0 ? s : r;
            l >= 0 ? (r = n) : (s = n + 1);
        }
    }
    between(t, e, i, n) {
        for (let o = this.findIndex(e, -1e9, !0), s = this.findIndex(i, 1e9, !1, o); o < s; o++) if (!1 === n(this.from[o] + t, this.to[o] + t, this.value[o])) return !1;
    }
    map(t, e) {
        let i = [],
            n = [],
            o = [],
            s = -1,
            r = -1;
        for (let l = 0; l < this.value.length; l++) {
            let a,
                c,
                h = this.value[l],
                d = this.from[l] + t,
                u = this.to[l] + t;
            if (d == u) {
                let t = e.mapPos(d, h.startSide, h.mapMode);
                if (null == t) continue;
                if (((a = c = t), h.startSide != h.endSide && ((c = e.mapPos(d, h.endSide)), c < a))) continue;
            } else if (((a = e.mapPos(d, h.startSide)), (c = e.mapPos(u, h.endSide)), a > c || (a == c && h.startSide > 0 && h.endSide <= 0))) continue;
            (c - a || h.endSide - h.startSide) < 0 || (s < 0 && (s = a), h.point && (r = Math.max(r, c - a)), i.push(h), n.push(a - s), o.push(c - s));
        }
        return { mapped: i.length ? new ae(n, o, i, r) : null, pos: s };
    }
}
class ce {
    constructor(t, e, i, n) {
        (this.chunkPos = t), (this.chunk = e), (this.nextLayer = i), (this.maxPoint = n);
    }
    static create(t, e, i, n) {
        return new ce(t, e, i, n);
    }
    get length() {
        let t = this.chunk.length - 1;
        return t < 0 ? 0 : Math.max(this.chunkEnd(t), this.nextLayer.length);
    }
    get size() {
        if (this.isEmpty) return 0;
        let t = this.nextLayer.size;
        for (let e of this.chunk) t += e.value.length;
        return t;
    }
    chunkEnd(t) {
        return this.chunkPos[t] + this.chunk[t].length;
    }
    update(t) {
        let { add: e = [], sort: i = !1, filterFrom: n = 0, filterTo: o = this.length } = t,
            s = t.filter;
        if (0 == e.length && !s) return this;
        if ((i && (e = e.slice().sort(le)), this.isEmpty)) return e.length ? ce.of(e) : this;
        let r = new ue(this, null, -1).goto(0),
            l = 0,
            a = [],
            c = new he();
        for (; r.value || l < e.length;)
            if (l < e.length && (r.from - e[l].from || r.startSide - e[l].value.startSide) >= 0) {
                let t = e[l++];
                c.addInner(t.from, t.to, t.value) || a.push(t);
            } else
                1 == r.rangeIndex &&
                    r.chunkIndex < this.chunk.length &&
                    (l == e.length || this.chunkEnd(r.chunkIndex) < e[l].from) &&
                    (!s || n > this.chunkEnd(r.chunkIndex) || o < this.chunkPos[r.chunkIndex]) &&
                    c.addChunk(this.chunkPos[r.chunkIndex], this.chunk[r.chunkIndex])
                    ? r.nextChunk()
                    : ((!s || n > r.to || o < r.from || s(r.from, r.to, r.value)) && (c.addInner(r.from, r.to, r.value) || a.push(re.create(r.from, r.to, r.value))), r.next());
        return c.finishInner(this.nextLayer.isEmpty && !a.length ? ce.empty : this.nextLayer.update({ add: a, filter: s, filterFrom: n, filterTo: o }));
    }
    map(t) {
        if (t.empty || this.isEmpty) return this;
        let e = [],
            i = [],
            n = -1;
        for (let o = 0; o < this.chunk.length; o++) {
            let s = this.chunkPos[o],
                r = this.chunk[o],
                l = t.touchesRange(s, s + r.length);
            if (!1 === l) (n = Math.max(n, r.maxPoint)), e.push(r), i.push(t.mapPos(s));
            else if (!0 === l) {
                let { mapped: o, pos: l } = r.map(s, t);
                o && ((n = Math.max(n, o.maxPoint)), e.push(o), i.push(l));
            }
        }
        let o = this.nextLayer.map(t);
        return 0 == e.length ? o : new ce(i, e, o || ce.empty, n);
    }
    between(t, e, i) {
        if (!this.isEmpty) {
            for (let n = 0; n < this.chunk.length; n++) {
                let o = this.chunkPos[n],
                    s = this.chunk[n];
                if (e >= o && t <= o + s.length && !1 === s.between(o, t - o, e - o, i)) return;
            }
            this.nextLayer.between(t, e, i);
        }
    }
    iter(t = 0) {
        return pe.from([this]).goto(t);
    }
    get isEmpty() {
        return this.nextLayer == this;
    }
    static iter(t, e = 0) {
        return pe.from(t).goto(e);
    }
    static compare(t, e, i, n, o = -1) {
        let s = t.filter((t) => t.maxPoint > 0 || (!t.isEmpty && t.maxPoint >= o)),
            r = e.filter((t) => t.maxPoint > 0 || (!t.isEmpty && t.maxPoint >= o)),
            l = de(s, r, i),
            a = new ge(s, l, o),
            c = new ge(r, l, o);
        i.iterGaps((t, e, i) => fe(a, t, c, e, i, n)), i.empty && 0 == i.length && fe(a, 0, c, 0, 0, n);
    }
    static eq(t, e, i = 0, n) {
        null == n && (n = 999999999);
        let o = t.filter((t) => !t.isEmpty && e.indexOf(t) < 0),
            s = e.filter((e) => !e.isEmpty && t.indexOf(e) < 0);
        if (o.length != s.length) return !1;
        if (!o.length) return !0;
        let r = de(o, s),
            l = new ge(o, r, 0).goto(i),
            a = new ge(s, r, 0).goto(i);
        for (; ;) {
            if (l.to != a.to || !be(l.active, a.active) || (l.point && (!a.point || !l.point.eq(a.point)))) return !1;
            if (l.to > n) return !0;
            l.next(), a.next();
        }
    }
    static spans(t, e, i, n, o = -1) {
        let s = new ge(t, null, o).goto(e),
            r = e,
            l = s.openStart;
        for (; ;) {
            let t = Math.min(s.to, i);
            if (s.point) {
                let i = s.activeForPoint(s.to),
                    o = s.pointFrom < e ? i.length + 1 : s.point.startSide < 0 ? i.length : Math.min(i.length, l);
                n.point(r, t, s.point, i, o, s.pointRank), (l = Math.min(s.openEnd(t), i.length));
            } else t > r && (n.span(r, t, s.active, l), (l = s.openEnd(t)));
            if (s.to > i) return l + (s.point && s.to > i ? 1 : 0);
            (r = s.to), s.next();
        }
    }
    static of(t, e = !1) {
        let i = new he();
        for (let n of t instanceof re
            ? [t]
            : e
                ? (function (t) {
                    if (t.length > 1)
                        for (let e = t[0], i = 1; i < t.length; i++) {
                            let n = t[i];
                            if (le(e, n) > 0) return t.slice().sort(le);
                            e = n;
                        }
                    return t;
                })(t)
                : t)
            i.add(n.from, n.to, n.value);
        return i.finish();
    }
    static join(t) {
        if (!t.length) return ce.empty;
        let e = t[t.length - 1];
        for (let i = t.length - 2; i >= 0; i--) for (let n = t[i]; n != ce.empty; n = n.nextLayer) e = new ce(n.chunkPos, n.chunk, e, Math.max(n.maxPoint, e.maxPoint));
        return e;
    }
}
(ce.empty = new ce([], [], null, -1)), (ce.empty.nextLayer = ce.empty);
class he {
    finishChunk(t) {
        this.chunks.push(new ae(this.from, this.to, this.value, this.maxPoint)),
            this.chunkPos.push(this.chunkStart),
            (this.chunkStart = -1),
            (this.setMaxPoint = Math.max(this.setMaxPoint, this.maxPoint)),
            (this.maxPoint = -1),
            t && ((this.from = []), (this.to = []), (this.value = []));
    }
    constructor() {
        (this.chunks = []),
            (this.chunkPos = []),
            (this.chunkStart = -1),
            (this.last = null),
            (this.lastFrom = -1e9),
            (this.lastTo = -1e9),
            (this.from = []),
            (this.to = []),
            (this.value = []),
            (this.maxPoint = -1),
            (this.setMaxPoint = -1),
            (this.nextLayer = null);
    }
    add(t, e, i) {
        this.addInner(t, e, i) || (this.nextLayer || (this.nextLayer = new he())).add(t, e, i);
    }
    addInner(t, e, i) {
        let n = t - this.lastTo || i.startSide - this.last.endSide;
        if (n <= 0 && (t - this.lastFrom || i.startSide - this.last.startSide) < 0) throw new Error("Ranges must be added sorted by `from` position and `startSide`");
        return !(
            n < 0 ||
            (250 == this.from.length && this.finishChunk(!0),
                this.chunkStart < 0 && (this.chunkStart = t),
                this.from.push(t - this.chunkStart),
                this.to.push(e - this.chunkStart),
                (this.last = i),
                (this.lastFrom = t),
                (this.lastTo = e),
                this.value.push(i),
                i.point && (this.maxPoint = Math.max(this.maxPoint, e - t)),
                0)
        );
    }
    addChunk(t, e) {
        if ((t - this.lastTo || e.value[0].startSide - this.last.endSide) < 0) return !1;
        this.from.length && this.finishChunk(!0), (this.setMaxPoint = Math.max(this.setMaxPoint, e.maxPoint)), this.chunks.push(e), this.chunkPos.push(t);
        let i = e.value.length - 1;
        return (this.last = e.value[i]), (this.lastFrom = e.from[i] + t), (this.lastTo = e.to[i] + t), !0;
    }
    finish() {
        return this.finishInner(ce.empty);
    }
    finishInner(t) {
        if ((this.from.length && this.finishChunk(!1), 0 == this.chunks.length)) return t;
        let e = ce.create(this.chunkPos, this.chunks, this.nextLayer ? this.nextLayer.finishInner(t) : t, this.setMaxPoint);
        return (this.from = null), e;
    }
}
function de(t, e, i) {
    let n = new Map();
    for (let e of t) for (let t = 0; t < e.chunk.length; t++) e.chunk[t].maxPoint <= 0 && n.set(e.chunk[t], e.chunkPos[t]);
    let o = new Set();
    for (let t of e)
        for (let e = 0; e < t.chunk.length; e++) {
            let s = n.get(t.chunk[e]);
            null == s || (i ? i.mapPos(s) : s) != t.chunkPos[e] || (null == i ? void 0 : i.touchesRange(s, s + t.chunk[e].length)) || o.add(t.chunk[e]);
        }
    return o;
}
class ue {
    constructor(t, e, i, n = 0) {
        (this.layer = t), (this.skip = e), (this.minPoint = i), (this.rank = n);
    }
    get startSide() {
        return this.value ? this.value.startSide : 0;
    }
    get endSide() {
        return this.value ? this.value.endSide : 0;
    }
    goto(t, e = -1e9) {
        return (this.chunkIndex = this.rangeIndex = 0), this.gotoInner(t, e, !1), this;
    }
    gotoInner(t, e, i) {
        for (; this.chunkIndex < this.layer.chunk.length;) {
            let e = this.layer.chunk[this.chunkIndex];
            if (!((this.skip && this.skip.has(e)) || this.layer.chunkEnd(this.chunkIndex) < t || e.maxPoint < this.minPoint)) break;
            this.chunkIndex++, (i = !1);
        }
        if (this.chunkIndex < this.layer.chunk.length) {
            let n = this.layer.chunk[this.chunkIndex].findIndex(t - this.layer.chunkPos[this.chunkIndex], e, !0);
            (!i || this.rangeIndex < n) && this.setRangeIndex(n);
        }
        this.next();
    }
    forward(t, e) {
        (this.to - t || this.endSide - e) < 0 && this.gotoInner(t, e, !0);
    }
    next() {
        for (; ;) {
            if (this.chunkIndex == this.layer.chunk.length) {
                (this.from = this.to = 1e9), (this.value = null);
                break;
            }
            {
                let t = this.layer.chunkPos[this.chunkIndex],
                    e = this.layer.chunk[this.chunkIndex],
                    i = t + e.from[this.rangeIndex];
                if (((this.from = i), (this.to = t + e.to[this.rangeIndex]), (this.value = e.value[this.rangeIndex]), this.setRangeIndex(this.rangeIndex + 1), this.minPoint < 0 || (this.value.point && this.to - this.from >= this.minPoint)))
                    break;
            }
        }
    }
    setRangeIndex(t) {
        if (t == this.layer.chunk[this.chunkIndex].value.length) {
            if ((this.chunkIndex++, this.skip)) for (; this.chunkIndex < this.layer.chunk.length && this.skip.has(this.layer.chunk[this.chunkIndex]);) this.chunkIndex++;
            this.rangeIndex = 0;
        } else this.rangeIndex = t;
    }
    nextChunk() {
        this.chunkIndex++, (this.rangeIndex = 0), this.next();
    }
    compare(t) {
        return this.from - t.from || this.startSide - t.startSide || this.rank - t.rank || this.to - t.to || this.endSide - t.endSide;
    }
}
class pe {
    constructor(t) {
        this.heap = t;
    }
    static from(t, e = null, i = -1) {
        let n = [];
        for (let o = 0; o < t.length; o++) for (let s = t[o]; !s.isEmpty; s = s.nextLayer) s.maxPoint >= i && n.push(new ue(s, e, i, o));
        return 1 == n.length ? n[0] : new pe(n);
    }
    get startSide() {
        return this.value ? this.value.startSide : 0;
    }
    goto(t, e = -1e9) {
        for (let i of this.heap) i.goto(t, e);
        for (let t = this.heap.length >> 1; t >= 0; t--) me(this.heap, t);
        return this.next(), this;
    }
    forward(t, e) {
        for (let i of this.heap) i.forward(t, e);
        for (let t = this.heap.length >> 1; t >= 0; t--) me(this.heap, t);
        (this.to - t || this.value.endSide - e) < 0 && this.next();
    }
    next() {
        if (0 == this.heap.length) (this.from = this.to = 1e9), (this.value = null), (this.rank = -1);
        else {
            let t = this.heap[0];
            (this.from = t.from), (this.to = t.to), (this.value = t.value), (this.rank = t.rank), t.value && t.next(), me(this.heap, 0);
        }
    }
}
function me(t, e) {
    for (let i = t[e]; ;) {
        let n = 1 + (e << 1);
        if (n >= t.length) break;
        let o = t[n];
        if ((n + 1 < t.length && o.compare(t[n + 1]) >= 0 && ((o = t[n + 1]), n++), i.compare(o) < 0)) break;
        (t[n] = i), (t[e] = o), (e = n);
    }
}
class ge {
    constructor(t, e, i) {
        (this.minPoint = i),
            (this.active = []),
            (this.activeTo = []),
            (this.activeRank = []),
            (this.minActive = -1),
            (this.point = null),
            (this.pointFrom = 0),
            (this.pointRank = 0),
            (this.to = -1e9),
            (this.endSide = 0),
            (this.openStart = -1),
            (this.cursor = pe.from(t, e, i));
    }
    goto(t, e = -1e9) {
        return this.cursor.goto(t, e), (this.active.length = this.activeTo.length = this.activeRank.length = 0), (this.minActive = -1), (this.to = t), (this.endSide = e), (this.openStart = -1), this.next(), this;
    }
    forward(t, e) {
        for (; this.minActive > -1 && (this.activeTo[this.minActive] - t || this.active[this.minActive].endSide - e) < 0;) this.removeActive(this.minActive);
        this.cursor.forward(t, e);
    }
    removeActive(t) {
        ve(this.active, t), ve(this.activeTo, t), ve(this.activeRank, t), (this.minActive = we(this.active, this.activeTo));
    }
    addActive(t) {
        let e = 0,
            { value: i, to: n, rank: o } = this.cursor;
        for (; e < this.activeRank.length && (o - this.activeRank[e] || n - this.activeTo[e]) > 0;) e++;
        ye(this.active, e, i), ye(this.activeTo, e, n), ye(this.activeRank, e, o), t && ye(t, e, this.cursor.from), (this.minActive = we(this.active, this.activeTo));
    }
    next() {
        let t = this.to,
            e = this.point;
        this.point = null;
        let i = this.openStart < 0 ? [] : null;
        for (; ;) {
            let n = this.minActive;
            if (n > -1 && (this.activeTo[n] - this.cursor.from || this.active[n].endSide - this.cursor.startSide) < 0) {
                if (this.activeTo[n] > t) {
                    (this.to = this.activeTo[n]), (this.endSide = this.active[n].endSide);
                    break;
                }
                this.removeActive(n), i && ve(i, n);
            } else {
                if (!this.cursor.value) {
                    this.to = this.endSide = 1e9;
                    break;
                }
                if (this.cursor.from > t) {
                    (this.to = this.cursor.from), (this.endSide = this.cursor.startSide);
                    break;
                }
                {
                    let t = this.cursor.value;
                    if (t.point) {
                        if (!(e && this.cursor.to == this.to && this.cursor.from < this.cursor.to)) {
                            (this.point = t), (this.pointFrom = this.cursor.from), (this.pointRank = this.cursor.rank), (this.to = this.cursor.to), (this.endSide = t.endSide), this.cursor.next(), this.forward(this.to, this.endSide);
                            break;
                        }
                        this.cursor.next();
                    } else this.addActive(i), this.cursor.next();
                }
            }
        }
        if (i) {
            this.openStart = 0;
            for (let e = i.length - 1; e >= 0 && i[e] < t; e--) this.openStart++;
        }
    }
    activeForPoint(t) {
        if (!this.active.length) return this.active;
        let e = [];
        for (let i = this.active.length - 1; i >= 0 && !(this.activeRank[i] < this.pointRank); i--) (this.activeTo[i] > t || (this.activeTo[i] == t && this.active[i].endSide >= this.point.endSide)) && e.push(this.active[i]);
        return e.reverse();
    }
    openEnd(t) {
        let e = 0;
        for (let i = this.activeTo.length - 1; i >= 0 && this.activeTo[i] > t; i--) e++;
        return e;
    }
}
function fe(t, e, i, n, o, s) {
    t.goto(e), i.goto(n);
    let r = n + o,
        l = n,
        a = n - e;
    for (; ;) {
        let e = t.to + a - i.to,
            n = e || t.endSide - i.endSide,
            o = n < 0 ? t.to + a : i.to,
            c = Math.min(o, r);
        if (
            (t.point || i.point
                ? (t.point && i.point && (t.point == i.point || t.point.eq(i.point)) && be(t.activeForPoint(t.to), i.activeForPoint(i.to))) || s.comparePoint(l, c, t.point, i.point)
                : c > l && !be(t.active, i.active) && s.compareRange(l, c, t.active, i.active),
                o > r)
        )
            break;
        (e || t.openEnd != i.openEnd) && s.boundChange && s.boundChange(o), (l = o), n <= 0 && t.next(), n >= 0 && i.next();
    }
}
function be(t, e) {
    if (t.length != e.length) return !1;
    for (let i = 0; i < t.length; i++) if (t[i] != e[i] && !t[i].eq(e[i])) return !1;
    return !0;
}
function ve(t, e) {
    for (let i = e, n = t.length - 1; i < n; i++) t[i] = t[i + 1];
    t.pop();
}
function ye(t, e, i) {
    for (let i = t.length - 1; i >= e; i--) t[i + 1] = t[i];
    t[e] = i;
}
function we(t, e) {
    let i = -1,
        n = 1e9;
    for (let o = 0; o < e.length; o++) (e[o] - n || t[o].endSide - t[i].endSide) < 0 && ((i = o), (n = e[o]));
    return i;
}
const xe = "undefined" == typeof Symbol ? "__ͼ" : Symbol.for("ͼ"),
    Ce = "undefined" == typeof Symbol ? "__styleSet" + Math.floor(1e8 * Math.random()) : Symbol("styleSet"),
    ke = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : {};
class Se {
    constructor(t, e) {
        this.rules = [];
        let { finish: i } = e || {};
        function n(t) {
            return /^@/.test(t) ? [t] : t.split(/,\s*/);
        }
        function o(t, e, s, r) {
            let l = [],
                a = /^@(\w+)\b/.exec(t[0]),
                c = a && "keyframes" == a[1];
            if (a && null == e) return s.push(t[0] + ";");
            for (let i in e) {
                let r = e[i];
                if (/&/.test(i))
                    o(
                        i
                            .split(/,\s*/)
                            .map((e) => t.map((t) => e.replace(/&/, t)))
                            .reduce((t, e) => t.concat(e)),
                        r,
                        s
                    );
                else if (r && "object" == typeof r) {
                    if (!a) throw new RangeError("The value of a property (" + i + ") should be a primitive value.");
                    o(n(i), r, l, c);
                } else null != r && l.push(i.replace(/_.*/, "").replace(/[A-Z]/g, (t) => "-" + t.toLowerCase()) + ": " + r + ";");
            }
            (l.length || c) && s.push((!i || a || r ? t : t.map(i)).join(", ") + " {" + l.join(" ") + "}");
        }
        for (let e in t) o(n(e), t[e], this.rules);
    }
    getRules() {
        return this.rules.join("\n");
    }
    static newName() {
        let t = ke[xe] || 1;
        return (ke[xe] = t + 1), "ͼ" + t.toString(36);
    }
    static mount(t, e, i) {
        let n = t[Ce],
            o = i && i.nonce;
        n ? o && n.setNonce(o) : (n = new Ee(t, o)), n.mount(Array.isArray(e) ? e : [e], t);
    }
}
let Te = new Map();
class Ee {
    constructor(t, e) {
        let i = t.ownerDocument || t,
            n = i.defaultView;
        if (!t.head && t.adoptedStyleSheets && n.CSSStyleSheet) {
            let e = Te.get(i);
            if (e) return (t[Ce] = e);
            (this.sheet = new n.CSSStyleSheet()), Te.set(i, this);
        } else (this.styleTag = i.createElement("style")), e && this.styleTag.setAttribute("nonce", e);
        (this.modules = []), (t[Ce] = this);
    }
    mount(t, e) {
        let i = this.sheet,
            n = 0,
            o = 0;
        for (let e = 0; e < t.length; e++) {
            let s = t[e],
                r = this.modules.indexOf(s);
            if ((r < o && r > -1 && (this.modules.splice(r, 1), o--, (r = -1)), -1 == r)) {
                if ((this.modules.splice(o++, 0, s), i)) for (let t = 0; t < s.rules.length; t++) i.insertRule(s.rules[t], n++);
            } else {
                for (; o < r;) n += this.modules[o++].rules.length;
                (n += s.rules.length), o++;
            }
        }
        if (i) e.adoptedStyleSheets.indexOf(this.sheet) < 0 && (e.adoptedStyleSheets = [this.sheet, ...e.adoptedStyleSheets]);
        else {
            let t = "";
            for (let e = 0; e < this.modules.length; e++) t += this.modules[e].getRules() + "\n";
            this.styleTag.textContent = t;
            let i = e.head || e;
            this.styleTag.parentNode != i && i.insertBefore(this.styleTag, i.firstChild);
        }
    }
    setNonce(t) {
        this.styleTag && this.styleTag.getAttribute("nonce") != t && this.styleTag.setAttribute("nonce", t);
    }
}
var Me = {
    8: "Backspace",
    9: "Tab",
    10: "Enter",
    12: "NumLock",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    44: "PrintScreen",
    45: "Insert",
    46: "Delete",
    59: ";",
    61: "=",
    91: "Meta",
    92: "Meta",
    106: "*",
    107: "+",
    108: ",",
    109: "-",
    110: ".",
    111: "/",
    144: "NumLock",
    145: "ScrollLock",
    160: "Shift",
    161: "Shift",
    162: "Control",
    163: "Control",
    164: "Alt",
    165: "Alt",
    173: "-",
    186: ";",
    187: "=",
    188: ",",
    189: "-",
    190: ".",
    191: "/",
    192: "`",
    219: "[",
    220: "\\",
    221: "]",
    222: "'",
},
    Ae = { 48: ")", 49: "!", 50: "@", 51: "#", 52: "$", 53: "%", 54: "^", 55: "&", 56: "*", 57: "(", 59: ":", 61: "+", 173: "_", 186: ":", 187: "+", 188: "<", 189: "_", 190: ">", 191: "?", 192: "~", 219: "{", 220: "|", 221: "}", 222: '"' };
"undefined" != typeof navigator && /Mac/.test(navigator.platform), "undefined" != typeof navigator && /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent);
for (var De = 0; De < 10; De++) Me[48 + De] = Me[96 + De] = String(De);
for (De = 1; De <= 24; De++) Me[De + 111] = "F" + De;
for (De = 65; De <= 90; De++) (Me[De] = String.fromCharCode(De + 32)), (Ae[De] = String.fromCharCode(De));
for (var Ie in Me) Ae.hasOwnProperty(Ie) || (Ae[Ie] = Me[Ie]);
function Oe(t) {
    let e;
    return (e = 11 == t.nodeType ? (t.getSelection ? t : t.ownerDocument) : t), e.getSelection();
}
function Be(t, e) {
    return !!e && (t == e || t.contains(1 != e.nodeType ? e.parentNode : e));
}
function qe(t, e) {
    if (!e.anchorNode) return !1;
    try {
        return Be(t, e.anchorNode);
    } catch (t) {
        return !1;
    }
}
function Ne(t) {
    return 3 == t.nodeType ? Ye(t, 0, t.nodeValue.length).getClientRects() : 1 == t.nodeType ? t.getClientRects() : [];
}
function Le(t, e, i, n) {
    return !!i && (_e(t, e, i, n, -1) || _e(t, e, i, n, 1));
}
function Re(t) {
    for (var e = 0; ; e++) if (!(t = t.previousSibling)) return e;
}
function Pe(t) {
    return 1 == t.nodeType && /^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(t.nodeName);
}
function _e(t, e, i, n, o) {
    for (; ;) {
        if (t == i && e == n) return !0;
        if (e == (o < 0 ? 0 : Fe(t))) {
            if ("DIV" == t.nodeName) return !1;
            let i = t.parentNode;
            if (!i || 1 != i.nodeType) return !1;
            (e = Re(t) + (o < 0 ? 0 : 1)), (t = i);
        } else {
            if (1 != t.nodeType) return !1;
            if (1 == (t = t.childNodes[e + (o < 0 ? -1 : 0)]).nodeType && "false" == t.contentEditable) return !1;
            e = o < 0 ? Fe(t) : 0;
        }
    }
}
function Fe(t) {
    return 3 == t.nodeType ? t.nodeValue.length : t.childNodes.length;
}
function Ve(t, e) {
    let i = e ? t.left : t.right;
    return { left: i, right: i, top: t.top, bottom: t.bottom };
}
function He(t) {
    let e = t.visualViewport;
    return e ? { left: 0, right: e.width, top: 0, bottom: e.height } : { left: 0, right: t.innerWidth, top: 0, bottom: t.innerHeight };
}
function ze(t, e) {
    let i = e.width / t.offsetWidth,
        n = e.height / t.offsetHeight;
    return ((i > 0.995 && i < 1.005) || !isFinite(i) || Math.abs(e.width - t.offsetWidth) < 1) && (i = 1), ((n > 0.995 && n < 1.005) || !isFinite(n) || Math.abs(e.height - t.offsetHeight) < 1) && (n = 1), { scaleX: i, scaleY: n };
}
class $e {
    constructor() {
        (this.anchorNode = null), (this.anchorOffset = 0), (this.focusNode = null), (this.focusOffset = 0);
    }
    eq(t) {
        return this.anchorNode == t.anchorNode && this.anchorOffset == t.anchorOffset && this.focusNode == t.focusNode && this.focusOffset == t.focusOffset;
    }
    setRange(t) {
        let { anchorNode: e, focusNode: i } = t;
        this.set(e, Math.min(t.anchorOffset, e ? Fe(e) : 0), i, Math.min(t.focusOffset, i ? Fe(i) : 0));
    }
    set(t, e, i, n) {
        (this.anchorNode = t), (this.anchorOffset = e), (this.focusNode = i), (this.focusOffset = n);
    }
}
let We,
    Ue = null;
function je(t) {
    if (t.setActive) return t.setActive();
    if (Ue) return t.focus(Ue);
    let e = [];
    for (let i = t; i && (e.push(i, i.scrollTop, i.scrollLeft), i != i.ownerDocument); i = i.parentNode);
    if (
        (t.focus(
            null == Ue
                ? {
                    get preventScroll() {
                        return (Ue = { preventScroll: !0 }), !0;
                    },
                }
                : void 0
        ),
            !Ue)
    ) {
        Ue = !1;
        for (let t = 0; t < e.length;) {
            let i = e[t++],
                n = e[t++],
                o = e[t++];
            i.scrollTop != n && (i.scrollTop = n), i.scrollLeft != o && (i.scrollLeft = o);
        }
    }
}
function Ye(t, e, i = e) {
    let n = We || (We = document.createRange());
    return n.setEnd(t, i), n.setStart(t, e), n;
}
function Ge(t, e, i, n) {
    let o = { key: e, code: e, keyCode: i, which: i, cancelable: !0 };
    n && ({ altKey: o.altKey, ctrlKey: o.ctrlKey, shiftKey: o.shiftKey, metaKey: o.metaKey } = n);
    let s = new KeyboardEvent("keydown", o);
    (s.synthetic = !0), t.dispatchEvent(s);
    let r = new KeyboardEvent("keyup", o);
    return (r.synthetic = !0), t.dispatchEvent(r), s.defaultPrevented || r.defaultPrevented;
}
function Ze(t) {
    for (; t.attributes.length;) t.removeAttributeNode(t.attributes[0]);
}
function Ke(t) {
    return t.scrollTop > Math.max(1, t.scrollHeight - t.clientHeight - 4);
}
function Xe(t, e) {
    for (let i = t, n = e; ;) {
        if (3 == i.nodeType && n > 0) return { node: i, offset: n };
        if (1 == i.nodeType && n > 0) {
            if ("false" == i.contentEditable) return null;
            (i = i.childNodes[n - 1]), (n = Fe(i));
        } else {
            if (!i.parentNode || Pe(i)) return null;
            (n = Re(i)), (i = i.parentNode);
        }
    }
}
function Je(t, e) {
    for (let i = t, n = e; ;) {
        if (3 == i.nodeType && n < i.nodeValue.length) return { node: i, offset: n };
        if (1 == i.nodeType && n < i.childNodes.length) {
            if ("false" == i.contentEditable) return null;
            (i = i.childNodes[n]), (n = 0);
        } else {
            if (!i.parentNode || Pe(i)) return null;
            (n = Re(i) + 1), (i = i.parentNode);
        }
    }
}
class Qe {
    constructor(t, e, i = !0) {
        (this.node = t), (this.offset = e), (this.precise = i);
    }
    static before(t, e) {
        return new Qe(t.parentNode, Re(t), e);
    }
    static after(t, e) {
        return new Qe(t.parentNode, Re(t) + 1, e);
    }
}
const ti = [];
class ei {
    constructor() {
        (this.parent = null), (this.dom = null), (this.flags = 2);
    }
    get overrideDOMText() {
        return null;
    }
    get posAtStart() {
        return this.parent ? this.parent.posBefore(this) : 0;
    }
    get posAtEnd() {
        return this.posAtStart + this.length;
    }
    posBefore(t) {
        let e = this.posAtStart;
        for (let i of this.children) {
            if (i == t) return e;
            e += i.length + i.breakAfter;
        }
        throw new RangeError("Invalid child in posBefore");
    }
    posAfter(t) {
        return this.posBefore(t) + t.length;
    }
    sync(t, e) {
        if (2 & this.flags) {
            let i,
                n = this.dom,
                o = null;
            for (let s of this.children) {
                if (7 & s.flags) {
                    if (!s.dom && (i = o ? o.nextSibling : n.firstChild)) {
                        let t = ei.get(i);
                        (!t || (!t.parent && t.canReuseDOM(s))) && s.reuseDOM(i);
                    }
                    s.sync(t, e), (s.flags &= -8);
                }
                if (((i = o ? o.nextSibling : n.firstChild), e && !e.written && e.node == n && i != s.dom && (e.written = !0), s.dom.parentNode == n)) for (; i && i != s.dom;) i = ii(i);
                else n.insertBefore(s.dom, i);
                o = s.dom;
            }
            for (i = o ? o.nextSibling : n.firstChild, i && e && e.node == n && (e.written = !0); i;) i = ii(i);
        } else if (1 & this.flags) for (let i of this.children) 7 & i.flags && (i.sync(t, e), (i.flags &= -8));
    }
    reuseDOM(t) { }
    localPosFromDOM(t, e) {
        let i;
        if (t == this.dom) i = this.dom.childNodes[e];
        else {
            let n = 0 == Fe(t) ? 0 : 0 == e ? -1 : 1;
            for (; ;) {
                let e = t.parentNode;
                if (e == this.dom) break;
                0 == n && e.firstChild != e.lastChild && (n = t == e.firstChild ? -1 : 1), (t = e);
            }
            i = n < 0 ? t : t.nextSibling;
        }
        if (i == this.dom.firstChild) return 0;
        for (; i && !ei.get(i);) i = i.nextSibling;
        if (!i) return this.length;
        for (let t = 0, e = 0; ; t++) {
            let n = this.children[t];
            if (n.dom == i) return e;
            e += n.length + n.breakAfter;
        }
    }
    domBoundsAround(t, e, i = 0) {
        let n = -1,
            o = -1,
            s = -1,
            r = -1;
        for (let l = 0, a = i, c = i; l < this.children.length; l++) {
            let i = this.children[l],
                h = a + i.length;
            if (a < t && h > e) return i.domBoundsAround(t, e, a);
            if ((h >= t && -1 == n && ((n = l), (o = a)), a > e && i.dom.parentNode == this.dom)) {
                (s = l), (r = c);
                break;
            }
            (c = h), (a = h + i.breakAfter);
        }
        return { from: o, to: r < 0 ? i + this.length : r, startDOM: (n ? this.children[n - 1].dom.nextSibling : null) || this.dom.firstChild, endDOM: s < this.children.length && s >= 0 ? this.children[s].dom : null };
    }
    markDirty(t = !1) {
        (this.flags |= 2), this.markParentsDirty(t);
    }
    markParentsDirty(t) {
        for (let e = this.parent; e; e = e.parent) {
            if ((t && (e.flags |= 2), 1 & e.flags)) return;
            (e.flags |= 1), (t = !1);
        }
    }
    setParent(t) {
        this.parent != t && ((this.parent = t), 7 & this.flags && this.markParentsDirty(!0));
    }
    setDOM(t) {
        this.dom != t && (this.dom && (this.dom.cmView = null), (this.dom = t), (t.cmView = this));
    }
    get rootView() {
        for (let t = this; ;) {
            let e = t.parent;
            if (!e) return t;
            t = e;
        }
    }
    replaceChildren(t, e, i = ti) {
        this.markDirty();
        for (let n = t; n < e; n++) {
            let t = this.children[n];
            t.parent == this && i.indexOf(t) < 0 && t.destroy();
        }
        i.length < 250 ? this.children.splice(t, e - t, ...i) : (this.children = [].concat(this.children.slice(0, t), i, this.children.slice(e)));
        for (let t = 0; t < i.length; t++) i[t].setParent(this);
    }
    ignoreMutation(t) {
        return !1;
    }
    ignoreEvent(t) {
        return !1;
    }
    childCursor(t = this.length) {
        return new ni(this.children, t, this.children.length);
    }
    childPos(t, e = 1) {
        return this.childCursor().findPos(t, e);
    }
    toString() {
        let t = this.constructor.name.replace("View", "");
        return t + (this.children.length ? "(" + this.children.join() + ")" : this.length ? "[" + ("Text" == t ? this.text : this.length) + "]" : "") + (this.breakAfter ? "#" : "");
    }
    static get(t) {
        return t.cmView;
    }
    get isEditable() {
        return !0;
    }
    get isWidget() {
        return !1;
    }
    get isHidden() {
        return !1;
    }
    merge(t, e, i, n, o, s) {
        return !1;
    }
    become(t) {
        return !1;
    }
    canReuseDOM(t) {
        return t.constructor == this.constructor && !(8 & (this.flags | t.flags));
    }
    getSide() {
        return 0;
    }
    destroy() {
        for (let t of this.children) t.parent == this && t.destroy();
        this.parent = null;
    }
}
function ii(t) {
    let e = t.nextSibling;
    return t.parentNode.removeChild(t), e;
}
ei.prototype.breakAfter = 0;
class ni {
    constructor(t, e, i) {
        (this.children = t), (this.pos = e), (this.i = i), (this.off = 0);
    }
    findPos(t, e = 1) {
        for (; ;) {
            if (t > this.pos || (t == this.pos && (e > 0 || 0 == this.i || this.children[this.i - 1].breakAfter))) return (this.off = t - this.pos), this;
            let i = this.children[--this.i];
            this.pos -= i.length + i.breakAfter;
        }
    }
}
function oi(t, e, i, n, o, s, r, l, a) {
    let { children: c } = t,
        h = c.length ? c[e] : null,
        d = s.length ? s[s.length - 1] : null,
        u = d ? d.breakAfter : r;
    if (!(e == n && h && !r && !u && s.length < 2 && h.merge(i, o, s.length ? d : null, 0 == i, l, a))) {
        if (n < c.length) {
            let t = c[n];
            t && (o < t.length || (t.breakAfter && (null == d ? void 0 : d.breakAfter)))
                ? (e == n && ((t = t.split(o)), (o = 0)), !u && d && t.merge(0, o, d, !0, 0, a) ? (s[s.length - 1] = t) : ((o || (t.children.length && !t.children[0].length)) && t.merge(0, o, null, !1, 0, a), s.push(t)))
                : (null == t ? void 0 : t.breakAfter) && (d ? (d.breakAfter = 1) : (r = 1)),
                n++;
        }
        for (
            h &&
            ((h.breakAfter = r),
                i > 0 &&
                (!r && s.length && h.merge(i, h.length, s[0], !1, l, 0)
                    ? (h.breakAfter = s.shift().breakAfter)
                    : (i < h.length || (h.children.length && 0 == h.children[h.children.length - 1].length)) && h.merge(i, h.length, null, !1, l, 0),
                    e++));
            e < n && s.length;

        )
            if (c[n - 1].become(s[s.length - 1])) n--, s.pop(), (a = s.length ? 0 : l);
            else {
                if (!c[e].become(s[0])) break;
                e++, s.shift(), (l = s.length ? 0 : a);
            }
        !s.length && e && n < c.length && !c[e - 1].breakAfter && c[n].merge(0, 0, c[e - 1], !1, l, a) && e--, (e < n || s.length) && t.replaceChildren(e, n, s);
    }
}
function si(t, e, i, n, o, s) {
    let r = t.childCursor(),
        { i: l, off: a } = r.findPos(i, 1),
        { i: c, off: h } = r.findPos(e, -1),
        d = e - i;
    for (let t of n) d += t.length;
    (t.length += d), oi(t, c, h, l, a, n, 0, o, s);
}
let ri = "undefined" != typeof navigator ? navigator : { userAgent: "", vendor: "", platform: "" },
    li = "undefined" != typeof document ? document : { documentElement: { style: {} } };
const ai = /Edge\/(\d+)/.exec(ri.userAgent),
    ci = /MSIE \d/.test(ri.userAgent),
    hi = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(ri.userAgent),
    di = !!(ci || hi || ai),
    ui = !di && /gecko\/(\d+)/i.test(ri.userAgent),
    pi = !di && /Chrome\/(\d+)/.exec(ri.userAgent),
    mi = "webkitFontSmoothing" in li.documentElement.style,
    gi = !di && /Apple Computer/.test(ri.vendor),
    fi = gi && (/Mobile\/\w+/.test(ri.userAgent) || ri.maxTouchPoints > 2);
var bi = {
    mac: fi || /Mac/.test(ri.platform),
    windows: /Win/.test(ri.platform),
    linux: /Linux|X11/.test(ri.platform),
    ie: di,
    ie_version: ci ? li.documentMode || 6 : hi ? +hi[1] : ai ? +ai[1] : 0,
    gecko: ui,
    gecko_version: ui ? +(/Firefox\/(\d+)/.exec(ri.userAgent) || [0, 0])[1] : 0,
    chrome: !!pi,
    chrome_version: pi ? +pi[1] : 0,
    ios: fi,
    android: /Android\b/.test(ri.userAgent),
    webkit: mi,
    safari: gi,
    webkit_version: mi ? +(/\bAppleWebKit\/(\d+)/.exec(ri.userAgent) || [0, 0])[1] : 0,
    tabSize: null != li.documentElement.style.tabSize ? "tab-size" : "-moz-tab-size",
};
class vi extends ei {
    constructor(t) {
        super(), (this.text = t);
    }
    get length() {
        return this.text.length;
    }
    createDOM(t) {
        this.setDOM(t || document.createTextNode(this.text));
    }
    sync(t, e) {
        this.dom || this.createDOM(), this.dom.nodeValue != this.text && (e && e.node == this.dom && (e.written = !0), (this.dom.nodeValue = this.text));
    }
    reuseDOM(t) {
        3 == t.nodeType && this.createDOM(t);
    }
    merge(t, e, i) {
        return !(8 & this.flags || (i && (!(i instanceof vi) || this.length - (e - t) + i.length > 256 || 8 & i.flags)) || ((this.text = this.text.slice(0, t) + (i ? i.text : "") + this.text.slice(e)), this.markDirty(), 0));
    }
    split(t) {
        let e = new vi(this.text.slice(t));
        return (this.text = this.text.slice(0, t)), this.markDirty(), (e.flags |= 8 & this.flags), e;
    }
    localPosFromDOM(t, e) {
        return t == this.dom ? e : e ? this.text.length : 0;
    }
    domAtPos(t) {
        return new Qe(this.dom, t);
    }
    domBoundsAround(t, e, i) {
        return { from: i, to: i + this.length, startDOM: this.dom, endDOM: this.dom.nextSibling };
    }
    coordsAt(t, e) {
        return (function (t, e, i) {
            let n = t.nodeValue.length;
            e > n && (e = n);
            let o = e,
                s = e,
                r = 0;
            (0 == e && i < 0) || (e == n && i >= 0) ? bi.chrome || bi.gecko || (e ? (o--, (r = 1)) : s < n && (s++, (r = -1))) : i < 0 ? o-- : s < n && s++;
            let l = Ye(t, o, s).getClientRects();
            if (!l.length) return null;
            let a = l[(r ? r < 0 : i >= 0) ? 0 : l.length - 1];
            return bi.safari && !r && 0 == a.width && (a = Array.prototype.find.call(l, (t) => t.width) || a), r ? Ve(a, r < 0) : a || null;
        })(this.dom, t, e);
    }
}
class yi extends ei {
    constructor(t, e = [], i = 0) {
        super(), (this.mark = t), (this.children = e), (this.length = i);
        for (let t of e) t.setParent(this);
    }
    setAttrs(t) {
        if ((Ze(t), this.mark.class && (t.className = this.mark.class), this.mark.attrs)) for (let e in this.mark.attrs) t.setAttribute(e, this.mark.attrs[e]);
        return t;
    }
    canReuseDOM(t) {
        return super.canReuseDOM(t) && !(8 & (this.flags | t.flags));
    }
    reuseDOM(t) {
        t.nodeName == this.mark.tagName.toUpperCase() && (this.setDOM(t), (this.flags |= 6));
    }
    sync(t, e) {
        this.dom ? 4 & this.flags && this.setAttrs(this.dom) : this.setDOM(this.setAttrs(document.createElement(this.mark.tagName))), super.sync(t, e);
    }
    merge(t, e, i, n, o, s) {
        return !((i && (!(i instanceof yi && i.mark.eq(this.mark)) || (t && o <= 0) || (e < this.length && s <= 0))) || (si(this, t, e, i ? i.children.slice() : [], o - 1, s - 1), this.markDirty(), 0));
    }
    split(t) {
        let e = [],
            i = 0,
            n = -1,
            o = 0;
        for (let s of this.children) {
            let r = i + s.length;
            r > t && e.push(i < t ? s.split(t - i) : s), n < 0 && i >= t && (n = o), (i = r), o++;
        }
        let s = this.length - t;
        return (this.length = t), n > -1 && ((this.children.length = n), this.markDirty()), new yi(this.mark, e, s);
    }
    domAtPos(t) {
        return Ci(this, t);
    }
    coordsAt(t, e) {
        return Si(this, t, e);
    }
}
class wi extends ei {
    static create(t, e, i) {
        return new wi(t, e, i);
    }
    constructor(t, e, i) {
        super(), (this.widget = t), (this.length = e), (this.side = i), (this.prevWidget = null);
    }
    split(t) {
        let e = wi.create(this.widget, this.length - t, this.side);
        return (this.length -= t), e;
    }
    sync(t) {
        (this.dom && this.widget.updateDOM(this.dom, t)) ||
            (this.dom && this.prevWidget && this.prevWidget.destroy(this.dom), (this.prevWidget = null), this.setDOM(this.widget.toDOM(t)), this.widget.editable || (this.dom.contentEditable = "false"));
    }
    getSide() {
        return this.side;
    }
    merge(t, e, i, n, o, s) {
        return !((i && (!(i instanceof wi && this.widget.compare(i.widget)) || (t > 0 && o <= 0) || (e < this.length && s <= 0))) || ((this.length = t + (i ? i.length : 0) + (this.length - e)), 0));
    }
    become(t) {
        return (
            t instanceof wi &&
            t.side == this.side &&
            this.widget.constructor == t.widget.constructor &&
            (this.widget.compare(t.widget) || this.markDirty(!0), this.dom && !this.prevWidget && (this.prevWidget = this.widget), (this.widget = t.widget), (this.length = t.length), !0)
        );
    }
    ignoreMutation() {
        return !0;
    }
    ignoreEvent(t) {
        return this.widget.ignoreEvent(t);
    }
    get overrideDOMText() {
        if (0 == this.length) return U.empty;
        let t = this;
        for (; t.parent;) t = t.parent;
        let { view: e } = t,
            i = e && e.state.doc,
            n = this.posAtStart;
        return i ? i.slice(n, n + this.length) : U.empty;
    }
    domAtPos(t) {
        return (this.length ? 0 == t : this.side > 0) ? Qe.before(this.dom) : Qe.after(this.dom, t == this.length);
    }
    domBoundsAround() {
        return null;
    }
    coordsAt(t, e) {
        let i = this.widget.coordsAt(this.dom, t, e);
        if (i) return i;
        let n = this.dom.getClientRects(),
            o = null;
        if (!n.length) return null;
        let s = this.side ? this.side < 0 : t > 0;
        for (let e = s ? n.length - 1 : 0; (o = n[e]), !(t > 0 ? 0 == e : e == n.length - 1 || o.top < o.bottom); e += s ? -1 : 1);
        return Ve(o, !s);
    }
    get isEditable() {
        return !1;
    }
    get isWidget() {
        return !0;
    }
    get isHidden() {
        return this.widget.isHidden;
    }
    destroy() {
        super.destroy(), this.dom && this.widget.destroy(this.dom);
    }
}
class xi extends ei {
    constructor(t) {
        super(), (this.side = t);
    }
    get length() {
        return 0;
    }
    merge() {
        return !1;
    }
    become(t) {
        return t instanceof xi && t.side == this.side;
    }
    split() {
        return new xi(this.side);
    }
    sync() {
        if (!this.dom) {
            let t = document.createElement("img");
            (t.className = "cm-widgetBuffer"), t.setAttribute("aria-hidden", "true"), this.setDOM(t);
        }
    }
    getSide() {
        return this.side;
    }
    domAtPos(t) {
        return this.side > 0 ? Qe.before(this.dom) : Qe.after(this.dom);
    }
    localPosFromDOM() {
        return 0;
    }
    domBoundsAround() {
        return null;
    }
    coordsAt(t) {
        return this.dom.getBoundingClientRect();
    }
    get overrideDOMText() {
        return U.empty;
    }
    get isHidden() {
        return !0;
    }
}
function Ci(t, e) {
    let i = t.dom,
        { children: n } = t,
        o = 0;
    for (let t = 0; o < n.length; o++) {
        let s = n[o],
            r = t + s.length;
        if (!(r == t && s.getSide() <= 0)) {
            if (e > t && e < r && s.dom.parentNode == i) return s.domAtPos(e - t);
            if (e <= t) break;
            t = r;
        }
    }
    for (let t = o; t > 0; t--) {
        let e = n[t - 1];
        if (e.dom.parentNode == i) return e.domAtPos(e.length);
    }
    for (let t = o; t < n.length; t++) {
        let e = n[t];
        if (e.dom.parentNode == i) return e.domAtPos(0);
    }
    return new Qe(i, 0);
}
function ki(t, e, i) {
    let n,
        { children: o } = t;
    i > 0 && e instanceof yi && o.length && (n = o[o.length - 1]) instanceof yi && n.mark.eq(e.mark) ? ki(n, e.children[0], i - 1) : (o.push(e), e.setParent(t)), (t.length += e.length);
}
function Si(t, e, i) {
    let n = null,
        o = -1,
        s = null,
        r = -1;
    !(function t(e, l) {
        for (let a = 0, c = 0; a < e.children.length && c <= l; a++) {
            let h = e.children[a],
                d = c + h.length;
            d >= l &&
                (h.children.length
                    ? t(h, l - c)
                    : (!s || (s.isHidden && (i > 0 || Ti(s, h)))) && (d > l || (c == d && h.getSide() > 0))
                        ? ((s = h), (r = l - c))
                        : (c < l || (c == d && h.getSide() < 0 && !h.isHidden)) && ((n = h), (o = l - c))),
                (c = d);
        }
    })(t, e);
    let l = (i < 0 ? n : s) || n || s;
    return l
        ? l.coordsAt(Math.max(0, l == n ? o : r), i)
        : (function (t) {
            let e = t.dom.lastChild;
            if (!e) return t.dom.getBoundingClientRect();
            let i = Ne(e);
            return i[i.length - 1] || null;
        })(t);
}
function Ti(t, e) {
    let i = t.coordsAt(0, 1),
        n = e.coordsAt(0, 1);
    return i && n && n.top < i.bottom;
}
function Ei(t, e) {
    for (let i in t) "class" == i && e.class ? (e.class += " " + t.class) : "style" == i && e.style ? (e.style += ";" + t.style) : (e[i] = t[i]);
    return e;
}
vi.prototype.children = wi.prototype.children = xi.prototype.children = ti;
const Mi = Object.create(null);
function Ai(t, e, i) {
    if (t == e) return !0;
    t || (t = Mi), e || (e = Mi);
    let n = Object.keys(t),
        o = Object.keys(e);
    if (n.length - (i && n.indexOf(i) > -1 ? 1 : 0) != o.length - (i && o.indexOf(i) > -1 ? 1 : 0)) return !1;
    for (let s of n) if (s != i && (-1 == o.indexOf(s) || t[s] !== e[s])) return !1;
    return !0;
}
function Di(t, e, i) {
    let n = !1;
    if (e) for (let o in e) (i && o in i) || ((n = !0), "style" == o ? (t.style.cssText = "") : t.removeAttribute(o));
    if (i) for (let o in i) (e && e[o] == i[o]) || ((n = !0), "style" == o ? (t.style.cssText = i[o]) : t.setAttribute(o, i[o]));
    return n;
}
function Ii(t) {
    let e = Object.create(null);
    for (let i = 0; i < t.attributes.length; i++) {
        let n = t.attributes[i];
        e[n.name] = n.value;
    }
    return e;
}
class Oi {
    eq(t) {
        return !1;
    }
    updateDOM(t, e) {
        return !1;
    }
    compare(t) {
        return this == t || (this.constructor == t.constructor && this.eq(t));
    }
    get estimatedHeight() {
        return -1;
    }
    get lineBreaks() {
        return 0;
    }
    ignoreEvent(t) {
        return !0;
    }
    coordsAt(t, e, i) {
        return null;
    }
    get isHidden() {
        return !1;
    }
    get editable() {
        return !1;
    }
    destroy(t) { }
}
var Bi = (function (t) {
    return (t[(t.Text = 0)] = "Text"), (t[(t.WidgetBefore = 1)] = "WidgetBefore"), (t[(t.WidgetAfter = 2)] = "WidgetAfter"), (t[(t.WidgetRange = 3)] = "WidgetRange"), t;
})(Bi || (Bi = {}));
class qi extends se {
    constructor(t, e, i, n) {
        super(), (this.startSide = t), (this.endSide = e), (this.widget = i), (this.spec = n);
    }
    get heightRelevant() {
        return !1;
    }
    static mark(t) {
        return new Ni(t);
    }
    static widget(t) {
        let e = Math.max(-1e4, Math.min(1e4, t.side || 0)),
            i = !!t.block;
        return (e += i && !t.inlineOrder ? (e > 0 ? 3e8 : -4e8) : e > 0 ? 1e8 : -1e8), new Ri(t, e, e, i, t.widget || null, !1);
    }
    static replace(t) {
        let e,
            i,
            n = !!t.block;
        if (t.isBlockGap) (e = -5e8), (i = 4e8);
        else {
            let { start: o, end: s } = Pi(t, n);
            (e = (o ? (n ? -3e8 : -1) : 5e8) - 1), (i = 1 + (s ? (n ? 2e8 : 1) : -6e8));
        }
        return new Ri(t, e, i, n, t.widget || null, !0);
    }
    static line(t) {
        return new Li(t);
    }
    static set(t, e = !1) {
        return ce.of(t, e);
    }
    hasHeight() {
        return !!this.widget && this.widget.estimatedHeight > -1;
    }
}
qi.none = ce.empty;
class Ni extends qi {
    constructor(t) {
        let { start: e, end: i } = Pi(t);
        super(e ? -1 : 5e8, i ? 1 : -6e8, null, t), (this.tagName = t.tagName || "span"), (this.class = t.class || ""), (this.attrs = t.attributes || null);
    }
    eq(t) {
        var e, i;
        return (
            this == t ||
            (t instanceof Ni &&
                this.tagName == t.tagName &&
                (this.class || (null === (e = this.attrs) || void 0 === e ? void 0 : e.class)) == (t.class || (null === (i = t.attrs) || void 0 === i ? void 0 : i.class)) &&
                Ai(this.attrs, t.attrs, "class"))
        );
    }
    range(t, e = t) {
        if (t >= e) throw new RangeError("Mark decorations may not be empty");
        return super.range(t, e);
    }
}
Ni.prototype.point = !1;
class Li extends qi {
    constructor(t) {
        super(-2e8, -2e8, null, t);
    }
    eq(t) {
        return t instanceof Li && this.spec.class == t.spec.class && Ai(this.spec.attributes, t.spec.attributes);
    }
    range(t, e = t) {
        if (e != t) throw new RangeError("Line decoration ranges must be zero-length");
        return super.range(t, e);
    }
}
(Li.prototype.mapMode = nt.TrackBefore), (Li.prototype.point = !0);
class Ri extends qi {
    constructor(t, e, i, n, o, s) {
        super(e, i, o, t), (this.block = n), (this.isReplace = s), (this.mapMode = n ? (e <= 0 ? nt.TrackBefore : nt.TrackAfter) : nt.TrackDel);
    }
    get type() {
        return this.startSide != this.endSide ? Bi.WidgetRange : this.startSide <= 0 ? Bi.WidgetBefore : Bi.WidgetAfter;
    }
    get heightRelevant() {
        return this.block || (!!this.widget && (this.widget.estimatedHeight >= 5 || this.widget.lineBreaks > 0));
    }
    eq(t) {
        return t instanceof Ri && ((e = this.widget) == (i = t.widget) || !!(e && i && e.compare(i))) && this.block == t.block && this.startSide == t.startSide && this.endSide == t.endSide;
        var e, i;
    }
    range(t, e = t) {
        if (this.isReplace && (t > e || (t == e && this.startSide > 0 && this.endSide <= 0))) throw new RangeError("Invalid range for replacement decoration");
        if (!this.isReplace && e != t) throw new RangeError("Widget decorations can only have zero-length ranges");
        return super.range(t, e);
    }
}
function Pi(t, e = !1) {
    let { inclusiveStart: i, inclusiveEnd: n } = t;
    return null == i && (i = t.inclusive), null == n && (n = t.inclusive), { start: null != i ? i : e, end: null != n ? n : e };
}
function _i(t, e, i, n = 0) {
    let o = i.length - 1;
    o >= 0 && i[o] + n >= t ? (i[o] = Math.max(i[o], e)) : i.push(t, e);
}
Ri.prototype.point = !0;
class Fi extends ei {
    constructor() {
        super(...arguments), (this.children = []), (this.length = 0), (this.prevAttrs = void 0), (this.attrs = null), (this.breakAfter = 0);
    }
    merge(t, e, i, n, o, s) {
        if (i) {
            if (!(i instanceof Fi)) return !1;
            this.dom || i.transferDOM(this);
        }
        return n && this.setDeco(i ? i.attrs : null), si(this, t, e, i ? i.children.slice() : [], o, s), !0;
    }
    split(t) {
        let e = new Fi();
        if (((e.breakAfter = this.breakAfter), 0 == this.length)) return e;
        let { i: i, off: n } = this.childPos(t);
        n && (e.append(this.children[i].split(n), 0), this.children[i].merge(n, this.children[i].length, null, !1, 0, 0), i++);
        for (let t = i; t < this.children.length; t++) e.append(this.children[t], 0);
        for (; i > 0 && 0 == this.children[i - 1].length;) this.children[--i].destroy();
        return (this.children.length = i), this.markDirty(), (this.length = t), e;
    }
    transferDOM(t) {
        this.dom && (this.markDirty(), t.setDOM(this.dom), (t.prevAttrs = void 0 === this.prevAttrs ? this.attrs : this.prevAttrs), (this.prevAttrs = void 0), (this.dom = null));
    }
    setDeco(t) {
        Ai(this.attrs, t) || (this.dom && ((this.prevAttrs = this.attrs), this.markDirty()), (this.attrs = t));
    }
    append(t, e) {
        ki(this, t, e);
    }
    addLineDeco(t) {
        let e = t.spec.attributes,
            i = t.spec.class;
        e && (this.attrs = Ei(e, this.attrs || {})), i && (this.attrs = Ei({ class: i }, this.attrs || {}));
    }
    domAtPos(t) {
        return Ci(this, t);
    }
    reuseDOM(t) {
        "DIV" == t.nodeName && (this.setDOM(t), (this.flags |= 6));
    }
    sync(t, e) {
        var i;
        this.dom
            ? 4 & this.flags && (Ze(this.dom), (this.dom.className = "cm-line"), (this.prevAttrs = this.attrs ? null : void 0))
            : (this.setDOM(document.createElement("div")), (this.dom.className = "cm-line"), (this.prevAttrs = this.attrs ? null : void 0)),
            void 0 !== this.prevAttrs && (Di(this.dom, this.prevAttrs, this.attrs), this.dom.classList.add("cm-line"), (this.prevAttrs = void 0)),
            super.sync(t, e);
        let n = this.dom.lastChild;
        for (; n && ei.get(n) instanceof yi;) n = n.lastChild;
        if (!(n && this.length && ("BR" == n.nodeName || 0 != (null === (i = ei.get(n)) || void 0 === i ? void 0 : i.isEditable) || (bi.ios && this.children.some((t) => t instanceof vi))))) {
            let t = document.createElement("BR");
            (t.cmIgnore = !0), this.dom.appendChild(t);
        }
    }
    measureTextSize() {
        if (0 == this.children.length || this.length > 20) return null;
        let t,
            e = 0;
        for (let i of this.children) {
            if (!(i instanceof vi) || /[^ -~]/.test(i.text)) return null;
            let n = Ne(i.dom);
            if (1 != n.length) return null;
            (e += n[0].width), (t = n[0].height);
        }
        return e ? { lineHeight: this.dom.getBoundingClientRect().height, charWidth: e / this.length, textHeight: t } : null;
    }
    coordsAt(t, e) {
        let i = Si(this, t, e);
        if (!this.children.length && i && this.parent) {
            let { heightOracle: t } = this.parent.view.viewState,
                e = i.bottom - i.top;
            if (Math.abs(e - t.lineHeight) < 2 && t.textHeight < e) {
                let n = (e - t.textHeight) / 2;
                return { top: i.top + n, bottom: i.bottom - n, left: i.left, right: i.left };
            }
        }
        return i;
    }
    become(t) {
        return t instanceof Fi && 0 == this.children.length && 0 == t.children.length && Ai(this.attrs, t.attrs) && this.breakAfter == t.breakAfter;
    }
    covers() {
        return !0;
    }
    static find(t, e) {
        for (let i = 0, n = 0; i < t.children.length; i++) {
            let o = t.children[i],
                s = n + o.length;
            if (s >= e) {
                if (o instanceof Fi) return o;
                if (s > e) break;
            }
            n = s + o.breakAfter;
        }
        return null;
    }
}
class Vi extends ei {
    constructor(t, e, i) {
        super(), (this.widget = t), (this.length = e), (this.deco = i), (this.breakAfter = 0), (this.prevWidget = null);
    }
    merge(t, e, i, n, o, s) {
        return !((i && (!(i instanceof Vi && this.widget.compare(i.widget)) || (t > 0 && o <= 0) || (e < this.length && s <= 0))) || ((this.length = t + (i ? i.length : 0) + (this.length - e)), 0));
    }
    domAtPos(t) {
        return 0 == t ? Qe.before(this.dom) : Qe.after(this.dom, t == this.length);
    }
    split(t) {
        let e = this.length - t;
        this.length = t;
        let i = new Vi(this.widget, e, this.deco);
        return (i.breakAfter = this.breakAfter), i;
    }
    get children() {
        return ti;
    }
    sync(t) {
        (this.dom && this.widget.updateDOM(this.dom, t)) ||
            (this.dom && this.prevWidget && this.prevWidget.destroy(this.dom), (this.prevWidget = null), this.setDOM(this.widget.toDOM(t)), this.widget.editable || (this.dom.contentEditable = "false"));
    }
    get overrideDOMText() {
        return this.parent ? this.parent.view.state.doc.slice(this.posAtStart, this.posAtEnd) : U.empty;
    }
    domBoundsAround() {
        return null;
    }
    become(t) {
        return (
            t instanceof Vi &&
            t.widget.constructor == this.widget.constructor &&
            (t.widget.compare(this.widget) || this.markDirty(!0),
                this.dom && !this.prevWidget && (this.prevWidget = this.widget),
                (this.widget = t.widget),
                (this.length = t.length),
                (this.deco = t.deco),
                (this.breakAfter = t.breakAfter),
                !0)
        );
    }
    ignoreMutation() {
        return !0;
    }
    ignoreEvent(t) {
        return this.widget.ignoreEvent(t);
    }
    get isEditable() {
        return !1;
    }
    get isWidget() {
        return !0;
    }
    coordsAt(t, e) {
        return this.widget.coordsAt(this.dom, t, e) || (this.widget instanceof Hi ? null : Ve(this.dom.getBoundingClientRect(), this.length ? 0 == t : e <= 0));
    }
    destroy() {
        super.destroy(), this.dom && this.widget.destroy(this.dom);
    }
    covers(t) {
        let { startSide: e, endSide: i } = this.deco;
        return e != i && (t < 0 ? e < 0 : i > 0);
    }
}
class Hi extends Oi {
    constructor(t) {
        super(), (this.height = t);
    }
    toDOM() {
        let t = document.createElement("div");
        return (t.className = "cm-gap"), this.updateDOM(t), t;
    }
    eq(t) {
        return t.height == this.height;
    }
    updateDOM(t) {
        return (t.style.height = this.height + "px"), !0;
    }
    get editable() {
        return !0;
    }
    get estimatedHeight() {
        return this.height;
    }
    ignoreEvent() {
        return !1;
    }
}
class zi {
    constructor(t, e, i, n) {
        (this.doc = t),
            (this.pos = e),
            (this.end = i),
            (this.disallowBlockEffectsFor = n),
            (this.content = []),
            (this.curLine = null),
            (this.breakAtStart = 0),
            (this.pendingBuffer = 0),
            (this.bufferMarks = []),
            (this.atCursorPos = !0),
            (this.openStart = -1),
            (this.openEnd = -1),
            (this.text = ""),
            (this.textOff = 0),
            (this.cursor = t.iter()),
            (this.skip = e);
    }
    posCovered() {
        if (0 == this.content.length) return !this.breakAtStart && this.doc.lineAt(this.pos).from != this.pos;
        let t = this.content[this.content.length - 1];
        return !(t.breakAfter || (t instanceof Vi && t.deco.endSide < 0));
    }
    getLine() {
        return this.curLine || (this.content.push((this.curLine = new Fi())), (this.atCursorPos = !0)), this.curLine;
    }
    flushBuffer(t = this.bufferMarks) {
        this.pendingBuffer && (this.curLine.append($i(new xi(-1), t), t.length), (this.pendingBuffer = 0));
    }
    addBlockWidget(t) {
        this.flushBuffer(), (this.curLine = null), this.content.push(t);
    }
    finish(t) {
        this.pendingBuffer && t <= this.bufferMarks.length ? this.flushBuffer() : (this.pendingBuffer = 0), this.posCovered() || (t && this.content.length && this.content[this.content.length - 1] instanceof Vi) || this.getLine();
    }
    buildText(t, e, i) {
        for (; t > 0;) {
            if (this.textOff == this.text.length) {
                let { value: e, lineBreak: i, done: n } = this.cursor.next(this.skip);
                if (((this.skip = 0), n)) throw new Error("Ran out of text content when drawing inline views");
                if (i) {
                    this.posCovered() || this.getLine(), this.content.length ? (this.content[this.content.length - 1].breakAfter = 1) : (this.breakAtStart = 1), this.flushBuffer(), (this.curLine = null), (this.atCursorPos = !0), t--;
                    continue;
                }
                (this.text = e), (this.textOff = 0);
            }
            let n = Math.min(this.text.length - this.textOff, t, 512);
            this.flushBuffer(e.slice(e.length - i)), this.getLine().append($i(new vi(this.text.slice(this.textOff, this.textOff + n)), e), i), (this.atCursorPos = !0), (this.textOff += n), (t -= n), (i = 0);
        }
    }
    span(t, e, i, n) {
        this.buildText(e - t, i, n), (this.pos = e), this.openStart < 0 && (this.openStart = n);
    }
    point(t, e, i, n, o, s) {
        if (this.disallowBlockEffectsFor[s] && i instanceof Ri) {
            if (i.block) throw new RangeError("Block decorations may not be specified via plugins");
            if (e > this.doc.lineAt(this.pos).to) throw new RangeError("Decorations that replace line breaks may not be specified via plugins");
        }
        let r = e - t;
        if (i instanceof Ri)
            if (i.block) i.startSide > 0 && !this.posCovered() && this.getLine(), this.addBlockWidget(new Vi(i.widget || Wi.block, r, i));
            else {
                let s = wi.create(i.widget || Wi.inline, r, r ? 0 : i.startSide),
                    l = this.atCursorPos && !s.isEditable && o <= n.length && (t < e || i.startSide > 0),
                    a = !s.isEditable && (t < e || o > n.length || i.startSide <= 0),
                    c = this.getLine();
                2 != this.pendingBuffer || l || s.isEditable || (this.pendingBuffer = 0),
                    this.flushBuffer(n),
                    l && (c.append($i(new xi(1), n), o), (o = n.length + Math.max(0, o - n.length))),
                    c.append($i(s, n), o),
                    (this.atCursorPos = a),
                    (this.pendingBuffer = a ? (t < e || o > n.length ? 1 : 2) : 0),
                    this.pendingBuffer && (this.bufferMarks = n.slice());
            }
        else this.doc.lineAt(this.pos).from == this.pos && this.getLine().addLineDeco(i);
        r && (this.textOff + r <= this.text.length ? (this.textOff += r) : ((this.skip += r - (this.text.length - this.textOff)), (this.text = ""), (this.textOff = 0)), (this.pos = e)), this.openStart < 0 && (this.openStart = o);
    }
    static build(t, e, i, n, o) {
        let s = new zi(t, e, i, o);
        return (s.openEnd = ce.spans(n, e, i, s)), s.openStart < 0 && (s.openStart = s.openEnd), s.finish(s.openEnd), s;
    }
}
function $i(t, e) {
    for (let i of e) t = new yi(i, [t], t.length);
    return t;
}
class Wi extends Oi {
    constructor(t) {
        super(), (this.tag = t);
    }
    eq(t) {
        return t.tag == this.tag;
    }
    toDOM() {
        return document.createElement(this.tag);
    }
    updateDOM(t) {
        return t.nodeName.toLowerCase() == this.tag;
    }
    get isHidden() {
        return !0;
    }
}
(Wi.inline = new Wi("span")), (Wi.block = new Wi("div"));
var Ui = (function (t) {
    return (t[(t.LTR = 0)] = "LTR"), (t[(t.RTL = 1)] = "RTL"), t;
})(Ui || (Ui = {}));
const ji = Ui.LTR,
    Yi = Ui.RTL;
function Gi(t) {
    let e = [];
    for (let i = 0; i < t.length; i++) e.push(1 << +t[i]);
    return e;
}
const Zi = Gi(
    "88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008"
),
    Ki = Gi(
        "4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333"
    ),
    Xi = Object.create(null),
    Ji = [];
for (let t of ["()", "[]", "{}"]) {
    let e = t.charCodeAt(0),
        i = t.charCodeAt(1);
    (Xi[e] = i), (Xi[i] = -e);
}
function Qi(t) {
    return t <= 247 ? Zi[t] : 1424 <= t && t <= 1524 ? 2 : 1536 <= t && t <= 1785 ? Ki[t - 1536] : 1774 <= t && t <= 2220 ? 4 : 8192 <= t && t <= 8204 ? 256 : 64336 <= t && t <= 65023 ? 4 : 1;
}
const tn = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/;
class en {
    get dir() {
        return this.level % 2 ? Yi : ji;
    }
    constructor(t, e, i) {
        (this.from = t), (this.to = e), (this.level = i);
    }
    side(t, e) {
        return (this.dir == e) == t ? this.to : this.from;
    }
    forward(t, e) {
        return t == (this.dir == e);
    }
    static find(t, e, i, n) {
        let o = -1;
        for (let s = 0; s < t.length; s++) {
            let r = t[s];
            if (r.from <= e && r.to >= e) {
                if (r.level == i) return s;
                (o < 0 || (0 != n ? (n < 0 ? r.from < e : r.to > e) : t[o].level > r.level)) && (o = s);
            }
        }
        if (o < 0) throw new RangeError("Index out of range");
        return o;
    }
}
function nn(t, e) {
    if (t.length != e.length) return !1;
    for (let i = 0; i < t.length; i++) {
        let n = t[i],
            o = e[i];
        if (n.from != o.from || n.to != o.to || n.direction != o.direction || !nn(n.inner, o.inner)) return !1;
    }
    return !0;
}
const on = [];
function sn(t, e, i, n, o, s, r) {
    let l = n % 2 ? 2 : 1;
    if (n % 2 == o % 2)
        for (let a = e, c = 0; a < i;) {
            let e = !0,
                h = !1;
            if (c == s.length || a < s[c].from) {
                let t = on[a];
                t != l && ((e = !1), (h = 16 == t));
            }
            let d = e || 1 != l ? null : [],
                u = e ? n : n + 1,
                p = a;
            t: for (; ;)
                if (c < s.length && p == s[c].from) {
                    if (h) break t;
                    let m = s[c];
                    if (!e)
                        for (let t = m.to, e = c + 1; ;) {
                            if (t == i) break t;
                            if (!(e < s.length && s[e].from == t)) {
                                if (on[t] == l) break t;
                                break;
                            }
                            t = s[e++].to;
                        }
                    c++, d ? d.push(m) : (m.from > a && r.push(new en(a, m.from, u)), rn(t, (m.direction == ji) != !(u % 2) ? n + 1 : n, o, m.inner, m.from, m.to, r), (a = m.to)), (p = m.to);
                } else {
                    if (p == i || (e ? on[p] != l : on[p] == l)) break;
                    p++;
                }
            d ? sn(t, a, p, n + 1, o, d, r) : a < p && r.push(new en(a, p, u)), (a = p);
        }
    else
        for (let a = i, c = s.length; a > e;) {
            let i = !0,
                h = !1;
            if (!c || a > s[c - 1].to) {
                let t = on[a - 1];
                t != l && ((i = !1), (h = 16 == t));
            }
            let d = i || 1 != l ? null : [],
                u = i ? n : n + 1,
                p = a;
            t: for (; ;)
                if (c && p == s[c - 1].to) {
                    if (h) break t;
                    let m = s[--c];
                    if (!i)
                        for (let t = m.from, i = c; ;) {
                            if (t == e) break t;
                            if (!i || s[i - 1].to != t) {
                                if (on[t - 1] == l) break t;
                                break;
                            }
                            t = s[--i].from;
                        }
                    d ? d.push(m) : (m.to < a && r.push(new en(m.to, a, u)), rn(t, (m.direction == ji) != !(u % 2) ? n + 1 : n, o, m.inner, m.from, m.to, r), (a = m.from)), (p = m.from);
                } else {
                    if (p == e || (i ? on[p - 1] != l : on[p - 1] == l)) break;
                    p--;
                }
            d ? sn(t, p, a, n + 1, o, d, r) : p < a && r.push(new en(p, a, u)), (a = p);
        }
}
function rn(t, e, i, n, o, s, r) {
    let l = e % 2 ? 2 : 1;
    !(function (t, e, i, n, o) {
        for (let s = 0; s <= n.length; s++) {
            let r = s ? n[s - 1].to : e,
                l = s < n.length ? n[s].from : i,
                a = s ? 256 : o;
            for (let e = r, i = a, n = a; e < l; e++) {
                let o = Qi(t.charCodeAt(e));
                512 == o ? (o = i) : 8 == o && 4 == n && (o = 16), (on[e] = 4 == o ? 2 : o), 7 & o && (n = o), (i = o);
            }
            for (let t = r, e = a, n = a; t < l; t++) {
                let o = on[t];
                if (128 == o) t < l - 1 && e == on[t + 1] && 24 & e ? (o = on[t] = e) : (on[t] = 256);
                else if (64 == o) {
                    let o = t + 1;
                    for (; o < l && 64 == on[o];) o++;
                    let s = (t && 8 == e) || (o < i && 8 == on[o]) ? (1 == n ? 1 : 8) : 256;
                    for (let e = t; e < o; e++) on[e] = s;
                    t = o - 1;
                } else 8 == o && 1 == n && (on[t] = 1);
                (e = o), 7 & o && (n = o);
            }
        }
    })(t, o, s, n, l),
        (function (t, e, i, n, o) {
            let s = 1 == o ? 2 : 1;
            for (let r = 0, l = 0, a = 0; r <= n.length; r++) {
                let c = r ? n[r - 1].to : e,
                    h = r < n.length ? n[r].from : i;
                for (let e, i, n, r = c; r < h; r++)
                    if ((i = Xi[(e = t.charCodeAt(r))]))
                        if (i < 0) {
                            for (let t = l - 3; t >= 0; t -= 3)
                                if (Ji[t + 1] == -i) {
                                    let e = Ji[t + 2],
                                        i = 2 & e ? o : 4 & e ? (1 & e ? s : o) : 0;
                                    i && (on[r] = on[Ji[t]] = i), (l = t);
                                    break;
                                }
                        } else {
                            if (189 == Ji.length) break;
                            (Ji[l++] = r), (Ji[l++] = e), (Ji[l++] = a);
                        }
                    else if (2 == (n = on[r]) || 1 == n) {
                        let t = n == o;
                        a = t ? 0 : 1;
                        for (let e = l - 3; e >= 0; e -= 3) {
                            let i = Ji[e + 2];
                            if (2 & i) break;
                            if (t) Ji[e + 2] |= 2;
                            else {
                                if (4 & i) break;
                                Ji[e + 2] |= 4;
                            }
                        }
                    }
            }
        })(t, o, s, n, l),
        (function (t, e, i, n) {
            for (let o = 0, s = n; o <= i.length; o++) {
                let r = o ? i[o - 1].to : t,
                    l = o < i.length ? i[o].from : e;
                for (let a = r; a < l;) {
                    let r = on[a];
                    if (256 == r) {
                        let r = a + 1;
                        for (; ;)
                            if (r == l) {
                                if (o == i.length) break;
                                (r = i[o++].to), (l = o < i.length ? i[o].from : e);
                            } else {
                                if (256 != on[r]) break;
                                r++;
                            }
                        let c = 1 == s,
                            h = c == (1 == (r < e ? on[r] : n)) ? (c ? 1 : 2) : n;
                        for (let e = r, n = o, s = n ? i[n - 1].to : t; e > a;) e == s && ((e = i[--n].from), (s = n ? i[n - 1].to : t)), (on[--e] = h);
                        a = r;
                    } else (s = r), a++;
                }
            }
        })(o, s, n, l),
        sn(t, o, s, e, i, n, r);
}
function ln(t) {
    return [new en(0, t, 0)];
}
let an = "";
function cn(t, e, i, n, o) {
    var s;
    let r = n.head - t.from,
        l = en.find(e, r, null !== (s = n.bidiLevel) && void 0 !== s ? s : -1, n.assoc),
        a = e[l],
        c = a.side(o, i);
    if (r == c) {
        let t = (l += o ? 1 : -1);
        if (t < 0 || t >= e.length) return null;
        (a = e[(l = t)]), (r = a.side(!o, i)), (c = a.side(o, i));
    }
    let h = et(t.text, r, a.forward(o, i));
    (h < a.from || h > a.to) && (h = c), (an = t.text.slice(Math.min(r, h), Math.max(r, h)));
    let d = l == (o ? e.length - 1 : 0) ? null : e[l + (o ? 1 : -1)];
    return d && h == c && d.level + (o ? 0 : 1) < a.level ? pt.cursor(d.side(!o, i) + t.from, d.forward(o, i) ? 1 : -1, d.level) : pt.cursor(h + t.from, a.forward(o, i) ? -1 : 1, a.level);
}
function hn(t, e, i) {
    for (let n = e; n < i; n++) {
        let e = Qi(t.charCodeAt(n));
        if (1 == e) return ji;
        if (2 == e || 4 == e) return Yi;
    }
    return ji;
}
const dn = ft.define(),
    un = ft.define(),
    pn = ft.define(),
    mn = ft.define(),
    gn = ft.define(),
    fn = ft.define(),
    bn = ft.define(),
    vn = ft.define(),
    yn = ft.define(),
    wn = ft.define({ combine: (t) => t.some((t) => t) }),
    xn = ft.define({ combine: (t) => t.some((t) => t) }),
    Cn = ft.define();
class kn {
    constructor(t, e = "nearest", i = "nearest", n = 5, o = 5, s = !1) {
        (this.range = t), (this.y = e), (this.x = i), (this.yMargin = n), (this.xMargin = o), (this.isSnapshot = s);
    }
    map(t) {
        return t.empty ? this : new kn(this.range.map(t), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot);
    }
    clip(t) {
        return this.range.to <= t.doc.length ? this : new kn(pt.cursor(t.doc.length), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot);
    }
}
const Sn = jt.define({ map: (t, e) => t.map(e) }),
    Tn = jt.define();
function En(t, e, i) {
    let n = t.facet(mn);
    n.length ? n[0](e) : window.onerror && window.onerror(String(e), i, void 0, void 0, e);
}
const Mn = ft.define({ combine: (t) => !t.length || t[0] });
let An = 0;
const Dn = ft.define({
    combine: (t) =>
        t.filter((e, i) => {
            for (let n = 0; n < i; n++) if (t[n].plugin == e.plugin) return !1;
            return !0;
        }),
});
class In {
    constructor(t, e, i, n, o) {
        (this.id = t), (this.create = e), (this.domEventHandlers = i), (this.domEventObservers = n), (this.baseExtensions = o(this)), (this.extension = this.baseExtensions.concat(Dn.of({ plugin: this, arg: void 0 })));
    }
    of(t) {
        return this.baseExtensions.concat(Dn.of({ plugin: this, arg: t }));
    }
    static define(t, e) {
        const { eventHandlers: i, eventObservers: n, provide: o, decorations: s } = e || {};
        return new In(An++, t, i, n, (t) => {
            let e = [];
            return (
                s &&
                e.push(
                    Nn.of((e) => {
                        let i = e.plugin(t);
                        return i ? s(i) : qi.none;
                    })
                ),
                o && e.push(o(t)),
                e
            );
        });
    }
    static fromClass(t, e) {
        return In.define((e, i) => new t(e, i), e);
    }
}
class On {
    constructor(t) {
        (this.spec = t), (this.mustUpdate = null), (this.value = null);
    }
    get plugin() {
        return this.spec && this.spec.plugin;
    }
    update(t) {
        if (this.value) {
            if (this.mustUpdate) {
                let e = this.mustUpdate;
                if (((this.mustUpdate = null), this.value.update))
                    try {
                        this.value.update(e);
                    } catch (i) {
                        if ((En(e.state, i, "CodeMirror plugin crashed"), this.value.destroy))
                            try {
                                this.value.destroy();
                            } catch (t) { }
                        this.deactivate();
                    }
            }
        } else if (this.spec)
            try {
                this.value = this.spec.plugin.create(t, this.spec.arg);
            } catch (e) {
                En(t.state, e, "CodeMirror plugin crashed"), this.deactivate();
            }
        return this;
    }
    destroy(t) {
        var e;
        if (null === (e = this.value) || void 0 === e ? void 0 : e.destroy)
            try {
                this.value.destroy();
            } catch (e) {
                En(t.state, e, "CodeMirror plugin crashed");
            }
    }
    deactivate() {
        this.spec = this.value = null;
    }
}
const Bn = ft.define(),
    qn = ft.define(),
    Nn = ft.define(),
    Ln = ft.define(),
    Rn = ft.define(),
    Pn = ft.define();
function _n(t, e) {
    let i = t.state.facet(Pn);
    if (!i.length) return i;
    let n = i.map((e) => (e instanceof Function ? e(t) : e)),
        o = [];
    return (
        ce.spans(n, e.from, e.to, {
            point() { },
            span(t, i, n, s) {
                let r = t - e.from,
                    l = i - e.from,
                    a = o;
                for (let t = n.length - 1; t >= 0; t--, s--) {
                    let i,
                        o = n[t].spec.bidiIsolate;
                    if ((null == o && (o = hn(e.text, r, l)), s > 0 && a.length && (i = a[a.length - 1]).to == r && i.direction == o)) (i.to = l), (a = i.inner);
                    else {
                        let t = { from: r, to: l, direction: o, inner: [] };
                        a.push(t), (a = t.inner);
                    }
                }
            },
        }),
        o
    );
}
const Fn = ft.define();
function Vn(t) {
    let e = 0,
        i = 0,
        n = 0,
        o = 0;
    for (let s of t.state.facet(Fn)) {
        let r = s(t);
        r && (null != r.left && (e = Math.max(e, r.left)), null != r.right && (i = Math.max(i, r.right)), null != r.top && (n = Math.max(n, r.top)), null != r.bottom && (o = Math.max(o, r.bottom)));
    }
    return { left: e, right: i, top: n, bottom: o };
}
const Hn = ft.define();
class zn {
    constructor(t, e, i, n) {
        (this.fromA = t), (this.toA = e), (this.fromB = i), (this.toB = n);
    }
    join(t) {
        return new zn(Math.min(this.fromA, t.fromA), Math.max(this.toA, t.toA), Math.min(this.fromB, t.fromB), Math.max(this.toB, t.toB));
    }
    addToSet(t) {
        let e = t.length,
            i = this;
        for (; e > 0; e--) {
            let n = t[e - 1];
            if (!(n.fromA > i.toA)) {
                if (n.toA < i.fromA) break;
                (i = i.join(n)), t.splice(e - 1, 1);
            }
        }
        return t.splice(e, 0, i), t;
    }
    static extendWithRanges(t, e) {
        if (0 == e.length) return t;
        let i = [];
        for (let n = 0, o = 0, s = 0, r = 0; ; n++) {
            let l = n == t.length ? null : t[n],
                a = s - r,
                c = l ? l.fromB : 1e9;
            for (; o < e.length && e[o] < c;) {
                let t = e[o],
                    n = e[o + 1],
                    s = Math.max(r, t),
                    l = Math.min(c, n);
                if ((s <= l && new zn(s + a, l + a, s, l).addToSet(i), n > c)) break;
                o += 2;
            }
            if (!l) return i;
            new zn(l.fromA, l.toA, l.fromB, l.toB).addToSet(i), (s = l.toA), (r = l.toB);
        }
    }
}
class $n {
    constructor(t, e, i) {
        (this.view = t), (this.state = e), (this.transactions = i), (this.flags = 0), (this.startState = t.state), (this.changes = st.empty(this.startState.doc.length));
        for (let t of i) this.changes = this.changes.compose(t.changes);
        let n = [];
        this.changes.iterChangedRanges((t, e, i, o) => n.push(new zn(t, e, i, o))), (this.changedRanges = n);
    }
    static create(t, e, i) {
        return new $n(t, e, i);
    }
    get viewportChanged() {
        return (4 & this.flags) > 0;
    }
    get viewportMoved() {
        return (8 & this.flags) > 0;
    }
    get heightChanged() {
        return (2 & this.flags) > 0;
    }
    get geometryChanged() {
        return this.docChanged || (18 & this.flags) > 0;
    }
    get focusChanged() {
        return (1 & this.flags) > 0;
    }
    get docChanged() {
        return !this.changes.empty;
    }
    get selectionSet() {
        return this.transactions.some((t) => t.selection);
    }
    get empty() {
        return 0 == this.flags && 0 == this.transactions.length;
    }
}
class Wn extends ei {
    get length() {
        return this.view.state.doc.length;
    }
    constructor(t) {
        super(),
            (this.view = t),
            (this.decorations = []),
            (this.dynamicDecorationMap = [!1]),
            (this.domChanged = null),
            (this.hasComposition = null),
            (this.markedForComposition = new Set()),
            (this.editContextFormatting = qi.none),
            (this.lastCompositionAfterCursor = !1),
            (this.minWidth = 0),
            (this.minWidthFrom = 0),
            (this.minWidthTo = 0),
            (this.impreciseAnchor = null),
            (this.impreciseHead = null),
            (this.forceSelection = !1),
            (this.lastUpdate = Date.now()),
            this.setDOM(t.contentDOM),
            (this.children = [new Fi()]),
            this.children[0].setParent(this),
            this.updateDeco(),
            this.updateInner([new zn(0, 0, 0, t.state.doc.length)], 0, null);
    }
    update(t) {
        var e;
        let i = t.changedRanges;
        this.minWidth > 0 &&
            i.length &&
            (i.every(({ fromA: t, toA: e }) => e < this.minWidthFrom || t > this.minWidthTo)
                ? ((this.minWidthFrom = t.changes.mapPos(this.minWidthFrom, 1)), (this.minWidthTo = t.changes.mapPos(this.minWidthTo, 1)))
                : (this.minWidth = this.minWidthFrom = this.minWidthTo = 0)),
            this.updateEditContextFormatting(t);
        let n = -1;
        this.view.inputState.composing >= 0 &&
            !this.view.observer.editContext &&
            ((null === (e = this.domChanged) || void 0 === e ? void 0 : e.newSel)
                ? (n = this.domChanged.newSel.head)
                : (function (t, e) {
                    let i = !1;
                    return (
                        e &&
                        t.iterChangedRanges((t, n) => {
                            t < e.to && n > e.from && (i = !0);
                        }),
                        i
                    );
                })(t.changes, this.hasComposition) ||
                t.selectionSet ||
                (n = t.state.selection.main.head));
        let o =
            n > -1
                ? (function (t, e, i) {
                    let n = Un(t, i);
                    if (!n) return null;
                    let { node: o, from: s, to: r } = n,
                        l = o.nodeValue;
                    if (/[\n\r]/.test(l)) return null;
                    if (t.state.doc.sliceString(n.from, n.to) != l) return null;
                    let a = e.invertedDesc,
                        c = new zn(a.mapPos(s), a.mapPos(r), s, r),
                        h = [];
                    for (let e = o.parentNode; ; e = e.parentNode) {
                        let i = ei.get(e);
                        if (i instanceof yi) h.push({ node: e, deco: i.mark });
                        else {
                            if (i instanceof Fi || ("DIV" == e.nodeName && e.parentNode == t.contentDOM)) return { range: c, text: o, marks: h, line: e };
                            if (e == t.contentDOM) return null;
                            h.push({ node: e, deco: new Ni({ inclusive: !0, attributes: Ii(e), tagName: e.tagName.toLowerCase() }) });
                        }
                    }
                })(this.view, t.changes, n)
                : null;
        if (((this.domChanged = null), this.hasComposition)) {
            this.markedForComposition.clear();
            let { from: e, to: n } = this.hasComposition;
            i = new zn(e, n, t.changes.mapPos(e, -1), t.changes.mapPos(n, 1)).addToSet(i.slice());
        }
        (this.hasComposition = o ? { from: o.range.fromB, to: o.range.toB } : null), (bi.ie || bi.chrome) && !o && t && t.state.doc.lines != t.startState.doc.lines && (this.forceSelection = !0);
        let s = (function (t, e, i) {
            let n = new jn();
            return ce.compare(t, e, i, n), n.changes;
        })(this.decorations, this.updateDeco(), t.changes);
        return (i = zn.extendWithRanges(i, s)), !!(7 & this.flags || 0 != i.length) && (this.updateInner(i, t.startState.doc.length, o), t.transactions.length && (this.lastUpdate = Date.now()), !0);
    }
    updateInner(t, e, i) {
        (this.view.viewState.mustMeasureContent = !0), this.updateChildren(t, e, i);
        let { observer: n } = this.view;
        n.ignore(() => {
            (this.dom.style.height = this.view.viewState.contentHeight / this.view.scaleY + "px"), (this.dom.style.flexBasis = this.minWidth ? this.minWidth + "px" : "");
            let t = bi.chrome || bi.ios ? { node: n.selectionRange.focusNode, written: !1 } : void 0;
            this.sync(this.view, t), (this.flags &= -8), t && (t.written || n.selectionRange.focusNode != t.node) && (this.forceSelection = !0), (this.dom.style.height = "");
        }),
            this.markedForComposition.forEach((t) => (t.flags &= -9));
        let o = [];
        if (this.view.viewport.from || this.view.viewport.to < this.view.state.doc.length) for (let t of this.children) t instanceof Vi && t.widget instanceof Hi && o.push(t.dom);
        n.updateGaps(o);
    }
    updateChildren(t, e, i) {
        let n = i ? i.range.addToSet(t.slice()) : t,
            o = this.childCursor(e);
        for (let t = n.length - 1; ; t--) {
            let e = t >= 0 ? n[t] : null;
            if (!e) break;
            let s,
                r,
                l,
                a,
                { fromA: c, toA: h, fromB: d, toB: u } = e;
            if (i && i.range.fromB < u && i.range.toB > d) {
                let t = zi.build(this.view.state.doc, d, i.range.fromB, this.decorations, this.dynamicDecorationMap),
                    e = zi.build(this.view.state.doc, i.range.toB, u, this.decorations, this.dynamicDecorationMap);
                (r = t.breakAtStart), (l = t.openStart), (a = e.openEnd);
                let n = this.compositionView(i);
                e.breakAtStart ? (n.breakAfter = 1) : e.content.length && n.merge(n.length, n.length, e.content[0], !1, e.openStart, 0) && ((n.breakAfter = e.content[0].breakAfter), e.content.shift()),
                    t.content.length && n.merge(0, 0, t.content[t.content.length - 1], !0, 0, t.openEnd) && t.content.pop(),
                    (s = t.content.concat(n).concat(e.content));
            } else ({ content: s, breakAtStart: r, openStart: l, openEnd: a } = zi.build(this.view.state.doc, d, u, this.decorations, this.dynamicDecorationMap));
            let { i: p, off: m } = o.findPos(h, 1),
                { i: g, off: f } = o.findPos(c, -1);
            oi(this, g, f, p, m, s, r, l, a);
        }
        i && this.fixCompositionDOM(i);
    }
    updateEditContextFormatting(t) {
        this.editContextFormatting = this.editContextFormatting.map(t.changes);
        for (let e of t.transactions) for (let t of e.effects) t.is(Tn) && (this.editContextFormatting = t.value);
    }
    compositionView(t) {
        let e = new vi(t.text.nodeValue);
        e.flags |= 8;
        for (let { deco: i } of t.marks) e = new yi(i, [e], e.length);
        let i = new Fi();
        return i.append(e, 0), i;
    }
    fixCompositionDOM(t) {
        let e = (t, e) => {
            (e.flags |= 8 | (e.children.some((t) => 7 & t.flags) ? 1 : 0)), this.markedForComposition.add(e);
            let i = ei.get(t);
            i && i != e && (i.dom = null), e.setDOM(t);
        },
            i = this.childPos(t.range.fromB, 1),
            n = this.children[i.i];
        e(t.line, n);
        for (let o = t.marks.length - 1; o >= -1; o--) (i = n.childPos(i.off, 1)), (n = n.children[i.i]), e(o >= 0 ? t.marks[o].node : t.text, n);
    }
    updateSelection(t = !1, e = !1) {
        (!t && this.view.observer.selectionRange.focusNode) || this.view.observer.readSelectionRange();
        let i = this.view.root.activeElement,
            n = i == this.dom,
            o = !n && !(this.view.state.facet(Mn) || this.dom.tabIndex > -1) && qe(this.dom, this.view.observer.selectionRange) && !(i && this.dom.contains(i));
        if (!(n || e || o)) return;
        let s = this.forceSelection;
        this.forceSelection = !1;
        let r = this.view.state.selection.main,
            l = this.moveToLine(this.domAtPos(r.anchor)),
            a = r.empty ? l : this.moveToLine(this.domAtPos(r.head));
        if (
            bi.gecko &&
            r.empty &&
            !this.hasComposition &&
            1 == (c = l).node.nodeType &&
            c.node.firstChild &&
            (0 == c.offset || "false" == c.node.childNodes[c.offset - 1].contentEditable) &&
            (c.offset == c.node.childNodes.length || "false" == c.node.childNodes[c.offset].contentEditable)
        ) {
            let t = document.createTextNode("");
            this.view.observer.ignore(() => l.node.insertBefore(t, l.node.childNodes[l.offset] || null)), (l = a = new Qe(t, 0)), (s = !0);
        }
        var c;
        let h = this.view.observer.selectionRange;
        (!s && h.focusNode && ((Le(l.node, l.offset, h.anchorNode, h.anchorOffset) && Le(a.node, a.offset, h.focusNode, h.focusOffset)) || this.suppressWidgetCursorChange(h, r))) ||
            (this.view.observer.ignore(() => {
                bi.android &&
                    bi.chrome &&
                    this.dom.contains(h.focusNode) &&
                    (function (t, e) {
                        for (let i = t; i && i != e; i = i.assignedSlot || i.parentNode) if (1 == i.nodeType && "false" == i.contentEditable) return !0;
                        return !1;
                    })(h.focusNode, this.dom) &&
                    (this.dom.blur(), this.dom.focus({ preventScroll: !0 }));
                let t = Oe(this.view.root);
                if (t)
                    if (r.empty) {
                        if (bi.gecko) {
                            let t = ((e = l.node), (n = l.offset), 1 != e.nodeType ? 0 : (n && "false" == e.childNodes[n - 1].contentEditable ? 1 : 0) | (n < e.childNodes.length && "false" == e.childNodes[n].contentEditable ? 2 : 0));
                            if (t && 3 != t) {
                                let e = (1 == t ? Xe : Je)(l.node, l.offset);
                                e && (l = new Qe(e.node, e.offset));
                            }
                        }
                        t.collapse(l.node, l.offset), null != r.bidiLevel && void 0 !== t.caretBidiLevel && (t.caretBidiLevel = r.bidiLevel);
                    } else if (t.extend) {
                        t.collapse(l.node, l.offset);
                        try {
                            t.extend(a.node, a.offset);
                        } catch (t) { }
                    } else {
                        let e = document.createRange();
                        r.anchor > r.head && ([l, a] = [a, l]), e.setEnd(a.node, a.offset), e.setStart(l.node, l.offset), t.removeAllRanges(), t.addRange(e);
                    }
                var e, n;
                o && this.view.root.activeElement == this.dom && (this.dom.blur(), i && i.focus());
            }),
                this.view.observer.setSelectionRange(l, a)),
            (this.impreciseAnchor = l.precise ? null : new Qe(h.anchorNode, h.anchorOffset)),
            (this.impreciseHead = a.precise ? null : new Qe(h.focusNode, h.focusOffset));
    }
    suppressWidgetCursorChange(t, e) {
        return this.hasComposition && e.empty && Le(t.focusNode, t.focusOffset, t.anchorNode, t.anchorOffset) && this.posFromDOM(t.focusNode, t.focusOffset) == e.head;
    }
    enforceCursorAssoc() {
        if (this.hasComposition) return;
        let { view: t } = this,
            e = t.state.selection.main,
            i = Oe(t.root),
            { anchorNode: n, anchorOffset: o } = t.observer.selectionRange;
        if (!(i && e.empty && e.assoc && i.modify)) return;
        let s = Fi.find(this, e.head);
        if (!s) return;
        let r = s.posAtStart;
        if (e.head == r || e.head == r + s.length) return;
        let l = this.coordsAt(e.head, -1),
            a = this.coordsAt(e.head, 1);
        if (!l || !a || l.bottom > a.top) return;
        let c = this.domAtPos(e.head + e.assoc);
        i.collapse(c.node, c.offset), i.modify("move", e.assoc < 0 ? "forward" : "backward", "lineboundary"), t.observer.readSelectionRange();
        let h = t.observer.selectionRange;
        t.docView.posFromDOM(h.anchorNode, h.anchorOffset) != e.from && i.collapse(n, o);
    }
    moveToLine(t) {
        let e,
            i = this.dom;
        if (t.node != i) return t;
        for (let n = t.offset; !e && n < i.childNodes.length; n++) {
            let t = ei.get(i.childNodes[n]);
            t instanceof Fi && (e = t.domAtPos(0));
        }
        for (let n = t.offset - 1; !e && n >= 0; n--) {
            let t = ei.get(i.childNodes[n]);
            t instanceof Fi && (e = t.domAtPos(t.length));
        }
        return e ? new Qe(e.node, e.offset, !0) : t;
    }
    nearest(t) {
        for (let e = t; e;) {
            let t = ei.get(e);
            if (t && t.rootView == this) return t;
            e = e.parentNode;
        }
        return null;
    }
    posFromDOM(t, e) {
        let i = this.nearest(t);
        if (!i) throw new RangeError("Trying to find position for a DOM position outside of the document");
        return i.localPosFromDOM(t, e) + i.posAtStart;
    }
    domAtPos(t) {
        let { i: e, off: i } = this.childCursor().findPos(t, -1);
        for (; e < this.children.length - 1;) {
            let t = this.children[e];
            if (i < t.length || t instanceof Fi) break;
            e++, (i = 0);
        }
        return this.children[e].domAtPos(i);
    }
    coordsAt(t, e) {
        let i = null,
            n = 0;
        for (let o = this.length, s = this.children.length - 1; s >= 0; s--) {
            let r = this.children[s],
                l = o - r.breakAfter,
                a = l - r.length;
            if (l < t) break;
            if (a <= t && (a < t || r.covers(-1)) && (l > t || r.covers(1)) && (!i || (r instanceof Fi && !(i instanceof Fi && e >= 0)))) (i = r), (n = a);
            else if (i && a == t && l == t && r instanceof Vi && Math.abs(e) < 2) {
                if (r.deco.startSide < 0) break;
                s && (i = null);
            }
            o = a;
        }
        return i ? i.coordsAt(t - n, e) : null;
    }
    coordsForChar(t) {
        let { i: e, off: i } = this.childPos(t, 1),
            n = this.children[e];
        if (!(n instanceof Fi)) return null;
        for (; n.children.length;) {
            let { i: t, off: e } = n.childPos(i, 1);
            for (; ; t++) {
                if (t == n.children.length) return null;
                if ((n = n.children[t]).length) break;
            }
            i = e;
        }
        if (!(n instanceof vi)) return null;
        let o = et(n.text, i);
        if (o == i) return null;
        let s = Ye(n.dom, i, o).getClientRects();
        for (let t = 0; t < s.length; t++) {
            let e = s[t];
            if (t == s.length - 1 || (e.top < e.bottom && e.left < e.right)) return e;
        }
        return null;
    }
    measureVisibleLineHeights(t) {
        let e = [],
            { from: i, to: n } = t,
            o = this.view.contentDOM.clientWidth,
            s = o > Math.max(this.view.scrollDOM.clientWidth, this.minWidth) + 1,
            r = -1,
            l = this.view.textDirection == Ui.LTR;
        for (let t = 0, a = 0; a < this.children.length; a++) {
            let c = this.children[a],
                h = t + c.length;
            if (h > n) break;
            if (t >= i) {
                let i = c.dom.getBoundingClientRect();
                if ((e.push(i.height), s)) {
                    let e = c.dom.lastChild,
                        n = e ? Ne(e) : [];
                    if (n.length) {
                        let e = n[n.length - 1],
                            s = l ? e.right - i.left : i.right - e.left;
                        s > r && ((r = s), (this.minWidth = o), (this.minWidthFrom = t), (this.minWidthTo = h));
                    }
                }
            }
            t = h + c.breakAfter;
        }
        return e;
    }
    textDirectionAt(t) {
        let { i: e } = this.childPos(t, 1);
        return "rtl" == getComputedStyle(this.children[e].dom).direction ? Ui.RTL : Ui.LTR;
    }
    measureTextSize() {
        for (let t of this.children)
            if (t instanceof Fi) {
                let e = t.measureTextSize();
                if (e) return e;
            }
        let t,
            e,
            i,
            n = document.createElement("div");
        return (
            (n.className = "cm-line"),
            (n.style.width = "99999px"),
            (n.style.position = "absolute"),
            (n.textContent = "abc def ghi jkl mno pqr stu"),
            this.view.observer.ignore(() => {
                this.dom.appendChild(n);
                let o = Ne(n.firstChild)[0];
                (t = n.getBoundingClientRect().height), (e = o ? o.width / 27 : 7), (i = o ? o.height : t), n.remove();
            }),
            { lineHeight: t, charWidth: e, textHeight: i }
        );
    }
    childCursor(t = this.length) {
        let e = this.children.length;
        return e && (t -= this.children[--e].length), new ni(this.children, t, e);
    }
    computeBlockGapDeco() {
        let t = [],
            e = this.view.viewState;
        for (let i = 0, n = 0; ; n++) {
            let o = n == e.viewports.length ? null : e.viewports[n],
                s = o ? o.from - 1 : this.length;
            if (s > i) {
                let n = (e.lineBlockAt(s).bottom - e.lineBlockAt(i).top) / this.view.scaleY;
                t.push(qi.replace({ widget: new Hi(n), block: !0, inclusive: !0, isBlockGap: !0 }).range(i, s));
            }
            if (!o) break;
            i = o.to + 1;
        }
        return qi.set(t);
    }
    updateDeco() {
        let t = 1,
            e = this.view.state.facet(Nn).map((e) => ((this.dynamicDecorationMap[t++] = "function" == typeof e) ? e(this.view) : e)),
            i = !1,
            n = this.view.state.facet(Ln).map((t, e) => {
                let n = "function" == typeof t;
                return n && (i = !0), n ? t(this.view) : t;
            });
        for (n.length && ((this.dynamicDecorationMap[t++] = i), e.push(ce.join(n))), this.decorations = [this.editContextFormatting, ...e, this.computeBlockGapDeco(), this.view.viewState.lineGapDeco]; t < this.decorations.length;)
            this.dynamicDecorationMap[t++] = !1;
        return this.decorations;
    }
    scrollIntoView(t) {
        if (t.isSnapshot) {
            let e = this.view.viewState.lineBlockAt(t.range.head);
            return (this.view.scrollDOM.scrollTop = e.top - t.yMargin), void (this.view.scrollDOM.scrollLeft = t.xMargin);
        }
        for (let e of this.view.state.facet(Cn))
            try {
                if (e(this.view, t.range, t)) return !0;
            } catch (t) {
                En(this.view.state, t, "scroll handler");
            }
        let e,
            { range: i } = t,
            n = this.coordsAt(i.head, i.empty ? i.assoc : i.head > i.anchor ? -1 : 1);
        if (!n) return;
        !i.empty && (e = this.coordsAt(i.anchor, i.anchor > i.head ? -1 : 1)) && (n = { left: Math.min(n.left, e.left), top: Math.min(n.top, e.top), right: Math.max(n.right, e.right), bottom: Math.max(n.bottom, e.bottom) });
        let o = Vn(this.view),
            s = { left: n.left - o.left, top: n.top - o.top, right: n.right + o.right, bottom: n.bottom + o.bottom },
            { offsetWidth: r, offsetHeight: l } = this.view.scrollDOM;
        !(function (t, e, i, n, o, s, r, l) {
            let a = t.ownerDocument,
                c = a.defaultView || window;
            for (let h = t, d = !1; h && !d;)
                if (1 == h.nodeType) {
                    let t,
                        u = h == a.body,
                        p = 1,
                        m = 1;
                    if (u) t = He(c);
                    else {
                        if ((/^(fixed|sticky)$/.test(getComputedStyle(h).position) && (d = !0), h.scrollHeight <= h.clientHeight && h.scrollWidth <= h.clientWidth)) {
                            h = h.assignedSlot || h.parentNode;
                            continue;
                        }
                        let e = h.getBoundingClientRect();
                        ({ scaleX: p, scaleY: m } = ze(h, e)), (t = { left: e.left, right: e.left + h.clientWidth * p, top: e.top, bottom: e.top + h.clientHeight * m });
                    }
                    let g = 0,
                        f = 0;
                    if ("nearest" == o)
                        e.top < t.top
                            ? ((f = e.top - (t.top + r)), i > 0 && e.bottom > t.bottom + f && (f = e.bottom - t.bottom + r))
                            : e.bottom > t.bottom && ((f = e.bottom - t.bottom + r), i < 0 && e.top - f < t.top && (f = e.top - (t.top + r)));
                    else {
                        let n = e.bottom - e.top,
                            s = t.bottom - t.top;
                        f = ("center" == o && n <= s ? e.top + n / 2 - s / 2 : "start" == o || ("center" == o && i < 0) ? e.top - r : e.bottom - s + r) - t.top;
                    }
                    if (
                        ("nearest" == n
                            ? e.left < t.left
                                ? ((g = e.left - (t.left + s)), i > 0 && e.right > t.right + g && (g = e.right - t.right + s))
                                : e.right > t.right && ((g = e.right - t.right + s), i < 0 && e.left < t.left + g && (g = e.left - (t.left + s)))
                            : (g = ("center" == n ? e.left + (e.right - e.left) / 2 - (t.right - t.left) / 2 : ("start" == n) == l ? e.left - s : e.right - (t.right - t.left) + s) - t.left),
                            g || f)
                    )
                        if (u) c.scrollBy(g, f);
                        else {
                            let t = 0,
                                i = 0;
                            if (f) {
                                let t = h.scrollTop;
                                (h.scrollTop += f / m), (i = (h.scrollTop - t) * m);
                            }
                            if (g) {
                                let e = h.scrollLeft;
                                (h.scrollLeft += g / p), (t = (h.scrollLeft - e) * p);
                            }
                            (e = { left: e.left - t, top: e.top - i, right: e.right - t, bottom: e.bottom - i }), t && Math.abs(t - g) < 1 && (n = "nearest"), i && Math.abs(i - f) < 1 && (o = "nearest");
                        }
                    if (u) break;
                    (e.top < t.top || e.bottom > t.bottom || e.left < t.left || e.right > t.right) &&
                        (e = { left: Math.max(e.left, t.left), right: Math.min(e.right, t.right), top: Math.max(e.top, t.top), bottom: Math.min(e.bottom, t.bottom) }),
                        (h = h.assignedSlot || h.parentNode);
                } else {
                    if (11 != h.nodeType) break;
                    h = h.host;
                }
        })(this.view.scrollDOM, s, i.head < i.anchor ? -1 : 1, t.x, t.y, Math.max(Math.min(t.xMargin, r), -r), Math.max(Math.min(t.yMargin, l), -l), this.view.textDirection == Ui.LTR);
    }
}
function Un(t, e) {
    let i = t.observer.selectionRange;
    if (!i.focusNode) return null;
    let n = Xe(i.focusNode, i.focusOffset),
        o = Je(i.focusNode, i.focusOffset),
        s = n || o;
    if (o && n && o.node != n.node) {
        let e = ei.get(o.node);
        if (!e || (e instanceof vi && e.text != o.node.nodeValue)) s = o;
        else if (t.docView.lastCompositionAfterCursor) {
            let t = ei.get(n.node);
            !t || (t instanceof vi && t.text != n.node.nodeValue) || (s = o);
        }
    }
    if (((t.docView.lastCompositionAfterCursor = s != n), !s)) return null;
    let r = e - s.offset;
    return { from: r, to: r + s.node.nodeValue.length, node: s.node };
}
let jn = class {
    constructor() {
        this.changes = [];
    }
    compareRange(t, e) {
        _i(t, e, this.changes);
    }
    comparePoint(t, e) {
        _i(t, e, this.changes);
    }
    boundChange(t) {
        _i(t, t, this.changes);
    }
};
function Yn(t, e) {
    return e.left > t ? e.left - t : Math.max(0, t - e.right);
}
function Gn(t, e) {
    return e.top > t ? e.top - t : Math.max(0, t - e.bottom);
}
function Zn(t, e) {
    return t.top < e.bottom - 1 && t.bottom > e.top + 1;
}
function Kn(t, e) {
    return e < t.top ? { top: e, left: t.left, right: t.right, bottom: t.bottom } : t;
}
function Xn(t, e) {
    return e > t.bottom ? { top: t.top, left: t.left, right: t.right, bottom: e } : t;
}
function Jn(t, e, i) {
    let n,
        o,
        s,
        r,
        l,
        a,
        c,
        h,
        d = !1;
    for (let u = t.firstChild; u; u = u.nextSibling) {
        let t = Ne(u);
        for (let p = 0; p < t.length; p++) {
            let m = t[p];
            o && Zn(o, m) && (m = Kn(Xn(m, o.bottom), o.top));
            let g = Yn(e, m),
                f = Gn(i, m);
            if (0 == g && 0 == f) return 3 == u.nodeType ? Qn(u, e, i) : Jn(u, e, i);
            (!n || r > f || (r == f && s > g)) && ((n = u), (o = m), (s = g), (r = f), (d = !g || (e < m.left ? p > 0 : p < t.length - 1))),
                0 == g ? (i > m.bottom && (!c || c.bottom < m.bottom) ? ((l = u), (c = m)) : i < m.top && (!h || h.top > m.top) && ((a = u), (h = m))) : c && Zn(c, m) ? (c = Xn(c, m.bottom)) : h && Zn(h, m) && (h = Kn(h, m.top));
        }
    }
    if ((c && c.bottom >= i ? ((n = l), (o = c)) : h && h.top <= i && ((n = a), (o = h)), !n)) return { node: t, offset: 0 };
    let u = Math.max(o.left, Math.min(o.right, e));
    return 3 == n.nodeType ? Qn(n, u, i) : d && "false" != n.contentEditable ? Jn(n, u, i) : { node: t, offset: Array.prototype.indexOf.call(t.childNodes, n) + (e >= (o.left + o.right) / 2 ? 1 : 0) };
}
function Qn(t, e, i) {
    let n = t.nodeValue.length,
        o = -1,
        s = 1e9,
        r = 0;
    for (let l = 0; l < n; l++) {
        let n = Ye(t, l, l + 1).getClientRects();
        for (let a = 0; a < n.length; a++) {
            let c = n[a];
            if (c.top == c.bottom) continue;
            r || (r = e - c.left);
            let h = (c.top > i ? c.top - i : i - c.bottom) - 1;
            if (c.left - 1 <= e && c.right + 1 >= e && h < s) {
                let i = e >= (c.left + c.right) / 2,
                    n = i;
                if (((bi.chrome || bi.gecko) && Ye(t, l).getBoundingClientRect().left == c.right && (n = !i), h <= 0)) return { node: t, offset: l + (n ? 1 : 0) };
                (o = l + (n ? 1 : 0)), (s = h);
            }
        }
    }
    return { node: t, offset: o > -1 ? o : r > 0 ? t.nodeValue.length : 0 };
}
function to(t, e, i, n = -1) {
    var o, s;
    let r,
        l = t.contentDOM.getBoundingClientRect(),
        a = l.top + t.viewState.paddingTop,
        { docHeight: c } = t.viewState,
        { x: h, y: d } = e,
        u = d - a;
    if (u < 0) return 0;
    if (u > c) return t.state.doc.length;
    for (let e = t.viewState.heightOracle.textHeight / 2, o = !1; (r = t.elementAtHeight(u)), r.type != Bi.Text;)
        for (; (u = n > 0 ? r.bottom + e : r.top - e), !(u >= 0 && u <= c);) {
            if (o) return i ? null : 0;
            (o = !0), (n = -n);
        }
    d = a + u;
    let p = r.from;
    if (p < t.viewport.from) return 0 == t.viewport.from ? 0 : i ? null : eo(t, l, r, h, d);
    if (p > t.viewport.to) return t.viewport.to == t.state.doc.length ? t.state.doc.length : i ? null : eo(t, l, r, h, d);
    let m = t.dom.ownerDocument,
        g = t.root.elementFromPoint ? t.root : m,
        f = g.elementFromPoint(h, d);
    f && !t.contentDOM.contains(f) && (f = null), f || ((h = Math.max(l.left + 1, Math.min(l.right - 1, h))), (f = g.elementFromPoint(h, d)), f && !t.contentDOM.contains(f) && (f = null));
    let b,
        v = -1;
    if (f && 0 != (null === (o = t.docView.nearest(f)) || void 0 === o ? void 0 : o.isEditable)) {
        if (m.caretPositionFromPoint) {
            let t = m.caretPositionFromPoint(h, d);
            t && ({ offsetNode: b, offset: v } = t);
        } else if (m.caretRangeFromPoint) {
            let e = m.caretRangeFromPoint(h, d);
            e &&
                (({ startContainer: b, startOffset: v } = e),
                    (!t.contentDOM.contains(b) ||
                        (bi.safari &&
                            (function (t, e, i) {
                                let n,
                                    o = t;
                                if (3 != t.nodeType || e != (n = t.nodeValue.length)) return !1;
                                for (; ;) {
                                    let t = o.nextSibling;
                                    if (t) {
                                        if ("BR" == t.nodeName) break;
                                        return !1;
                                    }
                                    {
                                        let t = o.parentNode;
                                        if (!t || "DIV" == t.nodeName) break;
                                        o = t;
                                    }
                                }
                                return Ye(t, n - 1, n).getBoundingClientRect().right > i;
                            })(b, v, h)) ||
                        (bi.chrome &&
                            (function (t, e, i) {
                                if (0 != e) return !1;
                                for (let e = t; ;) {
                                    let t = e.parentNode;
                                    if (!t || 1 != t.nodeType || t.firstChild != e) return !1;
                                    if (t.classList.contains("cm-line")) break;
                                    e = t;
                                }
                                return i - (1 == t.nodeType ? t.getBoundingClientRect() : Ye(t, 0, Math.max(t.nodeValue.length, 1)).getBoundingClientRect()).left > 5;
                            })(b, v, h))) &&
                    (b = void 0));
        }
        b && (v = Math.min(Fe(b), v));
    }
    if (!b || !t.docView.dom.contains(b)) {
        let e = Fi.find(t.docView, p);
        if (!e) return u > r.top + r.height / 2 ? r.to : r.from;
        ({ node: b, offset: v } = Jn(e.dom, h, d));
    }
    let y = t.docView.nearest(b);
    if (!y) return null;
    if (y.isWidget && 1 == (null === (s = y.dom) || void 0 === s ? void 0 : s.nodeType)) {
        let t = y.dom.getBoundingClientRect();
        return e.y < t.top || (e.y <= t.bottom && e.x <= (t.left + t.right) / 2) ? y.posAtStart : y.posAtEnd;
    }
    return y.localPosFromDOM(b, v) + y.posAtStart;
}
function eo(t, e, i, n, o) {
    let s = Math.round((n - e.left) * t.defaultCharacterWidth);
    if (t.lineWrapping && i.height > 1.5 * t.defaultLineHeight) {
        let e = t.viewState.heightOracle.textHeight;
        s += Math.floor((o - i.top - 0.5 * (t.defaultLineHeight - e)) / e) * t.viewState.heightOracle.lineLength;
    }
    let r = t.state.sliceDoc(i.from, i.to);
    return (
        i.from +
        (function (t, e, i, n) {
            for (let n = 0, o = 0; ;) {
                if (o >= e) return n;
                if (n == t.length) break;
                (o += 9 == t.charCodeAt(n) ? i - (o % i) : 1), (n = et(t, n));
            }
            return t.length;
        })(r, s, t.state.tabSize)
    );
}
function io(t, e, i, n) {
    let o = (function (t, e, i) {
        let n = t.lineBlockAt(e);
        if (Array.isArray(n.type)) {
            let t;
            for (let o of n.type) {
                if (o.from > e) break;
                if (!(o.to < e)) {
                    if (o.from < e && o.to > e) return o;
                    (t && (o.type != Bi.Text || (t.type == o.type && !(i < 0 ? o.from < e : o.to > e)))) || (t = o);
                }
            }
            return t || n;
        }
        return n;
    })(t, e.head, e.assoc || -1),
        s = n && o.type == Bi.Text && (t.lineWrapping || o.widgetLineBreaks) ? t.coordsAtPos(e.assoc < 0 && e.head > o.from ? e.head - 1 : e.head) : null;
    if (s) {
        let e = t.dom.getBoundingClientRect(),
            n = t.textDirectionAt(o.from),
            r = t.posAtCoords({ x: i == (n == Ui.LTR) ? e.right - 1 : e.left + 1, y: (s.top + s.bottom) / 2 });
        if (null != r) return pt.cursor(r, i ? -1 : 1);
    }
    return pt.cursor(i ? o.to : o.from, i ? -1 : 1);
}
function no(t, e, i, n) {
    let o = t.state.doc.lineAt(e.head),
        s = t.bidiSpans(o),
        r = t.textDirectionAt(o.from);
    for (let l = e, a = null; ;) {
        let e = cn(o, s, r, l, i),
            c = an;
        if (!e) {
            if (o.number == (i ? t.state.doc.lines : 1)) return l;
            (c = "\n"), (o = t.state.doc.line(o.number + (i ? 1 : -1))), (s = t.bidiSpans(o)), (e = t.visualLineSide(o, !i));
        }
        if (a) {
            if (!a(c)) return l;
        } else {
            if (!n) return e;
            a = n(c);
        }
        l = e;
    }
}
function oo(t, e, i) {
    for (; ;) {
        let n = 0;
        for (let o of t)
            o.between(e - 1, e + 1, (t, o, s) => {
                if (e > t && e < o) {
                    let s = n || i || (e - t < o - e ? -1 : 1);
                    (e = s < 0 ? t : o), (n = s);
                }
            });
        if (!n) return e;
    }
}
function so(t, e, i) {
    let n = oo(
        t.state.facet(Rn).map((e) => e(t)),
        i.from,
        e.head > i.from ? -1 : 1
    );
    return n == i.from ? i : pt.cursor(n, n < i.from ? 1 : -1);
}
const ro = "￿";
class lo {
    constructor(t, e) {
        (this.points = t), (this.text = ""), (this.lineSeparator = e.facet(oe.lineSeparator));
    }
    append(t) {
        this.text += t;
    }
    lineBreak() {
        this.text += ro;
    }
    readRange(t, e) {
        if (!t) return this;
        let i = t.parentNode;
        for (let n = t; ;) {
            this.findPointBefore(i, n);
            let t = this.text.length;
            this.readNode(n);
            let o = n.nextSibling;
            if (o == e) break;
            let s = ei.get(n),
                r = ei.get(o);
            (s && r ? s.breakAfter : (s ? s.breakAfter : Pe(n)) || (Pe(o) && ("BR" != n.nodeName || n.cmIgnore) && this.text.length > t)) && this.lineBreak(), (n = o);
        }
        return this.findPointBefore(i, e), this;
    }
    readTextNode(t) {
        let e = t.nodeValue;
        for (let i of this.points) i.node == t && (i.pos = this.text.length + Math.min(i.offset, e.length));
        for (let i = 0, n = this.lineSeparator ? null : /\r\n?|\n/g; ;) {
            let o,
                s = -1,
                r = 1;
            if ((this.lineSeparator ? ((s = e.indexOf(this.lineSeparator, i)), (r = this.lineSeparator.length)) : (o = n.exec(e)) && ((s = o.index), (r = o[0].length)), this.append(e.slice(i, s < 0 ? e.length : s)), s < 0)) break;
            if ((this.lineBreak(), r > 1)) for (let e of this.points) e.node == t && e.pos > this.text.length && (e.pos -= r - 1);
            i = s + r;
        }
    }
    readNode(t) {
        if (t.cmIgnore) return;
        let e = ei.get(t),
            i = e && e.overrideDOMText;
        if (null != i) {
            this.findPointInside(t, i.length);
            for (let t = i.iter(); !t.next().done;) t.lineBreak ? this.lineBreak() : this.append(t.value);
        } else 3 == t.nodeType ? this.readTextNode(t) : "BR" == t.nodeName ? t.nextSibling && this.lineBreak() : 1 == t.nodeType && this.readRange(t.firstChild, null);
    }
    findPointBefore(t, e) {
        for (let i of this.points) i.node == t && t.childNodes[i.offset] == e && (i.pos = this.text.length);
    }
    findPointInside(t, e) {
        for (let i of this.points) (3 == t.nodeType ? i.node == t : t.contains(i.node)) && (i.pos = this.text.length + (ao(t, i.node, i.offset) ? e : 0));
    }
}
function ao(t, e, i) {
    for (; ;) {
        if (!e || i < Fe(e)) return !1;
        if (e == t) return !0;
        (i = Re(e) + 1), (e = e.parentNode);
    }
}
class co {
    constructor(t, e) {
        (this.node = t), (this.offset = e), (this.pos = -1);
    }
}
class ho {
    constructor(t, e, i, n) {
        (this.typeOver = n), (this.bounds = null), (this.text = ""), (this.domChanged = e > -1);
        let { impreciseHead: o, impreciseAnchor: s } = t.docView;
        if (t.state.readOnly && e > -1) this.newSel = null;
        else if (e > -1 && (this.bounds = t.docView.domBoundsAround(e, i, 0))) {
            let e =
                o || s
                    ? []
                    : (function (t) {
                        let e = [];
                        if (t.root.activeElement != t.contentDOM) return e;
                        let { anchorNode: i, anchorOffset: n, focusNode: o, focusOffset: s } = t.observer.selectionRange;
                        return i && (e.push(new co(i, n)), (o == i && s == n) || e.push(new co(o, s))), e;
                    })(t),
                i = new lo(e, t.state);
            i.readRange(this.bounds.startDOM, this.bounds.endDOM),
                (this.text = i.text),
                (this.newSel = (function (t, e) {
                    if (0 == t.length) return null;
                    let i = t[0].pos,
                        n = 2 == t.length ? t[1].pos : i;
                    return i > -1 && n > -1 ? pt.single(i + e, n + e) : null;
                })(e, this.bounds.from));
        } else {
            let e = t.observer.selectionRange,
                i = (o && o.node == e.focusNode && o.offset == e.focusOffset) || !Be(t.contentDOM, e.focusNode) ? t.state.selection.main.head : t.docView.posFromDOM(e.focusNode, e.focusOffset),
                n = (s && s.node == e.anchorNode && s.offset == e.anchorOffset) || !Be(t.contentDOM, e.anchorNode) ? t.state.selection.main.anchor : t.docView.posFromDOM(e.anchorNode, e.anchorOffset),
                r = t.viewport;
            if ((bi.ios || bi.chrome) && t.state.selection.main.empty && i != n && (r.from > 0 || r.to < t.state.doc.length)) {
                let e = Math.min(i, n),
                    o = Math.max(i, n),
                    s = r.from - e,
                    l = r.to - o;
                (0 != s && 1 != s && 0 != e) || (0 != l && -1 != l && o != t.state.doc.length) || ((i = 0), (n = t.state.doc.length));
            }
            this.newSel = pt.single(n, i);
        }
    }
}
function uo(t, e) {
    let i,
        { newSel: n } = e,
        o = t.state.selection.main,
        s = t.inputState.lastKeyTime > Date.now() - 100 ? t.inputState.lastKeyCode : -1;
    if (e.bounds) {
        let { from: n, to: r } = e.bounds,
            l = o.from,
            a = null;
        (8 === s || (bi.android && e.text.length < r - n)) && ((l = o.to), (a = "end"));
        let c = (function (t, e, i, n) {
            let o = Math.min(t.length, e.length),
                s = 0;
            for (; s < o && t.charCodeAt(s) == e.charCodeAt(s);) s++;
            if (s == o && t.length == e.length) return null;
            let r = t.length,
                l = e.length;
            for (; r > 0 && l > 0 && t.charCodeAt(r - 1) == e.charCodeAt(l - 1);) r--, l--;
            return (
                "end" == n && (i -= r + Math.max(0, s - Math.min(r, l)) - s),
                r < s && t.length < e.length ? ((s -= i <= s && i >= r ? s - i : 0), (l = s + (l - r)), (r = s)) : l < s && ((s -= i <= s && i >= l ? s - i : 0), (r = s + (r - l)), (l = s)),
                { from: s, toA: r, toB: l }
            );
        })(t.state.doc.sliceString(n, r, ro), e.text, l - n, a);
        c && (bi.chrome && 13 == s && c.toB == c.from + 2 && "￿￿" == e.text.slice(c.from, c.toB) && c.toB--, (i = { from: n + c.from, to: n + c.toA, insert: U.of(e.text.slice(c.from, c.toB).split(ro)) }));
    } else n && ((!t.hasFocus && t.state.facet(Mn)) || n.main.eq(o)) && (n = null);
    if (!i && !n) return !1;
    if (
        (!i && e.typeOver && !o.empty && n && n.main.empty
            ? (i = { from: o.from, to: o.to, insert: t.state.doc.slice(o.from, o.to) })
            : (bi.mac || bi.android) && i && i.from == i.to && i.from == o.head - 1 && /^\. ?$/.test(i.insert.toString()) && "off" == t.contentDOM.getAttribute("autocorrect")
                ? (n && 2 == i.insert.length && (n = pt.single(n.main.anchor - 1, n.main.head - 1)), (i = { from: i.from, to: i.to, insert: U.of([i.insert.toString().replace(".", " ")]) }))
                : i && i.from >= o.from && i.to <= o.to && (i.from != o.from || i.to != o.to) && o.to - o.from - (i.to - i.from) <= 4
                    ? (i = { from: o.from, to: o.to, insert: t.state.doc.slice(o.from, i.from).append(i.insert).append(t.state.doc.slice(i.to, o.to)) })
                    : bi.chrome && i && i.from == i.to && i.from == o.head && "\n " == i.insert.toString() && t.lineWrapping && (n && (n = pt.single(n.main.anchor - 1, n.main.head - 1)), (i = { from: o.from, to: o.to, insert: U.of([" "]) })),
            i)
    )
        return po(t, i, n, s);
    if (n && !n.main.eq(o)) {
        let e = !1,
            i = "select";
        return t.inputState.lastSelectionTime > Date.now() - 50 && ("select" == t.inputState.lastSelectionOrigin && (e = !0), (i = t.inputState.lastSelectionOrigin)), t.dispatch({ selection: n, scrollIntoView: e, userEvent: i }), !0;
    }
    return !1;
}
function po(t, e, i, n = -1) {
    if (bi.ios && t.inputState.flushIOSKey(e)) return !0;
    let o = t.state.selection.main;
    if (
        bi.android &&
        ((e.to == o.to && (e.from == o.from || (e.from == o.from - 1 && " " == t.state.sliceDoc(e.from, o.from))) && 1 == e.insert.length && 2 == e.insert.lines && Ge(t.contentDOM, "Enter", 13)) ||
            (((e.from == o.from - 1 && e.to == o.to && 0 == e.insert.length) || (8 == n && e.insert.length < e.to - e.from && e.to > o.head)) && Ge(t.contentDOM, "Backspace", 8)) ||
            (e.from == o.from && e.to == o.to + 1 && 0 == e.insert.length && Ge(t.contentDOM, "Delete", 46)))
    )
        return !0;
    let s,
        r = e.insert.toString();
    t.inputState.composing >= 0 && t.inputState.composing++;
    let l = () =>
        s ||
        (s = (function (t, e, i) {
            let n,
                o = t.state,
                s = o.selection.main;
            if (e.from >= s.from && e.to <= s.to && e.to - e.from >= (s.to - s.from) / 3 && (!i || (i.main.empty && i.main.from == e.from + e.insert.length)) && t.inputState.composing < 0) {
                let i = s.from < e.from ? o.sliceDoc(s.from, e.from) : "",
                    r = s.to > e.to ? o.sliceDoc(e.to, s.to) : "";
                n = o.replaceSelection(t.state.toText(i + e.insert.sliceString(0, void 0, t.state.lineBreak) + r));
            } else {
                let r = o.changes(e),
                    l = i && i.main.to <= r.newLength ? i.main : void 0;
                if (o.selection.ranges.length > 1 && t.inputState.composing >= 0 && e.to <= s.to && e.to >= s.to - 10) {
                    let a,
                        c = t.state.sliceDoc(e.from, e.to),
                        h = i && Un(t, i.main.head);
                    if (h) {
                        let t = e.insert.length - (e.to - e.from);
                        a = { from: h.from, to: h.to - t };
                    } else a = t.state.doc.lineAt(s.head);
                    let d = s.to - e.to,
                        u = s.to - s.from;
                    n = o.changeByRange((i) => {
                        if (i.from == s.from && i.to == s.to) return { changes: r, range: l || i.map(r) };
                        let n = i.to - d,
                            h = n - c.length;
                        if (i.to - i.from != u || t.state.sliceDoc(h, n) != c || (i.to >= a.from && i.from <= a.to)) return { range: i };
                        let p = o.changes({ from: h, to: n, insert: e.insert }),
                            m = i.to - s.to;
                        return { changes: p, range: l ? pt.range(Math.max(0, l.anchor + m), Math.max(0, l.head + m)) : i.map(p) };
                    });
                } else n = { changes: r, selection: l && o.selection.replaceRange(l) };
            }
            let r = "input.type";
            return (
                (t.composing || (t.inputState.compositionPendingChange && t.inputState.compositionEndedAt > Date.now() - 50)) &&
                ((t.inputState.compositionPendingChange = !1), (r += ".compose"), t.inputState.compositionFirstChange && ((r += ".start"), (t.inputState.compositionFirstChange = !1))),
                o.update(n, { userEvent: r, scrollIntoView: !0 })
            );
        })(t, e, i));
    return t.state.facet(fn).some((i) => i(t, e.from, e.to, r, l)) || t.dispatch(l()), !0;
}
class mo {
    setSelectionOrigin(t) {
        (this.lastSelectionOrigin = t), (this.lastSelectionTime = Date.now());
    }
    constructor(t) {
        (this.view = t),
            (this.lastKeyCode = 0),
            (this.lastKeyTime = 0),
            (this.lastTouchTime = 0),
            (this.lastFocusTime = 0),
            (this.lastScrollTop = 0),
            (this.lastScrollLeft = 0),
            (this.pendingIOSKey = void 0),
            (this.tabFocusMode = -1),
            (this.lastSelectionOrigin = null),
            (this.lastSelectionTime = 0),
            (this.lastContextMenu = 0),
            (this.scrollHandlers = []),
            (this.handlers = Object.create(null)),
            (this.composing = -1),
            (this.compositionFirstChange = null),
            (this.compositionEndedAt = 0),
            (this.compositionPendingKey = !1),
            (this.compositionPendingChange = !1),
            (this.mouseSelection = null),
            (this.draggedContent = null),
            (this.handleEvent = this.handleEvent.bind(this)),
            (this.notifiedFocused = t.hasFocus),
            bi.safari && t.contentDOM.addEventListener("input", () => null),
            bi.gecko &&
            (function (t) {
                Ho.has(t) || (Ho.add(t), t.addEventListener("copy", () => { }), t.addEventListener("cut", () => { }));
            })(t.contentDOM.ownerDocument);
    }
    handleEvent(t) {
        (function (t, e) {
            if (!e.bubbles) return !0;
            if (e.defaultPrevented) return !1;
            for (let i, n = e.target; n != t.contentDOM; n = n.parentNode) if (!n || 11 == n.nodeType || ((i = ei.get(n)) && i.ignoreEvent(e))) return !1;
            return !0;
        })(this.view, t) &&
            !this.ignoreDuringComposition(t) &&
            (("keydown" == t.type && this.keydown(t)) || (0 != this.view.updateState ? Promise.resolve().then(() => this.runHandlers(t.type, t)) : this.runHandlers(t.type, t)));
    }
    runHandlers(t, e) {
        let i = this.handlers[t];
        if (i) {
            for (let t of i.observers) t(this.view, e);
            for (let t of i.handlers) {
                if (e.defaultPrevented) break;
                if (t(this.view, e)) {
                    e.preventDefault();
                    break;
                }
            }
        }
    }
    ensureHandlers(t) {
        let e = fo(t),
            i = this.handlers,
            n = this.view.contentDOM;
        for (let t in e)
            if ("scroll" != t) {
                let o = !e[t].handlers.length,
                    s = i[t];
                s && o != !s.handlers.length && (n.removeEventListener(t, this.handleEvent), (s = null)), s || n.addEventListener(t, this.handleEvent, { passive: o });
            }
        for (let t in i) "scroll" == t || e[t] || n.removeEventListener(t, this.handleEvent);
        this.handlers = e;
    }
    keydown(t) {
        if (((this.lastKeyCode = t.keyCode), (this.lastKeyTime = Date.now()), 9 == t.keyCode && this.tabFocusMode > -1 && (!this.tabFocusMode || Date.now() <= this.tabFocusMode))) return !0;
        if ((this.tabFocusMode > 0 && 27 != t.keyCode && yo.indexOf(t.keyCode) < 0 && (this.tabFocusMode = -1), bi.android && bi.chrome && !t.synthetic && (13 == t.keyCode || 8 == t.keyCode)))
            return this.view.observer.delayAndroidKey(t.key, t.keyCode), !0;
        let e;
        return !bi.ios || t.synthetic || t.altKey || t.metaKey || !(((e = bo.find((e) => e.keyCode == t.keyCode)) && !t.ctrlKey) || (vo.indexOf(t.key) > -1 && t.ctrlKey && !t.shiftKey))
            ? (229 != t.keyCode && this.view.observer.forceFlush(), !1)
            : ((this.pendingIOSKey = e || t), setTimeout(() => this.flushIOSKey(), 250), !0);
    }
    flushIOSKey(t) {
        let e = this.pendingIOSKey;
        return !!e && !("Enter" == e.key && t && t.from < t.to && /^\S+$/.test(t.insert.toString())) && ((this.pendingIOSKey = void 0), Ge(this.view.contentDOM, e.key, e.keyCode, e instanceof KeyboardEvent ? e : void 0));
    }
    ignoreDuringComposition(t) {
        return !!/^key/.test(t.type) && (this.composing > 0 || (!!(bi.safari && !bi.ios && this.compositionPendingKey && Date.now() - this.compositionEndedAt < 100) && ((this.compositionPendingKey = !1), !0)));
    }
    startMouseSelection(t) {
        this.mouseSelection && this.mouseSelection.destroy(), (this.mouseSelection = t);
    }
    update(t) {
        this.view.observer.update(t),
            this.mouseSelection && this.mouseSelection.update(t),
            this.draggedContent && t.docChanged && (this.draggedContent = this.draggedContent.map(t.changes)),
            t.transactions.length && (this.lastKeyCode = this.lastSelectionTime = 0);
    }
    destroy() {
        this.mouseSelection && this.mouseSelection.destroy();
    }
}
function go(t, e) {
    return (i, n) => {
        try {
            return e.call(t, n, i);
        } catch (t) {
            En(i.state, t);
        }
    };
}
function fo(t) {
    let e = Object.create(null);
    function i(t) {
        return e[t] || (e[t] = { observers: [], handlers: [] });
    }
    for (let e of t) {
        let t = e.spec,
            n = t && t.plugin.domEventHandlers,
            o = t && t.plugin.domEventObservers;
        if (n)
            for (let t in n) {
                let o = n[t];
                o && i(t).handlers.push(go(e.value, o));
            }
        if (o)
            for (let t in o) {
                let n = o[t];
                n && i(t).observers.push(go(e.value, n));
            }
    }
    for (let t in Co) i(t).handlers.push(Co[t]);
    for (let t in ko) i(t).observers.push(ko[t]);
    return e;
}
const bo = [
    { key: "Backspace", keyCode: 8, inputType: "deleteContentBackward" },
    { key: "Enter", keyCode: 13, inputType: "insertParagraph" },
    { key: "Enter", keyCode: 13, inputType: "insertLineBreak" },
    { key: "Delete", keyCode: 46, inputType: "deleteContentForward" },
],
    vo = "dthko",
    yo = [16, 17, 18, 20, 91, 92, 224, 225];
function wo(t) {
    return 0.7 * Math.max(0, t) + 8;
}
class xo {
    constructor(t, e, i, n) {
        (this.view = t),
            (this.startEvent = e),
            (this.style = i),
            (this.mustSelect = n),
            (this.scrollSpeed = { x: 0, y: 0 }),
            (this.scrolling = -1),
            (this.lastEvent = e),
            (this.scrollParents = (function (t) {
                let e,
                    i,
                    n = t.ownerDocument;
                for (let o = t.parentNode; o && !(o == n.body || (e && i));)
                    if (1 == o.nodeType) !i && o.scrollHeight > o.clientHeight && (i = o), !e && o.scrollWidth > o.clientWidth && (e = o), (o = o.assignedSlot || o.parentNode);
                    else {
                        if (11 != o.nodeType) break;
                        o = o.host;
                    }
                return { x: e, y: i };
            })(t.contentDOM)),
            (this.atoms = t.state.facet(Rn).map((e) => e(t)));
        let o = t.contentDOM.ownerDocument;
        o.addEventListener("mousemove", (this.move = this.move.bind(this))),
            o.addEventListener("mouseup", (this.up = this.up.bind(this))),
            (this.extend = e.shiftKey),
            (this.multiple =
                t.state.facet(oe.allowMultipleSelections) &&
                (function (t, e) {
                    let i = t.state.facet(dn);
                    return i.length ? i[0](e) : bi.mac ? e.metaKey : e.ctrlKey;
                })(t, e)),
            (this.dragging =
                !(
                    !(function (t, e) {
                        let { main: i } = t.state.selection;
                        if (i.empty) return !1;
                        let n = Oe(t.root);
                        if (!n || 0 == n.rangeCount) return !0;
                        let o = n.getRangeAt(0).getClientRects();
                        for (let t = 0; t < o.length; t++) {
                            let i = o[t];
                            if (i.left <= e.clientX && i.right >= e.clientX && i.top <= e.clientY && i.bottom >= e.clientY) return !0;
                        }
                        return !1;
                    })(t, e) || 1 != Lo(e)
                ) && null);
    }
    start(t) {
        !1 === this.dragging && this.select(t);
    }
    move(t) {
        if (0 == t.buttons) return this.destroy();
        if (this.dragging || (null == this.dragging && ((e = this.startEvent), (i = t), Math.max(Math.abs(e.clientX - i.clientX), Math.abs(e.clientY - i.clientY)) < 10))) return;
        var e, i;
        this.select((this.lastEvent = t));
        let n = 0,
            o = 0,
            s = 0,
            r = 0,
            l = this.view.win.innerWidth,
            a = this.view.win.innerHeight;
        this.scrollParents.x && ({ left: s, right: l } = this.scrollParents.x.getBoundingClientRect()), this.scrollParents.y && ({ top: r, bottom: a } = this.scrollParents.y.getBoundingClientRect());
        let c = Vn(this.view);
        t.clientX - c.left <= s + 6 ? (n = -wo(s - t.clientX)) : t.clientX + c.right >= l - 6 && (n = wo(t.clientX - l)),
            t.clientY - c.top <= r + 6 ? (o = -wo(r - t.clientY)) : t.clientY + c.bottom >= a - 6 && (o = wo(t.clientY - a)),
            this.setScrollSpeed(n, o);
    }
    up(t) {
        null == this.dragging && this.select(this.lastEvent), this.dragging || t.preventDefault(), this.destroy();
    }
    destroy() {
        this.setScrollSpeed(0, 0);
        let t = this.view.contentDOM.ownerDocument;
        t.removeEventListener("mousemove", this.move), t.removeEventListener("mouseup", this.up), (this.view.inputState.mouseSelection = this.view.inputState.draggedContent = null);
    }
    setScrollSpeed(t, e) {
        (this.scrollSpeed = { x: t, y: e }), t || e ? this.scrolling < 0 && (this.scrolling = setInterval(() => this.scroll(), 50)) : this.scrolling > -1 && (clearInterval(this.scrolling), (this.scrolling = -1));
    }
    scroll() {
        let { x: t, y: e } = this.scrollSpeed;
        t && this.scrollParents.x && ((this.scrollParents.x.scrollLeft += t), (t = 0)),
            e && this.scrollParents.y && ((this.scrollParents.y.scrollTop += e), (e = 0)),
            (t || e) && this.view.win.scrollBy(t, e),
            !1 === this.dragging && this.select(this.lastEvent);
    }
    skipAtoms(t) {
        let e = null;
        for (let i = 0; i < t.ranges.length; i++) {
            let n = t.ranges[i],
                o = null;
            if (n.empty) {
                let t = oo(this.atoms, n.from, 0);
                t != n.from && (o = pt.cursor(t, -1));
            } else {
                let t = oo(this.atoms, n.from, -1),
                    e = oo(this.atoms, n.to, 1);
                (t == n.from && e == n.to) || (o = pt.range(n.from == n.anchor ? t : e, n.from == n.head ? t : e));
            }
            o && (e || (e = t.ranges.slice()), (e[i] = o));
        }
        return e ? pt.create(e, t.mainIndex) : t;
    }
    select(t) {
        let { view: e } = this,
            i = this.skipAtoms(this.style.get(t, this.extend, this.multiple));
        (!this.mustSelect && i.eq(e.state.selection, !1 === this.dragging)) || this.view.dispatch({ selection: i, userEvent: "select.pointer" }), (this.mustSelect = !1);
    }
    update(t) {
        t.transactions.some((t) => t.isUserEvent("input.type")) ? this.destroy() : this.style.update(t) && setTimeout(() => this.select(this.lastEvent), 20);
    }
}
const Co = Object.create(null),
    ko = Object.create(null),
    So = (bi.ie && bi.ie_version < 15) || (bi.ios && bi.webkit_version < 604);
function To(t, e, i) {
    for (let n of t.facet(e)) i = n(i, t);
    return i;
}
function Eo(t, e) {
    e = To(t.state, vn, e);
    let i,
        { state: n } = t,
        o = 1,
        s = n.toText(e),
        r = s.lines == n.selection.ranges.length;
    if (null != Po && n.selection.ranges.every((t) => t.empty) && Po == s.toString()) {
        let t = -1;
        i = n.changeByRange((i) => {
            let l = n.doc.lineAt(i.from);
            if (l.from == t) return { range: i };
            t = l.from;
            let a = n.toText((r ? s.line(o++).text : e) + n.lineBreak);
            return { changes: { from: l.from, insert: a }, range: pt.cursor(i.from + a.length) };
        });
    } else
        i = r
            ? n.changeByRange((t) => {
                let e = s.line(o++);
                return { changes: { from: t.from, to: t.to, insert: e.text }, range: pt.cursor(t.from + e.length) };
            })
            : n.replaceSelection(s);
    t.dispatch(i, { userEvent: "input.paste", scrollIntoView: !0 });
}
function Mo(t, e, i, n) {
    if (1 == n) return pt.cursor(e, i);
    if (2 == n)
        return (function (t, e, i = 1) {
            let n = t.charCategorizer(e),
                o = t.doc.lineAt(e),
                s = e - o.from;
            if (0 == o.length) return pt.cursor(e);
            0 == s ? (i = 1) : s == o.length && (i = -1);
            let r = s,
                l = s;
            i < 0 ? (r = et(o.text, s, !1)) : (l = et(o.text, s));
            let a = n(o.text.slice(r, l));
            for (; r > 0;) {
                let t = et(o.text, r, !1);
                if (n(o.text.slice(t, r)) != a) break;
                r = t;
            }
            for (; l < o.length;) {
                let t = et(o.text, l);
                if (n(o.text.slice(l, t)) != a) break;
                l = t;
            }
            return pt.range(r + o.from, l + o.from);
        })(t.state, e, i);
    {
        let i = Fi.find(t.docView, e),
            n = t.state.doc.lineAt(i ? i.posAtEnd : e),
            o = i ? i.posAtStart : n.from,
            s = i ? i.posAtEnd : n.to;
        return s < t.state.doc.length && s == n.to && s++, pt.range(o, s);
    }
}
(ko.scroll = (t) => {
    (t.inputState.lastScrollTop = t.scrollDOM.scrollTop), (t.inputState.lastScrollLeft = t.scrollDOM.scrollLeft);
}),
    (Co.keydown = (t, e) => (t.inputState.setSelectionOrigin("select"), 27 == e.keyCode && 0 != t.inputState.tabFocusMode && (t.inputState.tabFocusMode = Date.now() + 2e3), !1)),
    (ko.touchstart = (t, e) => {
        (t.inputState.lastTouchTime = Date.now()), t.inputState.setSelectionOrigin("select.pointer");
    }),
    (ko.touchmove = (t) => {
        t.inputState.setSelectionOrigin("select.pointer");
    }),
    (Co.mousedown = (t, e) => {
        if ((t.observer.flush(), t.inputState.lastTouchTime > Date.now() - 2e3)) return !1;
        let i = null;
        for (let n of t.state.facet(pn)) if (((i = n(t, e)), i)) break;
        if (
            (i ||
                0 != e.button ||
                (i = (function (t, e) {
                    let i = Io(t, e),
                        n = Lo(e),
                        o = t.state.selection;
                    return {
                        update(t) {
                            t.docChanged && ((i.pos = t.changes.mapPos(i.pos)), (o = o.map(t.changes)));
                        },
                        get(e, s, r) {
                            let l,
                                a = Io(t, e),
                                c = Mo(t, a.pos, a.bias, n);
                            if (i.pos != a.pos && !s) {
                                let e = Mo(t, i.pos, i.bias, n),
                                    o = Math.min(e.from, c.from),
                                    s = Math.max(e.to, c.to);
                                c = o < c.from ? pt.range(o, s) : pt.range(s, o);
                            }
                            return s
                                ? o.replaceRange(o.main.extend(c.from, c.to))
                                : r &&
                                    1 == n &&
                                    o.ranges.length > 1 &&
                                    (l = (function (t, e) {
                                        for (let i = 0; i < t.ranges.length; i++) {
                                            let { from: n, to: o } = t.ranges[i];
                                            if (n <= e && o >= e) return pt.create(t.ranges.slice(0, i).concat(t.ranges.slice(i + 1)), t.mainIndex == i ? 0 : t.mainIndex - (t.mainIndex > i ? 1 : 0));
                                        }
                                        return null;
                                    })(o, a.pos))
                                    ? l
                                    : r
                                        ? o.addRange(c)
                                        : pt.create([c]);
                        },
                    };
                })(t, e)),
                i)
        ) {
            let n = !t.hasFocus;
            t.inputState.startMouseSelection(new xo(t, e, i, n)),
                n &&
                t.observer.ignore(() => {
                    je(t.contentDOM);
                    let e = t.root.activeElement;
                    e && !e.contains(t.contentDOM) && e.blur();
                });
            let o = t.inputState.mouseSelection;
            if (o) return o.start(e), !1 === o.dragging;
        }
        return !1;
    });
let Ao = (t, e, i) => e >= i.top && e <= i.bottom && t >= i.left && t <= i.right;
function Do(t, e, i, n) {
    let o = Fi.find(t.docView, e);
    if (!o) return 1;
    let s = e - o.posAtStart;
    if (0 == s) return 1;
    if (s == o.length) return -1;
    let r = o.coordsAt(s, -1);
    if (r && Ao(i, n, r)) return -1;
    let l = o.coordsAt(s, 1);
    return l && Ao(i, n, l) ? 1 : r && r.bottom >= n ? -1 : 1;
}
function Io(t, e) {
    let i = t.posAtCoords({ x: e.clientX, y: e.clientY }, !1);
    return { pos: i, bias: Do(t, i, e.clientX, e.clientY) };
}
const Oo = bi.ie && bi.ie_version <= 11;
let Bo = null,
    qo = 0,
    No = 0;
function Lo(t) {
    if (!Oo) return t.detail;
    let e = Bo,
        i = No;
    return (Bo = t), (No = Date.now()), (qo = !e || (i > Date.now() - 400 && Math.abs(e.clientX - t.clientX) < 2 && Math.abs(e.clientY - t.clientY) < 2) ? (qo + 1) % 3 : 1);
}
function Ro(t, e, i, n) {
    if (!(i = To(t.state, vn, i))) return;
    let o = t.posAtCoords({ x: e.clientX, y: e.clientY }, !1),
        { draggedContent: s } = t.inputState,
        r =
            n &&
                s &&
                (function (t, e) {
                    let i = t.state.facet(un);
                    return i.length ? i[0](e) : bi.mac ? !e.altKey : !e.ctrlKey;
                })(t, e)
                ? { from: s.from, to: s.to }
                : null,
        l = { from: o, insert: i },
        a = t.state.changes(r ? [r, l] : l);
    t.focus(), t.dispatch({ changes: a, selection: { anchor: a.mapPos(o, -1), head: a.mapPos(o, 1) }, userEvent: r ? "move.drop" : "input.drop" }), (t.inputState.draggedContent = null);
}
(Co.dragstart = (t, e) => {
    let {
        selection: { main: i },
    } = t.state;
    if (e.target.draggable) {
        let n = t.docView.nearest(e.target);
        if (n && n.isWidget) {
            let t = n.posAtStart,
                e = t + n.length;
            (t >= i.to || e <= i.from) && (i = pt.range(t, e));
        }
    }
    let { inputState: n } = t;
    return n.mouseSelection && (n.mouseSelection.dragging = !0), (n.draggedContent = i), e.dataTransfer && (e.dataTransfer.setData("Text", To(t.state, yn, t.state.sliceDoc(i.from, i.to))), (e.dataTransfer.effectAllowed = "copyMove")), !1;
}),
    (Co.dragend = (t) => ((t.inputState.draggedContent = null), !1)),
    (Co.drop = (t, e) => {
        if (!e.dataTransfer) return !1;
        if (t.state.readOnly) return !0;
        let i = e.dataTransfer.files;
        if (i && i.length) {
            let n = Array(i.length),
                o = 0,
                s = () => {
                    ++o == i.length && Ro(t, e, n.filter((t) => null != t).join(t.state.lineBreak), !1);
                };
            for (let t = 0; t < i.length; t++) {
                let e = new FileReader();
                (e.onerror = s),
                    (e.onload = () => {
                        /[\x00-\x08\x0e-\x1f]{2}/.test(e.result) || (n[t] = e.result), s();
                    }),
                    e.readAsText(i[t]);
            }
            return !0;
        }
        {
            let i = e.dataTransfer.getData("Text");
            if (i) return Ro(t, e, i, !0), !0;
        }
        return !1;
    }),
    (Co.paste = (t, e) => {
        if (t.state.readOnly) return !0;
        t.observer.flush();
        let i = So ? null : e.clipboardData;
        return i
            ? (Eo(t, i.getData("text/plain") || i.getData("text/uri-list")), !0)
            : ((function (t) {
                let e = t.dom.parentNode;
                if (!e) return;
                let i = e.appendChild(document.createElement("textarea"));
                (i.style.cssText = "position: fixed; left: -10000px; top: 10px"),
                    i.focus(),
                    setTimeout(() => {
                        t.focus(), i.remove(), Eo(t, i.value);
                    }, 50);
            })(t),
                !1);
    });
let Po = null;
Co.copy = Co.cut = (t, e) => {
    let { text: i, ranges: n, linewise: o } = (function (t) {
        let e = [],
            i = [],
            n = !1;
        for (let n of t.selection.ranges) n.empty || (e.push(t.sliceDoc(n.from, n.to)), i.push(n));
        if (!e.length) {
            let o = -1;
            for (let { from: n } of t.selection.ranges) {
                let s = t.doc.lineAt(n);
                s.number > o && (e.push(s.text), i.push({ from: s.from, to: Math.min(t.doc.length, s.to + 1) })), (o = s.number);
            }
            n = !0;
        }
        return { text: To(t, yn, e.join(t.lineBreak)), ranges: i, linewise: n };
    })(t.state);
    if (!i && !o) return !1;
    (Po = o ? i : null), "cut" != e.type || t.state.readOnly || t.dispatch({ changes: n, scrollIntoView: !0, userEvent: "delete.cut" });
    let s = So ? null : e.clipboardData;
    return s
        ? (s.clearData(), s.setData("text/plain", i), !0)
        : ((function (t, e) {
            let i = t.dom.parentNode;
            if (!i) return;
            let n = i.appendChild(document.createElement("textarea"));
            (n.style.cssText = "position: fixed; left: -10000px; top: 10px"),
                (n.value = e),
                n.focus(),
                (n.selectionEnd = e.length),
                (n.selectionStart = 0),
                setTimeout(() => {
                    n.remove(), t.focus();
                }, 50);
        })(t, i),
            !1);
};
const _o = $t.define();
function Fo(t, e) {
    let i = [];
    for (let n of t.facet(bn)) {
        let o = n(t, e);
        o && i.push(o);
    }
    return i.length ? t.update({ effects: i, annotations: _o.of(!0) }) : null;
}
function Vo(t) {
    setTimeout(() => {
        let e = t.hasFocus;
        if (e != t.inputState.notifiedFocused) {
            let i = Fo(t.state, e);
            i ? t.dispatch(i) : t.update([]);
        }
    }, 10);
}
(ko.focus = (t) => {
    (t.inputState.lastFocusTime = Date.now()),
        t.scrollDOM.scrollTop || (!t.inputState.lastScrollTop && !t.inputState.lastScrollLeft) || ((t.scrollDOM.scrollTop = t.inputState.lastScrollTop), (t.scrollDOM.scrollLeft = t.inputState.lastScrollLeft)),
        Vo(t);
}),
    (ko.blur = (t) => {
        t.observer.clearSelectionRange(), Vo(t);
    }),
    (ko.compositionstart = ko.compositionupdate = (t) => {
        t.observer.editContext || (null == t.inputState.compositionFirstChange && (t.inputState.compositionFirstChange = !0), t.inputState.composing < 0 && (t.inputState.composing = 0));
    }),
    (ko.compositionend = (t) => {
        t.observer.editContext ||
            ((t.inputState.composing = -1),
                (t.inputState.compositionEndedAt = Date.now()),
                (t.inputState.compositionPendingKey = !0),
                (t.inputState.compositionPendingChange = t.observer.pendingRecords().length > 0),
                (t.inputState.compositionFirstChange = null),
                bi.chrome && bi.android
                    ? t.observer.flushSoon()
                    : t.inputState.compositionPendingChange
                        ? Promise.resolve().then(() => t.observer.flush())
                        : setTimeout(() => {
                            t.inputState.composing < 0 && t.docView.hasComposition && t.update([]);
                        }, 50));
    }),
    (ko.contextmenu = (t) => {
        t.inputState.lastContextMenu = Date.now();
    }),
    (Co.beforeinput = (t, e) => {
        var i, n;
        if ("insertReplacementText" == e.inputType && t.observer.editContext) {
            let n = null === (i = e.dataTransfer) || void 0 === i ? void 0 : i.getData("text/plain"),
                o = e.getTargetRanges();
            if (n && o.length) {
                let e = o[0],
                    i = t.posAtDOM(e.startContainer, e.startOffset),
                    s = t.posAtDOM(e.endContainer, e.endOffset);
                return po(t, { from: i, to: s, insert: t.state.toText(n) }, null), !0;
            }
        }
        let o;
        if (bi.chrome && bi.android && (o = bo.find((t) => t.inputType == e.inputType)) && (t.observer.delayAndroidKey(o.key, o.keyCode), "Backspace" == o.key || "Delete" == o.key)) {
            let e = (null === (n = window.visualViewport) || void 0 === n ? void 0 : n.height) || 0;
            setTimeout(() => {
                var i;
                ((null === (i = window.visualViewport) || void 0 === i ? void 0 : i.height) || 0) > e + 10 && t.hasFocus && (t.contentDOM.blur(), t.focus());
            }, 100);
        }
        return bi.ios && "deleteContentForward" == e.inputType && t.observer.flushSoon(), bi.safari && "insertText" == e.inputType && t.inputState.composing >= 0 && setTimeout(() => ko.compositionend(t, e), 20), !1;
    });
const Ho = new Set(),
    zo = ["pre-wrap", "normal", "pre-line", "break-spaces"];
let $o = !1;
function Wo() {
    $o = !1;
}
class Uo {
    constructor(t) {
        (this.lineWrapping = t), (this.doc = U.empty), (this.heightSamples = {}), (this.lineHeight = 14), (this.charWidth = 7), (this.textHeight = 14), (this.lineLength = 30);
    }
    heightForGap(t, e) {
        let i = this.doc.lineAt(e).number - this.doc.lineAt(t).number + 1;
        return this.lineWrapping && (i += Math.max(0, Math.ceil((e - t - i * this.lineLength * 0.5) / this.lineLength))), this.lineHeight * i;
    }
    heightForLine(t) {
        return this.lineWrapping ? (1 + Math.max(0, Math.ceil((t - this.lineLength) / (this.lineLength - 5)))) * this.lineHeight : this.lineHeight;
    }
    setDoc(t) {
        return (this.doc = t), this;
    }
    mustRefreshForWrapping(t) {
        return zo.indexOf(t) > -1 != this.lineWrapping;
    }
    mustRefreshForHeights(t) {
        let e = !1;
        for (let i = 0; i < t.length; i++) {
            let n = t[i];
            n < 0 ? i++ : this.heightSamples[Math.floor(10 * n)] || ((e = !0), (this.heightSamples[Math.floor(10 * n)] = !0));
        }
        return e;
    }
    refresh(t, e, i, n, o, s) {
        let r = zo.indexOf(t) > -1,
            l = Math.round(e) != Math.round(this.lineHeight) || this.lineWrapping != r;
        if (((this.lineWrapping = r), (this.lineHeight = e), (this.charWidth = i), (this.textHeight = n), (this.lineLength = o), l)) {
            this.heightSamples = {};
            for (let t = 0; t < s.length; t++) {
                let e = s[t];
                e < 0 ? t++ : (this.heightSamples[Math.floor(10 * e)] = !0);
            }
        }
        return l;
    }
}
class jo {
    constructor(t, e) {
        (this.from = t), (this.heights = e), (this.index = 0);
    }
    get more() {
        return this.index < this.heights.length;
    }
}
class Yo {
    constructor(t, e, i, n, o) {
        (this.from = t), (this.length = e), (this.top = i), (this.height = n), (this._content = o);
    }
    get type() {
        return "number" == typeof this._content ? Bi.Text : Array.isArray(this._content) ? this._content : this._content.type;
    }
    get to() {
        return this.from + this.length;
    }
    get bottom() {
        return this.top + this.height;
    }
    get widget() {
        return this._content instanceof Ri ? this._content.widget : null;
    }
    get widgetLineBreaks() {
        return "number" == typeof this._content ? this._content : 0;
    }
    join(t) {
        let e = (Array.isArray(this._content) ? this._content : [this]).concat(Array.isArray(t._content) ? t._content : [t]);
        return new Yo(this.from, this.length + t.length, this.top, this.height + t.height, e);
    }
}
var Go = (function (t) {
    return (t[(t.ByPos = 0)] = "ByPos"), (t[(t.ByHeight = 1)] = "ByHeight"), (t[(t.ByPosNoHeight = 2)] = "ByPosNoHeight"), t;
})(Go || (Go = {}));
const Zo = 0.001;
class Ko {
    constructor(t, e, i = 2) {
        (this.length = t), (this.height = e), (this.flags = i);
    }
    get outdated() {
        return (2 & this.flags) > 0;
    }
    set outdated(t) {
        this.flags = (t ? 2 : 0) | (-3 & this.flags);
    }
    setHeight(t) {
        this.height != t && (Math.abs(this.height - t) > Zo && ($o = !0), (this.height = t));
    }
    replace(t, e, i) {
        return Ko.of(i);
    }
    decomposeLeft(t, e) {
        e.push(this);
    }
    decomposeRight(t, e) {
        e.push(this);
    }
    applyChanges(t, e, i, n) {
        let o = this,
            s = i.doc;
        for (let r = n.length - 1; r >= 0; r--) {
            let { fromA: l, toA: a, fromB: c, toB: h } = n[r],
                d = o.lineAt(l, Go.ByPosNoHeight, i.setDoc(e), 0, 0),
                u = d.to >= a ? d : o.lineAt(a, Go.ByPosNoHeight, i, 0, 0);
            for (h += u.to - a, a = u.to; r > 0 && d.from <= n[r - 1].toA;) (l = n[r - 1].fromA), (c = n[r - 1].fromB), r--, l < d.from && (d = o.lineAt(l, Go.ByPosNoHeight, i, 0, 0));
            (c += d.from - l), (l = d.from);
            let p = ns.build(i.setDoc(s), t, c, h);
            o = Xo(o, o.replace(l, a, p));
        }
        return o.updateHeight(i, 0);
    }
    static empty() {
        return new Qo(0, 0);
    }
    static of(t) {
        if (1 == t.length) return t[0];
        let e = 0,
            i = t.length,
            n = 0,
            o = 0;
        for (; ;)
            if (e == i)
                if (n > 2 * o) {
                    let o = t[e - 1];
                    o.break ? t.splice(--e, 1, o.left, null, o.right) : t.splice(--e, 1, o.left, o.right), (i += 1 + o.break), (n -= o.size);
                } else {
                    if (!(o > 2 * n)) break;
                    {
                        let e = t[i];
                        e.break ? t.splice(i, 1, e.left, null, e.right) : t.splice(i, 1, e.left, e.right), (i += 2 + e.break), (o -= e.size);
                    }
                }
            else if (n < o) {
                let i = t[e++];
                i && (n += i.size);
            } else {
                let e = t[--i];
                e && (o += e.size);
            }
        let s = 0;
        return null == t[e - 1] ? ((s = 1), e--) : null == t[e] && ((s = 1), i++), new es(Ko.of(t.slice(0, e)), s, Ko.of(t.slice(i)));
    }
}
function Xo(t, e) {
    return t == e ? t : (t.constructor != e.constructor && ($o = !0), e);
}
Ko.prototype.size = 1;
class Jo extends Ko {
    constructor(t, e, i) {
        super(t, e), (this.deco = i);
    }
    blockAt(t, e, i, n) {
        return new Yo(n, this.length, i, this.height, this.deco || 0);
    }
    lineAt(t, e, i, n, o) {
        return this.blockAt(0, i, n, o);
    }
    forEachLine(t, e, i, n, o, s) {
        t <= o + this.length && e >= o && s(this.blockAt(0, i, n, o));
    }
    updateHeight(t, e = 0, i = !1, n) {
        return n && n.from <= e && n.more && this.setHeight(n.heights[n.index++]), (this.outdated = !1), this;
    }
    toString() {
        return `block(${this.length})`;
    }
}
class Qo extends Jo {
    constructor(t, e) {
        super(t, e, null), (this.collapsed = 0), (this.widgetHeight = 0), (this.breaks = 0);
    }
    blockAt(t, e, i, n) {
        return new Yo(n, this.length, i, this.height, this.breaks);
    }
    replace(t, e, i) {
        let n = i[0];
        return 1 == i.length && (n instanceof Qo || (n instanceof ts && 4 & n.flags)) && Math.abs(this.length - n.length) < 10
            ? (n instanceof ts ? (n = new Qo(n.length, this.height)) : (n.height = this.height), this.outdated || (n.outdated = !1), n)
            : Ko.of(i);
    }
    updateHeight(t, e = 0, i = !1, n) {
        return (
            n && n.from <= e && n.more ? this.setHeight(n.heights[n.index++]) : (i || this.outdated) && this.setHeight(Math.max(this.widgetHeight, t.heightForLine(this.length - this.collapsed)) + this.breaks * t.lineHeight),
            (this.outdated = !1),
            this
        );
    }
    toString() {
        return `line(${this.length}${this.collapsed ? -this.collapsed : ""}${this.widgetHeight ? ":" + this.widgetHeight : ""})`;
    }
}
class ts extends Ko {
    constructor(t) {
        super(t, 0);
    }
    heightMetrics(t, e) {
        let i,
            n = t.doc.lineAt(e).number,
            o = t.doc.lineAt(e + this.length).number,
            s = o - n + 1,
            r = 0;
        if (t.lineWrapping) {
            let e = Math.min(this.height, t.lineHeight * s);
            (i = e / s), this.length > s + 1 && (r = (this.height - e) / (this.length - s - 1));
        } else i = this.height / s;
        return { firstLine: n, lastLine: o, perLine: i, perChar: r };
    }
    blockAt(t, e, i, n) {
        let { firstLine: o, lastLine: s, perLine: r, perChar: l } = this.heightMetrics(e, n);
        if (e.lineWrapping) {
            let o = n + (t < e.lineHeight ? 0 : Math.round(Math.max(0, Math.min(1, (t - i) / this.height)) * this.length)),
                s = e.doc.lineAt(o),
                a = r + s.length * l,
                c = Math.max(i, t - a / 2);
            return new Yo(s.from, s.length, c, a, 0);
        }
        {
            let n = Math.max(0, Math.min(s - o, Math.floor((t - i) / r))),
                { from: l, length: a } = e.doc.line(o + n);
            return new Yo(l, a, i + r * n, r, 0);
        }
    }
    lineAt(t, e, i, n, o) {
        if (e == Go.ByHeight) return this.blockAt(t, i, n, o);
        if (e == Go.ByPosNoHeight) {
            let { from: e, to: n } = i.doc.lineAt(t);
            return new Yo(e, n - e, 0, 0, 0);
        }
        let { firstLine: s, perLine: r, perChar: l } = this.heightMetrics(i, o),
            a = i.doc.lineAt(t),
            c = r + a.length * l,
            h = a.number - s,
            d = n + r * h + l * (a.from - o - h);
        return new Yo(a.from, a.length, Math.max(n, Math.min(d, n + this.height - c)), c, 0);
    }
    forEachLine(t, e, i, n, o, s) {
        (t = Math.max(t, o)), (e = Math.min(e, o + this.length));
        let { firstLine: r, perLine: l, perChar: a } = this.heightMetrics(i, o);
        for (let c = t, h = n; c <= e;) {
            let e = i.doc.lineAt(c);
            if (c == t) {
                let i = e.number - r;
                h += l * i + a * (t - o - i);
            }
            let n = l + a * e.length;
            s(new Yo(e.from, e.length, h, n, 0)), (h += n), (c = e.to + 1);
        }
    }
    replace(t, e, i) {
        let n = this.length - e;
        if (n > 0) {
            let t = i[i.length - 1];
            t instanceof ts ? (i[i.length - 1] = new ts(t.length + n)) : i.push(null, new ts(n - 1));
        }
        if (t > 0) {
            let e = i[0];
            e instanceof ts ? (i[0] = new ts(t + e.length)) : i.unshift(new ts(t - 1), null);
        }
        return Ko.of(i);
    }
    decomposeLeft(t, e) {
        e.push(new ts(t - 1), null);
    }
    decomposeRight(t, e) {
        e.push(null, new ts(this.length - t - 1));
    }
    updateHeight(t, e = 0, i = !1, n) {
        let o = e + this.length;
        if (n && n.from <= e + this.length && n.more) {
            let i = [],
                s = Math.max(e, n.from),
                r = -1;
            for (n.from > e && i.push(new ts(n.from - e - 1).updateHeight(t, e)); s <= o && n.more;) {
                let e = t.doc.lineAt(s).length;
                i.length && i.push(null);
                let o = n.heights[n.index++];
                -1 == r ? (r = o) : Math.abs(o - r) >= Zo && (r = -2);
                let l = new Qo(e, o);
                (l.outdated = !1), i.push(l), (s += e + 1);
            }
            s <= o && i.push(null, new ts(o - s).updateHeight(t, s));
            let l = Ko.of(i);
            return (r < 0 || Math.abs(l.height - this.height) >= Zo || Math.abs(r - this.heightMetrics(t, e).perLine) >= Zo) && ($o = !0), Xo(this, l);
        }
        return (i || this.outdated) && (this.setHeight(t.heightForGap(e, e + this.length)), (this.outdated = !1)), this;
    }
    toString() {
        return `gap(${this.length})`;
    }
}
class es extends Ko {
    constructor(t, e, i) {
        super(t.length + e + i.length, t.height + i.height, e | (t.outdated || i.outdated ? 2 : 0)), (this.left = t), (this.right = i), (this.size = t.size + i.size);
    }
    get break() {
        return 1 & this.flags;
    }
    blockAt(t, e, i, n) {
        let o = i + this.left.height;
        return t < o ? this.left.blockAt(t, e, i, n) : this.right.blockAt(t, e, o, n + this.left.length + this.break);
    }
    lineAt(t, e, i, n, o) {
        let s = n + this.left.height,
            r = o + this.left.length + this.break,
            l = e == Go.ByHeight ? t < s : t < r,
            a = l ? this.left.lineAt(t, e, i, n, o) : this.right.lineAt(t, e, i, s, r);
        if (this.break || (l ? a.to < r : a.from > r)) return a;
        let c = e == Go.ByPosNoHeight ? Go.ByPosNoHeight : Go.ByPos;
        return l ? a.join(this.right.lineAt(r, c, i, s, r)) : this.left.lineAt(r, c, i, n, o).join(a);
    }
    forEachLine(t, e, i, n, o, s) {
        let r = n + this.left.height,
            l = o + this.left.length + this.break;
        if (this.break) t < l && this.left.forEachLine(t, e, i, n, o, s), e >= l && this.right.forEachLine(t, e, i, r, l, s);
        else {
            let a = this.lineAt(l, Go.ByPos, i, n, o);
            t < a.from && this.left.forEachLine(t, a.from - 1, i, n, o, s), a.to >= t && a.from <= e && s(a), e > a.to && this.right.forEachLine(a.to + 1, e, i, r, l, s);
        }
    }
    replace(t, e, i) {
        let n = this.left.length + this.break;
        if (e < n) return this.balanced(this.left.replace(t, e, i), this.right);
        if (t > this.left.length) return this.balanced(this.left, this.right.replace(t - n, e - n, i));
        let o = [];
        t > 0 && this.decomposeLeft(t, o);
        let s = o.length;
        for (let t of i) o.push(t);
        if ((t > 0 && is(o, s - 1), e < this.length)) {
            let t = o.length;
            this.decomposeRight(e, o), is(o, t);
        }
        return Ko.of(o);
    }
    decomposeLeft(t, e) {
        let i = this.left.length;
        if (t <= i) return this.left.decomposeLeft(t, e);
        e.push(this.left), this.break && (i++, t >= i && e.push(null)), t > i && this.right.decomposeLeft(t - i, e);
    }
    decomposeRight(t, e) {
        let i = this.left.length,
            n = i + this.break;
        if (t >= n) return this.right.decomposeRight(t - n, e);
        t < i && this.left.decomposeRight(t, e), this.break && t < n && e.push(null), e.push(this.right);
    }
    balanced(t, e) {
        return t.size > 2 * e.size || e.size > 2 * t.size
            ? Ko.of(this.break ? [t, null, e] : [t, e])
            : ((this.left = Xo(this.left, t)),
                (this.right = Xo(this.right, e)),
                this.setHeight(t.height + e.height),
                (this.outdated = t.outdated || e.outdated),
                (this.size = t.size + e.size),
                (this.length = t.length + this.break + e.length),
                this);
    }
    updateHeight(t, e = 0, i = !1, n) {
        let { left: o, right: s } = this,
            r = e + o.length + this.break,
            l = null;
        return (
            n && n.from <= e + o.length && n.more ? (l = o = o.updateHeight(t, e, i, n)) : o.updateHeight(t, e, i),
            n && n.from <= r + s.length && n.more ? (l = s = s.updateHeight(t, r, i, n)) : s.updateHeight(t, r, i),
            l ? this.balanced(o, s) : ((this.height = this.left.height + this.right.height), (this.outdated = !1), this)
        );
    }
    toString() {
        return this.left + (this.break ? " " : "-") + this.right;
    }
}
function is(t, e) {
    let i, n;
    null == t[e] && (i = t[e - 1]) instanceof ts && (n = t[e + 1]) instanceof ts && t.splice(e - 1, 3, new ts(i.length + 1 + n.length));
}
class ns {
    constructor(t, e) {
        (this.pos = t), (this.oracle = e), (this.nodes = []), (this.lineStart = -1), (this.lineEnd = -1), (this.covering = null), (this.writtenTo = t);
    }
    get isCovered() {
        return this.covering && this.nodes[this.nodes.length - 1] == this.covering;
    }
    span(t, e) {
        if (this.lineStart > -1) {
            let t = Math.min(e, this.lineEnd),
                i = this.nodes[this.nodes.length - 1];
            i instanceof Qo ? (i.length += t - this.pos) : (t > this.pos || !this.isCovered) && this.nodes.push(new Qo(t - this.pos, -1)), (this.writtenTo = t), e > t && (this.nodes.push(null), this.writtenTo++, (this.lineStart = -1));
        }
        this.pos = e;
    }
    point(t, e, i) {
        if (t < e || i.heightRelevant) {
            let n = i.widget ? i.widget.estimatedHeight : 0,
                o = i.widget ? i.widget.lineBreaks : 0;
            n < 0 && (n = this.oracle.lineHeight);
            let s = e - t;
            i.block ? this.addBlock(new Jo(s, n, i)) : (s || o || n >= 5) && this.addLineDeco(n, o, s);
        } else e > t && this.span(t, e);
        this.lineEnd > -1 && this.lineEnd < this.pos && (this.lineEnd = this.oracle.doc.lineAt(this.pos).to);
    }
    enterLine() {
        if (this.lineStart > -1) return;
        let { from: t, to: e } = this.oracle.doc.lineAt(this.pos);
        (this.lineStart = t),
            (this.lineEnd = e),
            this.writtenTo < t && ((this.writtenTo < t - 1 || null == this.nodes[this.nodes.length - 1]) && this.nodes.push(this.blankContent(this.writtenTo, t - 1)), this.nodes.push(null)),
            this.pos > t && this.nodes.push(new Qo(this.pos - t, -1)),
            (this.writtenTo = this.pos);
    }
    blankContent(t, e) {
        let i = new ts(e - t);
        return this.oracle.doc.lineAt(t).to == e && (i.flags |= 4), i;
    }
    ensureLine() {
        this.enterLine();
        let t = this.nodes.length ? this.nodes[this.nodes.length - 1] : null;
        if (t instanceof Qo) return t;
        let e = new Qo(0, -1);
        return this.nodes.push(e), e;
    }
    addBlock(t) {
        this.enterLine();
        let e = t.deco;
        e && e.startSide > 0 && !this.isCovered && this.ensureLine(), this.nodes.push(t), (this.writtenTo = this.pos = this.pos + t.length), e && e.endSide > 0 && (this.covering = t);
    }
    addLineDeco(t, e, i) {
        let n = this.ensureLine();
        (n.length += i), (n.collapsed += i), (n.widgetHeight = Math.max(n.widgetHeight, t)), (n.breaks += e), (this.writtenTo = this.pos = this.pos + i);
    }
    finish(t) {
        let e = 0 == this.nodes.length ? null : this.nodes[this.nodes.length - 1];
        !(this.lineStart > -1) || e instanceof Qo || this.isCovered ? (this.writtenTo < this.pos || null == e) && this.nodes.push(this.blankContent(this.writtenTo, this.pos)) : this.nodes.push(new Qo(0, -1));
        let i = t;
        for (let t of this.nodes) t instanceof Qo && t.updateHeight(this.oracle, i), (i += t ? t.length : 1);
        return this.nodes;
    }
    static build(t, e, i, n) {
        let o = new ns(i, t);
        return ce.spans(e, i, n, o, 0), o.finish(i);
    }
}
class os {
    constructor() {
        this.changes = [];
    }
    compareRange() { }
    comparePoint(t, e, i, n) {
        (t < e || (i && i.heightRelevant) || (n && n.heightRelevant)) && _i(t, e, this.changes, 5);
    }
}
function ss(t, e) {
    let i = t.getBoundingClientRect(),
        n = t.ownerDocument,
        o = n.defaultView || window,
        s = Math.max(0, i.left),
        r = Math.min(o.innerWidth, i.right),
        l = Math.max(0, i.top),
        a = Math.min(o.innerHeight, i.bottom);
    for (let e = t.parentNode; e && e != n.body;)
        if (1 == e.nodeType) {
            let i = e,
                n = window.getComputedStyle(i);
            if ((i.scrollHeight > i.clientHeight || i.scrollWidth > i.clientWidth) && "visible" != n.overflow) {
                let n = i.getBoundingClientRect();
                (s = Math.max(s, n.left)), (r = Math.min(r, n.right)), (l = Math.max(l, n.top)), (a = Math.min(e == t.parentNode ? o.innerHeight : a, n.bottom));
            }
            e = "absolute" == n.position || "fixed" == n.position ? i.offsetParent : i.parentNode;
        } else {
            if (11 != e.nodeType) break;
            e = e.host;
        }
    return { left: s - i.left, right: Math.max(s, r) - i.left, top: l - (i.top + e), bottom: Math.max(l, a) - (i.top + e) };
}
function rs(t, e) {
    let i = t.getBoundingClientRect();
    return { left: 0, right: i.right - i.left, top: e, bottom: i.bottom - (i.top + e) };
}
class ls {
    constructor(t, e, i, n) {
        (this.from = t), (this.to = e), (this.size = i), (this.displaySize = n);
    }
    static same(t, e) {
        if (t.length != e.length) return !1;
        for (let i = 0; i < t.length; i++) {
            let n = t[i],
                o = e[i];
            if (n.from != o.from || n.to != o.to || n.size != o.size) return !1;
        }
        return !0;
    }
    draw(t, e) {
        return qi.replace({ widget: new as(this.displaySize * (e ? t.scaleY : t.scaleX), e) }).range(this.from, this.to);
    }
}
class as extends Oi {
    constructor(t, e) {
        super(), (this.size = t), (this.vertical = e);
    }
    eq(t) {
        return t.size == this.size && t.vertical == this.vertical;
    }
    toDOM() {
        let t = document.createElement("div");
        return this.vertical ? (t.style.height = this.size + "px") : ((t.style.width = this.size + "px"), (t.style.height = "2px"), (t.style.display = "inline-block")), t;
    }
    get estimatedHeight() {
        return this.vertical ? this.size : -1;
    }
}
class cs {
    constructor(t) {
        (this.state = t),
            (this.pixelViewport = { left: 0, right: window.innerWidth, top: 0, bottom: 0 }),
            (this.inView = !0),
            (this.paddingTop = 0),
            (this.paddingBottom = 0),
            (this.contentDOMWidth = 0),
            (this.contentDOMHeight = 0),
            (this.editorHeight = 0),
            (this.editorWidth = 0),
            (this.scrollTop = 0),
            (this.scrolledToBottom = !1),
            (this.scaleX = 1),
            (this.scaleY = 1),
            (this.scrollAnchorPos = 0),
            (this.scrollAnchorHeight = -1),
            (this.scaler = ps),
            (this.scrollTarget = null),
            (this.printing = !1),
            (this.mustMeasureContent = !0),
            (this.defaultTextDirection = Ui.LTR),
            (this.visibleRanges = []),
            (this.mustEnforceCursorAssoc = !1);
        let e = t.facet(qn).some((t) => "function" != typeof t && "cm-lineWrapping" == t.class);
        (this.heightOracle = new Uo(e)),
            (this.stateDeco = t.facet(Nn).filter((t) => "function" != typeof t)),
            (this.heightMap = Ko.empty().applyChanges(this.stateDeco, U.empty, this.heightOracle.setDoc(t.doc), [new zn(0, 0, 0, t.doc.length)]));
        for (let t = 0; t < 2 && ((this.viewport = this.getViewport(0, null)), this.updateForViewport()); t++);
        this.updateViewportLines(), (this.lineGaps = this.ensureLineGaps([])), (this.lineGapDeco = qi.set(this.lineGaps.map((t) => t.draw(this, !1)))), this.computeVisibleRanges();
    }
    updateForViewport() {
        let t = [this.viewport],
            { main: e } = this.state.selection;
        for (let i = 0; i <= 1; i++) {
            let n = i ? e.head : e.anchor;
            if (!t.some(({ from: t, to: e }) => n >= t && n <= e)) {
                let { from: e, to: i } = this.lineBlockAt(n);
                t.push(new hs(e, i));
            }
        }
        return (this.viewports = t.sort((t, e) => t.from - e.from)), this.updateScaler();
    }
    updateScaler() {
        let t = this.scaler;
        return (this.scaler = this.heightMap.height <= 7e6 ? ps : new ms(this.heightOracle, this.heightMap, this.viewports)), t.eq(this.scaler) ? 0 : 2;
    }
    updateViewportLines() {
        (this.viewportLines = []),
            this.heightMap.forEachLine(this.viewport.from, this.viewport.to, this.heightOracle.setDoc(this.state.doc), 0, 0, (t) => {
                this.viewportLines.push(gs(t, this.scaler));
            });
    }
    update(t, e = null) {
        this.state = t.state;
        let i = this.stateDeco;
        this.stateDeco = this.state.facet(Nn).filter((t) => "function" != typeof t);
        let n = t.changedRanges,
            o = zn.extendWithRanges(
                n,
                (function (t, e, i) {
                    let n = new os();
                    return ce.compare(t, e, i, n, 0), n.changes;
                })(i, this.stateDeco, t ? t.changes : st.empty(this.state.doc.length))
            ),
            s = this.heightMap.height,
            r = this.scrolledToBottom ? null : this.scrollAnchorAt(this.scrollTop);
        Wo(),
            (this.heightMap = this.heightMap.applyChanges(this.stateDeco, t.startState.doc, this.heightOracle.setDoc(this.state.doc), o)),
            (this.heightMap.height != s || $o) && (t.flags |= 2),
            r ? ((this.scrollAnchorPos = t.changes.mapPos(r.from, -1)), (this.scrollAnchorHeight = r.top)) : ((this.scrollAnchorPos = -1), (this.scrollAnchorHeight = s));
        let l = o.length ? this.mapViewport(this.viewport, t.changes) : this.viewport;
        ((e && (e.range.head < l.from || e.range.head > l.to)) || !this.viewportIsAppropriate(l)) && (l = this.getViewport(0, e));
        let a = l.from != this.viewport.from || l.to != this.viewport.to;
        (this.viewport = l),
            (t.flags |= this.updateForViewport()),
            (a || !t.changes.empty || 2 & t.flags) && this.updateViewportLines(),
            (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(this.mapLineGaps(this.lineGaps, t.changes))),
            (t.flags |= this.computeVisibleRanges(t.changes)),
            e && (this.scrollTarget = e),
            !this.mustEnforceCursorAssoc && t.selectionSet && t.view.lineWrapping && t.state.selection.main.empty && t.state.selection.main.assoc && !t.state.facet(xn) && (this.mustEnforceCursorAssoc = !0);
    }
    measure(t) {
        let e = t.contentDOM,
            i = window.getComputedStyle(e),
            n = this.heightOracle,
            o = i.whiteSpace;
        this.defaultTextDirection = "rtl" == i.direction ? Ui.RTL : Ui.LTR;
        let s = this.heightOracle.mustRefreshForWrapping(o),
            r = e.getBoundingClientRect(),
            l = s || this.mustMeasureContent || this.contentDOMHeight != r.height;
        (this.contentDOMHeight = r.height), (this.mustMeasureContent = !1);
        let a = 0,
            c = 0;
        if (r.width && r.height) {
            let { scaleX: t, scaleY: i } = ze(e, r);
            ((t > 0.005 && Math.abs(this.scaleX - t) > 0.005) || (i > 0.005 && Math.abs(this.scaleY - i) > 0.005)) && ((this.scaleX = t), (this.scaleY = i), (a |= 16), (s = l = !0));
        }
        let h = (parseInt(i.paddingTop) || 0) * this.scaleY,
            d = (parseInt(i.paddingBottom) || 0) * this.scaleY;
        (this.paddingTop == h && this.paddingBottom == d) || ((this.paddingTop = h), (this.paddingBottom = d), (a |= 18)),
            this.editorWidth != t.scrollDOM.clientWidth && (n.lineWrapping && (l = !0), (this.editorWidth = t.scrollDOM.clientWidth), (a |= 16));
        let u = t.scrollDOM.scrollTop * this.scaleY;
        this.scrollTop != u && ((this.scrollAnchorHeight = -1), (this.scrollTop = u)), (this.scrolledToBottom = Ke(t.scrollDOM));
        let p = (this.printing ? rs : ss)(e, this.paddingTop),
            m = p.top - this.pixelViewport.top,
            g = p.bottom - this.pixelViewport.bottom;
        this.pixelViewport = p;
        let f = this.pixelViewport.bottom > this.pixelViewport.top && this.pixelViewport.right > this.pixelViewport.left;
        if (
            (f != this.inView && ((this.inView = f), f && (l = !0)),
                !this.inView &&
                !this.scrollTarget &&
                !(function (t) {
                    let e = t.getBoundingClientRect(),
                        i = t.ownerDocument.defaultView || window;
                    return e.left < i.innerWidth && e.right > 0 && e.top < i.innerHeight && e.bottom > 0;
                })(t.dom))
        )
            return 0;
        let b = r.width;
        if (((this.contentDOMWidth == b && this.editorHeight == t.scrollDOM.clientHeight) || ((this.contentDOMWidth = r.width), (this.editorHeight = t.scrollDOM.clientHeight), (a |= 16)), l)) {
            let e = t.docView.measureVisibleLineHeights(this.viewport);
            if ((n.mustRefreshForHeights(e) && (s = !0), s || (n.lineWrapping && Math.abs(b - this.contentDOMWidth) > n.charWidth))) {
                let { lineHeight: i, charWidth: r, textHeight: l } = t.docView.measureTextSize();
                (s = i > 0 && n.refresh(o, i, r, l, b / r, e)), s && ((t.docView.minWidth = 0), (a |= 16));
            }
            m > 0 && g > 0 ? (c = Math.max(m, g)) : m < 0 && g < 0 && (c = Math.min(m, g)), Wo();
            for (let i of this.viewports) {
                let o = i.from == this.viewport.from ? e : t.docView.measureVisibleLineHeights(i);
                this.heightMap = (s ? Ko.empty().applyChanges(this.stateDeco, U.empty, this.heightOracle, [new zn(0, 0, 0, t.state.doc.length)]) : this.heightMap).updateHeight(n, 0, s, new jo(i.from, o));
            }
            $o && (a |= 2);
        }
        let v = !this.viewportIsAppropriate(this.viewport, c) || (this.scrollTarget && (this.scrollTarget.range.head < this.viewport.from || this.scrollTarget.range.head > this.viewport.to));
        return (
            v && (2 & a && (a |= this.updateScaler()), (this.viewport = this.getViewport(c, this.scrollTarget)), (a |= this.updateForViewport())),
            (2 & a || v) && this.updateViewportLines(),
            (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(s ? [] : this.lineGaps, t)),
            (a |= this.computeVisibleRanges()),
            this.mustEnforceCursorAssoc && ((this.mustEnforceCursorAssoc = !1), t.docView.enforceCursorAssoc()),
            a
        );
    }
    get visibleTop() {
        return this.scaler.fromDOM(this.pixelViewport.top);
    }
    get visibleBottom() {
        return this.scaler.fromDOM(this.pixelViewport.bottom);
    }
    getViewport(t, e) {
        let i = 0.5 - Math.max(-0.5, Math.min(0.5, t / 1e3 / 2)),
            n = this.heightMap,
            o = this.heightOracle,
            { visibleTop: s, visibleBottom: r } = this,
            l = new hs(n.lineAt(s - 1e3 * i, Go.ByHeight, o, 0, 0).from, n.lineAt(r + 1e3 * (1 - i), Go.ByHeight, o, 0, 0).to);
        if (e) {
            let { head: t } = e.range;
            if (t < l.from || t > l.to) {
                let i,
                    s = Math.min(this.editorHeight, this.pixelViewport.bottom - this.pixelViewport.top),
                    r = n.lineAt(t, Go.ByPos, o, 0, 0);
                (i = "center" == e.y ? (r.top + r.bottom) / 2 - s / 2 : "start" == e.y || ("nearest" == e.y && t < l.from) ? r.top : r.bottom - s),
                    (l = new hs(n.lineAt(i - 500, Go.ByHeight, o, 0, 0).from, n.lineAt(i + s + 500, Go.ByHeight, o, 0, 0).to));
            }
        }
        return l;
    }
    mapViewport(t, e) {
        let i = e.mapPos(t.from, -1),
            n = e.mapPos(t.to, 1);
        return new hs(this.heightMap.lineAt(i, Go.ByPos, this.heightOracle, 0, 0).from, this.heightMap.lineAt(n, Go.ByPos, this.heightOracle, 0, 0).to);
    }
    viewportIsAppropriate({ from: t, to: e }, i = 0) {
        if (!this.inView) return !0;
        let { top: n } = this.heightMap.lineAt(t, Go.ByPos, this.heightOracle, 0, 0),
            { bottom: o } = this.heightMap.lineAt(e, Go.ByPos, this.heightOracle, 0, 0),
            { visibleTop: s, visibleBottom: r } = this;
        return (0 == t || n <= s - Math.max(10, Math.min(-i, 250))) && (e == this.state.doc.length || o >= r + Math.max(10, Math.min(i, 250))) && n > s - 2e3 && o < r + 2e3;
    }
    mapLineGaps(t, e) {
        if (!t.length || e.empty) return t;
        let i = [];
        for (let n of t) e.touchesRange(n.from, n.to) || i.push(new ls(e.mapPos(n.from), e.mapPos(n.to), n.size, n.displaySize));
        return i;
    }
    ensureLineGaps(t, e) {
        let i = this.heightOracle.lineWrapping,
            n = i ? 1e4 : 2e3,
            o = n >> 1,
            s = n << 1;
        if (this.defaultTextDirection != Ui.LTR && !i) return [];
        let r = [],
            l = (n, s, a, c) => {
                if (s - n < o) return;
                let h = this.state.selection.main,
                    d = [h.from];
                h.empty || d.push(h.to);
                for (let t of d) if (t > n && t < s) return l(n, t - 10, a, c), void l(t + 10, s, a, c);
                let u = (function (t, e) {
                    for (let i of t) if (e(i)) return i;
                })(t, (t) => t.from >= a.from && t.to <= a.to && Math.abs(t.from - n) < o && Math.abs(t.to - s) < o && !d.some((e) => t.from < e && t.to > e));
                if (!u) {
                    if (s < a.to && e && i && e.visibleRanges.some((t) => t.from <= s && t.to >= s)) {
                        let t = e.moveToLineBoundary(pt.cursor(s), !1, !0).head;
                        t > n && (s = t);
                    }
                    let t = this.gapSize(a, n, s, c);
                    u = new ls(n, s, t, i || t < 2e6 ? t : 2e6);
                }
                r.push(u);
            },
            a = (e) => {
                if (e.length < s || e.type != Bi.Text) return;
                let o = (function (t, e, i) {
                    let n = [],
                        o = t,
                        s = 0;
                    return (
                        ce.spans(
                            i,
                            t,
                            e,
                            {
                                span() { },
                                point(t, e) {
                                    t > o && (n.push({ from: o, to: t }), (s += t - o)), (o = e);
                                },
                            },
                            20
                        ),
                        o < e && (n.push({ from: o, to: e }), (s += e - o)),
                        { total: s, ranges: n }
                    );
                })(e.from, e.to, this.stateDeco);
                if (o.total < s) return;
                let r,
                    a,
                    c = this.scrollTarget ? this.scrollTarget.range.head : null;
                if (i) {
                    let t,
                        i,
                        s = (n / this.heightOracle.lineLength) * this.heightOracle.lineHeight;
                    if (null != c) {
                        let n = us(o, c),
                            r = ((this.visibleBottom - this.visibleTop) / 2 + s) / e.height;
                        (t = n - r), (i = n + r);
                    } else (t = (this.visibleTop - e.top - s) / e.height), (i = (this.visibleBottom - e.top + s) / e.height);
                    (r = ds(o, t)), (a = ds(o, i));
                } else {
                    let i = o.total * this.heightOracle.charWidth,
                        s = n * this.heightOracle.charWidth,
                        l = 0;
                    if (i > 2e6) for (let i of t) i.from >= e.from && i.from < e.to && i.size != i.displaySize && i.from * this.heightOracle.charWidth + l < this.pixelViewport.left && (l = i.size - i.displaySize);
                    let h,
                        d,
                        u = this.pixelViewport.left + l,
                        p = this.pixelViewport.right + l;
                    if (null != c) {
                        let t = us(o, c),
                            e = ((p - u) / 2 + s) / i;
                        (h = t - e), (d = t + e);
                    } else (h = (u - s) / i), (d = (p + s) / i);
                    (r = ds(o, h)), (a = ds(o, d));
                }
                r > e.from && l(e.from, r, e, o), a < e.to && l(a, e.to, e, o);
            };
        for (let t of this.viewportLines) Array.isArray(t.type) ? t.type.forEach(a) : a(t);
        return r;
    }
    gapSize(t, e, i, n) {
        let o = us(n, i) - us(n, e);
        return this.heightOracle.lineWrapping ? t.height * o : n.total * this.heightOracle.charWidth * o;
    }
    updateLineGaps(t) {
        ls.same(t, this.lineGaps) || ((this.lineGaps = t), (this.lineGapDeco = qi.set(t.map((t) => t.draw(this, this.heightOracle.lineWrapping)))));
    }
    computeVisibleRanges(t) {
        let e = this.stateDeco;
        this.lineGaps.length && (e = e.concat(this.lineGapDeco));
        let i = [];
        ce.spans(
            e,
            this.viewport.from,
            this.viewport.to,
            {
                span(t, e) {
                    i.push({ from: t, to: e });
                },
                point() { },
            },
            20
        );
        let n = 0;
        if (i.length != this.visibleRanges.length) n = 12;
        else
            for (let e = 0; e < i.length && !(8 & n); e++) {
                let o = this.visibleRanges[e],
                    s = i[e];
                (o.from == s.from && o.to == s.to) || ((n |= 4), (t && t.mapPos(o.from, -1) == s.from && t.mapPos(o.to, 1) == s.to) || (n |= 8));
            }
        return (this.visibleRanges = i), n;
    }
    lineBlockAt(t) {
        return (t >= this.viewport.from && t <= this.viewport.to && this.viewportLines.find((e) => e.from <= t && e.to >= t)) || gs(this.heightMap.lineAt(t, Go.ByPos, this.heightOracle, 0, 0), this.scaler);
    }
    lineBlockAtHeight(t) {
        return (
            (t >= this.viewportLines[0].top && t <= this.viewportLines[this.viewportLines.length - 1].bottom && this.viewportLines.find((e) => e.top <= t && e.bottom >= t)) ||
            gs(this.heightMap.lineAt(this.scaler.fromDOM(t), Go.ByHeight, this.heightOracle, 0, 0), this.scaler)
        );
    }
    scrollAnchorAt(t) {
        let e = this.lineBlockAtHeight(t + 8);
        return e.from >= this.viewport.from || this.viewportLines[0].top - t > 200 ? e : this.viewportLines[0];
    }
    elementAtHeight(t) {
        return gs(this.heightMap.blockAt(this.scaler.fromDOM(t), this.heightOracle, 0, 0), this.scaler);
    }
    get docHeight() {
        return this.scaler.toDOM(this.heightMap.height);
    }
    get contentHeight() {
        return this.docHeight + this.paddingTop + this.paddingBottom;
    }
}
class hs {
    constructor(t, e) {
        (this.from = t), (this.to = e);
    }
}
function ds({ total: t, ranges: e }, i) {
    if (i <= 0) return e[0].from;
    if (i >= 1) return e[e.length - 1].to;
    let n = Math.floor(t * i);
    for (let t = 0; ; t++) {
        let { from: i, to: o } = e[t],
            s = o - i;
        if (n <= s) return i + n;
        n -= s;
    }
}
function us(t, e) {
    let i = 0;
    for (let { from: n, to: o } of t.ranges) {
        if (e <= o) {
            i += e - n;
            break;
        }
        i += o - n;
    }
    return i / t.total;
}
const ps = {
    toDOM: (t) => t,
    fromDOM: (t) => t,
    scale: 1,
    eq(t) {
        return t == this;
    },
};
class ms {
    constructor(t, e, i) {
        let n = 0,
            o = 0,
            s = 0;
        (this.viewports = i.map(({ from: i, to: o }) => {
            let s = e.lineAt(i, Go.ByPos, t, 0, 0).top,
                r = e.lineAt(o, Go.ByPos, t, 0, 0).bottom;
            return (n += r - s), { from: i, to: o, top: s, bottom: r, domTop: 0, domBottom: 0 };
        })),
            (this.scale = (7e6 - n) / (e.height - n));
        for (let t of this.viewports) (t.domTop = s + (t.top - o) * this.scale), (s = t.domBottom = t.domTop + (t.bottom - t.top)), (o = t.bottom);
    }
    toDOM(t) {
        for (let e = 0, i = 0, n = 0; ; e++) {
            let o = e < this.viewports.length ? this.viewports[e] : null;
            if (!o || t < o.top) return n + (t - i) * this.scale;
            if (t <= o.bottom) return o.domTop + (t - o.top);
            (i = o.bottom), (n = o.domBottom);
        }
    }
    fromDOM(t) {
        for (let e = 0, i = 0, n = 0; ; e++) {
            let o = e < this.viewports.length ? this.viewports[e] : null;
            if (!o || t < o.domTop) return i + (t - n) / this.scale;
            if (t <= o.domBottom) return o.top + (t - o.domTop);
            (i = o.bottom), (n = o.domBottom);
        }
    }
    eq(t) {
        return t instanceof ms && this.scale == t.scale && this.viewports.length == t.viewports.length && this.viewports.every((e, i) => e.from == t.viewports[i].from && e.to == t.viewports[i].to);
    }
}
function gs(t, e) {
    if (1 == e.scale) return t;
    let i = e.toDOM(t.top),
        n = e.toDOM(t.bottom);
    return new Yo(t.from, t.length, i, n - i, Array.isArray(t._content) ? t._content.map((t) => gs(t, e)) : t._content);
}
const fs = ft.define({ combine: (t) => t.join(" ") }),
    bs = ft.define({ combine: (t) => t.indexOf(!0) > -1 }),
    vs = Se.newName(),
    ys = Se.newName(),
    ws = Se.newName(),
    xs = { "&light": "." + ys, "&dark": "." + ws };
function Cs(t, e, i) {
    return new Se(e, {
        finish: (e) =>
            /&/.test(e)
                ? e.replace(/&\w*/, (e) => {
                    if ("&" == e) return t;
                    if (!i || !i[e]) throw new RangeError(`Unsupported selector: ${e}`);
                    return i[e];
                })
                : t + " " + e,
    });
}
const ks = Cs(
    "." + vs,
    {
        "&": { position: "relative !important", boxSizing: "border-box", "&.cm-focused": { outline: "1px dotted #212121" }, display: "flex !important", flexDirection: "column" },
        ".cm-scroller": { display: "flex !important", alignItems: "flex-start !important", fontFamily: "monospace", lineHeight: 1.4, height: "100%", overflowX: "auto", position: "relative", zIndex: 0, overflowAnchor: "none" },
        ".cm-content": {
            margin: 0,
            flexGrow: 2,
            flexShrink: 0,
            display: "block",
            whiteSpace: "pre",
            wordWrap: "normal",
            boxSizing: "border-box",
            minHeight: "100%",
            padding: "4px 0",
            outline: "none",
            "&[contenteditable=true]": { WebkitUserModify: "read-write-plaintext-only" },
        },
        ".cm-lineWrapping": { whiteSpace_fallback: "pre-wrap", whiteSpace: "break-spaces", wordBreak: "break-word", overflowWrap: "anywhere", flexShrink: 1 },
        "&light .cm-content": { caretColor: "black" },
        "&dark .cm-content": { caretColor: "white" },
        ".cm-line": { display: "block", padding: "0 2px 0 6px" },
        ".cm-layer": { position: "absolute", left: 0, top: 0, contain: "size style", "& > *": { position: "absolute" } },
        "&light .cm-selectionBackground": { background: "#d9d9d9" },
        "&dark .cm-selectionBackground": { background: "#222" },
        "&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": { background: "#d7d4f0" },
        "&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": { background: "#233" },
        ".cm-cursorLayer": { pointerEvents: "none" },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer": { animation: "steps(1) cm-blink 1.2s infinite" },
        "@keyframes cm-blink": { "0%": {}, "50%": { opacity: 0 }, "100%": {} },
        "@keyframes cm-blink2": { "0%": {}, "50%": { opacity: 0 }, "100%": {} },
        ".cm-cursor, .cm-dropCursor": { borderLeft: "1.2px solid black", marginLeft: "-0.6px", pointerEvents: "none" },
        ".cm-cursor": { display: "none" },
        "&dark .cm-cursor": { borderLeftColor: "#ddd" },
        ".cm-dropCursor": { position: "absolute" },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor": { display: "block" },
        ".cm-iso": { unicodeBidi: "isolate" },
        ".cm-announced": { position: "fixed", top: "-10000px" },
        "@media print": { ".cm-announced": { display: "none" } },
        "&light .cm-activeLine": { backgroundColor: "#cceeff44" },
        "&dark .cm-activeLine": { backgroundColor: "#99eeff33" },
        "&light .cm-specialChar": { color: "red" },
        "&dark .cm-specialChar": { color: "#f78" },
        ".cm-gutters": { flexShrink: 0, display: "flex", height: "100%", boxSizing: "border-box", zIndex: 200 },
        ".cm-gutters-before": { insetInlineStart: 0 },
        ".cm-gutters-after": { insetInlineEnd: 0 },
        "&light .cm-gutters": { backgroundColor: "#f5f5f5", color: "#6c6c6c", border: "0px solid #ddd", "&.cm-gutters-before": { borderRightWidth: "1px" }, "&.cm-gutters-after": { borderLeftWidth: "1px" } },
        "&dark .cm-gutters": { backgroundColor: "#333338", color: "#ccc" },
        ".cm-gutter": { display: "flex !important", flexDirection: "column", flexShrink: 0, boxSizing: "border-box", minHeight: "100%", overflow: "hidden" },
        ".cm-gutterElement": { boxSizing: "border-box" },
        ".cm-lineNumbers .cm-gutterElement": { padding: "0 3px 0 5px", minWidth: "20px", textAlign: "right", whiteSpace: "nowrap" },
        "&light .cm-activeLineGutter": { backgroundColor: "#e2f2ff" },
        "&dark .cm-activeLineGutter": { backgroundColor: "#222227" },
        ".cm-panels": { boxSizing: "border-box", position: "sticky", left: 0, right: 0, zIndex: 300 },
        "&light .cm-panels": { backgroundColor: "#f5f5f5", color: "black" },
        "&light .cm-panels-top": { borderBottom: "1px solid #ddd" },
        "&light .cm-panels-bottom": { borderTop: "1px solid #ddd" },
        "&dark .cm-panels": { backgroundColor: "#333338", color: "white" },
        ".cm-dialog": { padding: "2px 19px 4px 6px", position: "relative", "& label": { fontSize: "80%" } },
        ".cm-dialog-close": { position: "absolute", top: "3px", right: "4px", backgroundColor: "inherit", border: "none", font: "inherit", fontSize: "14px", padding: "0" },
        ".cm-tab": { display: "inline-block", overflow: "hidden", verticalAlign: "bottom" },
        ".cm-widgetBuffer": { verticalAlign: "text-top", height: "1em", width: 0, display: "inline" },
        ".cm-placeholder": { color: "#888", display: "inline-block", verticalAlign: "top", userSelect: "none" },
        ".cm-highlightSpace": { backgroundImage: "radial-gradient(circle at 50% 55%, #aaa 20%, transparent 5%)", backgroundPosition: "center" },
        ".cm-highlightTab": {
            backgroundImage: 'url(\'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>\')',
            backgroundSize: "auto 100%",
            backgroundPosition: "right 90%",
            backgroundRepeat: "no-repeat",
        },
        ".cm-trailingSpace": { backgroundColor: "#ff332255" },
        ".cm-button": { verticalAlign: "middle", color: "inherit", fontSize: "70%", padding: ".2em 1em", borderRadius: "1px" },
        "&light .cm-button": { backgroundImage: "linear-gradient(#eff1f5, #d9d9df)", border: "1px solid #888", "&:active": { backgroundImage: "linear-gradient(#b4b4b4, #d0d3d6)" } },
        "&dark .cm-button": { backgroundImage: "linear-gradient(#393939, #111)", border: "1px solid #888", "&:active": { backgroundImage: "linear-gradient(#111, #333)" } },
        ".cm-textfield": { verticalAlign: "middle", color: "inherit", fontSize: "70%", border: "1px solid silver", padding: ".2em .5em" },
        "&light .cm-textfield": { backgroundColor: "white" },
        "&dark .cm-textfield": { border: "1px solid #555", backgroundColor: "inherit" },
    },
    xs
),
    Ss = { childList: !0, characterData: !0, subtree: !0, attributes: !0, characterDataOldValue: !0 },
    Ts = bi.ie && bi.ie_version <= 11;
class Es {
    constructor(t) {
        (this.view = t),
            (this.active = !1),
            (this.editContext = null),
            (this.selectionRange = new $e()),
            (this.selectionChanged = !1),
            (this.delayedFlush = -1),
            (this.resizeTimeout = -1),
            (this.queue = []),
            (this.delayedAndroidKey = null),
            (this.flushingAndroidKey = -1),
            (this.lastChange = 0),
            (this.scrollTargets = []),
            (this.intersection = null),
            (this.resizeScroll = null),
            (this.intersecting = !1),
            (this.gapIntersection = null),
            (this.gaps = []),
            (this.printQuery = null),
            (this.parentCheck = -1),
            (this.dom = t.contentDOM),
            (this.observer = new MutationObserver((e) => {
                for (let t of e) this.queue.push(t);
                ((bi.ie && bi.ie_version <= 11) || (bi.ios && t.composing)) && e.some((t) => ("childList" == t.type && t.removedNodes.length) || ("characterData" == t.type && t.oldValue.length > t.target.nodeValue.length))
                    ? this.flushSoon()
                    : this.flush();
            })),
            !window.EditContext ||
            !bi.android ||
            !1 === t.constructor.EDIT_CONTEXT ||
            (bi.chrome && bi.chrome_version < 126) ||
            ((this.editContext = new Ds(t)), t.state.facet(Mn) && (t.contentDOM.editContext = this.editContext.editContext)),
            Ts &&
            (this.onCharData = (t) => {
                this.queue.push({ target: t.target, type: "characterData", oldValue: t.prevValue }), this.flushSoon();
            }),
            (this.onSelectionChange = this.onSelectionChange.bind(this)),
            (this.onResize = this.onResize.bind(this)),
            (this.onPrint = this.onPrint.bind(this)),
            (this.onScroll = this.onScroll.bind(this)),
            window.matchMedia && (this.printQuery = window.matchMedia("print")),
            "function" == typeof ResizeObserver &&
            ((this.resizeScroll = new ResizeObserver(() => {
                var t;
                (null === (t = this.view.docView) || void 0 === t ? void 0 : t.lastUpdate) < Date.now() - 75 && this.onResize();
            })),
                this.resizeScroll.observe(t.scrollDOM)),
            this.addWindowListeners((this.win = t.win)),
            this.start(),
            "function" == typeof IntersectionObserver &&
            ((this.intersection = new IntersectionObserver(
                (t) => {
                    this.parentCheck < 0 && (this.parentCheck = setTimeout(this.listenForScroll.bind(this), 1e3)),
                        t.length > 0 &&
                        t[t.length - 1].intersectionRatio > 0 != this.intersecting &&
                        ((this.intersecting = !this.intersecting), this.intersecting != this.view.inView && this.onScrollChanged(document.createEvent("Event")));
                },
                { threshold: [0, 0.001] }
            )),
                this.intersection.observe(this.dom),
                (this.gapIntersection = new IntersectionObserver((t) => {
                    t.length > 0 && t[t.length - 1].intersectionRatio > 0 && this.onScrollChanged(document.createEvent("Event"));
                }, {}))),
            this.listenForScroll(),
            this.readSelectionRange();
    }
    onScrollChanged(t) {
        this.view.inputState.runHandlers("scroll", t), this.intersecting && this.view.measure();
    }
    onScroll(t) {
        this.intersecting && this.flush(!1), this.editContext && this.view.requestMeasure(this.editContext.measureReq), this.onScrollChanged(t);
    }
    onResize() {
        this.resizeTimeout < 0 &&
            (this.resizeTimeout = setTimeout(() => {
                (this.resizeTimeout = -1), this.view.requestMeasure();
            }, 50));
    }
    onPrint(t) {
        (("change" != t.type && t.type) || t.matches) &&
            ((this.view.viewState.printing = !0),
                this.view.measure(),
                setTimeout(() => {
                    (this.view.viewState.printing = !1), this.view.requestMeasure();
                }, 500));
    }
    updateGaps(t) {
        if (this.gapIntersection && (t.length != this.gaps.length || this.gaps.some((e, i) => e != t[i]))) {
            this.gapIntersection.disconnect();
            for (let e of t) this.gapIntersection.observe(e);
            this.gaps = t;
        }
    }
    onSelectionChange(t) {
        let e = this.selectionChanged;
        if (!this.readSelectionRange() || this.delayedAndroidKey) return;
        let { view: i } = this,
            n = this.selectionRange;
        if (i.state.facet(Mn) ? i.root.activeElement != this.dom : !qe(this.dom, n)) return;
        let o = n.anchorNode && i.docView.nearest(n.anchorNode);
        o && o.ignoreEvent(t)
            ? e || (this.selectionChanged = !1)
            : ((bi.ie && bi.ie_version <= 11) || (bi.android && bi.chrome)) && !i.state.selection.main.empty && n.focusNode && Le(n.focusNode, n.focusOffset, n.anchorNode, n.anchorOffset)
                ? this.flushSoon()
                : this.flush(!1);
    }
    readSelectionRange() {
        let { view: t } = this,
            e = Oe(t.root);
        if (!e) return !1;
        let i =
            (bi.safari &&
                11 == t.root.nodeType &&
                t.root.activeElement == this.dom &&
                (function (t, e) {
                    if (e.getComposedRanges) {
                        let i = e.getComposedRanges(t.root)[0];
                        if (i) return As(t, i);
                    }
                    let i = null;
                    function n(t) {
                        t.preventDefault(), t.stopImmediatePropagation(), (i = t.getTargetRanges()[0]);
                    }
                    return t.contentDOM.addEventListener("beforeinput", n, !0), t.dom.ownerDocument.execCommand("indent"), t.contentDOM.removeEventListener("beforeinput", n, !0), i ? As(t, i) : null;
                })(this.view, e)) ||
            e;
        if (!i || this.selectionRange.eq(i)) return !1;
        let n = qe(this.dom, i);
        return n &&
            !this.selectionChanged &&
            t.inputState.lastFocusTime > Date.now() - 200 &&
            t.inputState.lastTouchTime < Date.now() - 300 &&
            (function (t, e) {
                let i = e.focusNode,
                    n = e.focusOffset;
                if (!i || e.anchorNode != i || e.anchorOffset != n) return !1;
                for (n = Math.min(n, Fe(i)); ;)
                    if (n) {
                        if (1 != i.nodeType) return !1;
                        let t = i.childNodes[n - 1];
                        "false" == t.contentEditable ? n-- : ((i = t), (n = Fe(i)));
                    } else {
                        if (i == t) return !0;
                        (n = Re(i)), (i = i.parentNode);
                    }
            })(this.dom, i)
            ? ((this.view.inputState.lastFocusTime = 0), t.docView.updateSelection(), !1)
            : (this.selectionRange.setRange(i), n && (this.selectionChanged = !0), !0);
    }
    setSelectionRange(t, e) {
        this.selectionRange.set(t.node, t.offset, e.node, e.offset), (this.selectionChanged = !1);
    }
    clearSelectionRange() {
        this.selectionRange.set(null, 0, null, 0);
    }
    listenForScroll() {
        this.parentCheck = -1;
        let t = 0,
            e = null;
        for (let i = this.dom; i;)
            if (1 == i.nodeType) !e && t < this.scrollTargets.length && this.scrollTargets[t] == i ? t++ : e || (e = this.scrollTargets.slice(0, t)), e && e.push(i), (i = i.assignedSlot || i.parentNode);
            else {
                if (11 != i.nodeType) break;
                i = i.host;
            }
        if ((t < this.scrollTargets.length && !e && (e = this.scrollTargets.slice(0, t)), e)) {
            for (let t of this.scrollTargets) t.removeEventListener("scroll", this.onScroll);
            for (let t of (this.scrollTargets = e)) t.addEventListener("scroll", this.onScroll);
        }
    }
    ignore(t) {
        if (!this.active) return t();
        try {
            return this.stop(), t();
        } finally {
            this.start(), this.clear();
        }
    }
    start() {
        this.active || (this.observer.observe(this.dom, Ss), Ts && this.dom.addEventListener("DOMCharacterDataModified", this.onCharData), (this.active = !0));
    }
    stop() {
        this.active && ((this.active = !1), this.observer.disconnect(), Ts && this.dom.removeEventListener("DOMCharacterDataModified", this.onCharData));
    }
    clear() {
        this.processRecords(), (this.queue.length = 0), (this.selectionChanged = !1);
    }
    delayAndroidKey(t, e) {
        var i;
        if (!this.delayedAndroidKey) {
            let t = () => {
                let t = this.delayedAndroidKey;
                t && (this.clearDelayedAndroidKey(), (this.view.inputState.lastKeyCode = t.keyCode), (this.view.inputState.lastKeyTime = Date.now()), !this.flush() && t.force && Ge(this.dom, t.key, t.keyCode));
            };
            this.flushingAndroidKey = this.view.win.requestAnimationFrame(t);
        }
        (this.delayedAndroidKey && "Enter" != t) || (this.delayedAndroidKey = { key: t, keyCode: e, force: this.lastChange < Date.now() - 50 || !!(null === (i = this.delayedAndroidKey) || void 0 === i ? void 0 : i.force) });
    }
    clearDelayedAndroidKey() {
        this.win.cancelAnimationFrame(this.flushingAndroidKey), (this.delayedAndroidKey = null), (this.flushingAndroidKey = -1);
    }
    flushSoon() {
        this.delayedFlush < 0 &&
            (this.delayedFlush = this.view.win.requestAnimationFrame(() => {
                (this.delayedFlush = -1), this.flush();
            }));
    }
    forceFlush() {
        this.delayedFlush >= 0 && (this.view.win.cancelAnimationFrame(this.delayedFlush), (this.delayedFlush = -1)), this.flush();
    }
    pendingRecords() {
        for (let t of this.observer.takeRecords()) this.queue.push(t);
        return this.queue;
    }
    processRecords() {
        let t = this.pendingRecords();
        t.length && (this.queue = []);
        let e = -1,
            i = -1,
            n = !1;
        for (let o of t) {
            let t = this.readMutation(o);
            t && (t.typeOver && (n = !0), -1 == e ? ({ from: e, to: i } = t) : ((e = Math.min(t.from, e)), (i = Math.max(t.to, i))));
        }
        return { from: e, to: i, typeOver: n };
    }
    readChange() {
        let { from: t, to: e, typeOver: i } = this.processRecords(),
            n = this.selectionChanged && qe(this.dom, this.selectionRange);
        if (t < 0 && !n) return null;
        t > -1 && (this.lastChange = Date.now()), (this.view.inputState.lastFocusTime = 0), (this.selectionChanged = !1);
        let o = new ho(this.view, t, e, i);
        return (this.view.docView.domChanged = { newSel: o.newSel ? o.newSel.main : null }), o;
    }
    flush(t = !0) {
        if (this.delayedFlush >= 0 || this.delayedAndroidKey) return !1;
        t && this.readSelectionRange();
        let e = this.readChange();
        if (!e) return this.view.requestMeasure(), !1;
        let i = this.view.state,
            n = uo(this.view, e);
        return this.view.state == i && (e.domChanged || (e.newSel && !e.newSel.main.eq(this.view.state.selection.main))) && this.view.update([]), n;
    }
    readMutation(t) {
        let e = this.view.docView.nearest(t.target);
        if (!e || e.ignoreMutation(t)) return null;
        if ((e.markDirty("attributes" == t.type), "attributes" == t.type && (e.flags |= 4), "childList" == t.type)) {
            let i = Ms(e, t.previousSibling || t.target.previousSibling, -1),
                n = Ms(e, t.nextSibling || t.target.nextSibling, 1);
            return { from: i ? e.posAfter(i) : e.posAtStart, to: n ? e.posBefore(n) : e.posAtEnd, typeOver: !1 };
        }
        return "characterData" == t.type ? { from: e.posAtStart, to: e.posAtEnd, typeOver: t.target.nodeValue == t.oldValue } : null;
    }
    setWindow(t) {
        t != this.win && (this.removeWindowListeners(this.win), (this.win = t), this.addWindowListeners(this.win));
    }
    addWindowListeners(t) {
        t.addEventListener("resize", this.onResize),
            this.printQuery ? (this.printQuery.addEventListener ? this.printQuery.addEventListener("change", this.onPrint) : this.printQuery.addListener(this.onPrint)) : t.addEventListener("beforeprint", this.onPrint),
            t.addEventListener("scroll", this.onScroll),
            t.document.addEventListener("selectionchange", this.onSelectionChange);
    }
    removeWindowListeners(t) {
        t.removeEventListener("scroll", this.onScroll),
            t.removeEventListener("resize", this.onResize),
            this.printQuery ? (this.printQuery.removeEventListener ? this.printQuery.removeEventListener("change", this.onPrint) : this.printQuery.removeListener(this.onPrint)) : t.removeEventListener("beforeprint", this.onPrint),
            t.document.removeEventListener("selectionchange", this.onSelectionChange);
    }
    update(t) {
        this.editContext && (this.editContext.update(t), t.startState.facet(Mn) != t.state.facet(Mn) && (t.view.contentDOM.editContext = t.state.facet(Mn) ? this.editContext.editContext : null));
    }
    destroy() {
        var t, e, i;
        this.stop(), null === (t = this.intersection) || void 0 === t || t.disconnect(), null === (e = this.gapIntersection) || void 0 === e || e.disconnect(), null === (i = this.resizeScroll) || void 0 === i || i.disconnect();
        for (let t of this.scrollTargets) t.removeEventListener("scroll", this.onScroll);
        this.removeWindowListeners(this.win),
            clearTimeout(this.parentCheck),
            clearTimeout(this.resizeTimeout),
            this.win.cancelAnimationFrame(this.delayedFlush),
            this.win.cancelAnimationFrame(this.flushingAndroidKey),
            this.editContext && ((this.view.contentDOM.editContext = null), this.editContext.destroy());
    }
}
function Ms(t, e, i) {
    for (; e;) {
        let n = ei.get(e);
        if (n && n.parent == t) return n;
        let o = e.parentNode;
        e = o != t.dom ? o : i > 0 ? e.nextSibling : e.previousSibling;
    }
    return null;
}
function As(t, e) {
    let i = e.startContainer,
        n = e.startOffset,
        o = e.endContainer,
        s = e.endOffset,
        r = t.docView.domAtPos(t.state.selection.main.anchor);
    return Le(r.node, r.offset, o, s) && ([i, n, o, s] = [o, s, i, n]), { anchorNode: i, anchorOffset: n, focusNode: o, focusOffset: s };
}
class Ds {
    constructor(t) {
        (this.from = 0), (this.to = 0), (this.pendingContextChange = null), (this.handlers = Object.create(null)), (this.composing = null), this.resetRange(t.state);
        let e = (this.editContext = new window.EditContext({
            text: t.state.doc.sliceString(this.from, this.to),
            selectionStart: this.toContextPos(Math.max(this.from, Math.min(this.to, t.state.selection.main.anchor))),
            selectionEnd: this.toContextPos(t.state.selection.main.head),
        }));
        (this.handlers.textupdate = (e) => {
            let i = t.state.selection.main,
                { anchor: n, head: o } = i,
                s = this.toEditorPos(e.updateRangeStart),
                r = this.toEditorPos(e.updateRangeEnd);
            t.inputState.composing >= 0 && !this.composing && (this.composing = { contextBase: e.updateRangeStart, editorBase: s, drifted: !1 });
            let l = { from: s, to: r, insert: U.of(e.text.split("\n")) };
            if ((l.from == this.from && n < this.from ? (l.from = n) : l.to == this.to && n > this.to && (l.to = n), l.from != l.to || l.insert.length)) {
                if (
                    ((bi.mac || bi.android) && l.from == o - 1 && /^\. ?$/.test(e.text) && "off" == t.contentDOM.getAttribute("autocorrect") && (l = { from: s, to: r, insert: U.of([e.text.replace(".", " ")]) }),
                        (this.pendingContextChange = l),
                        !t.state.readOnly)
                ) {
                    let i = this.to - this.from + (l.to - l.from + l.insert.length);
                    po(t, l, pt.single(this.toEditorPos(e.selectionStart, i), this.toEditorPos(e.selectionEnd, i)));
                }
                this.pendingContextChange && (this.revertPending(t.state), this.setSelection(t.state));
            } else {
                let n = pt.single(this.toEditorPos(e.selectionStart), this.toEditorPos(e.selectionEnd));
                n.main.eq(i) || t.dispatch({ selection: n, userEvent: "select" });
            }
        }),
            (this.handlers.characterboundsupdate = (i) => {
                let n = [],
                    o = null;
                for (let e = this.toEditorPos(i.rangeStart), s = this.toEditorPos(i.rangeEnd); e < s; e++) {
                    let i = t.coordsForChar(e);
                    (o = (i && new DOMRect(i.left, i.top, i.right - i.left, i.bottom - i.top)) || o || new DOMRect()), n.push(o);
                }
                e.updateCharacterBounds(i.rangeStart, n);
            }),
            (this.handlers.textformatupdate = (e) => {
                let i = [];
                for (let t of e.getTextFormats()) {
                    let e = t.underlineStyle,
                        n = t.underlineThickness;
                    if ("None" != e && "None" != n) {
                        let o = this.toEditorPos(t.rangeStart),
                            s = this.toEditorPos(t.rangeEnd);
                        if (o < s) {
                            let t = `text-decoration: underline ${"Dashed" == e ? "dashed " : "Squiggle" == e ? "wavy " : ""}${"Thin" == n ? 1 : 2}px`;
                            i.push(qi.mark({ attributes: { style: t } }).range(o, s));
                        }
                    }
                }
                t.dispatch({ effects: Tn.of(qi.set(i)) });
            }),
            (this.handlers.compositionstart = () => {
                t.inputState.composing < 0 && ((t.inputState.composing = 0), (t.inputState.compositionFirstChange = !0));
            }),
            (this.handlers.compositionend = () => {
                if (((t.inputState.composing = -1), (t.inputState.compositionFirstChange = null), this.composing)) {
                    let { drifted: e } = this.composing;
                    (this.composing = null), e && this.reset(t.state);
                }
            });
        for (let t in this.handlers) e.addEventListener(t, this.handlers[t]);
        this.measureReq = {
            read: (t) => {
                this.editContext.updateControlBounds(t.contentDOM.getBoundingClientRect());
                let e = Oe(t.root);
                e && e.rangeCount && this.editContext.updateSelectionBounds(e.getRangeAt(0).getBoundingClientRect());
            },
        };
    }
    applyEdits(t) {
        let e = 0,
            i = !1,
            n = this.pendingContextChange;
        return (
            t.changes.iterChanges((o, s, r, l, a) => {
                if (i) return;
                let c = a.length - (s - o);
                if (n && s >= n.to) {
                    if (n.from == o && n.to == s && n.insert.eq(a)) return (n = this.pendingContextChange = null), (e += c), void (this.to += c);
                    (n = null), this.revertPending(t.state);
                }
                if (((o += e), (s += e) <= this.from)) (this.from += c), (this.to += c);
                else if (o < this.to) {
                    if (o < this.from || s > this.to || this.to - this.from + a.length > 3e4) return void (i = !0);
                    this.editContext.updateText(this.toContextPos(o), this.toContextPos(s), a.toString()), (this.to += c);
                }
                e += c;
            }),
            n && !i && this.revertPending(t.state),
            !i
        );
    }
    update(t) {
        let e = this.pendingContextChange,
            i = t.startState.selection.main;
        this.composing && (this.composing.drifted || (!t.changes.touchesRange(i.from, i.to) && t.transactions.some((t) => !t.isUserEvent("input.type") && t.changes.touchesRange(this.from, this.to))))
            ? ((this.composing.drifted = !0), (this.composing.editorBase = t.changes.mapPos(this.composing.editorBase)))
            : this.applyEdits(t) && this.rangeIsValid(t.state)
                ? (t.docChanged || t.selectionSet || e) && this.setSelection(t.state)
                : ((this.pendingContextChange = null), this.reset(t.state)),
            (t.geometryChanged || t.docChanged || t.selectionSet) && t.view.requestMeasure(this.measureReq);
    }
    resetRange(t) {
        let { head: e } = t.selection.main;
        (this.from = Math.max(0, e - 1e4)), (this.to = Math.min(t.doc.length, e + 1e4));
    }
    reset(t) {
        this.resetRange(t), this.editContext.updateText(0, this.editContext.text.length, t.doc.sliceString(this.from, this.to)), this.setSelection(t);
    }
    revertPending(t) {
        let e = this.pendingContextChange;
        (this.pendingContextChange = null), this.editContext.updateText(this.toContextPos(e.from), this.toContextPos(e.from + e.insert.length), t.doc.sliceString(e.from, e.to));
    }
    setSelection(t) {
        let { main: e } = t.selection,
            i = this.toContextPos(Math.max(this.from, Math.min(this.to, e.anchor))),
            n = this.toContextPos(e.head);
        (this.editContext.selectionStart == i && this.editContext.selectionEnd == n) || this.editContext.updateSelection(i, n);
    }
    rangeIsValid(t) {
        let { head: e } = t.selection.main;
        return !((this.from > 0 && e - this.from < 500) || (this.to < t.doc.length && this.to - e < 500) || this.to - this.from > 3e4);
    }
    toEditorPos(t, e = this.to - this.from) {
        t = Math.min(t, e);
        let i = this.composing;
        return i && i.drifted ? i.editorBase + (t - i.contextBase) : t + this.from;
    }
    toContextPos(t) {
        let e = this.composing;
        return e && e.drifted ? e.contextBase + (t - e.editorBase) : t - this.from;
    }
    destroy() {
        for (let t in this.handlers) this.editContext.removeEventListener(t, this.handlers[t]);
    }
}
class Is {
    get state() {
        return this.viewState.state;
    }
    get viewport() {
        return this.viewState.viewport;
    }
    get visibleRanges() {
        return this.viewState.visibleRanges;
    }
    get inView() {
        return this.viewState.inView;
    }
    get composing() {
        return !!this.inputState && this.inputState.composing > 0;
    }
    get compositionStarted() {
        return !!this.inputState && this.inputState.composing >= 0;
    }
    get root() {
        return this._root;
    }
    get win() {
        return this.dom.ownerDocument.defaultView || window;
    }
    constructor(t = {}) {
        var e;
        (this.plugins = []),
            (this.pluginMap = new Map()),
            (this.editorAttrs = {}),
            (this.contentAttrs = {}),
            (this.bidiCache = []),
            (this.destroyed = !1),
            (this.updateState = 2),
            (this.measureScheduled = -1),
            (this.measureRequests = []),
            (this.contentDOM = document.createElement("div")),
            (this.scrollDOM = document.createElement("div")),
            (this.scrollDOM.tabIndex = -1),
            (this.scrollDOM.className = "cm-scroller"),
            this.scrollDOM.appendChild(this.contentDOM),
            (this.announceDOM = document.createElement("div")),
            (this.announceDOM.className = "cm-announced"),
            this.announceDOM.setAttribute("aria-live", "polite"),
            (this.dom = document.createElement("div")),
            this.dom.appendChild(this.announceDOM),
            this.dom.appendChild(this.scrollDOM),
            t.parent && t.parent.appendChild(this.dom);
        let { dispatch: i } = t;
        (this.dispatchTransactions = t.dispatchTransactions || (i && ((t) => t.forEach((t) => i(t, this)))) || ((t) => this.update(t))),
            (this.dispatch = this.dispatch.bind(this)),
            (this._root =
                t.root ||
                (function (t) {
                    for (; t;) {
                        if (t && (9 == t.nodeType || (11 == t.nodeType && t.host))) return t;
                        t = t.assignedSlot || t.parentNode;
                    }
                    return null;
                })(t.parent) ||
                document),
            (this.viewState = new cs(t.state || oe.create(t))),
            t.scrollTo && t.scrollTo.is(Sn) && (this.viewState.scrollTarget = t.scrollTo.value.clip(this.viewState.state)),
            (this.plugins = this.state.facet(Dn).map((t) => new On(t)));
        for (let t of this.plugins) t.update(this);
        (this.observer = new Es(this)),
            (this.inputState = new mo(this)),
            this.inputState.ensureHandlers(this.plugins),
            (this.docView = new Wn(this)),
            this.mountStyles(),
            this.updateAttrs(),
            (this.updateState = 0),
            this.requestMeasure(),
            (null === (e = document.fonts) || void 0 === e ? void 0 : e.ready) && document.fonts.ready.then(() => this.requestMeasure());
    }
    dispatch(...t) {
        let e = 1 == t.length && t[0] instanceof Yt ? t : 1 == t.length && Array.isArray(t[0]) ? t[0] : [this.state.update(...t)];
        this.dispatchTransactions(e, this);
    }
    update(t) {
        if (0 != this.updateState) throw new Error("Calls to EditorView.update are not allowed while an update is in progress");
        let e,
            i = !1,
            n = !1,
            o = this.state;
        for (let e of t) {
            if (e.startState != o) throw new RangeError("Trying to update state with a transaction that doesn't start from the previous state.");
            o = e.state;
        }
        if (this.destroyed) return void (this.viewState.state = o);
        let s = this.hasFocus,
            r = 0,
            l = null;
        t.some((t) => t.annotation(_o)) ? ((this.inputState.notifiedFocused = s), (r = 1)) : s != this.inputState.notifiedFocused && ((this.inputState.notifiedFocused = s), (l = Fo(o, s)), l || (r = 1));
        let a = this.observer.delayedAndroidKey,
            c = null;
        if (
            (a ? (this.observer.clearDelayedAndroidKey(), (c = this.observer.readChange()), ((c && !this.state.doc.eq(o.doc)) || !this.state.selection.eq(o.selection)) && (c = null)) : this.observer.clear(),
                o.facet(oe.phrases) != this.state.facet(oe.phrases))
        )
            return this.setState(o);
        (e = $n.create(this, o, t)), (e.flags |= r);
        let h = this.viewState.scrollTarget;
        try {
            this.updateState = 2;
            for (let e of t) {
                if ((h && (h = h.map(e.changes)), e.scrollIntoView)) {
                    let { main: t } = e.state.selection;
                    h = new kn(t.empty ? t : pt.cursor(t.head, t.head > t.anchor ? -1 : 1));
                }
                for (let t of e.effects) t.is(Sn) && (h = t.value.clip(this.state));
            }
            this.viewState.update(e, h),
                (this.bidiCache = qs.update(this.bidiCache, e.changes)),
                e.empty || (this.updatePlugins(e), this.inputState.update(e)),
                (i = this.docView.update(e)),
                this.state.facet(Hn) != this.styleModules && this.mountStyles(),
                (n = this.updateAttrs()),
                this.showAnnouncements(t),
                this.docView.updateSelection(
                    i,
                    t.some((t) => t.isUserEvent("select.pointer"))
                );
        } finally {
            this.updateState = 0;
        }
        if (
            (e.startState.facet(fs) != e.state.facet(fs) && (this.viewState.mustMeasureContent = !0),
                (i || n || h || this.viewState.mustEnforceCursorAssoc || this.viewState.mustMeasureContent) && this.requestMeasure(),
                i && this.docViewUpdate(),
                !e.empty)
        )
            for (let i of this.state.facet(gn))
                try {
                    i(e);
                } catch (t) {
                    En(this.state, t, "update listener");
                }
        (l || c) &&
            Promise.resolve().then(() => {
                l && this.state == l.startState && this.dispatch(l), c && !uo(this, c) && a.force && Ge(this.contentDOM, a.key, a.keyCode);
            });
    }
    setState(t) {
        if (0 != this.updateState) throw new Error("Calls to EditorView.setState are not allowed while an update is in progress");
        if (this.destroyed) return void (this.viewState.state = t);
        this.updateState = 2;
        let e = this.hasFocus;
        try {
            for (let t of this.plugins) t.destroy(this);
            (this.viewState = new cs(t)), (this.plugins = t.facet(Dn).map((t) => new On(t))), this.pluginMap.clear();
            for (let t of this.plugins) t.update(this);
            this.docView.destroy(), (this.docView = new Wn(this)), this.inputState.ensureHandlers(this.plugins), this.mountStyles(), this.updateAttrs(), (this.bidiCache = []);
        } finally {
            this.updateState = 0;
        }
        e && this.focus(), this.requestMeasure();
    }
    updatePlugins(t) {
        let e = t.startState.facet(Dn),
            i = t.state.facet(Dn);
        if (e != i) {
            let n = [];
            for (let o of i) {
                let i = e.indexOf(o);
                if (i < 0) n.push(new On(o));
                else {
                    let e = this.plugins[i];
                    (e.mustUpdate = t), n.push(e);
                }
            }
            for (let e of this.plugins) e.mustUpdate != t && e.destroy(this);
            (this.plugins = n), this.pluginMap.clear();
        } else for (let e of this.plugins) e.mustUpdate = t;
        for (let t = 0; t < this.plugins.length; t++) this.plugins[t].update(this);
        e != i && this.inputState.ensureHandlers(this.plugins);
    }
    docViewUpdate() {
        for (let t of this.plugins) {
            let e = t.value;
            if (e && e.docViewUpdate)
                try {
                    e.docViewUpdate(this);
                } catch (t) {
                    En(this.state, t, "doc view update listener");
                }
        }
    }
    measure(t = !0) {
        if (this.destroyed) return;
        if ((this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.observer.delayedAndroidKey)) return (this.measureScheduled = -1), void this.requestMeasure();
        (this.measureScheduled = 0), t && this.observer.forceFlush();
        let e = null,
            i = this.scrollDOM,
            n = i.scrollTop * this.scaleY,
            { scrollAnchorPos: o, scrollAnchorHeight: s } = this.viewState;
        Math.abs(n - this.viewState.scrollTop) > 1 && (s = -1), (this.viewState.scrollAnchorHeight = -1);
        try {
            for (let r = 0; ; r++) {
                if (s < 0)
                    if (Ke(i)) (o = -1), (s = this.viewState.heightMap.height);
                    else {
                        let t = this.viewState.scrollAnchorAt(n);
                        (o = t.from), (s = t.top);
                    }
                this.updateState = 1;
                let l = this.viewState.measure(this);
                if (!l && !this.measureRequests.length && null == this.viewState.scrollTarget) break;
                if (r > 5) break;
                let a = [];
                4 & l || ([this.measureRequests, a] = [a, this.measureRequests]);
                let c = a.map((t) => {
                    try {
                        return t.read(this);
                    } catch (t) {
                        return En(this.state, t), Bs;
                    }
                }),
                    h = $n.create(this, this.state, []),
                    d = !1;
                (h.flags |= l), e ? (e.flags |= l) : (e = h), (this.updateState = 2), h.empty || (this.updatePlugins(h), this.inputState.update(h), this.updateAttrs(), (d = this.docView.update(h)), d && this.docViewUpdate());
                for (let e = 0; e < a.length; e++)
                    if (c[e] != Bs)
                        try {
                            let t = a[e];
                            t.write && t.write(c[e], this);
                        } catch (t) {
                            En(this.state, t);
                        }
                if ((d && this.docView.updateSelection(!0), !h.viewportChanged && 0 == this.measureRequests.length)) {
                    if (this.viewState.editorHeight) {
                        if (this.viewState.scrollTarget) {
                            this.docView.scrollIntoView(this.viewState.scrollTarget), (this.viewState.scrollTarget = null), (s = -1);
                            continue;
                        }
                        {
                            let t = (o < 0 ? this.viewState.heightMap.height : this.viewState.lineBlockAt(o).top) - s;
                            if (t > 1 || t < -1) {
                                (n += t), (i.scrollTop = n / this.scaleY), (s = -1);
                                continue;
                            }
                        }
                    }
                    break;
                }
            }
        } finally {
            (this.updateState = 0), (this.measureScheduled = -1);
        }
        if (e && !e.empty) for (let t of this.state.facet(gn)) t(e);
    }
    get themeClasses() {
        return vs + " " + (this.state.facet(bs) ? ws : ys) + " " + this.state.facet(fs);
    }
    updateAttrs() {
        let t = Ns(this, Bn, { class: "cm-editor" + (this.hasFocus ? " cm-focused " : " ") + this.themeClasses }),
            e = {
                spellcheck: "false",
                autocorrect: "off",
                autocapitalize: "off",
                writingsuggestions: "false",
                translate: "no",
                contenteditable: this.state.facet(Mn) ? "true" : "false",
                class: "cm-content",
                style: `${bi.tabSize}: ${this.state.tabSize}`,
                role: "textbox",
                "aria-multiline": "true",
            };
        this.state.readOnly && (e["aria-readonly"] = "true"), Ns(this, qn, e);
        let i = this.observer.ignore(() => {
            let i = Di(this.contentDOM, this.contentAttrs, e),
                n = Di(this.dom, this.editorAttrs, t);
            return i || n;
        });
        return (this.editorAttrs = t), (this.contentAttrs = e), i;
    }
    showAnnouncements(t) {
        let e = !0;
        for (let i of t) for (let t of i.effects) t.is(Is.announce) && (e && (this.announceDOM.textContent = ""), (e = !1), (this.announceDOM.appendChild(document.createElement("div")).textContent = t.value));
    }
    mountStyles() {
        this.styleModules = this.state.facet(Hn);
        let t = this.state.facet(Is.cspNonce);
        Se.mount(this.root, this.styleModules.concat(ks).reverse(), t ? { nonce: t } : void 0);
    }
    readMeasured() {
        if (2 == this.updateState) throw new Error("Reading the editor layout isn't allowed during an update");
        0 == this.updateState && this.measureScheduled > -1 && this.measure(!1);
    }
    requestMeasure(t) {
        if ((this.measureScheduled < 0 && (this.measureScheduled = this.win.requestAnimationFrame(() => this.measure())), t)) {
            if (this.measureRequests.indexOf(t) > -1) return;
            if (null != t.key) for (let e = 0; e < this.measureRequests.length; e++) if (this.measureRequests[e].key === t.key) return void (this.measureRequests[e] = t);
            this.measureRequests.push(t);
        }
    }
    plugin(t) {
        let e = this.pluginMap.get(t);
        return (void 0 === e || (e && e.plugin != t)) && this.pluginMap.set(t, (e = this.plugins.find((e) => e.plugin == t) || null)), e && e.update(this).value;
    }
    get documentTop() {
        return this.contentDOM.getBoundingClientRect().top + this.viewState.paddingTop;
    }
    get documentPadding() {
        return { top: this.viewState.paddingTop, bottom: this.viewState.paddingBottom };
    }
    get scaleX() {
        return this.viewState.scaleX;
    }
    get scaleY() {
        return this.viewState.scaleY;
    }
    elementAtHeight(t) {
        return this.readMeasured(), this.viewState.elementAtHeight(t);
    }
    lineBlockAtHeight(t) {
        return this.readMeasured(), this.viewState.lineBlockAtHeight(t);
    }
    get viewportLineBlocks() {
        return this.viewState.viewportLines;
    }
    lineBlockAt(t) {
        return this.viewState.lineBlockAt(t);
    }
    get contentHeight() {
        return this.viewState.contentHeight;
    }
    moveByChar(t, e, i) {
        return so(this, t, no(this, t, e, i));
    }
    moveByGroup(t, e) {
        return so(
            this,
            t,
            no(this, t, e, (e) =>
                (function (t, e, i) {
                    let n = t.state.charCategorizer(e),
                        o = n(i);
                    return (t) => {
                        let e = n(t);
                        return o == te.Space && (o = e), o == e;
                    };
                })(this, t.head, e)
            )
        );
    }
    visualLineSide(t, e) {
        let i = this.bidiSpans(t),
            n = this.textDirectionAt(t.from),
            o = i[e ? i.length - 1 : 0];
        return pt.cursor(o.side(e, n) + t.from, o.forward(!e, n) ? 1 : -1);
    }
    moveToLineBoundary(t, e, i = !0) {
        return io(this, t, e, i);
    }
    moveVertically(t, e, i) {
        return so(
            this,
            t,
            (function (t, e, i, n) {
                let o = e.head,
                    s = i ? 1 : -1;
                if (o == (i ? t.state.doc.length : 0)) return pt.cursor(o, e.assoc);
                let r,
                    l = e.goalColumn,
                    a = t.contentDOM.getBoundingClientRect(),
                    c = t.coordsAtPos(o, e.assoc || -1),
                    h = t.documentTop;
                if (c) null == l && (l = c.left - a.left), (r = s < 0 ? c.top : c.bottom);
                else {
                    let e = t.viewState.lineBlockAt(o);
                    null == l && (l = Math.min(a.right - a.left, t.defaultCharacterWidth * (o - e.from))), (r = (s < 0 ? e.top : e.bottom) + h);
                }
                let d = a.left + l,
                    u = null != n ? n : t.viewState.heightOracle.textHeight >> 1;
                for (let e = 0; ; e += 10) {
                    let i = r + (u + e) * s,
                        n = to(t, { x: d, y: i }, !1, s);
                    if (i < a.top || i > a.bottom || (s < 0 ? n < o : n > o)) {
                        let e = t.docView.coordsForChar(n),
                            o = !e || i < e.top ? -1 : 1;
                        return pt.cursor(n, o, void 0, l);
                    }
                }
            })(this, t, e, i)
        );
    }
    domAtPos(t) {
        return this.docView.domAtPos(t);
    }
    posAtDOM(t, e = 0) {
        return this.docView.posFromDOM(t, e);
    }
    posAtCoords(t, e = !0) {
        return this.readMeasured(), to(this, t, e);
    }
    coordsAtPos(t, e = 1) {
        this.readMeasured();
        let i = this.docView.coordsAt(t, e);
        if (!i || i.left == i.right) return i;
        let n = this.state.doc.lineAt(t),
            o = this.bidiSpans(n);
        return Ve(i, (o[en.find(o, t - n.from, -1, e)].dir == Ui.LTR) == e > 0);
    }
    coordsForChar(t) {
        return this.readMeasured(), this.docView.coordsForChar(t);
    }
    get defaultCharacterWidth() {
        return this.viewState.heightOracle.charWidth;
    }
    get defaultLineHeight() {
        return this.viewState.heightOracle.lineHeight;
    }
    get textDirection() {
        return this.viewState.defaultTextDirection;
    }
    textDirectionAt(t) {
        return !this.state.facet(wn) || t < this.viewport.from || t > this.viewport.to ? this.textDirection : (this.readMeasured(), this.docView.textDirectionAt(t));
    }
    get lineWrapping() {
        return this.viewState.heightOracle.lineWrapping;
    }
    bidiSpans(t) {
        if (t.length > Os) return ln(t.length);
        let e,
            i = this.textDirectionAt(t.from);
        for (let n of this.bidiCache) if (n.from == t.from && n.dir == i && (n.fresh || nn(n.isolates, (e = _n(this, t))))) return n.order;
        e || (e = _n(this, t));
        let n = (function (t, e, i) {
            if (!t) return [new en(0, 0, e == Yi ? 1 : 0)];
            if (e == ji && !i.length && !tn.test(t)) return ln(t.length);
            if (i.length) for (; t.length > on.length;) on[on.length] = 256;
            let n = [],
                o = e == ji ? 0 : 1;
            return rn(t, o, o, i, 0, t.length, n), n;
        })(t.text, i, e);
        return this.bidiCache.push(new qs(t.from, t.to, i, e, !0, n)), n;
    }
    get hasFocus() {
        var t;
        return (this.dom.ownerDocument.hasFocus() || (bi.safari && (null === (t = this.inputState) || void 0 === t ? void 0 : t.lastContextMenu) > Date.now() - 3e4)) && this.root.activeElement == this.contentDOM;
    }
    focus() {
        this.observer.ignore(() => {
            je(this.contentDOM), this.docView.updateSelection();
        });
    }
    setRoot(t) {
        this._root != t && ((this._root = t), this.observer.setWindow((9 == t.nodeType ? t : t.ownerDocument).defaultView || window), this.mountStyles());
    }
    destroy() {
        this.root.activeElement == this.contentDOM && this.contentDOM.blur();
        for (let t of this.plugins) t.destroy(this);
        (this.plugins = []), this.inputState.destroy(), this.docView.destroy(), this.dom.remove(), this.observer.destroy(), this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), (this.destroyed = !0);
    }
    static scrollIntoView(t, e = {}) {
        return Sn.of(new kn("number" == typeof t ? pt.cursor(t) : t, e.y, e.x, e.yMargin, e.xMargin));
    }
    scrollSnapshot() {
        let { scrollTop: t, scrollLeft: e } = this.scrollDOM,
            i = this.viewState.scrollAnchorAt(t);
        return Sn.of(new kn(pt.cursor(i.from), "start", "start", i.top - t, e, !0));
    }
    setTabFocusMode(t) {
        null == t
            ? (this.inputState.tabFocusMode = this.inputState.tabFocusMode < 0 ? 0 : -1)
            : "boolean" == typeof t
                ? (this.inputState.tabFocusMode = t ? 0 : -1)
                : 0 != this.inputState.tabFocusMode && (this.inputState.tabFocusMode = Date.now() + t);
    }
    static domEventHandlers(t) {
        return In.define(() => ({}), { eventHandlers: t });
    }
    static domEventObservers(t) {
        return In.define(() => ({}), { eventObservers: t });
    }
    static theme(t, e) {
        let i = Se.newName(),
            n = [fs.of(i), Hn.of(Cs(`.${i}`, t))];
        return e && e.dark && n.push(bs.of(!0)), n;
    }
    static baseTheme(t) {
        return Dt.lowest(Hn.of(Cs("." + vs, t, xs)));
    }
    static findFromDOM(t) {
        var e;
        let i = t.querySelector(".cm-content"),
            n = (i && ei.get(i)) || ei.get(t);
        return (null === (e = null == n ? void 0 : n.rootView) || void 0 === e ? void 0 : e.view) || null;
    }
}
(Is.styleModule = Hn),
    (Is.inputHandler = fn),
    (Is.clipboardInputFilter = vn),
    (Is.clipboardOutputFilter = yn),
    (Is.scrollHandler = Cn),
    (Is.focusChangeEffect = bn),
    (Is.perLineTextDirection = wn),
    (Is.exceptionSink = mn),
    (Is.updateListener = gn),
    (Is.editable = Mn),
    (Is.mouseSelectionStyle = pn),
    (Is.dragMovesSelection = un),
    (Is.clickAddsSelectionRange = dn),
    (Is.decorations = Nn),
    (Is.outerDecorations = Ln),
    (Is.atomicRanges = Rn),
    (Is.bidiIsolatedRanges = Pn),
    (Is.scrollMargins = Fn),
    (Is.darkTheme = bs),
    (Is.cspNonce = ft.define({ combine: (t) => (t.length ? t[0] : "") })),
    (Is.contentAttributes = qn),
    (Is.editorAttributes = Bn),
    (Is.lineWrapping = Is.contentAttributes.of({ class: "cm-lineWrapping" })),
    (Is.announce = jt.define());
const Os = 4096,
    Bs = {};
class qs {
    constructor(t, e, i, n, o, s) {
        (this.from = t), (this.to = e), (this.dir = i), (this.isolates = n), (this.fresh = o), (this.order = s);
    }
    static update(t, e) {
        if (e.empty && !t.some((t) => t.fresh)) return t;
        let i = [],
            n = t.length ? t[t.length - 1].dir : Ui.LTR;
        for (let o = Math.max(0, t.length - 10); o < t.length; o++) {
            let s = t[o];
            s.dir != n || e.touchesRange(s.from, s.to) || i.push(new qs(e.mapPos(s.from, 1), e.mapPos(s.to, -1), s.dir, s.isolates, !1, s.order));
        }
        return i;
    }
}
function Ns(t, e, i) {
    for (let n = t.state.facet(e), o = n.length - 1; o >= 0; o--) {
        let e = n[o],
            s = "function" == typeof e ? e(t) : e;
        s && Ei(s, i);
    }
    return i;
}
class Ls extends se {
    compare(t) {
        return this == t || (this.constructor == t.constructor && this.eq(t));
    }
    eq(t) {
        return !1;
    }
    destroy(t) { }
}
(Ls.prototype.elementClass = ""), (Ls.prototype.toDOM = void 0), (Ls.prototype.mapMode = nt.TrackBefore), (Ls.prototype.startSide = Ls.prototype.endSide = -1), (Ls.prototype.point = !0);
let Rs = 0;
class Ps {
    constructor(t, e, i, n) {
        (this.name = t), (this.set = e), (this.base = i), (this.modified = n), (this.id = Rs++);
    }
    toString() {
        let { name: t } = this;
        for (let e of this.modified) e.name && (t = `${e.name}(${t})`);
        return t;
    }
    static define(t, e) {
        let i = "string" == typeof t ? t : "?";
        if ((t instanceof Ps && (e = t), null == e ? void 0 : e.base)) throw new Error("Can not derive from a modified tag");
        let n = new Ps(i, [], null, []);
        if ((n.set.push(n), e)) for (let t of e.set) n.set.push(t);
        return n;
    }
    static defineModifier(t) {
        let e = new Fs(t);
        return (t) =>
            t.modified.indexOf(e) > -1
                ? t
                : Fs.get(
                    t.base || t,
                    t.modified.concat(e).sort((t, e) => t.id - e.id)
                );
    }
}
let _s = 0;
class Fs {
    constructor(t) {
        (this.name = t), (this.instances = []), (this.id = _s++);
    }
    static get(t, e) {
        if (!e.length) return t;
        let i = e[0].instances.find((i) => {
            return i.base == t && ((n = e), (o = i.modified), n.length == o.length && n.every((t, e) => t == o[e]));
            var n, o;
        });
        if (i) return i;
        let n = [],
            o = new Ps(t.name, n, t, e);
        for (let t of e) t.instances.push(o);
        let s = (function (t) {
            let e = [[]];
            for (let i = 0; i < t.length; i++) for (let n = 0, o = e.length; n < o; n++) e.push(e[n].concat(t[i]));
            return e.sort((t, e) => e.length - t.length);
        })(e);
        for (let e of t.set) if (!e.modified.length) for (let t of s) n.push(Fs.get(e, t));
        return o;
    }
}
function Vs(t) {
    let e = Object.create(null);
    for (let i in t) {
        let n = t[i];
        Array.isArray(n) || (n = [n]);
        for (let t of i.split(" "))
            if (t) {
                let i = [],
                    o = 2,
                    s = t;
                for (let e = 0; ;) {
                    if ("..." == s && e > 0 && e + 3 == t.length) {
                        o = 1;
                        break;
                    }
                    let n = /^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(s);
                    if (!n) throw new RangeError("Invalid path: " + t);
                    if ((i.push("*" == n[0] ? "" : '"' == n[0][0] ? JSON.parse(n[0]) : n[0]), (e += n[0].length), e == t.length)) break;
                    let r = t[e++];
                    if (e == t.length && "!" == r) {
                        o = 0;
                        break;
                    }
                    if ("/" != r) throw new RangeError("Invalid path: " + t);
                    s = t.slice(e);
                }
                let r = i.length - 1,
                    l = i[r];
                if (!l) throw new RangeError("Invalid path: " + t);
                let a = new zs(n, o, r > 0 ? i.slice(0, r) : null);
                e[l] = a.sort(e[l]);
            }
    }
    return Hs.add(e);
}
const Hs = new r();
class zs {
    constructor(t, e, i, n) {
        (this.tags = t), (this.mode = e), (this.context = i), (this.next = n);
    }
    get opaque() {
        return 0 == this.mode;
    }
    get inherit() {
        return 1 == this.mode;
    }
    sort(t) {
        return !t || t.depth < this.depth ? ((this.next = t), this) : ((t.next = this.sort(t.next)), t);
    }
    get depth() {
        return this.context ? this.context.length : 0;
    }
}
function $s(t, e) {
    let i = Object.create(null);
    for (let e of t)
        if (Array.isArray(e.tag)) for (let t of e.tag) i[t.id] = e.class;
        else i[e.tag.id] = e.class;
    let { scope: n, all: o = null } = e || {};
    return {
        style: (t) => {
            let e = o;
            for (let n of t)
                for (let t of n.set) {
                    let n = i[t.id];
                    if (n) {
                        e = e ? e + " " + n : n;
                        break;
                    }
                }
            return e;
        },
        scope: n,
    };
}
zs.empty = new zs([], 2, null);
const Ws = Ps.define,
    Us = Ws(),
    js = Ws(),
    Ys = Ws(js),
    Gs = Ws(js),
    Zs = Ws(),
    Ks = Ws(Zs),
    Xs = Ws(Zs),
    Js = Ws(),
    Qs = Ws(Js),
    tr = Ws(),
    er = Ws(),
    ir = Ws(),
    nr = Ws(ir),
    or = Ws(),
    sr = {
        comment: Us,
        lineComment: Ws(Us),
        blockComment: Ws(Us),
        docComment: Ws(Us),
        name: js,
        variableName: Ws(js),
        typeName: Ys,
        tagName: Ws(Ys),
        propertyName: Gs,
        attributeName: Ws(Gs),
        className: Ws(js),
        labelName: Ws(js),
        namespace: Ws(js),
        macroName: Ws(js),
        literal: Zs,
        string: Ks,
        docString: Ws(Ks),
        character: Ws(Ks),
        attributeValue: Ws(Ks),
        number: Xs,
        integer: Ws(Xs),
        float: Ws(Xs),
        bool: Ws(Zs),
        regexp: Ws(Zs),
        escape: Ws(Zs),
        color: Ws(Zs),
        url: Ws(Zs),
        keyword: tr,
        self: Ws(tr),
        null: Ws(tr),
        atom: Ws(tr),
        unit: Ws(tr),
        modifier: Ws(tr),
        operatorKeyword: Ws(tr),
        controlKeyword: Ws(tr),
        definitionKeyword: Ws(tr),
        moduleKeyword: Ws(tr),
        operator: er,
        derefOperator: Ws(er),
        arithmeticOperator: Ws(er),
        logicOperator: Ws(er),
        bitwiseOperator: Ws(er),
        compareOperator: Ws(er),
        updateOperator: Ws(er),
        definitionOperator: Ws(er),
        typeOperator: Ws(er),
        controlOperator: Ws(er),
        punctuation: ir,
        separator: Ws(ir),
        bracket: nr,
        angleBracket: Ws(nr),
        squareBracket: Ws(nr),
        paren: Ws(nr),
        brace: Ws(nr),
        content: Js,
        heading: Qs,
        heading1: Ws(Qs),
        heading2: Ws(Qs),
        heading3: Ws(Qs),
        heading4: Ws(Qs),
        heading5: Ws(Qs),
        heading6: Ws(Qs),
        contentSeparator: Ws(Js),
        list: Ws(Js),
        quote: Ws(Js),
        emphasis: Ws(Js),
        strong: Ws(Js),
        link: Ws(Js),
        monospace: Ws(Js),
        strikethrough: Ws(Js),
        inserted: Ws(),
        deleted: Ws(),
        changed: Ws(),
        invalid: Ws(),
        meta: or,
        documentMeta: Ws(or),
        annotation: Ws(or),
        processingInstruction: Ws(or),
        definition: Ps.defineModifier("definition"),
        constant: Ps.defineModifier("constant"),
        function: Ps.defineModifier("function"),
        standard: Ps.defineModifier("standard"),
        local: Ps.defineModifier("local"),
        special: Ps.defineModifier("special"),
    };
for (let t in sr) {
    let e = sr[t];
    e instanceof Ps && (e.name = t);
}
var rr;
$s([
    { tag: sr.link, class: "tok-link" },
    { tag: sr.heading, class: "tok-heading" },
    { tag: sr.emphasis, class: "tok-emphasis" },
    { tag: sr.strong, class: "tok-strong" },
    { tag: sr.keyword, class: "tok-keyword" },
    { tag: sr.atom, class: "tok-atom" },
    { tag: sr.bool, class: "tok-bool" },
    { tag: sr.url, class: "tok-url" },
    { tag: sr.labelName, class: "tok-labelName" },
    { tag: sr.inserted, class: "tok-inserted" },
    { tag: sr.deleted, class: "tok-deleted" },
    { tag: sr.literal, class: "tok-literal" },
    { tag: sr.string, class: "tok-string" },
    { tag: sr.number, class: "tok-number" },
    { tag: [sr.regexp, sr.escape, sr.special(sr.string)], class: "tok-string2" },
    { tag: sr.variableName, class: "tok-variableName" },
    { tag: sr.local(sr.variableName), class: "tok-variableName tok-local" },
    { tag: sr.definition(sr.variableName), class: "tok-variableName tok-definition" },
    { tag: sr.special(sr.variableName), class: "tok-variableName2" },
    { tag: sr.definition(sr.propertyName), class: "tok-propertyName tok-definition" },
    { tag: sr.typeName, class: "tok-typeName" },
    { tag: sr.namespace, class: "tok-namespace" },
    { tag: sr.className, class: "tok-className" },
    { tag: sr.macroName, class: "tok-macroName" },
    { tag: sr.propertyName, class: "tok-propertyName" },
    { tag: sr.operator, class: "tok-operator" },
    { tag: sr.comment, class: "tok-comment" },
    { tag: sr.meta, class: "tok-meta" },
    { tag: sr.invalid, class: "tok-invalid" },
    { tag: sr.punctuation, class: "tok-punctuation" },
]);
const lr = new r(),
    ar = new r();
class cr {
    constructor(t, e, i = [], n = "") {
        (this.data = t),
            (this.name = n),
            oe.prototype.hasOwnProperty("tree") ||
            Object.defineProperty(oe.prototype, "tree", {
                get() {
                    return dr(this);
                },
            }),
            (this.parser = e),
            (this.extension = [
                wr.of(this),
                oe.languageData.of((t, e, i) => {
                    let n = hr(t, e, i),
                        o = n.type.prop(lr);
                    if (!o) return [];
                    let s = t.facet(o),
                        r = n.type.prop(ar);
                    if (r) {
                        let o = n.resolve(e - n.from, i);
                        for (let e of r)
                            if (e.test(o, t)) {
                                let i = t.facet(e.facet);
                                return "replace" == e.type ? i : i.concat(s);
                            }
                    }
                    return s;
                }),
            ].concat(i));
    }
    isActiveAt(t, e, i = -1) {
        return hr(t, e, i).type.prop(lr) == this.data;
    }
    findRegions(t) {
        let e = t.facet(wr);
        if ((null == e ? void 0 : e.data) == this.data) return [{ from: 0, to: t.doc.length }];
        if (!e || !e.allowsNesting) return [];
        let i = [],
            n = (t, e) => {
                if (t.prop(lr) == this.data) return void i.push({ from: e, to: e + t.length });
                let o = t.prop(r.mounted);
                if (o) {
                    if (o.tree.prop(lr) == this.data) {
                        if (o.overlay) for (let t of o.overlay) i.push({ from: t.from + e, to: t.to + e });
                        else i.push({ from: e, to: e + t.length });
                        return;
                    }
                    if (o.overlay) {
                        let t = i.length;
                        if ((n(o.tree, o.overlay[0].from + e), i.length > t)) return;
                    }
                }
                for (let i = 0; i < t.children.length; i++) {
                    let o = t.children[i];
                    o instanceof p && n(o, t.positions[i] + e);
                }
            };
        return n(dr(t), 0), i;
    }
    get allowsNesting() {
        return !0;
    }
}
function hr(t, e, i) {
    let n = t.facet(wr),
        o = dr(t).topNode;
    if (!n || n.allowsNesting) for (let t = o; t; t = t.enter(e, i, u.ExcludeBuffers)) t.type.isTop && (o = t);
    return o;
}
function dr(t) {
    let e = t.field(cr.state, !1);
    return e ? e.tree : p.empty;
}
cr.setState = jt.define();
class ur {
    constructor(t) {
        (this.doc = t), (this.cursorPos = 0), (this.string = ""), (this.cursor = t.iter());
    }
    get length() {
        return this.doc.length;
    }
    syncTo(t) {
        return (this.string = this.cursor.next(t - this.cursorPos).value), (this.cursorPos = t + this.string.length), this.cursorPos - this.string.length;
    }
    chunk(t) {
        return this.syncTo(t), this.string;
    }
    get lineChunks() {
        return !0;
    }
    read(t, e) {
        let i = this.cursorPos - this.string.length;
        return t < i || e >= this.cursorPos ? this.doc.sliceString(t, e) : this.string.slice(t - i, e - i);
    }
}
let pr = null;
class mr {
    constructor(t, e, i = [], n, o, s, r, l) {
        (this.parser = t), (this.state = e), (this.fragments = i), (this.tree = n), (this.treeLen = o), (this.viewport = s), (this.skipped = r), (this.scheduleOn = l), (this.parse = null), (this.tempSkipped = []);
    }
    static create(t, e, i) {
        return new mr(t, e, [], p.empty, 0, i, [], null);
    }
    startParse() {
        return this.parser.startParse(new ur(this.state.doc), this.fragments);
    }
    work(t, e) {
        return (
            null != e && e >= this.state.doc.length && (e = void 0),
            this.tree != p.empty && this.isDone(null != e ? e : this.state.doc.length)
                ? (this.takeTree(), !0)
                : this.withContext(() => {
                    var i;
                    if ("number" == typeof t) {
                        let e = Date.now() + t;
                        t = () => Date.now() > e;
                    }
                    for (this.parse || (this.parse = this.startParse()), null != e && (null == this.parse.stoppedAt || this.parse.stoppedAt > e) && e < this.state.doc.length && this.parse.stopAt(e); ;) {
                        let n = this.parse.advance();
                        if (n) {
                            if (
                                ((this.fragments = this.withoutTempSkipped(O.addTree(n, this.fragments, null != this.parse.stoppedAt))),
                                    (this.treeLen = null !== (i = this.parse.stoppedAt) && void 0 !== i ? i : this.state.doc.length),
                                    (this.tree = n),
                                    (this.parse = null),
                                    !(this.treeLen < (null != e ? e : this.state.doc.length)))
                            )
                                return !0;
                            this.parse = this.startParse();
                        }
                        if (t()) return !1;
                    }
                })
        );
    }
    takeTree() {
        let t, e;
        this.parse &&
            (t = this.parse.parsedPos) >= this.treeLen &&
            ((null == this.parse.stoppedAt || this.parse.stoppedAt > t) && this.parse.stopAt(t),
                this.withContext(() => {
                    for (; !(e = this.parse.advance()););
                }),
                (this.treeLen = t),
                (this.tree = e),
                (this.fragments = this.withoutTempSkipped(O.addTree(this.tree, this.fragments, !0))),
                (this.parse = null));
    }
    withContext(t) {
        let e = pr;
        pr = this;
        try {
            return t();
        } finally {
            pr = e;
        }
    }
    withoutTempSkipped(t) {
        for (let e; (e = this.tempSkipped.pop());) t = gr(t, e.from, e.to);
        return t;
    }
    changes(t, e) {
        let { fragments: i, tree: n, treeLen: o, viewport: s, skipped: r } = this;
        if ((this.takeTree(), !t.empty)) {
            let e = [];
            if ((t.iterChangedRanges((t, i, n, o) => e.push({ fromA: t, toA: i, fromB: n, toB: o })), (i = O.applyChanges(i, e)), (n = p.empty), (o = 0), (s = { from: t.mapPos(s.from, -1), to: t.mapPos(s.to, 1) }), this.skipped.length)) {
                r = [];
                for (let e of this.skipped) {
                    let i = t.mapPos(e.from, 1),
                        n = t.mapPos(e.to, -1);
                    i < n && r.push({ from: i, to: n });
                }
            }
        }
        return new mr(this.parser, e, i, n, o, s, r, this.scheduleOn);
    }
    updateViewport(t) {
        if (this.viewport.from == t.from && this.viewport.to == t.to) return !1;
        this.viewport = t;
        let e = this.skipped.length;
        for (let e = 0; e < this.skipped.length; e++) {
            let { from: i, to: n } = this.skipped[e];
            i < t.to && n > t.from && ((this.fragments = gr(this.fragments, i, n)), this.skipped.splice(e--, 1));
        }
        return !(this.skipped.length >= e || (this.reset(), 0));
    }
    reset() {
        this.parse && (this.takeTree(), (this.parse = null));
    }
    skipUntilInView(t, e) {
        this.skipped.push({ from: t, to: e });
    }
    static getSkippingParser(t) {
        return new (class extends B {
            createParse(e, i, n) {
                let o = n[0].from,
                    s = n[n.length - 1].to;
                return {
                    parsedPos: o,
                    advance() {
                        let e = pr;
                        if (e) {
                            for (let t of n) e.tempSkipped.push(t);
                            t && (e.scheduleOn = e.scheduleOn ? Promise.all([e.scheduleOn, t]) : t);
                        }
                        return (this.parsedPos = s), new p(c.none, [], [], s - o);
                    },
                    stoppedAt: null,
                    stopAt() { },
                };
            }
        })();
    }
    isDone(t) {
        t = Math.min(t, this.state.doc.length);
        let e = this.fragments;
        return this.treeLen >= t && e.length && 0 == e[0].from && e[0].to >= t;
    }
    static get() {
        return pr;
    }
}
function gr(t, e, i) {
    return O.applyChanges(t, [{ fromA: e, toA: i, fromB: e, toB: i }]);
}
class fr {
    constructor(t) {
        (this.context = t), (this.tree = t.tree);
    }
    apply(t) {
        if (!t.docChanged && this.tree == this.context.tree) return this;
        let e = this.context.changes(t.changes, t.state),
            i = this.context.treeLen == t.startState.doc.length ? void 0 : Math.max(t.changes.mapPos(this.context.treeLen), e.viewport.to);
        return e.work(20, i) || e.takeTree(), new fr(e);
    }
    static init(t) {
        let e = Math.min(3e3, t.doc.length),
            i = mr.create(t.facet(wr).parser, t, { from: 0, to: e });
        return i.work(20, e) || i.takeTree(), new fr(i);
    }
}
cr.state = kt.define({
    create: fr.init,
    update(t, e) {
        for (let t of e.effects) if (t.is(cr.setState)) return t.value;
        return e.startState.facet(wr) != e.state.facet(wr) ? fr.init(e.state) : t.apply(e);
    },
});
let br = (t) => {
    let e = setTimeout(() => t(), 500);
    return () => clearTimeout(e);
};
"undefined" != typeof requestIdleCallback &&
    (br = (t) => {
        let e = -1,
            i = setTimeout(() => {
                e = requestIdleCallback(t, { timeout: 400 });
            }, 100);
        return () => (e < 0 ? clearTimeout(i) : cancelIdleCallback(e));
    });
const vr = "undefined" != typeof navigator && (null === (rr = navigator.scheduling) || void 0 === rr ? void 0 : rr.isInputPending) ? () => navigator.scheduling.isInputPending() : null,
    yr = In.fromClass(
        class {
            constructor(t) {
                (this.view = t), (this.working = null), (this.workScheduled = 0), (this.chunkEnd = -1), (this.chunkBudget = -1), (this.work = this.work.bind(this)), this.scheduleWork();
            }
            update(t) {
                let e = this.view.state.field(cr.state).context;
                (e.updateViewport(t.view.viewport) || this.view.viewport.to > e.treeLen) && this.scheduleWork(),
                    (t.docChanged || t.selectionSet) && (this.view.hasFocus && (this.chunkBudget += 50), this.scheduleWork()),
                    this.checkAsyncSchedule(e);
            }
            scheduleWork() {
                if (this.working) return;
                let { state: t } = this.view,
                    e = t.field(cr.state);
                (e.tree == e.context.tree && e.context.isDone(t.doc.length)) || (this.working = br(this.work));
            }
            work(t) {
                this.working = null;
                let e = Date.now();
                if ((this.chunkEnd < e && (this.chunkEnd < 0 || this.view.hasFocus) && ((this.chunkEnd = e + 3e4), (this.chunkBudget = 3e3)), this.chunkBudget <= 0)) return;
                let {
                    state: i,
                    viewport: { to: n },
                } = this.view,
                    o = i.field(cr.state);
                if (o.tree == o.context.tree && o.context.isDone(n + 1e5)) return;
                let s = Date.now() + Math.min(this.chunkBudget, 100, t && !vr ? Math.max(25, t.timeRemaining() - 5) : 1e9),
                    r = o.context.treeLen < n && i.doc.length > n + 1e3,
                    l = o.context.work(() => (vr && vr()) || Date.now() > s, n + (r ? 0 : 1e5));
                (this.chunkBudget -= Date.now() - e),
                    (l || this.chunkBudget <= 0) && (o.context.takeTree(), this.view.dispatch({ effects: cr.setState.of(new fr(o.context)) })),
                    this.chunkBudget > 0 && (!l || r) && this.scheduleWork(),
                    this.checkAsyncSchedule(o.context);
            }
            checkAsyncSchedule(t) {
                t.scheduleOn &&
                    (this.workScheduled++,
                        t.scheduleOn
                            .then(() => this.scheduleWork())
                            .catch((t) => En(this.view.state, t))
                            .then(() => this.workScheduled--),
                        (t.scheduleOn = null));
            }
            destroy() {
                this.working && this.working();
            }
            isWorking() {
                return !!(this.working || this.workScheduled > 0);
            }
        },
        {
            eventHandlers: {
                focus() {
                    this.scheduleWork();
                },
            },
        }
    ),
    wr = ft.define({
        combine: (t) => (t.length ? t[0] : null),
        enables: (t) => [
            cr.state,
            yr,
            Is.contentAttributes.compute([t], (e) => {
                let i = e.facet(t);
                return i && i.name ? { "data-language": i.name } : {};
            }),
        ],
    });
sr.meta,
    sr.link,
    sr.heading,
    sr.emphasis,
    sr.strong,
    sr.strikethrough,
    sr.keyword,
    sr.atom,
    sr.bool,
    sr.url,
    sr.contentSeparator,
    sr.labelName,
    sr.literal,
    sr.inserted,
    sr.string,
    sr.deleted,
    sr.regexp,
    sr.escape,
    sr.string,
    sr.variableName,
    sr.variableName,
    sr.typeName,
    sr.namespace,
    sr.className,
    sr.variableName,
    sr.macroName,
    sr.propertyName,
    sr.comment,
    sr.invalid;
const xr = Object.create(null),
    Cr = [c.none],
    kr = [],
    Sr = Object.create(null),
    Tr = Object.create(null);
for (let [t, e] of [
    ["variable", "variableName"],
    ["variable-2", "variableName.special"],
    ["string-2", "string.special"],
    ["def", "variableName.definition"],
    ["tag", "tagName"],
    ["attribute", "attributeName"],
    ["type", "typeName"],
    ["builtin", "variableName.standard"],
    ["qualifier", "modifier"],
    ["error", "invalid"],
    ["header", "heading"],
    ["property", "propertyName"],
])
    Tr[t] = Mr(xr, e);
function Er(t, e) {
    kr.indexOf(t) > -1 || kr.push(t);
}
function Mr(t, e) {
    let i = [];
    for (let n of e.split(" ")) {
        let e = [];
        for (let i of n.split(".")) {
            let n = t[i] || sr[i];
            n
                ? "function" == typeof n
                    ? e.length
                        ? (e = e.map(n))
                        : Er(i, `Modifier ${i} used at start of tag`)
                    : e.length
                        ? Er(i, `Tag ${i} used as modifier`)
                        : (e = Array.isArray(n) ? n : [n])
                : Er(i, `Unknown highlighting tag ${i}`);
        }
        for (let t of e) i.push(t);
    }
    if (!i.length) return 0;
    let n = e.replace(/ /g, "_"),
        o = n + " " + i.map((t) => t.id),
        s = Sr[o];
    if (s) return s.id;
    let r = (Sr[o] = c.define({ id: Cr.length, name: n, props: [Vs({ [n]: i })] }));
    return Cr.push(r), r.id;
}
function Ar(t) {
    let e = Date.now().toString(36);
    return (e += Math.random().toString(36).substr(3, t)), e;
}
function Dr(t, e, i, n) {
    let o,
        s = { index: -1, subindex: -1 },
        r = n;
    return (
        i
            ? r.forEach((t, i) => {
                if ("SubmenuCommands" in t && ((o = t.SubmenuCommands.findIndex((t) => t.id == e.id)), o >= 0)) return (s = { index: i, subindex: o }), s;
            })
            : ((o = r.findIndex((t) => t.id == e.id)), (s = { index: o, subindex: -1 })),
        s
    );
}
function Ir(t, e) {
    let i,
        n = e.getLine(e.getCursor().line),
        o = "";
    const s = /^(\>*(\[[!\w]+\])?\s*)#+\s/;
    let r;
    const l = n.match(s);
    l && (r = l[0].trim()),
        t == r || "" == t ? (i = n.replace(s, "$1")) : ((i = n.replace(/^\s*(#*|\>|\-|\d+\.)\s*/m, "")), (i = t + " " + i)),
        (o = "" != i ? e.getRange(e.getCursor(), { line: e.getCursor().line, ch: n.length }) : e.getRange(e.getCursor(), { line: e.getCursor().line, ch: 0 })),
        e.setLine(e.getCursor().line, i),
        e.setCursor({ line: e.getCursor().line, ch: Number(i.length - o.length) });
}
function Or(t, e) {
    if (!e) return;
    const i = e.getSelection();
    if (!i || "" === i.trim()) return void this.plugin.setLastExecutedCommand("editing-toolbar:change-font-color");
    const n = /<font\s+color=["']?[^"'>]+["']?>(.*?)<\/font>/gms,
        o = n.test(i);
    if (((s = i), new RegExp(`^<font\\s+color=["']?${t}["']?>(.+)<\\/font>$`, "ms").test(s.trim()))) return;
    var s;
    const r = i.replace(n, (e, i) =>
        i
            .split("\n")
            .map((e) => (e.trim() ? `<font color="${t}">${e}</font>` : e))
            .join("\n")
    ),
        l =
            r === i
                ? i
                    .split("\n")
                    .map((e) => (e.trim() ? `<font color="${t}">${e}</font>` : e))
                    .join("\n")
                : r,
        a = e.listSelections().map((e) => {
            const i = o ? 0 : `<font color="${t}"></font>`.length;
            return e.anchor.line < e.head.line || (e.anchor.line === e.head.line && e.anchor.ch < e.head.ch)
                ? { anchor: { line: e.anchor.line, ch: e.anchor.ch }, head: { line: e.head.line, ch: e.head.ch + i } }
                : { anchor: { line: e.anchor.line, ch: e.anchor.ch + i }, head: { line: e.head.line, ch: e.head.ch } };
        });
    e.replaceSelection(l), e.setSelections(a);
}
function Br(t, e) {
    if (!e) return;
    const i = e.getSelection();
    if (!i || "" === i.trim()) return;
    const n = /<span\s+style=["']?background:(?:#[0-9a-fA-F]{3,6}|rgba?\([^)]+\))["']?>([\s\S]*?)<\/span>/g.test(i);
    if (
        ((t, e) => {
            const i = e.replace(/([()[{*+.$^\\|?])/g, "\\$1");
            return new RegExp(`^<span\\s+style=["']?background:${i}["']?>([sS]+)<\\/span>$`).test(t.trim());
        })(i, t)
    )
        return;
    let o;
    o = n
        ? i.replace(/(background:)(?:#[0-9a-fA-F]{3,6}|rgba?\([^)]+\))/gi, `$1${t}`)
        : i
            .split("\n")
            .map((e) => (e.trim() ? `<span style="background:${t}">${e}</span>` : e))
            .join("\n");
    const s = e.listSelections().map((e) => {
        const i = n ? 0 : `<span style="background:${t}"></span>`.length;
        return e.anchor.line < e.head.line || (e.anchor.line === e.head.line && e.anchor.ch < e.head.ch)
            ? { anchor: { line: e.anchor.line, ch: e.anchor.ch }, head: { line: e.head.line, ch: e.head.ch + i } }
            : { anchor: { line: e.anchor.line, ch: e.anchor.ch + i }, head: { line: e.head.line, ch: e.head.ch } };
    });
    e.replaceSelection(o), e.setSelections(s);
}
function qr(t) {
    var e, i;
    if (!t.getSelection()) {
        const n = t.getCursor(),
            o = t.getLine(n.line);
        if (/^\s*\d+\.\s/.test(o)) {
            const o = (null === (e = t.getLine(n.line).match(/^\s*/)) || void 0 === e ? void 0 : e[0].length) || 0,
                s = n.line - 1,
                r = s >= 0 ? t.getLine(s).trim() : "";
            if (s < 0 || !/^\s*\d+\.\s/.test(r) || ((null === (i = r.match(/^\s*/)) || void 0 === i ? void 0 : i[0].length) || 0) < o) {
                const { startLine: e, endLine: i } = (function (t, e) {
                    let i = e,
                        n = e;
                    for (; i > 0;) {
                        const e = t.getLine(i - 1);
                        if (!/^\s*\d+\.\s/.test(e.trim())) break;
                        i--;
                    }
                    for (; n < t.lineCount() - 1;) {
                        const e = t.getLine(n + 1);
                        if (!/^\s*\d+\.\s/.test(e.trim())) break;
                        n++;
                    }
                    return { startLine: i, endLine: n };
                })(t, n.line);
                Lr(t, e, i);
            } else {
                const { startLine: e, endLine: i } = (function (t, e) {
                    var i, n;
                    let o = e,
                        s = e;
                    const r = (null === (i = t.getLine(e).match(/^\s*/)) || void 0 === i ? void 0 : i[0].length) || 0;
                    for (; s < t.lineCount() - 1;) {
                        const e = t.getLine(s + 1),
                            i = (null === (n = e.match(/^\s*/)) || void 0 === n ? void 0 : n[0].length) || 0;
                        if (!/^\s*\d+\.\s/.test(e.trim()) || i < r) break;
                        s++;
                    }
                    return { startLine: o, endLine: s };
                })(t, n.line);
                Lr(t, e, i);
            }
        }
        return;
    }
    const { lines: n, startLine: o } = (function (t) {
        const e = t.getSelection(),
            i = t.getCursor("from");
        return { lines: e.split("\n"), startLine: i.line };
    })(t);
    Nr(n, o, t);
}
function Nr(e, i, n) {
    var o, s, r;
    let l = !1;
    for (const t of e)
        if (/^\s*\d+\.\s/.test(t.trim())) {
            l = !0;
            break;
        }
    if (!l) return;
    const a = null === (o = app.workspace.getActiveViewOfType(t.MarkdownView)) || void 0 === o ? void 0 : o.editor.cm;
    if (!a) return;
    const c = dr(a.state),
        h = n.posToOffset({ line: i, ch: 0 });
    let d = -1;
    if (
        (c.iterate({
            from: 0,
            to: h,
            enter: (t) => {
                "OrderedList" === t.name && (d = t.to);
            },
        }),
            d >= 0)
    ) {
        const t = n.offsetToPos(d).line + 1;
        t < i && !/^\s*$/.test(n.getLine(t).trim()) && (n.replaceRange("\n", { line: t, ch: 0 }, { line: t, ch: 0 }), i++);
    }
    let u = !0,
        p = [],
        m = -1;
    for (const t of e) {
        const e = t.trim();
        if (/^\d+\.\s/.test(e)) {
            const i = (null === (s = t.match(/^\s*/)) || void 0 === s ? void 0 : s[0].length) || 0,
                n = parseInt(e.match(/^\d+/)[0], 10);
            if (((p[i] = i !== m ? 1 : (p[i] || 1) + 1), n !== p[i])) {
                u = !1;
                break;
            }
            m = i;
        }
    }
    let g = [];
    const f = i - 1,
        b = f >= 0 ? n.getLine(f).trim() : "";
    if ((b && !/^\s*$/.test(b) && !b.includes("ㅤ") && (g.push(""), g.push("ㅤ")), u)) g.push(...e);
    else {
        let t = {},
            i = -1;
        for (const n of e) {
            const e = n.trim(),
                o = /^\d+\.\s/.test(e),
                s = (null === (r = n.match(/^\s*/)) || void 0 === r ? void 0 : r[0]) || "";
            if (o) {
                const n = s.length;
                (t[n] = n !== i ? 1 : (t[n] || 1) + 1), g.push(`${s}${t[n]}. ${e.replace(/^\d+\.\s/, "")}`), (i = n);
            } else g.push(n), (i = -1);
        }
    }
    n.replaceRange(g.join("\n"), { line: i, ch: 0 }, { line: i + e.length - 1, ch: n.getLine(i + e.length - 1).length });
}
function Lr(t, e, i) {
    const n = [];
    for (let o = e; o <= i; o++) n.push(t.getLine(o));
    Nr(n, e, t);
}
let Rr;
Ui.RTL, Ui.LTR;
const Pr = (e) => {
    Rr = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
    let i = Rr.getElementById("editingToolbarModalBar");
    i && (i.style.visibility = 0 == e ? "hidden" : "visible");
},
    _r = (e) => {
        (Rr = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document), Rr.documentElement.style.setProperty("--toolbar-vertical-offset", `${e.verticalPosition}px`);
    },
    Fr = (e) => {
        (Rr = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document), Rr.documentElement.style.setProperty("--toolbar-horizontal-offset", `${e.horizontalPosition}px`);
    };
var Vr = {
    "Editing Toolbar append method": "Editing Toolbar append method",
    "Choose where Editing Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.":
        "Choose where Editing Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.",
    "Editing Toolbar aesthetic": "Editing Toolbar aesthetic",
    "Choose between a glass morphism ,tiny and default style for Editing Toolbar. To see the change, hit the refresh button below, or in the status bar menu.":
        "Choose between a glass morphism ,tiny and default style for Editing Toolbar. To see the change, hit the refresh button below, or in the status bar menu.",
    "Editing Toolbar position": "Editing Toolbar position",
    "Choose between fixed position or cursor following mode.": "Choose between fixed position , cursor following  or Top mode .",
    "Editing Toolbar columns": "Editing Toolbar columns",
    "Choose the number of columns per row to display on Editing Toolbar.": "Choose the number of columns per row to display on Editing Toolbar.",
    "Editing Toolbar refresh": "Editing Toolbar refresh",
    "Editing Toolbar commands": "Editing Toolbar commands",
    "Add a command onto Editing Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Editing Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.":
        "Add a command onto Editing Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Editing Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.",
    "Format Brush Off!": "Format Brush Off!",
    "Hide & Show": "Hide & Show",
    "Editing Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.":
        "Editing Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.",
    "Font-Color formatting brush ON!": "Font-Color formatting brush ON!",
    More: "More",
    "Font Colors": "Font Colors",
    "Format Brush": "Format Brush",
    "Background color": "Background color",
    Refresh: "Refresh",
    Add: "Add",
    Delete: "Delete",
    "Change Command name": "Change Command name",
    "Add submenu": "Add submenu",
    "add hr": "add hr",
    "Enter the icon code, it looks like <svg>.... </svg> format": "Enter the icon code, it looks like <svg>.... </svg> format",
    "Please enter a new name：": "Please enter a new name：",
    "Drag the slider to move the position": "Drag the slider to move the position",
    "Plugin Settings": "Plugin Settings",
    "Background-color formatting brush ON!": "Background-color formatting brush ON!\nClick the  mouse middle or right key to close the formatting-brush",
    "Clear formatting brush ON!": "Clear formatting brush ON!",
    "Clear formatting brush ON!\nClick the  mouse middle or right key to close the formatting-brush": "Clear formatting brush ON!\nClick the  mouse middle or right key to close the formatting-brush",
    "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden": "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden",
    "Editing Toolbar Auto-hide": "Editing Toolbar Auto-hide",
    "Editing Toolbar Centred Display": "Editing Toolbar Centred Display",
    "Whether the toolbar is centred or full-width, the default is full-width.": "Whether the toolbar is centred or full-width, the default is full-width.",
    "Custom Backgroud Color": "Custom Backgroud Color",
    "Custom Font Color": "Custom Font Color",
    "🎨 Set custom background": "🎨 Set custom background",
    "🖌️ Set custom font color": "🖌️ Set custom font color",
    "Click on the picker to adjust the colour": "Click on the picker to adjust the colour",
    "Mobile enabled or not": "Mobile enabled or not",
    "Whether to enable the plugin for the mobile client, the default is enabled.": "Whether to enable the plugin for the mobile client, the default is enabled.",
    "Whether to enable on mobile devices with device width less than 768px, the default is disable.": "Whether to enable on mobile devices with device width less than 768px, the default is disable.",
    Reset: "Reset",
    Fix: "Fix",
    "Fix Editing Toolbar": "Fix Editing Toolbar",
    General: "General",
    Appearance: "Appearance",
    Commands: "Commands",
    "Choose between fixed position or cursor following mode": "Choose between fixed position , cursor following  or Top mode .",
    "Add and manage commands": "Add and manage commands",
    "Choose where Editing Toolbar will append upon regeneration.": "Choose where Editing Toolbar will append upon regeneration.",
    "Whether to enable on mobile devices with device width less than 768px": "Whether to enable on mobile devices with device width less than 768px",
    "Choose between a glass morphism, tiny and default style": "Choose between a glass morphism, tiny and default style",
    "Refresh Toolbar": "Refresh Toolbar",
    "Add Command": "Add Command",
    Settings: "Settings",
    "Position Style": "Position Style",
    Columns: "Columns",
    "Drag to Adjust Position": "Drag to Adjust Position",
    "Vertical Position": "Vertical Position",
    "Horizontal Position": "Horizontal Position",
    "Toolbar Position": "Toolbar Position",
    "Choose an icon": "Choose an icon",
    "Search for an icon...": "Search for an icon...",
    All: "All",
    Obsidian: "Obsidian",
    Glyph: "Glyph",
    Custom: "Custom",
    "Choose a command": "Choose a command",
    "The command": "The command",
    "already exists": "already exists",
    "Enter the icon code, format as <svg>.... </svg>": "Enter the icon code, format as <svg>.... </svg>",
    "No matching icons found": "No matching icons found",
    "Custom Commands": "Custom Commands",
    "Toolbar Commands": "Toolbar Commands",
    ID: "ID",
    Prefix: "Prefix",
    Suffix: "Suffix",
    Pattern: "Pattern",
    "Custom Format Commands": "Custom Format Commands",
    "Add, edit or delete custom format commands": "Add, edit or delete custom format commands",
    Edit: "Edit",
    "Command ID": "Command ID",
    'Unique identifier, no spaces, e.g.: "my-custom-format"': 'Unique identifier, no spaces, e.g.: "my-custom-format"',
    "Displayed name in toolbar and menu": "Displayed name in toolbar and menu",
    "Add content before selected text": "Add content before selected text",
    "Add content after selected text": "Add content after selected text",
    "Character offset of cursor after formatting": "Character offset of cursor after formatting",
    "Line offset of cursor after formatting": "Line offset of cursor after formatting",
    "Whether to insert at the beginning of the next line": "Whether to insert at the beginning of the next line",
    "Command icon (click to select)": "Command icon (click to select)",
    "Choose Icon": "Choose Icon",
    Save: "Save",
    Cancel: "Cancel",
    "Edit Custom Command": "Edit Custom Command",
    "Add Custom Command": "Add Custom Command",
    "Command ID and command name cannot be empty": "Command ID and command name cannot be empty",
    "Command ID cannot contain spaces": "Command ID cannot contain spaces",
    'Command ID "${this.commandId}" already exists': 'Command ID "${this.commandId}" already exists',
    "Cursor Position Offset": "Cursor Position Offset",
    "Line Offset": "Line Offset",
    "Line Head Format": "Line Head Format",
    Icon: "Icon",
    "Command Name": "Command Name",
    "Are you sure you want to restore all settings to default? This will lose all your custom configurations.": "Are you sure you want to restore all settings to default? This will lose all your custom configurations.",
    "Restore default": "Restore default",
    "Restore default settings": "Restore default settings",
    "🔄Restore default settings": "🔄Restore default settings",
    "🔧Data repair": "🔧Data repair",
    "Command IDs have been successfully repaired!": "Command IDs have been successfully repaired!",
    "No command IDs need to be repaired": "No command IDs need to be repaired",
    "Error repairing command IDs, please check the console for details": "Error repairing command IDs, please check the console for details",
    "Error restoring default settings, please check the console for details": "Error restoring default settings, please check the console for details",
    "Successfully restored default settings!": "Successfully restored default settings!",
    Close: "Close",
    Tips: "Tips",
    "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly":
        "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly",
    "Repair command ID": "Repair command ID",
    "This will reset all your custom configurations": "This will reset all your custom configurations",
    "Notice:": "Notice:",
    "This update rebuilds the entire code, reducing resource consumption": "This update rebuilds the entire code, reducing resource consumption",
    "Optimized mobile usage, added canvas support, and added custom commands": "Optimized mobile usage, added canvas support, and added custom commands",
    "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible": "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible",
    "⚠️If you want to restore the default settings, please click [Restore default settings]": "⚠️If you want to restore the default settings, please click [Restore default settings]",
    "Please execute a editingToolbar format command first, then enable the format brush": "Please execute a editingToolbar format command first, then enable the format brush",
    "Format brush ON! Select text to apply【": "Format brush ON! Select text to apply【",
    "】format": "】format\nClick the mouse middle or right key to close the formatting-brush",
    "Add to Toolbar": "Add to Toolbar",
    "This command is already in the toolbar": "This command is already in the toolbar",
    "Command added to toolbar": "Command added to toolbar",
    "Add this command to the toolbar": "Add this command to the toolbar",
    "Callout Type": "Callout Type",
    Title: "Title",
    "Optional, leave blank for default title": "Optional, leave blank for default title",
    "Input title": "Input title",
    "Collapse State": "Collapse State",
    Open: "Open",
    Closed: "Closed",
    Content: "Content",
    Insert: "Insert",
    Default: "Default",
    "Input content": "Input content",
    "Link Text": "Link Text",
    "Link Alias": "Link Alias",
    "Link URL": "Link URL",
    "Embed Content": "Embed Content",
    "Image Size": "Image Size",
    "Insert New Line": "Insert New Line",
    "Paste and Parse": "Paste and Parse",
    "URL Format Error": "URL Format Error",
    "Image Width": "Image Width",
    "Image Height": "Image Height",
    "If it is an image, turn on": "If it is an image, turn on",
    "Insert a link on the next line": "Insert a link on the next line",
    "Link Title(optional)": "Link Title(optional)",
    Alias: "Alias",
    Optional: "Optional",
    "Default 0, format will keep the text selected": "Default 0, format will keep the text selected",
    "to insert": "to insert",
    "Latest Changes": "Latest Changes",
    "📋View full changelog": "📋View full changelog",
    "Open changelog": "Open changelog",
    "Loading changelog...": "Loading changelog...",
    "Open the complete changelog in your browser": "Open the complete changelog in your browser",
    "Enable multiple configurations": "Enable multiple configurations",
    "Enable different command configurations for each position style (following, top, fixed)": "Enable different command configurations for each position style (following, top, fixed)",
    "Currently editing commands for": "Currently editing commands for",
    "position style": "position style",
    "Current Configuration": "Current Configuration",
    "Switch between different command configurations": "Switch between different command configurations",
    "Following Style": "Following Style",
    "Top Style": "Top Style",
    "Fixed Style": "Fixed Style",
    "Mobile Style": "Mobile Style",
    configuration: "configuration",
    "Deploy command to configurations": "Deploy command to configurations",
    "All Configurations": "All Configurations",
    Deploy: "Deploy",
    "Command deployed to selected configurations": "Command deployed to selected configurations",
    "No configuration selected for deployment": "No configuration selected for deployment",
    "Command already exists in selected configurations": "Command already exists in selected configurations",
    "Command deployed to: ": "Command deployed to: ",
    "Command deleted": "Command deleted",
    "Confirm delete?": "Confirm delete?",
    Confirm: "Confirm",
    "Are you sure you want to restore all settings to default? But custom commands will be preserved.": "Are you sure you want to restore all settings to default? But custom commands will be preserved.",
    "Successfully restored default settings! (Custom commands preserved)": "Successfully restored default settings! (Custom commands preserved)",
    "This will reset all your custom configurations, but custom commands will be preserved": "This will reset all your custom configurations, but custom commands will be preserved",
    "Import/Export": "Import/Export",
    "Export Configuration": "Export Configuration",
    "Export your toolbar configuration to share with others": "Export your toolbar configuration to share with others",
    Export: "Export",
    "Import Configuration": "Import Configuration",
    "Import toolbar configuration from JSON": "Import toolbar configuration from JSON",
    Import: "Import",
    "Usage Instructions": "Usage Instructions",
    "Export: Generate a JSON configuration that you can save or share": "Export: Generate a JSON configuration that you can save or share",
    "Import: Paste a previously exported JSON configuration": "Import: Paste a previously exported JSON configuration",
    "You can choose to export all settings, only toolbar commands, or only custom commands": "You can choose to export all settings, only toolbar commands, or only custom commands",
    "When importing, the plugin will only update the settings included in the import data": "When importing, the plugin will only update the settings included in the import data",
    "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.":
        "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.",
    "Export Type": "Export Type",
    "Choose what to export": "Choose what to export",
    "All Settings": "All Settings",
    "Toolbar Commands Only": "Toolbar Commands Only",
    "Custom Commands Only": "Custom Commands Only",
    "Export Content": "Export Content",
    "Copy this content to share with others": "Copy this content to share with others",
    "Loading...": "Loading...",
    "Copy to Clipboard": "Copy to Clipboard",
    "Configuration copied to clipboard": "Configuration copied to clipboard",
    "Failed to copy configuration": "Failed to copy configuration",
    "Paste the configuration JSON here": "Paste the configuration JSON here",
    "Paste configuration here...": "Paste configuration here...",
    "Invalid import data": "Invalid import data",
    "Configuration imported successfully": "Configuration imported successfully",
    "No valid configuration found in import data": "No valid configuration found in import data",
    "Failed to import configuration. Invalid format.": "Failed to import configuration. Invalid format.",
    "Import Mode": "Import Mode",
    "Choose how to import the configuration": "Choose how to import the configuration",
    "Update Mode (Add new items and update existing ones)": "Update Mode (Add new items and update existing ones)",
    "Overwrite Mode (Replace all settings with imported ones)": "Overwrite Mode (Replace all settings with imported ones)",
    "Configuration imported successfully (Overwrite mode)": "Configuration imported successfully (Overwrite mode)",
    "Configuration imported successfully (Update mode)": "Configuration imported successfully (Update mode)",
    "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.":
        "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.",
    "Warning: Update mode will add new items and update existing ones based on the imported configuration.": "Warning: Update mode will add new items and update existing ones based on the imported configuration.",
    "Add Format Command": "Add Format Command",
    Regex: "Regex",
    "Prefix/Suffix": "Prefix/Suffix",
    "Insert Special Char": "Insert Special Char",
    "Add Regex Command": "Add Regex Command",
    "Switch Regex Command Window": "Switch Regex Command Window",
    "Please select text first": "Please select text first",
    "The selected text does not meet the condition requirements": "The selected text does not meet the condition requirements",
    "Regex command execution error:": "Regex command execution error:",
    "Copy code": "Copy code",
    "Copied!": "Copied!",
    "Explain the syntax of JavaScript regular expressions": "Explain the syntax of JavaScript regular expressions",
    "Apply regular expression replacement": "Apply regular expression replacement",
    "Conditional matching": "Conditional matching",
    "Complete regular expression code (copy to AI for explanation)": "Complete regular expression code (copy to AI for explanation)",
    "Error:": "Error:",
    "Regex pattern cannot be empty": "Regex pattern cannot be empty",
    "Command already exists": "Command already exists",
    "Choose icon": "Choose icon",
    "URL to Markdown link": "URL to Markdown link",
    "Convert MM/DD/YYYY to YYYY-MM-DD": "Convert MM/DD/YYYY to YYYY-MM-DD",
    "Add bold to keywords": "Add bold to keywords",
    "Format phone number": "Format phone number",
    "Remove extra spaces": "Remove extra spaces",
    "Convert HTML bold tags to Markdown format": "Convert HTML bold tags to Markdown format",
    "Convert quoted text to quote block": "Convert quoted text to quote block",
    "Convert CSV to Markdown table row": "Convert CSV to Markdown table row",
    "Add uniform alias to Markdown links": "Add uniform alias to Markdown links",
    "Delete empty lines (multiline mode)": "Delete empty lines (multiline mode)",
    "Add list symbol to each line (multiline mode)": "Add list symbol to each line (multiline mode)",
    "If the text contains important, set the text highlight (conditional format)": "If the text contains important, set the text highlight (conditional format)",
    "Matching pattern": "Matching pattern",
    "Regex pattern to match": "Regex pattern to match",
    "Replacement pattern (use $1, $2, etc. to reference capture groups)": "Replacement pattern (use $1, $2, etc. to reference capture groups)",
    "Ignore case": "Ignore case",
    "Global replace": "Global replace",
    "Multiline mode": "Multiline mode",
    "Use condition": "Use condition",
    "Condition pattern": "Condition pattern",
    "Only apply custom command when text matches the condition": "Only apply custom command when text matches the condition",
    "Must exist regular expression or text": "Must exist regular expression or text",
    "Replacement pattern": "Replacement pattern",
    "Match case-insensitive": "Match case-insensitive",
    "^ and $ match the start and end of each line": "^ and $ match the start and end of each line",
    "Replace all matches": "Replace all matches",
    Command: "Command",
    "Error: ": "Error:",
    "Input example text to view the formatting effect of the command...": "Input example text to view the formatting effect of the command...",
    Description: "Description",
    "[Example]": "[Example]",
    "[Requirements]": "[Requirements]",
    "[Output]": "[Output]",
    "AI question template:": "AI question template:",
    "I need to convert the url to a markdown format link": "I need to convert the url to a markdown format link",
    "For example, convert https://example.com to [https://example.com](https://example.com)": "For example, convert https://example.com to [https://example.com](https://example.com)",
    "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)":
        "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)",
    "[Description]": "[Description]",
    "How to use AI to get regular expressions?": "How to use AI to get regular expressions?",
    "Regular expression examples": "Regular expression examples",
    "Edit regular expression command": "Edit regular expression command",
    "Add regular expression command": "Add regular expression command",
    "Result:": "Result:",
    "Example text:": "Example text:",
    Preview: "Preview",
    Result: "Result",
    "Please select text or copy text to clipboard first": "Please select text or copy text to clipboard first",
    "Overwrite Import": "Overwrite Import",
    "Update Import": "Update Import",
    "Importing configuration...": "Importing configuration...",
    "Following Style Only": "Following Style Only",
    "Top Style Only": "Top Style Only",
    "Fixed Style Only": "Fixed Style Only",
    "Mobile Style Only": "Mobile Style Only",
    "Unknown import type": "Unknown import type",
    "All Toolbar Commands": "All Toolbar Commands",
    "Initialize Commands": "Initialize Commands",
    "Copy commands from the main menu configuration": "Copy commands from the main menu configuration",
    "Initialize commands to default settings": "Initialize commands to default settings",
    "Reset Commands": "Reset Commands",
    "Commands reset successfully": "Commands reset successfully",
    "Following style commands initialized from current menu commands": "Following style commands initialized from current menu commands",
    "Commands initialized successfully": "Commands initialized successfully",
    "Reset to Menu Commands": "Reset to Menu Commands",
    "Are you sure you want to reset the current configuration?": "Are you sure you want to reset the current configuration?",
    "Following style commands successfully initialized": "Following style commands successfully initialized",
    "Top style commands successfully initialized": "Top style commands successfully initialized",
    "Fixed style commands successfully initialized": "Fixed style commands successfully initialized",
    "Mobile style commands successfully initialized": "Mobile style commands successfully initialized",
    "Reset commands to default settings": "Reset commands to default settings",
    Clear: "Clear",
    "Remove all commands from this configuration": "Remove all commands from this configuration",
    "Are you sure you want to clear all commands under the current style?": "Are you sure you want to clear all commands under the current style?",
    "Current style commands have been cleared": "Current style commands have been cleared",
    "Manage Commands": "Manage Commands",
    "Reset or clear all commands in this configuration": "Reset or clear all commands in this configuration",
    "One-click clear": "One-click clear",
    "Import Commands from Other Styles": "Import Commands from Other Styles",
    "Copy commands from another style configuration": "Copy commands from another style configuration",
    "Main menu only": "Main menu only",
    "This import will update:": "This import will update:",
    "Custom commands": "Custom commands",
    "Toolbar commands": "Toolbar commands",
    "General settings": "General settings",
    "Please paste configuration data first": "Please paste configuration data first",
    "Invalid import data format": "Invalid import data format",
    "Import From": "Import From",
    "This import will:": "This import will:",
    "Update general settings": "Update general settings",
    "Update Main Menu Commands": "Update Main Menu Commands",
    "Update Custom Commands": "Update Custom Commands",
    "Update Following Style Commands": "Update Following Style Commands",
    "Update Top Style Commands": "Update Top Style Commands",
    "Update Fixed Style Commands": "Update Fixed Style Commands",
    "Update Mobile Style Commands": "Update Mobile Style Commands",
    "Clear all Main Menu Commands": "Clear all Main Menu Commands",
    "Clear all Custom Commands": "Clear all Custom Commands",
    "Clear all Following Style Commands": "Clear all Following Style Commands",
    "Clear all Top Style Commands": "Clear all Top Style Commands",
    "Clear all Fixed Style Commands": "Clear all Fixed Style Commands",
    "Clear all Mobile Style Commands": "Clear all Mobile Style Commands",
    "Overwrite Mode (Replace settings with imported ones)": "Overwrite Mode (Replace settings with imported ones)",
    "Warning: Overwrite mode will replace existing settings with imported ones.": "Warning: Overwrite mode will replace existing settings with imported ones.",
    "Warning: Update mode will add new items and update existing ones.": "Warning: Update mode will add new items and update existing ones.",
    "Enable Multiple Config": "Enable Multiple Config",
    "Set Multiple Config to:": "Set Multiple Config to:",
    Enable: "Enable",
    Disable: "Disable",
    "Set Position Style to:": "Set Position Style to:",
    Following: "Following",
    Top: "Top",
    Fixed: "Fixed",
    Mobile: "Mobile",
    "All commands": "All commands",
    "⚠️ Overwrite mode will replace existing settings with imported ones.": "⚠️ Overwrite mode will replace existing settings with imported ones.",
    "ℹ️ Update mode will merge imported settings with existing ones.": "ℹ️ Update mode will merge imported settings with existing ones.",
    "Do you want to continue?": "Do you want to continue?",
    "Imported settings:": "Imported settings:",
    "Imported commands:": "Imported commands:",
    "Disable toolbar for this view": "Disable toolbar for this view",
    "Enable toolbar for this view": "Enable toolbar for this view",
    "Manage all view types": "Manage all view types",
    "Current View: ": "Current View: ",
    "Appearance Style": "Appearance Style",
    "Position Settings": "Position Settings",
    "All commands have been removed": "All commands have been removed",
    "Join the Community": "Join the Community",
    "Share your toolbar settings and styles in our": "Share your toolbar settings and styles in our",
    "Get inspired by what others have created or showcase your own customizations.": "Get inspired by what others have created or showcase your own customizations.",
    "Toolbar preview": "Toolbar preview (for example only)",
    "Toolbar theme": "Toolbar theme",
    "Select a preset toolbar theme, automatically setting the background color, icon color, and size": "Select a preset toolbar theme, automatically setting the background color, icon color, and size",
    "Toolbar background color": "Toolbar background color",
    "Set the background color of the toolbar": "Set the background color of the toolbar",
    "Toolbar icon color": "Toolbar icon color",
    "Set the color of the toolbar icon": "Set the color of the toolbar icon",
    "Toolbar icon size": "Toolbar icon size",
    "Set the size of the toolbar icon (px) default 18px": "Set the size of the toolbar icon (px) default 18px",
    "Custom theme": "Custom theme",
    "Fixed position offset": "Fixed position offset",
    "Choose the offset of the Editing Toolbar in the fixed position.": "Choose the offset of the Editing Toolbar in the fixed position.",
    "Renumber List": "Renumber List",
    "Fetch Remote Title": "Fetch Remote Title",
    "Please enter a URL first": "Please enter a URL first",
    "Failed to fetch title for": "Failed to fetch title for",
    "Link Title (optional)": "Link Title (optional)",
    "Unable to detect editor width": "Unable to detect editor width",
    "Fit Editor Width": "Fit Editor Width",
    "Please execute a format command or select format text first, then enable the format brush": "Please execute a format command or select format text first, then enable the format brush",
    "Use \\n to represent line breaks": "Use \\n to represent line breaks",
    "Use ↵ to represent line breaks": "Use ↵ to represent line breaks",
},
    Hr = {
        "Editing Toolbar append method": "工具栏的附加方法。",
        "Choose where Editing Toolbar will append upon regeneration. To see the change, hit the refresh button below, or in the status bar menu.":
            "工具栏在Obsidian中的追加的位置，只对固定和跟随模式有效。如果你遇到工具栏显示问题，可以选择body试试。请点击下面或者状态栏菜单中的刷新按钮生效。",
        "Editing Toolbar aesthetic": "工具栏样式",
        "Choose between a glass morphism ,tiny and default style for Editing Toolbar. To see the change, hit the refresh button below, or in the status bar menu.":
            "样式有毛玻璃,简约和默认风格选择。请点击下面或者状态栏菜单中的刷新按钮生效。",
        "Editing Toolbar position": "工具栏位置",
        "Choose between fixed position or cursor following mode.": "在固定位置,光标跟随模式或者置顶模式之间进行选择。",
        "Editing Toolbar columns": "工具栏栏目数",
        "Choose the number of columns per row to display on Editing Toolbar.": "选择在Editing Toolbar上显示的每行的列数。",
        "Editing Toolbar refresh": "刷新工具栏",
        "Editing Toolbar commands": "在工具栏中添加命令",
        "Add a command onto Editing Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Editing Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above.":
            "从Obsidian的命令库中添加一个命令到工具栏。要重新排列命令，可以拖放命令项。要删除它们，请使用命令项右边的删除按钮。图标选择Custom可以自定义图标",
        "Format Brush Off!": "关闭格式刷！",
        "Hide & Show": "隐藏 & 显示",
        "Editing Toolbar will only refresh automatically after you have either added or deleted a command from it. To see UI changes to editingToolbar (above settings changes) use the refresh button. If you forget to refresh in settings, no worries. There is also a refresh button in the editingToolbar status bar menu.":
            "对外观的更改生效需要使用刷新按钮。如果你忘记在设置中刷新，在状态栏菜单中也有一个刷新按钮。",
        "Font-Color formatting brush ON!": "字体颜色格式刷开启\n点击鼠标中键或者右键关闭格式刷",
        More: "更多",
        "Font Colors": "字体颜色",
        "Format Brush": "格式刷",
        "Background color": "背景颜色",
        Refresh: "刷新",
        Add: "添加",
        Delete: "删除",
        "Change Command name": "更改命令名称",
        "Add submenu": "添加子菜单",
        "add hr": "添加分割线",
        "Enter the icon code, it looks like <svg>.... </svg> format": "输入图标代码，类似<svg>.... </svg>格式",
        "Please enter a new name：": "请输入新名称：",
        "Drag the slider to move the position": "拖动滑块来移动位置",
        "Plugin Settings": "插件设置",
        "Background-color formatting brush ON!": "开启背景色格式刷",
        "Clear formatting brush ON!": "清除格式刷已开启",
        "Clear formatting brush ON!\nClick the  mouse middle or right key to close the formatting-brush": "清除格式刷已开启\n点击鼠标中键或者右键关闭格式刷",
        "The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden": "当鼠标移到工具栏上方时，工具栏显示，否则自动隐藏",
        "Editing Toolbar Auto-hide": "工具栏是否自动隐藏",
        "Editing Toolbar Centred Display": "工具栏是否居中显示",
        "Whether the toolbar is centred or full-width, the default is full-width.": "工具栏居中还是全宽显示，默认全宽显示",
        "Custom Backgroud Color": "设置自定义背景色",
        "Custom Font Color": "设置自定义字体颜色",
        "🎨 Set custom background": "🎨 设置自定义背景",
        "🖌️ Set custom font color": "🖌️ 设置自定义字体颜色",
        "Click on the picker to adjust the colour": "点击选取器来调整颜色",
        "Mobile enabled or not": "是否在移动端启用",
        "Whether to enable on mobile devices with device width less than 768px, the default is disable.": "是否在设备宽度小于768的移动设备启用。默认不启用",
        Reset: "重置",
        Fix: "修复",
        "Fix Editing Toolbar": "修复工具栏",
        General: "常规",
        Appearance: "外观",
        Commands: "命令",
        "Choose between fixed position or cursor following mode": "选择固定位置或者光标跟随模式",
        "Add and manage commands": "添加和管理命令",
        "Choose where Editing Toolbar will append upon regeneration.": "选择工具栏在Obsidian中的追加的位置。",
        "Whether to enable on mobile devices with device width less than 768px": "是否在移动设备中启用。默认不启用",
        "Choose between a glass morphism, tiny and default style": "选择毛玻璃,简约和默认风格",
        "Refresh Toolbar": "刷新工具栏",
        "Add Command": "添加命令",
        Settings: "设置",
        "Adjust Toolbar Position[Fixed mode]": "调整工具栏位置[固定模式]",
        "Position Style": "位置样式",
        Columns: "列数",
        "Drag to Adjust Position": "拖动调整位置",
        "Vertical Position": "垂直位置",
        "Horizontal Position": "水平位置",
        "Toolbar Position": "工具栏位置",
        "Choose an icon": "选择一个图标",
        "Search for an icon...": "搜索图标...",
        All: "全部",
        Obsidian: "Obsidian",
        Glyph: "Glyph",
        Custom: "自定义",
        "Choose a command": "选择一个命令",
        "The command": "命令",
        "already exists": "已存在",
        "Enter the icon code, format as <svg>.... </svg>": "输入图标代码，格式为 <svg>.... </svg>",
        "No matching icons found": "没有找到匹配的图标",
        "Custom Commands": "自定义命令",
        "Toolbar Commands": "工具栏命令",
        ID: "ID",
        Prefix: "前缀",
        Suffix: "后缀",
        "Custom Format Commands": "自定义格式命令",
        "Add, edit or delete custom format commands": "添加、编辑或删除自定义格式命令",
        Edit: "编辑",
        "Command ID": "命令ID",
        'Unique identifier, no spaces, e.g.: "my-custom-format"': '唯一标识符，不包含空格，例如："my-custom-format"',
        "Displayed name in toolbar and menu": "在工具栏和菜单中显示的名称",
        "Add content before selected text": "在选中的文本前添加内容",
        "Add content after selected text": "在选中的文本后添加内容",
        "Character offset of cursor after formatting": "格式化后光标的字符偏移量",
        "Line offset of cursor after formatting": "格式化后光标的行偏移量",
        "Whether to insert at the beginning of the next line": "是否在下一行首插入",
        "Command icon (click to select)": "命令图标（点击选择）",
        "Choose Icon": "选择图标",
        Save: "保存",
        Cancel: "取消",
        "Edit Custom Command": "编辑自定义命令",
        "Add Custom Command": "添加自定义命令",
        "Command ID and command name cannot be empty": "命令ID和命令名称不能为空",
        "Command ID cannot contain spaces": "命令ID不能包含空格",
        'Command ID "${this.commandId}" already exists': '命令ID "${this.commandId}" 已存在',
        "Command Name": "命令名称",
        "Cursor Position Offset": "光标位置偏移量",
        "Line Offset": "行偏移量",
        "Line Head Format": "行首格式",
        Icon: "图标",
        "Are you sure you want to restore all settings to default? This will lose all your custom configurations.": "确定要恢复所有设置为默认值吗？这将丢失您的所有自定义配置。",
        "Restore default": "恢复默认值",
        "Restore default settings": "恢复默认设置",
        "🔄Restore default settings": "🔄恢复默认设置",
        "🔧Data repair": "🔧数据修复",
        "Command IDs have been successfully repaired!": "命令ID已成功修复！",
        "No command IDs need to be repaired": "没有命令ID需要修复",
        "Error repairing command IDs, please check the console for details": "修复命令ID时出错，请查看控制台了解详情",
        "Error restoring default settings, please check the console for details": "恢复默认设置时出错，请查看控制台了解详情",
        "Successfully restored default settings!": "已成功恢复默认设置！",
        Close: "关闭",
        Tips: "提示",
        "This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly": "此次更新更改了部分命令的ID，请点击此按钮修复命令以确保工具栏正常工作",
        "Repair command ID": "修复命令ID",
        "This will reset all your custom configurations": "这将重置您的所有自定义配置",
        "Notice:": "注意",
        "This update rebuilds the entire code, reducing resource consumption": "此次更新重构了全部代码，降低了资源占用",
        "Optimized mobile usage, added canvas support, and added custom commands": "优化了移动端，增加了对canvas支持，增加了自定义命令",
        "⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible": "⚠️此次更新不兼容2.x旧版本命令id，请点击【修复命令】进行兼容",
        "⚠️If you want to restore the default settings, please click [Restore default settings]": "⚠️如果想恢复默认设置，请点击【恢复默认设置】",
        "Please execute a editingToolbar format command first, then enable the format brush": "请先执行一个格式命令，然后再启用格式刷",
        "Format brush ON! Select text to apply【": "格式刷已开启\n选中文本应用【",
        "】format": "】格式\n点击鼠标中键或者右键关闭格式刷",
        "Add to Toolbar": "添加到工具栏",
        "This command is already in the toolbar": "该命令已存在于工具栏中",
        "Command added to toolbar": "命令已添加到工具栏",
        "Add this command to the toolbar": "添加该命令到工具栏",
        "Callout Type": "Callout 类型",
        Title: "标题",
        "Optional, leave blank for default title": "可选，留空则使用默认标题",
        "Input title": "输入标题",
        "Collapse State": "折叠状态",
        Open: "展开",
        Closed: "折叠",
        Content: "内容",
        Insert: "插入",
        Default: "默认",
        "Input content": "输入内容",
        "Link Text": "链接文本",
        "Link Alias": "链接别名",
        "Link URL": "链接地址",
        "Embed Content": "嵌入内容",
        "Image Size": "图片尺寸",
        "Insert New Line": "插入新行",
        "Paste and Parse": "粘贴并解析",
        "URL Format Error": "URL格式错误",
        "Image Width": "图片宽度",
        "Image Height": "图片高度",
        "Insert a link on the next line": "在下一行插入链接",
        "If it is an image, turn on": "如果是图片，请开启",
        "Link Title(optional)": "链接标题(可选)",
        Alias: "别名",
        Optional: "可选",
        "Default 0, format will keep the text selected": "默认0，格式化将保持文本选中",
        "to insert": "插入",
        "Latest Changes": "最新更新",
        "📋View full changelog": "📋查看完整更新日志",
        "Open changelog": "打开更新日志",
        "Loading changelog...": "加载更新日志...",
        "Open the complete changelog in your browser": "在浏览器中打开完整更新日志",
        "Enable multiple configurations": "启用多配置",
        "Enable different command configurations for each position style (following, top, fixed)": "启用每个位置样式的不同命令配置（following，top，fixed）",
        "Currently editing commands for": "当前编辑的命令配置为：",
        "position style": "样式",
        "Current Configuration": "当前配置",
        "Switch between different command configurations": "切换不同的命令配置",
        "Following Style": "跟随样式",
        "Top Style": "顶部样式",
        "Fixed Style": "固定样式",
        "Mobile Style": "移动端样式",
        configuration: "配置",
        "Deploy command to configurations": "部署命令到配置",
        "All Configurations": "所有配置",
        Deploy: "部署",
        "Command deployed to selected configurations": "命令已部署到选中的配置",
        "No configuration selected for deployment": "没有选中的配置",
        "Command already exists in selected configurations": "命令已存在于选中的配置",
        "Command deployed to: ": "命令已部署到：",
        "Command deleted": "命令已删除",
        "Confirm delete?": "确认删除？",
        "Are you sure you want to restore all settings to default? But custom commands will be preserved.": "您确定要将所有设置恢复为默认值吗？但自定义命令将被保留。",
        "Successfully restored default settings! (Custom commands preserved)": "成功恢复默认设置！（自定义命令已保留）",
        "This will reset all your custom configurations, but custom commands will be preserved": "这将重置您的所有自定义配置，但自定义命令将被保留",
        "Import/Export": "导入/导出",
        "Export Configuration": "导出配置",
        "Export your toolbar configuration to share with others": "导出您的工具栏配置以与他人共享",
        Export: "导出",
        "Import Configuration": "导入配置",
        "Import toolbar configuration from JSON": "从JSON导入工具栏配置",
        Import: "导入",
        "Usage Instructions": "使用说明",
        "Export: Generate a JSON configuration that you can save or share": "导出：生成可保存或共享的JSON配置",
        "Import: Paste a previously exported JSON configuration": "导入：粘贴先前导出的JSON配置",
        "You can choose to export all settings, only toolbar commands, or only custom commands": "您可以选择导出所有设置、仅工具栏命令或仅自定义命令",
        "When importing, the plugin will only update the settings included in the import data": "导入时，插件将仅更新导入数据中包含的设置",
        "Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup.": "警告：导入配置将覆盖您当前的设置。建议先导出当前配置作为备份。",
        "Export Type": "导出类型",
        "Choose what to export": "选择要导出的内容",
        "All Settings": "所有设置",
        "Toolbar Commands Only": "仅工具栏命令",
        "Custom Commands Only": "仅自定义命令",
        "Export Content": "导出内容",
        "Copy this content to share with others": "复制此内容以与他人共享",
        "Loading...": "加载中...",
        "Copy to Clipboard": "复制到剪贴板",
        "Configuration copied to clipboard": "配置已复制到剪贴板",
        "Failed to copy configuration": "复制配置失败",
        "Paste the configuration JSON here": "在此处粘贴配置JSON",
        "Paste configuration here...": "在此处粘贴配置...",
        "Invalid import data": "无效的导入数据",
        "Configuration imported successfully": "配置导入成功",
        "No valid configuration found in import data": "导入数据中未找到有效配置",
        "Failed to import configuration. Invalid format.": "导入配置失败。格式无效。",
        "Import Mode": "导入模式",
        "Choose how to import the configuration": "选择如何导入配置",
        "Update Mode (Add new items and update existing ones)": "更新模式（添加新项目并更新现有项目）",
        "Overwrite Mode (Replace all settings with imported ones)": "覆盖模式（用导入的配置替换所有设置）",
        "Configuration imported successfully (Overwrite mode)": "配置导入成功（覆盖模式）",
        "Configuration imported successfully (Update mode)": "配置导入成功（更新模式）",
        "Warning: Overwrite mode will completely replace your current settings with the imported ones. Consider exporting your current configuration first as a backup.":
            "警告：覆盖模式将完全替换您当前的设置与导入的设置。建议先导出当前配置作为备份。",
        "Warning: Update mode will add new items and update existing ones based on the imported configuration.": "警告：更新模式将根据导入的配置添加新项目并更新现有项目。",
        "Add Format Command": "添加格式命令",
        Regex: "正则",
        "Prefix/Suffix": "前缀/后缀",
        "Insert Special Char": "增加特殊符号",
        "Add Regex Command": "添加正则表达式命令",
        "Switch Regex Command Window": "切换到正则命令窗口",
        "Please select text first": "请先选中文本",
        "The selected text does not meet the condition requirements": "选中的文本不满足条件要求",
        "Regex command execution error:": "正则表达式命令执行错误：",
        "Copy code": "复制代码",
        "Copied!": "已复制！",
        "Explain the syntax of JavaScript regular expressions": "解释JavaScript正则表达式的语法",
        "Apply regular expression replacement": "应用正则表达式替换",
        "Conditional matching": "条件匹配",
        "Complete regular expression code (copy to AI for explanation)": "完整正则表达式代码（复制到AI解释）",
        "Error:": "错误：",
        "Regex pattern cannot be empty": "正则表达式不能为空",
        "Command already exists": "命令已存在",
        "Choose icon": "选择图标",
        "URL to Markdown link": "URL转Markdown链接",
        "Convert MM/DD/YYYY to YYYY-MM-DD": "将MM/DD/YYYY日期格式转换为YYYY-MM-DD",
        "Add bold to keywords": "添加粗体到关键词",
        "Format phone number": "格式化电话号码",
        "Remove extra spaces": "删除多余空格",
        "Convert HTML bold tags to Markdown format": "将HTML粗体标签转换为Markdown格式",
        "Convert quoted text to quote block": "将引用的文本转换为引用块",
        "Convert CSV to Markdown table row": "将CSV转换为Markdown表格行",
        "Add uniform alias to Markdown links": "添加统一别名到Markdown链接",
        "Delete empty lines (multiline mode)": "删除空行（多行模式）",
        "Add list symbol to each line (multiline mode)": "添加列表符号到每行（多行模式）",
        "If the text contains important, set the text highlight (conditional format)": "如果文本包含重要内容，设置文本高亮（条件格式）",
        "Matching pattern": "匹配模式",
        "Regex pattern to match": "正则表达式匹配",
        "Replacement pattern (use $1, $2, etc. to reference capture groups)": "替换模式（使用$1, $2等引用捕获组）",
        "Ignore case": "忽略大小写",
        "Global replace": "全局替换",
        "Multiline mode": "多行模式",
        "Use condition": "使用条件",
        "Condition pattern": "条件模式",
        "Only apply custom command when text matches the condition": "仅在文本匹配条件时应用自定义命令",
        "Must exist regular expression or text": "必须存在正则表达式或文本",
        "Replacement pattern": "替换模式",
        "Match case-insensitive": "匹配不区分大小写",
        "^ and $ match the start and end of each line": "^ 和 $ 匹配每行的开始和结束",
        "Replace all matches": "替换所有匹配",
        Command: "命令",
        "Error: ": "错误：",
        "Input example text to view the formatting effect of the command...": "输入示例文本以查看命令的格式化效果...",
        Description: "描述",
        "[Example]": "[示例]",
        "[Requirements]": "[要求]",
        "[Output]": "[输出]",
        "AI question template:": "AI问题模板：",
        "I need to convert the url to a markdown format link": "我需要将URL转换为Markdown格式链接",
        "For example, convert https://example.com to [https://example.com](https://example.com)": "例如，将https://example.com转换为[https://example.com](https://example.com)",
        "Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)": "使用js正则表达式实现，并输出以下格式的参数（结果不需要用json转义）",
        "[Description]": "[描述]",
        "How to use AI to get regular expressions?": "如何使用AI获取正则表达式？",
        "Regular expression examples": "正则表达式示例",
        "Edit regular expression command": "编辑正则表达式命令",
        "Add regular expression command": "添加正则表达式命令",
        "Result:": "结果：",
        "Example text:": "示例文本：",
        Preview: "预览",
        Result: "结果",
        "Update Import": "增量导入",
        "Overwrite Import": "覆盖导入",
        "Importing configuration...": "正在导入配置...",
        "Following Style Only": "仅Following样式",
        "Top Style Only": "仅Top样式",
        "Fixed Style Only": "仅Fixed样式",
        "Mobile Style Only": "仅Mobile样式",
        "Unknown import type": "未知导入类型",
        "All Toolbar Commands": "所有工具栏命令",
        "Following style commands successfully initialized": "Following样式初始化成功",
        "Top style commands successfully initialized": "Top样式初始化成功",
        "Fixed style commands successfully initialized": "Fixed样式初始化成功",
        "Mobile style commands successfully initialized": "Mobile样式初始化成功",
        "Commands initialized successfully": "命令初始化成功",
        "Reset Commands": "重置命令",
        "Are you sure you want to reset the current configuration?": "您确定要将当前配置进行重置吗？",
        "Commands reset successfully": "命令重置成功",
        "Initialize Commands": "初始化命令",
        "Initialize commands to default settings": "初始化命令到默认设置",
        "Reset commands to default settings": "重置命令到默认设置",
        Clear: "清除",
        "Remove all commands from this configuration": "清除当前样式下的所有命令",
        "Are you sure you want to clear all commands under the current style?": "您确定要清除当前样式下的所有命令吗？",
        "Current style commands have been cleared": "当前样式下的命令已清除",
        "Manage Commands": "管理命令",
        "Reset or clear all commands in this configuration": "重置或清除当前样式下的所有命令",
        "Import Commands from Other Styles": "从其他样式导入命令",
        "Copy commands from another style configuration": "从另一个样式配置复制命令",
        "Main menu only": "Main menu only",
        "This import will update:": "此次导入将更新：",
        "Custom commands": "自定义命令",
        "Toolbar commands": "工具栏命令",
        "All settings": "所有设置",
        "Following style only": "跟随样式",
        "Top style only": "顶部样式",
        "Fixed style only": "固定样式",
        "Mobile style only": "移动端样式",
        "Main Menu Commands": "主菜单命令",
        "Following Style Commands": "跟随样式命令",
        "Top Style Commands": "顶部样式命令",
        "Fixed Style Commands": "固定样式命令",
        "Mobile Style Commands": "移动端样式命令",
        "General settings": "常规设置",
        "Please paste configuration data first": "请先粘贴配置数据",
        "Invalid import data format": "无效的导入数据格式",
        "Do you want to continue?": "您确定要继续吗？",
        "Warning: Update mode will add new items and update existing ones.": "警告：更新模式将添加新项目并更新现有项目。",
        "Warning: Overwrite mode will completely replace your current settings with the imported ones.": "警告：覆盖模式将完全替换您当前的设置与导入的设置。",
        "Overwrite Mode (Replace settings with imported ones)": "覆盖模式（用导入的配置替换所有设置）",
        "Warning: Overwrite mode will replace existing settings with imported ones.": "警告：覆盖模式将用导入的配置替换所有设置。",
        "Enable Multiple Config": "启用多配置",
        "One-click clear": "一键清除",
        "This import will:": "此次导入将：",
        "Update general settings": "更新常规设置",
        "Update Main Menu Commands": "更新主菜单命令",
        "Update Custom Commands": "更新自定义命令",
        "Update Following Style Commands": "更新跟随样式命令",
        "Update Top Style Commands": "更新顶部样式命令",
        "Update Fixed Style Commands": "更新固定样式命令",
        "Clear all Main Menu Commands": "清除所有主菜单命令",
        "Clear all Custom Commands": "清除所有自定义命令",
        "Clear all Following Style Commands": "清除所有跟随样式命令",
        "Clear all Top Style Commands": "清除所有顶部样式命令",
        "Clear all Fixed Style Commands": "清除所有固定样式命令",
        "Clear all Mobile Style Commands": "清除所有移动端样式命令",
        "Set Multiple Config to:": "设置多配置为：",
        Enable: "启用",
        Disable: "禁用",
        "Set Position Style to:": "设置位置样式为：",
        Following: "跟随",
        Top: "顶部",
        Fixed: "固定",
        Mobile: "移动端",
        "All commands": "所有命令",
        "⚠️ Overwrite mode will replace existing settings with imported ones.": "⚠️ 覆盖模式将用导入的配置替换所有设置。",
        "ℹ️ Update mode will merge imported settings with existing ones.": "ℹ️ 更新模式将合并导入的设置与现有的设置。",
        "Imported settings:": "导入的设置：",
        "Imported commands:": "导入的命令：",
        "Disable toolbar for this view": "禁用此视图的工具栏",
        "Enable toolbar for this view": "启用此视图的工具栏",
        "Manage all view types": "管理所有视图类型",
        "Current View: ": "当前视图：",
        "Appearance Style": "外观样式",
        "Position Settings": "位置设置",
        "Join the Community": "加入社区",
        "Share your toolbar settings and styles in our": "分享您的工具栏设置和样式：",
        "section!": "社区！",
        "Get inspired by what others have created or showcase your own customizations.": "获取灵感或展示您的自定义设置。",
        "Toolbar preview": "工具栏预览（按钮仅供参考）",
        "Toolbar theme": "工具栏主题",
        "Select a preset toolbar theme, automatically setting the background color, icon color, and size": "选择预设的工具栏主题，自动设置背景颜色、图标颜色和大小",
        "Toolbar background color": "工具栏背景颜色",
        "Set the background color of the toolbar": "设置工具栏的背景颜色",
        "Toolbar icon color": "工具栏图标颜色",
        "Set the color of the toolbar icon": "设置工具栏图标颜色",
        "Toolbar icon size": "工具栏图标大小",
        "Set the size of the toolbar icon (px) default 18px": "设置工具栏图标大小（px）默认18px",
        "Custom theme": "自定义主题",
        "Fixed position offset": "固定位置偏移",
        "Choose the offset of the Editing Toolbar in the fixed position.": "选择固定位置工具栏的偏移量。",
        "Renumber List": "列表重新编号",
        "Insert link": "插入链接",
        "Please enter a URL first": "请先输入一个URL",
        "Failed to fetch title for": "获取标题失败",
        "Link Title (optional)": "链接标题（可选）",
        "Unable to detect editor width": "无法检测编辑器宽度",
        "Fit Editor Width": "自适应宽度",
        "Fetch Remote Title": "获取URL标题",
        "Please execute a format command or select format text first, then enable the format brush": "请先执行一个格式命令或选中带格式的文本，然后启用格式刷",
        Confirm: "确认",
        "Use \\n to represent line breaks": "使用\\n表示换行符",
        "Use ↵ to represent line breaks": "使用↵表示换行符",
    },
    zr = Object.assign({}, Hr);
const $r = { ar: {}, cs: {}, da: {}, de: {}, en: Vr, "en-gb": {}, es: {}, fr: {}, hi: {}, id: {}, it: {}, ja: {}, ko: {}, nl: {}, nn: {}, pl: {}, pt: {}, "pt-br": {}, ro: {}, ru: {}, tr: {}, "zh-cn": Hr, "zh-tw": zr }[t.moment.locale()];
function Wr(t) {
    return ($r && $r[t]) || Vr[t];
}
class Ur extends t.FuzzySuggestModal {
    constructor(t, e, i = !1, n, o) {
        super(t.app), (this.customCallback = null), (this.plugin = t), (this.command = e), (this.issub = i), (this.customCallback = n || null), this.setPlaceholder(Wr("Choose an icon")), (this.currentEditingConfig = o || "");
    }
    capitalJoin(t) {
        return t
            .split(" ")
            .map((t) => t[0].toUpperCase() + t.substring(1))
            .join(" ");
    }
    getItems() {
        return i;
    }
    getItemText(t) {
        return this.capitalJoin(
            t
                .replace("feather-", "")
                .replace("remix-", "")
                .replace("bx-", "")
                .replace(/([A-Z])/g, " $1")
                .trim()
                .replace(/-/gi, " ")
        );
    }
    renderSuggestion(e, i) {
        const n = createSpan({ cls: "editingToolbarIconPick" });
        i.appendChild(n), t.setIcon(n, e.item), super.renderSuggestion(e, i);
    }
    onChooseItem(t) {
        return e(this, void 0, void 0, function* () {
            if ("Custom" === t)
                return this.customCallback
                    ? void new jr(this.app, this.plugin, { id: this.command.id, name: this.command.name, icon: "" }, this.issub, (t) => {
                        this.customCallback(t);
                    }).open()
                    : void new jr(this.app, this.plugin, this.command, this.issub, null, this.currentEditingConfig).open();
            if (this.customCallback) return void this.customCallback(t);
            const e = this.plugin.getCurrentCommands(this.currentEditingConfig);
            if (this.command.icon) {
                let i = Dr(this.plugin, this.command, this.issub, e);
                this.issub ? (e[i.index].SubmenuCommands[i.subindex].icon = t) : (e[i.index].icon = t), this.plugin.updateCurrentCommands(e);
            } else (this.command.icon = t), e.push(this.command), this.plugin.updateCurrentCommands(e);
            yield this.plugin.saveSettings(),
                setTimeout(() => {
                    dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100);
        });
    }
}
class jr extends t.Modal {
    constructor(t, e, i, n, o, s) {
        super(t),
            (this.customCallback = null),
            (this.plugin = e),
            (this.item = i),
            (this.issub = n),
            (this.customCallback = o || null),
            (this.currentEditingConfig = s || ""),
            this.containerEl.addClass("editingToolbar-Modal"),
            this.containerEl.addClass("customicon");
    }
    onOpen() {
        const { contentEl: t } = this;
        t.createEl("b", { text: Wr("Enter the icon code, format as <svg>.... </svg>") });
        const i = document.createElement("textarea");
        (i.className = "wideInputPromptInputEl"),
            (i.placeholder = ""),
            (i.value = this.item.icon || ""),
            (i.style.width = "100%"),
            (i.style.height = "200px"),
            t.appendChild(i),
            i.addEventListener("input", () =>
                e(this, void 0, void 0, function* () {
                    const t = i.value;
                    if (this.customCallback) return void (this.item.icon = t);
                    this.item.icon = t;
                    const e = this.plugin.getCurrentCommands(this.currentEditingConfig),
                        n = Dr(this.plugin, this.item, this.issub, e);
                    if (this.issub) {
                        let e = n.subindex;
                        -1 === e ? this.plugin.settings.menuCommands[n.index].SubmenuCommands.push(this.item) : (this.plugin.settings.menuCommands[n.index].SubmenuCommands[e].icon = t);
                    } else {
                        let t = n.index;
                        -1 === t ? this.plugin.settings.menuCommands.push(this.item) : (this.plugin.settings.menuCommands[t].icon = this.item.icon);
                    }
                    yield this.plugin.saveSettings();
                })
            ),
            this.submitEnterCallback && i.addEventListener("keydown", this.submitEnterCallback);
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty(),
            this.customCallback
                ? this.customCallback(this.item.icon || "")
                : setTimeout(() => {
                    dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100);
    }
}
class Yr extends t.FuzzySuggestModal {
    constructor(t, e) {
        super(t.app), (this.plugin = t), this.app, this.setPlaceholder(Wr("Choose a command")), (this.currentEditingConfig = e || "");
    }
    getItems() {
        return app.commands.listCommands();
    }
    getItemText(t) {
        return t.name;
    }
    onChooseItem(i) {
        return e(this, void 0, void 0, function* () {
            const e = this.plugin.getCurrentCommands(this.currentEditingConfig);
            e.findIndex((t) => t.id == i.id) > -1
                ? new t.Notice(Wr("The command") + i.name + Wr("already exists"), 3e3)
                : i.icon
                    ? (e.push(i),
                        this.plugin.updateCurrentCommands(e),
                        yield this.plugin.saveSettings(),
                        setTimeout(() => {
                            dispatchEvent(new Event("editingToolbar-NewCommand"));
                        }, 100))
                    : new Ur(this.plugin, i, !1).open();
        });
    }
}
class Gr extends t.Modal {
    constructor(t, e, i, n, o) {
        super(e.app), (this.plugin = e), (this.item = i), (this.issub = n), (this.currentEditingConfig = o || ""), this.containerEl.addClass("editingToolbar-Modal"), this.containerEl.addClass("changename");
    }
    onOpen() {
        var i;
        const { contentEl: n } = this;
        n.createEl("b", { text: Wr("Please enter a new name：") });
        const o = new t.TextComponent(n);
        o.inputEl.classList.add("InputPromptInputEl"),
            o
                .setPlaceholder("")
                .setValue(null !== (i = this.item.name) && void 0 !== i ? i : "")
                .onChange(
                    t.debounce(
                        (t) =>
                            e(this, void 0, void 0, function* () {
                                const e = this.plugin.getCurrentCommands(this.currentEditingConfig);
                                let i = Dr(this.plugin, this.item, this.issub, e);
                                if (((this.item.name = t), this.issub)) {
                                    let n = i.subindex;
                                    -1 === n ? e[i.index].SubmenuCommands.push(this.item) : (e[i.index].SubmenuCommands[n].name = t);
                                } else {
                                    let t = i.index;
                                    -1 === t ? e.push(this.item) : (e[t].name = this.item.name);
                                }
                                this.plugin.updateCurrentCommands(e), yield this.plugin.saveSettings();
                            }),
                        100,
                        !0
                    )
                )
                .inputEl.addEventListener("keydown", this.submitEnterCallback);
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty(),
            setTimeout(() => {
                dispatchEvent(new Event("editingToolbar-NewCommand"));
            }, 100);
    }
}
class Zr extends t.Modal {
    constructor(t, e) {
        super(e.app), (this.needSave = !1), (this.plugin = e), this.containerEl.addClass("editingToolbar-Modal");
    }
    onOpen() {
        const { contentEl: i } = this;
        i.createEl("p", { text: Wr("Drag the slider to move the position") });
        const n = i.createDiv({ cls: "slider-container" }),
            o = n.createDiv({ cls: "vertical-slider-container" });
        o.createEl("p", { text: Wr("Vertical Position") });
        const s = n.createDiv({ cls: "horizontal-slider-container" });
        s.createEl("p", { text: Wr("Horizontal Position") });
        const r = n.createDiv({ cls: "columns-slider-container" });
        r.createEl("p", { text: Wr("Editing Toolbar columns") });
        const l = document.body.clientHeight,
            a = document.body.clientWidth,
            c = Math.floor(l / 3),
            h = -Math.floor(l),
            d = Math.floor(a / 2),
            u = -Math.floor(a / 2),
            p = new t.SliderComponent(o)
                .setLimits(h, c, 5)
                .setValue(this.plugin.settings.verticalPosition || 0)
                .onChange(
                    t.debounce(
                        (t) => {
                            (this.needSave = !0), (this.plugin.settings.verticalPosition = t), _r(this.plugin.settings);
                        },
                        100,
                        !0
                    )
                )
                .setDynamicTooltip(),
            m = new t.SliderComponent(s)
                .setLimits(u, d, 10)
                .setValue(this.plugin.settings.horizontalPosition || 0)
                .onChange(
                    t.debounce(
                        (t) => {
                            (this.needSave = !0), (this.plugin.settings.horizontalPosition = t), Fr(this.plugin.settings);
                        },
                        100,
                        !0
                    )
                )
                .setDynamicTooltip(),
            g = new t.SliderComponent(r)
                .setLimits(1, 32, 1)
                .setValue(this.plugin.settings.cMenuNumRows || 12)
                .onChange(
                    t.debounce(
                        (t) =>
                            e(this, void 0, void 0, function* () {
                                (this.needSave = !0),
                                    (this.plugin.settings.cMenuNumRows = t),
                                    yield this.plugin.saveSettings(),
                                    setTimeout(() => {
                                        dispatchEvent(new Event("editingToolbar-NewCommand"));
                                    }, 100);
                            }),
                        100,
                        !0
                    )
                )
                .setDynamicTooltip();
        n.createDiv({ cls: "reset-container" })
            .createEl("button", { text: Wr("Reset"), cls: "reset-button" })
            .addEventListener("click", () => {
                (this.needSave = !0),
                    p.setValue(0),
                    m.setValue(0),
                    g.setValue(12),
                    (this.plugin.settings.verticalPosition = 0),
                    (this.plugin.settings.horizontalPosition = 0),
                    (this.plugin.settings.cMenuNumRows = 12),
                    _r(this.plugin.settings),
                    Fr(this.plugin.settings);
            });
    }
    onClose() {
        return e(this, void 0, void 0, function* () {
            const { contentEl: t } = this;
            t.empty(), this.needSave && (yield this.plugin.saveSettings());
        });
    }
}
const Kr = ["body", "workspace"],
    Xr = ["default", "tiny", "glass", "custom"],
    Jr = ["following", "top", "fixed"],
    Qr = {
        lastVersion: "0.0.0",
        aestheticStyle: "default",
        positionStyle: "top",
        menuCommands: [
            { id: "editing-toolbar:editor-undo", name: "Undo editor", icon: "undo-glyph" },
            { id: "editing-toolbar:editor-redo", name: "Redo editor", icon: "redo-glyph" },
            { id: "editing-toolbar:toggle-format-brush", name: "Format Brush", icon: "paintbrush" },
            { id: "editing-toolbar:format-eraser", name: "Clear text formatting", icon: "eraser" },
            { id: "editing-toolbar:header2-text", name: "Header 2", icon: "header-2" },
            { id: "editing-toolbar:header3-text", name: "Header 3", icon: "header-3" },
            {
                id: "SubmenuCommands-header",
                name: "submenu",
                icon: "header-n",
                SubmenuCommands: [
                    { id: "editing-toolbar:header1-text", name: "Header 1", icon: "header-1" },
                    { id: "editing-toolbar:header4-text", name: "Header 4", icon: "header-4" },
                    { id: "editing-toolbar:header5-text", name: "Header 5", icon: "header-5" },
                    { id: "editing-toolbar:header6-text", name: "Header 6", icon: "header-6" },
                ],
            },
            { id: "editing-toolbar:toggle-bold", name: "Bold", icon: "bold-glyph" },
            { id: "editing-toolbar:toggle-italics", name: "Italics", icon: "italic-glyph" },
            { id: "editing-toolbar:toggle-strikethrough", name: "Strikethrough", icon: "strikethrough-glyph" },
            { id: "editing-toolbar:underline", name: "Underline", icon: "underline-glyph" },
            { id: "editing-toolbar:toggle-highlight", name: "==Highlight==", icon: "highlight-glyph" },
            {
                id: "SubmenuCommands-lucdf3en5",
                name: "submenu",
                icon: "edit",
                SubmenuCommands: [
                    { id: "editing-toolbar:editor-copy", name: "Copy", icon: "lucide-copy" },
                    { id: "editing-toolbar:editor-cut", name: "Cut", icon: "lucide-scissors" },
                    { id: "editing-toolbar:editor-paste", name: "Paste", icon: "lucide-clipboard-type" },
                    { id: "editing-toolbar:editor:swap-line-down", name: "Swap line down", icon: "lucide-corner-right-down" },
                    { id: "editing-toolbar:editor:swap-line-up", name: "Swap line up", icon: "lucide-corner-right-up" },
                ],
            },
            { id: "editing-toolbar:editor:attach-file", name: "Attach file", icon: "lucide-paperclip" },
            { id: "editing-toolbar:editor:insert-table", name: "Insert Table", icon: "lucide-table" },
            { id: "editing-toolbar:editor:cycle-list-checklist", name: "Cycle list checklist", icon: "check-circle" },
            {
                id: "SubmenuCommands-luc8efull",
                name: "submenu",
                icon: "message-square",
                SubmenuCommands: [
                    { id: "editing-toolbar:editor:toggle-blockquote", name: "Blockquote", icon: "lucide-text-quote" },
                    { id: "editing-toolbar:insert-callout", name: "Insert Callout ", icon: "lucide-quote" },
                ],
            },
            {
                id: "SubmenuCommands-mdcmder",
                name: "submenu",
                icon:
                    '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M464 608 l0 -568 q0 -3 -2.5 -5.5 q-2.5 -2.5 -5.5 -2.5 l-80 0 q-3 0 -5.5 2.5 q-2.5 2.5 -2.5 5.5 l0 568 l-232 0 q-3 0 -5.5 2.5 q-2.5 2.5 -2.5 5.5 l0 80 q0 3 2.5 5.5 q2.5 2.5 5.5 2.5 l560 0 q3 0 5.5 -2.5 q2.5 -2.5 2.5 -5.5 l0 -80 q0 -3 -2.5 -5.5 q-2.5 -2.5 -5.5 -2.5 l-232 0 ZM864 696 q17 0 28.5 11.5 q11.5 11.5 11.5 28.5 q0 17 -11.5 28.5 q-11.5 11.5 -28.5 11.5 q-17 0 -28.5 -11.5 q-11.5 -11.5 -11.5 -28.5 q0 -17 11.5 -28.5 q11.5 -11.5 28.5 -11.5 ZM864 640 q-40 0 -68 28 q-28 28 -28 68 q0 40 28 68 q28 28 68 28 q40 0 68 -28 q28 -28 28 -68 q0 -40 -28 -68 q-28 -28 -68 -28 ZM576 322 l0 -63 q0 -3 2 -5 l89 -70 l-89 -70 q-2 -2 -2 -5 l0 -63 q0 -4 3.5 -5.5 q3.5 -1.5 6.5 0.5 l170 133 q4 3 4.5 8.5 q0.5 5.5 -2.5 9.5 l-2 2 l-170 133 q-3 2 -6.5 0.5 q-3.5 -1.5 -3.5 -5.5 ZM256 322 l0 -63 q0 -3 -2 -5 l-89 -70 l89 -70 q2 -2 2 -5 l0 -63 q0 -4 -3.5 -5.5 q-3.5 -1.5 -6.5 0.5 l-170 133 q-4 3 -4.5 8.5 q-0.5 5.5 2.5 9.5 l2 2 l170 133 q3 2 6.5 0.5 q3.5 -1.5 3.5 -5.5 Z"></path></g></svg>',
                SubmenuCommands: [
                    { id: "editing-toolbar:superscript", name: "Superscript", icon: "superscript-glyph" },
                    { id: "editing-toolbar:subscript", name: "Subscript", icon: "subscript-glyph" },
                    { id: "editing-toolbar:editor:toggle-code", name: "Inline code", icon: "code-glyph" },
                    { id: "editing-toolbar:codeblock", name: "Code block", icon: "codeblock-glyph" },
                    {
                        id: "editing-toolbar:editor:insert-wikilink",
                        name: "Insert wikilink [[]]",
                        icon:
                            '<svg width="15" height="15" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M306 134 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 7 q0 -8 -5 -8 l-45 0 q-5 0 -5 8 l0 784 q0 8 5 8 l45 0 q5 0 5 -8 q0 8 1 8 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 -623 q0 8 1 8 ZM139 134 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 7 q0 -8 -5 -8 l-45 0 q-5 0 -5 8 l0 784 q0 8 5 8 l45 0 q5 0 5 -8 q0 8 1 8 l91 0 q1 0 1 -8 l0 -80 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 -623 q0 8 1 8 ZM711 134 q1 0 1 -8 l0 623 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 q1 0 1 -8 q0 8 4 8 l46 0 q4 0 4 -8 l0 -784 q0 -8 -4 -8 l-46 0 q-4 0 -4 8 q0 -7 -1 -7 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 ZM878 134 q1 0 1 -8 l0 623 q0 -8 -1 -8 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 q1 0 1 -8 q0 8 5 8 l45 0 q4 0 4 -8 l0 -784 q0 -8 -4 -8 l-45 0 q-5 0 -5 8 q0 -7 -1 -7 l-91 0 q-1 0 -1 8 l0 80 q0 8 1 8 l91 0 Z"></path></g></svg>',
                    },
                    { id: "editing-toolbar:editor:insert-embed", name: "Insert embed ![[]]", icon: "note-glyph" },
                    { id: "editing-toolbar:insert-link", name: "Insert link []()", icon: "link-glyph" },
                    {
                        id: "editing-toolbar:hrline",
                        name: "Horizontal divider",
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M912 424 l0 -80 q0 -3 -2.5 -5.5 q-2.5 -2.5 -5.5 -2.5 l-784 0 q-3 0 -5.5 2.5 q-2.5 2.5 -2.5 5.5 l0 80 q0 3 2.5 5.5 q2.5 2.5 5.5 2.5 l784 0 q3 0 5.5 -2.5 q2.5 -2.5 2.5 -5.5 Z"></path></g></svg>',
                    },
                    { id: "editing-toolbar:toggle-inline-math", name: "Inline math", icon: "lucide-sigma" },
                    { id: "editing-toolbar:editor:insert-mathblock", name: "MathBlock", icon: "lucide-sigma-square" },
                ],
            },
            {
                id: "SubmenuCommands-list",
                name: "submenu-list",
                icon: "bullet-list-glyph",
                SubmenuCommands: [
                    { id: "editing-toolbar:editor:toggle-checklist-status", name: "Checklist", icon: "checkbox-glyph" },
                    { id: "editing-toolbar:renumber-ordered-list", name: "Renumber ordered list", icon: "list-restart" },
                    {
                        id: "editing-toolbar:toggle-numbered-list",
                        name: "Numbered list",
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M860 424 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-457 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l457 0 ZM860 756 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-457 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l457 0 ZM860 92 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-457 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l457 0 ZM264 136 l-3 -3 l-51 -57 l56 0 q14 0 24.5 -10 q10.5 -10 11.5 -25 l0 -1 q0 -15 -10.5 -25.5 q-10.5 -10.5 -24.5 -10.5 l-137 0 q-15 0 -25 10 q-10 10 -11 24.5 q-1 14.5 9 25.5 l63 70 l49 54 q7 7 7 16.5 q0 9.5 -7.5 16.5 q-7.5 7 -18.5 7 q-11 0 -18.5 -6.5 q-7.5 -6.5 -8.5 -16.5 l0 0 q0 -15 -10.5 -25.5 q-10.5 -10.5 -25.5 -10.5 q-15 0 -25.5 10.5 q-10.5 10.5 -10.5 25.5 q0 26 13.5 47.5 q13.5 21.5 36 34.5 q22.5 13 49 13 q26.5 0 49.5 -13 q23 -13 36 -34.5 q13 -21.5 13 -47.5 q0 -20 -7.5 -37.5 q-7.5 -17.5 -21.5 -30.5 l-1 -1 ZM173 794 q11 11 25 10.5 q14 -0.5 24.5 -10.5 q10.5 -10 10.5 -25 l0 -293 q0 -15 -10 -25.5 q-10 -10.5 -25 -10.5 q-15 0 -25.5 10 q-10.5 10 -11.5 25 l0 211 q-10 -8 -23.5 -7 q-13.5 1 -22.5 11 l-1 0 q-10 11 -9.5 25.5 q0.5 14.5 10.5 24.5 l58 54 Z"></path></g></svg>',
                    },
                    {
                        id: "editing-toolbar:toggle-bullet-list",
                        name: "Bullet list",
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M860 424 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-477 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l477 0 ZM860 756 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-477 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l477 0 ZM860 92 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-477 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l477 0 ZM176 716 l0 0 ZM112 716 q0 -27 18.5 -45.5 q18.5 -18.5 45.5 -18.5 q27 0 45.5 18.5 q18.5 18.5 18.5 45.5 q0 27 -18.5 45.5 q-18.5 18.5 -45.5 18.5 q-27 0 -45.5 -18.5 q-18.5 -18.5 -18.5 -45.5 ZM176 384 l0 0 ZM112 384 q0 -27 18.5 -45.5 q18.5 -18.5 45.5 -18.5 q27 0 45.5 18.5 q18.5 18.5 18.5 45.5 q0 27 -18.5 45.5 q-18.5 18.5 -45.5 18.5 q-27 0 -45.5 -18.5 q-18.5 -18.5 -18.5 -45.5 ZM176 52 l0 0 ZM112 52 q0 -27 18.5 -45.5 q18.5 -18.5 45.5 -18.5 q27 0 45.5 18.5 q18.5 18.5 18.5 45.5 q0 27 -18.5 45.5 q-18.5 18.5 -45.5 18.5 q-27 0 -45.5 -18.5 q-18.5 -18.5 -18.5 -45.5 Z"></path></g></svg>',
                    },
                    {
                        id: "editing-toolbar:undent-list",
                        name: "Unindent-list",
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M872 302 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 542 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 784 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM872 62 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM244 534 l-123 -122 q-8 -7 -8 -18 q0 -11 8 -18 l123 -122 q8 -7 19 -7 q11 0 18.5 7.5 q7.5 7.5 7.5 18.5 l0 242 q0 11 -7.5 18.5 q-7.5 7.5 -18.5 7.5 q-11 0 -19 -7 Z"></path></g></svg>',
                    },
                    {
                        id: "editing-toolbar:indent-list",
                        name: "Indent list",
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M872 302 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 542 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-429 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l429 0 ZM872 784 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM872 62 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM158 534 l124 -122 q7 -7 7 -18 q0 -11 -7 -18 l-124 -122 q-7 -7 -18 -7 q-11 0 -19 7.5 q-8 7.5 -8 18.5 l0 242 q0 11 8 18.5 q8 7.5 19 7.5 q11 0 18 -7 Z"></path></g></svg>',
                    },
                ],
            },
            {
                id: "SubmenuCommands-aligin",
                name: "submenu-aligin",
                icon:
                    '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M724 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM724 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
                SubmenuCommands: [
                    {
                        id: "editing-toolbar:justify",
                        name: '<p aligin="justify"></p>',
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M112 736 l0 0 ZM120 736 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 ZM112 331 l0 0 ZM120 331 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 ZM112 128 l0 0 ZM120 128 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 ZM112 533 l0 0 ZM120 533 l784 0 q8 0 8 -8 l0 -80 q0 -8 -8 -8 l-784 0 q-8 0 -8 8 l0 80 q0 8 8 8 Z"></path></g></svg>',
                    },
                    {
                        id: "editing-toolbar:left",
                        name: '<p aligin="left"></p>',
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M572 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM572 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
                    },
                    {
                        id: "editing-toolbar:center",
                        name: "<center>",
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M724 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM724 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
                    },
                    {
                        id: "editing-toolbar:right",
                        name: '<p aligin="right"></p>',
                        icon:
                            '<svg width="18" height="18" focusable="false" fill="currentColor"  viewBox="0 0 1024 1024"><g transform="scale(1, -1) translate(0, -896) scale(0.9, 0.9) "><path class="path" d="M872 304 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 540 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 ZM872 776 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-421 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l421 0 ZM872 68 q17 0 28.5 -11.5 q11.5 -11.5 11.5 -28 q0 -16.5 -11.5 -28.5 q-11.5 -12 -27.5 -12 l-721 0 q-17 0 -28.5 11.5 q-11.5 11.5 -11.5 28 q0 16.5 11.5 28.5 q11.5 12 27.5 12 l721 0 Z"></path></g></svg>',
                    },
                ],
            },
            {
                id: "editing-toolbar:change-font-color",
                name: "Change font color[html]",
                icon:
                    '<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" fill="currentColor"><g fill-rule="evenodd"><path id="change-font-color-icon" d="M3 18h18v3H3z" style="fill:#2DC26B"></path><path d="M8.7 16h-.8a.5.5 0 01-.5-.6l2.7-9c.1-.3.3-.4.5-.4h2.8c.2 0 .4.1.5.4l2.7 9a.5.5 0 01-.5.6h-.8a.5.5 0 01-.4-.4l-.7-2.2c0-.3-.3-.4-.5-.4h-3.4c-.2 0-.4.1-.5.4l-.7 2.2c0 .3-.2.4-.4.4zm2.6-7.6l-.6 2a.5.5 0 00.5.6h1.6a.5.5 0 00.5-.6l-.6-2c0-.3-.3-.4-.5-.4h-.4c-.2 0-.4.1-.5.4z"></path></g></svg>',
            },
            {
                id: "editing-toolbar:change-background-color",
                name: "Change Backgroundcolor[html]",
                icon:
                    '<svg width="18" height="24" viewBox="0 0 256 256" version="1.1" xmlns="http://www.w3.org/2000/svg"><g   stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd"><g  ><g fill="currentColor"><g transform="translate(119.502295, 137.878331) rotate(-135.000000) translate(-119.502295, -137.878331) translate(48.002295, 31.757731)" ><path d="M100.946943,60.8084699 L43.7469427,60.8084699 C37.2852111,60.8084699 32.0469427,66.0467383 32.0469427,72.5084699 L32.0469427,118.70847 C32.0469427,125.170201 37.2852111,130.40847 43.7469427,130.40847 L100.946943,130.40847 C107.408674,130.40847 112.646943,125.170201 112.646943,118.70847 L112.646943,72.5084699 C112.646943,66.0467383 107.408674,60.8084699 100.946943,60.8084699 Z M93.646,79.808 L93.646,111.408 L51.046,111.408 L51.046,79.808 L93.646,79.808 Z" fill-rule="nonzero"></path><path d="M87.9366521,16.90916 L87.9194966,68.2000001 C87.9183543,69.4147389 86.9334998,70.399264 85.7187607,70.4 L56.9423078,70.4 C55.7272813,70.4 54.7423078,69.4150264 54.7423078,68.2 L54.7423078,39.4621057 C54.7423078,37.2523513 55.5736632,35.1234748 57.0711706,33.4985176 L76.4832996,12.4342613 C78.9534987,9.75382857 83.1289108,9.5834005 85.8093436,12.0535996 C87.1658473,13.303709 87.9372691,15.0644715 87.9366521,16.90916 Z" fill-rule="evenodd"></path><path d="M131.3,111.241199 L11.7,111.241199 C5.23826843,111.241199 0,116.479467 0,122.941199 L0,200.541199 C0,207.002931 5.23826843,212.241199 11.7,212.241199 L131.3,212.241199 C137.761732,212.241199 143,207.002931 143,200.541199 L143,122.941199 C143,116.479467 137.761732,111.241199 131.3,111.241199 Z M124,130.241 L124,193.241 L19,193.241 L19,130.241 L124,130.241 Z" fill-rule="nonzero"></path></g></g><path d="M51,218 L205,218 C211.075132,218 216,222.924868 216,229 C216,235.075132 211.075132,240 205,240 L51,240 C44.9248678,240 40,235.075132 40,229 C40,222.924868 44.9248678,218 51,218 Z" id="change-background-color-icon" style="fill:#FA541C"></path></g></g></svg>',
            },
            { id: "editing-toolbar:fullscreen-focus", name: "Fullscreen focus mode", icon: "fullscreen" },
            { id: "editing-toolbar:workplace-fullscreen-focus", name: "Workplace-Fullscreen ", icon: "exit-fullscreen" },
        ],
        followingCommands: [],
        topCommands: [],
        fixedCommands: [],
        mobileCommands: [],
        enableMultipleConfig: !1,
        appendMethod: "workspace",
        shouldShowMenuOnSelect: !1,
        cMenuVisibility: !0,
        cMenuBottomValue: 4.25,
        cMenuNumRows: 12,
        cMenuWidth: 610,
        cMenuFontColor: "#2DC26B",
        cMenuBackgroundColor: "#d3f8b6",
        autohide: !1,
        Iscentered: !1,
        custom_bg1: "#FFB78B8C",
        custom_bg2: "#CDF4698C",
        custom_bg3: "#A0CCF68C",
        custom_bg4: "#F0A7D88C",
        custom_bg5: "#ADEFEF8C",
        custom_fc1: "#D83931",
        custom_fc2: "#DE7802",
        custom_fc3: "#245BDB",
        custom_fc4: "#6425D0",
        custom_fc5: "#646A73",
        isLoadOnMobile: !1,
        horizontalPosition: 0,
        verticalPosition: 0,
        formatBrushes: {},
        customCommands: [],
        viewTypeSettings: {},
        toolbarBackgroundColor: "rgba(var(--background-secondary-rgb), 0.7)",
        toolbarIconColor: "var(--text-normal)",
        toolbarIconSize: 18,
    };
class tl {
    static isAllowedViewType(t, e) {
        var i, n, o, s;
        if (!t) return !1;
        const r = t.getViewType(),
            l = null === (o = null === (n = null === (i = window.app) || void 0 === i ? void 0 : i.plugins) || void 0 === n ? void 0 : n.plugins) || void 0 === o ? void 0 : o["editing-toolbar"];
        return (null === (s = null == l ? void 0 : l.settings) || void 0 === s ? void 0 : s.viewTypeSettings) && void 0 !== l.settings.viewTypeSettings[r]
            ? l.settings.viewTypeSettings[r]
            : (e || ["markdown", "canvas", "thino_view", "meld-encrypted-view"]).includes(r);
    }
    static isSourceMode(t) {
        var e;
        return !!t && "source" === (null === (e = t.getMode) || void 0 === e ? void 0 : e.call(t));
    }
}
let el;
const il = { markdown: ".markdown-source-view", thino_view: ".markdown-source-view", canvas: ".canvas-wrapper", excalidraw: ".view-header", image: ".image-container", pdf: ".view-content", meld_encrypted_view: ".markdown-source-view" };
function nl() {
    el = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
    const e = el.getElementById("editingToolbarModalBar");
    e && e.remove();
    const i = (function () {
        const e = [];
        e.push(app.workspace.rootSplit);
        const i = app.workspace.floatingSplit;
        return (
            null == i ||
            i.children.forEach((i) => {
                i instanceof t.WorkspaceWindow && e.push(i);
            }),
            e
        );
    })();
    i &&
        i.forEach((t) => {
            (null == t ? void 0 : t.containerEl) &&
                ((t) => {
                    let e = t.querySelectorAll("#editingToolbarModalBar"),
                        i = t.querySelectorAll("#editingToolbarPopoverBar");
                    e.forEach((t) => {
                        t && (t.firstChild && t.removeChild(t.firstChild), t.remove());
                    }),
                        i.forEach((t) => {
                            t && (t.firstChild && t.removeChild(t.firstChild), t.remove());
                        });
                })(null == t ? void 0 : t.containerEl);
        });
}
function ol(e, i) {
    var n, o;
    return (
        (el = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document),
        ("top" == i.positionStyle
            ? null === (o = null === (n = e.workspace.activeLeaf) || void 0 === n ? void 0 : n.view.containerEl) || void 0 === o
                ? void 0
                : o.querySelector("#editingToolbarModalBar")
            : el.getElementById("editingToolbarModalBar")) || null
    );
}
const sl = (t, e) => e.reduce((t, e) => (t && "undefined" !== t[e] ? t[e] : void 0), t);
function rl(t, e) {
    return t && void 0 !== t[1][0] ? e + t.flat(2).join("+").replace("Mod", "Ctrl") + e : e + "–" + e;
}
function ll(t, e, i = !0) {
    let n = t.commands.findCommand(e),
        o = i ? "*" : "";
    if (n) {
        let e = n.hotkeys ? [[sl(n.hotkeys, [0, "modifiers"])], [sl(n.hotkeys, [0, "key"])]] : void 0,
            i = t.hotkeyManager.customKeys[n.id];
        var s = i ? [[sl(i, [0, "modifiers"])], [sl(i, [0, "key"])]] : void 0;
        return s ? rl(s, o) : rl(e, "");
    }
    return "–";
}
function al(t) {
    return /<[^>]+>/g.test(t);
}
function cl(e, i, n) {
    el = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
    const o = i.commandsManager.getActiveEditor();
    let s = ol(e, i),
        r = null == s ? void 0 : s.querySelector("#" + n);
    if (r) {
        let t = r.rows,
            e = t.length;
        for (let s = 1; s < e; s++) {
            let e = t[s].cells;
            for (let t = 0; t < e.length; t++)
                e[t].onclick = function () {
                    let t = this.style.backgroundColor;
                    "" != t &&
                        ((t = hl(t)),
                            "x-color-picker-table" == n
                                ? ((i.settings.cMenuFontColor = t),
                                    Or(t, o),
                                    el.querySelectorAll("#change-font-color-icon").forEach((e) => {
                                        e.style.fill = t;
                                    }))
                                : "x-backgroundcolor-picker-table" == n &&
                                ((i.settings.cMenuBackgroundColor = t),
                                    Br(t, o),
                                    el.querySelectorAll("#change-background-color-icon").forEach((e) => {
                                        e.style.fill = t;
                                    })),
                            i.saveSettings());
                };
        }
    }
}
const hl = function (t) {
    let e = t;
    if (/^(rgb|RGB)/.test(e)) {
        let t = e.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(","),
            i = "#";
        for (let e = 0; e < t.length; e++) {
            let n = Number(t[e]).toString(16);
            "0" === n && (n += n), 1 == n.length && (n = "0" + n), (i += n);
        }
        return 7 !== i.length && (i = e), i;
    }
    if (!/^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(e)) return e;
    {
        let t = e.replace(/#/, "").split("");
        if (6 === t.length) return e;
        if (3 === t.length) {
            let e = "#";
            for (let i = 0; i < t.length; i += 1) e += t[i] + t[i];
            return e;
        }
    }
};
function dl(t) {
    t.quiteAllFormatBrushes();
}
function ul(t, e) {
    let i = e.getSelection();
    if (i && "" !== i.trim())
        if (i.match(/^>\s*\[\![\w\s]*\]/m)) {
            let t = i.split("\n"),
                n = [],
                o = !1,
                s = 0,
                r = !1;
            for (let e = 0; e < t.length; e++) {
                let i = t[e],
                    l = i.match(/^(>+)\s*\[\!([\w\s]*)\]\s*(.*?)$/);
                if (!l || r)
                    if (o) {
                        let t = i.match(/^(>+)\s*/);
                        if (t && t[1].length >= s) {
                            let t = i.replace(new RegExp(`^>{${s}}\\s*`), "");
                            n.push(t);
                        } else (o = !1), n.push(i);
                    } else n.push(i);
                else (s = l[1].length), (r = !0), l[3].trim() && n.push(l[3].trim()), (o = !0);
            }
            e.replaceSelection(n.join("\n"));
        } else
            (i = i.replace(/(^#+\s|^#(?=\s)|^\>|^\- \[( |x)\]|^\+ |\<[^\<\>]+?\>|^1\. |^\s*\- |^\-+$|^\*+$)/gm, "")),
                (i = i.replace(/^[ ]+|[ ]+$/gm, "")),
                (i = i.replace(/\!?\[\[([^\[\]\|]*\|)*([^\(\)\[\]]+)\]\]/g, "$2")),
                (i = i.replace(/\!?\[+([^\[\]\(\)]+)\]+\(([^\(\)]+)\)/g, "$1")),
                (i = i.replace(/`([^`]+)`/g, "$1")),
                (i = i.replace(/_([^_]+)_/g, "$1")),
                (i = i.replace(/==([^=]+)==/g, "$1")),
                (i = i.replace(/\*\*\*([^\*]+)\*\*\*/g, "$1")),
                (i = i.replace(/\*\*?([^\*]+)\*\*?/g, "$1")),
                (i = i.replace(/~~([^~]+)~~/g, "$1")),
                e.replaceSelection(i);
}
function pl(e, i, n, o, s = !1) {
    let r = ol(e, n);
    const l = e.workspace.getActiveViewOfType(t.ItemView);
    if (!tl.isAllowedViewType(l)) return void (r && (r.style.visibility = "hidden"));
    if ("following" !== n.positionStyle) return;
    const a = "markdown" === (null == l ? void 0 : l.getViewType());
    let c = 30;
    if (((c = "tiny" === n.settings.aestheticStyle ? 30 : i + 14), a))
        if (tl.isSourceMode(l)) {
            if (r) {
                const t = s || o.somethingSelected();
                (r.style.visibility = t ? "visible" : "hidden"),
                    "visible" === r.style.visibility &&
                    ((r.style.height = c + "px"),
                        r.addClass("editingToolbarFlex"),
                        r.removeClass("editingToolbarGrid"),
                        (function (t, e) {
                            var i, n, o, s;
                            const r = e.containerEl.getBoundingClientRect(),
                                l = t.offsetWidth,
                                a = t.offsetHeight,
                                c = window.innerWidth,
                                h = e.getCursor("from");
                            e.getCursor("to");
                            const d = e.coordsAtPos(h),
                                u =
                                    (null !== (n = null === (i = el.getElementsByClassName("mod-left-split")[0]) || void 0 === i ? void 0 : i.clientWidth) && void 0 !== n ? n : 0) +
                                    (null !== (s = null === (o = el.getElementsByClassName("side-dock-ribbon mod-left")[0]) || void 0 === o ? void 0 : o.clientWidth) && void 0 !== s ? s : 0);
                            let p = d.left - u - 28;
                            p + l > c - u && (p = c - u - l - 12), (p = Math.max(0, p));
                            let m = (function (t, e, i, n) {
                                const o = t.getCursor("from"),
                                    s = t.getCursor("to"),
                                    r = t.coordsAtPos(s),
                                    l = o.line === s.line;
                                let a = e.top - n - 10;
                                if (l) a <= i.top && (a = r.bottom + 10);
                                else if (t.getCursor("head").ch == t.getCursor("from").ch) (a = e.top - n - 10), a <= i.top && (a = i.top + 2 * n);
                                else {
                                    const e = ((t) => {
                                        var e, i, n;
                                        let o,
                                            s = t.getCursor("head");
                                        if ((t.getCursor("head").ch !== t.getCursor("from").ch && (s.ch = Math.max(0, s.ch - 1)), t.cursorCoords)) o = t.cursorCoords(!0, "window");
                                        else {
                                            if (!t.coordsAtPos) return;
                                            {
                                                const r = t.posToOffset(s);
                                                o = null !== (n = null === (i = (e = t.cm).coordsAtPos) || void 0 === i ? void 0 : i.call(e, r)) && void 0 !== n ? n : t.coordsAtPos(r);
                                            }
                                        }
                                        return o;
                                    })(t);
                                    (a = e.bottom + 10), a >= i.bottom - n && (a = i.bottom - 2 * n);
                                }
                                return a;
                            })(e, d, r, a);
                            (m = Math.max(0, m)), (t.style.left = `${p}px`), (t.style.top = `${m}px`);
                        })(r, o));
            }
        } else r && (r.style.visibility = "hidden");
    else r && ((r.style.visibility = "visible"), (r.style.height = c + "px"), r.addClass("editingToolbarFlex"), r.removeClass("editingToolbarGrid"));
}
function ml(e, i) {
    let n = i.settings;
    el = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
    const o = { default: "editingToolbarDefaultAesthetic", tiny: "editingToolbarTinyAesthetic", glass: "editingToolbarGlassAesthetic", custom: "editingToolbarCustomAesthetic" };
    !(function () {
        function s(t, e) {
            Object.values(o).forEach((e) => {
                t.removeClass(e);
            });
            const i = o[e] || o.default;
            t.addClass(i);
        }
        if (!i.isLoadMobile()) return;
        const r = e.workspace.getActiveViewOfType(t.ItemView);
        tl.isAllowedViewType(r) &&
            (ol(e, i) ||
                ((() => {
                    var o, r;
                    let l = 0,
                        a = 0,
                        c = 26;
                    i.toolbarIconSize && (c = i.toolbarIconSize + 8);
                    let h = createEl("div");
                    if (h)
                        if ("top" == i.positionStyle) (h.className += " top"), n.autohide && (h.className += " autohide"), n.Iscentered && (h.className += " centered");
                        else if ("following" == i.positionStyle) h.style.visibility = "hidden";
                        else if ("fixed" == i.positionStyle) {
                            let t = n.toolbarIconSize || 18;
                            h.setAttribute(
                                "style",
                                `left: calc(50% - calc(${n.cMenuNumRows * (t + 10)}px / 2));\n       bottom: 4.25em; \n       grid-template-columns: repeat(${n.cMenuNumRows}, ${t + 10}px);\n       gap: ${(t - 18) / 4}px`
                            );
                        }
                    h.setAttribute("id", "editingToolbarModalBar");
                    let d = createEl("div");
                    if (
                        (d.addClass("editingToolbarpopover"),
                            d.addClass("editingToolbarTinyAesthetic"),
                            d.setAttribute("id", "editingToolbarPopoverBar"),
                            (d.style.visibility = "hidden"),
                            (d.style.height = "0"),
                            s(h, n.aestheticStyle),
                            s(d, n.aestheticStyle),
                            "top" == i.positionStyle)
                    ) {
                        let t = e.workspace.activeLeaf.view.containerEl,
                            i = null;
                        const n = e.workspace.activeLeaf.view.getViewType(),
                            o = il[n];
                        if ((o && (i = null == t ? void 0 : t.querySelector(o)), !i)) {
                            const e = null == t ? void 0 : t.querySelector(".view-content");
                            if (e) {
                                const t = e.querySelectorAll(":scope > div");
                                i = t.length > 0 ? t[0] : e;
                            }
                        }
                        if (!i) return;
                        (null == t ? void 0 : t.querySelector("#editingToolbarPopoverBar")) || ("excalidraw" == n ? i.insertAdjacentElement("afterend", d) : i.insertAdjacentElement("afterbegin", d)),
                            "excalidraw" == n ? i.insertAdjacentElement("afterend", h) : i.insertAdjacentElement("afterbegin", h),
                            (a = null == i ? void 0 : i.offsetWidth);
                    } else "body" == n.appendMethod ? el.body.appendChild(h) : "workspace" == n.appendMethod && (null === (o = el.body) || void 0 === o || o.querySelector(".mod-vertical.mod-root").insertAdjacentElement("afterbegin", h));
                    let u = null === (r = e.workspace.activeLeaf.view.containerEl) || void 0 === r ? void 0 : r.querySelector("#editingToolbarPopoverBar");
                    i.getCurrentCommands().forEach((o, s) => {
                        let r;
                        if ("SubmenuCommands" in o) {
                            let d;
                            l >= a - 4 * c && a > 100 ? (i.setIS_MORE_Button(!0), (d = new t.ButtonComponent(u))) : (d = new t.ButtonComponent(h)),
                                d.setClass("editingToolbarCommandsubItem" + s),
                                s >= n.cMenuNumRows ? d.setClass("editingToolbarSecond") : "top" != i.positionStyle && d.buttonEl.setAttribute("aria-label-position", "top"),
                                al(o.icon) ? (d.buttonEl.innerHTML = o.icon) : d.setIcon(o.icon),
                                (l += c + 2);
                            let p = (function (t) {
                                let e = createEl("div");
                                return e.addClass("subitem"), e;
                            })();
                            p &&
                                o.SubmenuCommands.forEach((o) => {
                                    let l = ll(e, o.id);
                                    r = "–" == l ? o.name : o.name + "(" + l + ")";
                                    let a = new t.ButtonComponent(p)
                                        .setTooltip(r)
                                        .setClass("menu-item")
                                        .onClick(() => {
                                            e.commands.executeCommandById(o.id);
                                            const t = i.commandsManager.getActiveEditor(),
                                                s = t && t.somethingSelected();
                                            0 == n.cMenuVisibility ? (h.style.visibility = "hidden") : "following" == i.positionStyle ? s || (h.style.visibility = "hidden") : (h.style.visibility = "visible");
                                        });
                                    s < n.cMenuNumRows && "top" != i.positionStyle && a.buttonEl.setAttribute("aria-label-position", "top"),
                                        "editingToolbar-Divider-Line" == o.id && a.setClass("editingToolbar-Divider-Line"),
                                        al(o.icon) ? (a.buttonEl.innerHTML = o.icon) : a.setIcon(o.icon),
                                        d.buttonEl.insertAdjacentElement("afterbegin", p);
                                });
                        } else if ("editing-toolbar:change-font-color" == o.id) {
                            let s = new t.ButtonComponent(h);
                            s
                                .setClass("editingToolbarCommandsubItem-font-color")
                                .setTooltip(Wr("Font Colors"))
                                .onClick(() => {
                                    e.commands.executeCommandById(o.id);
                                    const t = i.commandsManager.getActiveEditor(),
                                        s = t && t.somethingSelected();
                                    0 == n.cMenuVisibility ? (h.style.visibility = "hidden") : "following" == i.positionStyle ? s || (h.style.visibility = "hidden") : (h.style.visibility = "visible");
                                }),
                                al(o.icon) ? (s.buttonEl.innerHTML = o.icon) : s.setIcon(o.icon),
                                (l += c);
                            let r = createEl("div");
                            if ((r.addClass("subitem"), r)) {
                                (r.innerHTML = (function (t) {
                                    return `<div class='x-color-picker-wrapper'>\n<div class='x-color-picker' >\n  <table class="x-color-picker-table" id='x-color-picker-table'>\n    <tbody>\n      <tr>\n        <th colspan="10" class="ui-widget-content">Theme Colors</th>\n      </tr>\n      <tr>\n        <td style="background-color:#ffffff"><span></span></td>\n        <td style="background-color:#000000"><span></span></td>\n        <td style="background-color:#eeece1"><span></span></td>\n        <td style="background-color:#1f497d"><span></span></td>\n        <td style="background-color:#4f81bd"><span></span></td>\n        <td style="background-color:#c0504d"><span></span></td>\n        <td style="background-color:#9bbb59"><span></span></td>\n        <td style="background-color:#8064a2"><span></span></td>\n        <td style="background-color:#4bacc6"><span></span></td>\n        <td style="background-color:#f79646"><span></span></td>\n      </tr>\n      <tr>\n        <th colspan="10"></th>\n      </tr>\n      <tr class="top">\n        <td style="background-color:#f2f2f2"><span></span></td>\n        <td style="background-color:#7f7f7f"><span></span></td>\n        <td style="background-color:#ddd9c3"><span></span></td>\n        <td style="background-color:#c6d9f0"><span></span></td>\n        <td style="background-color:#dbe5f1"><span></span></td>\n        <td style="background-color:#f2dcdb"><span></span></td>\n        <td style="background-color:#ebf1dd"><span></span></td>\n        <td style="background-color:#e5e0ec"><span></span></td>\n        <td style="background-color:#dbeef3"><span></span></td>\n        <td style="background-color:#fdeada"><span></span></td>\n      </tr>\n      <tr class="in">\n        <td style="background-color:#d8d8d8"><span></span></td>\n        <td style="background-color:#595959"><span></span></td>\n        <td style="background-color:#c4bd97"><span></span></td>\n        <td style="background-color:#8db3e2"><span></span></td>\n        <td style="background-color:#b8cce4"><span></span></td>\n        <td style="background-color:#e5b9b7"><span></span></td>\n        <td style="background-color:#d7e3bc"><span></span></td>\n        <td style="background-color:#ccc1d9"><span></span></td>\n        <td style="background-color:#b7dde8"><span></span></td>\n        <td style="background-color:#fbd5b5"><span></span></td>\n      </tr>\n      <tr class="in">\n        <td style="background-color:#bfbfbf"><span></span></td>\n        <td style="background-color:#3f3f3f"><span></span></td>\n        <td style="background-color:#938953"><span></span></td>\n        <td style="background-color:#548dd4"><span></span></td>\n        <td style="background-color:#95b3d7"><span></span></td>\n        <td style="background-color:#d99694"><span></span></td>\n        <td style="background-color:#c3d69b"><span></span></td>\n        <td style="background-color:#b2a2c7"><span></span></td>\n        <td style="background-color:#92cddc"><span></span></td>\n        <td style="background-color:#fac08f"><span></span></td>\n      </tr>\n      <tr class="in">\n        <td style="background-color:#a5a5a5"><span></span></td>\n        <td style="background-color:#262626"><span></span></td>\n        <td style="background-color:#494429"><span></span></td>\n        <td style="background-color:#17365d"><span></span></td>\n        <td style="background-color:#366092"><span></span></td>\n        <td style="background-color:#953734"><span></span></td>\n        <td style="background-color:#76923c"><span></span></td>\n        <td style="background-color:#5f497a"><span></span></td>\n        <td style="background-color:#31859b"><span></span></td>\n        <td style="background-color:#e36c09"><span></span></td>\n      </tr>\n      <tr class="bottom">\n        <td style="background-color:#7f7f7f"><span></span></td>\n        <td style="background-color:#0c0c0c"><span></span></td>\n        <td style="background-color:#1d1b10"><span></span></td>\n        <td style="background-color:#0f243e"><span></span></td>\n        <td style="background-color:#244061"><span></span></td>\n        <td style="background-color:#632423"><span></span></td>\n        <td style="background-color:#4f6128"><span></span></td>\n        <td style="background-color:#3f3151"><span></span></td>\n        <td style="background-color:#205867"><span></span></td>\n        <td style="background-color:#974806"><span></span></td>\n      </tr>\n       <tr>\n        <th colspan="10"></th>\n      </tr>\n      <tr>\n        <th colspan="10" class="ui-widget-content">Standard Colors</th>\n      </tr>\n      <tr>\n        <td style="background-color:#c00000"><span></span></td>\n        <td style="background-color:#ff0000"><span></span></td>\n        <td style="background-color:#ffc000"><span></span></td>\n        <td style="background-color:#ffff00"><span></span></td>\n        <td style="background-color:#92d050"><span></span></td>\n        <td style="background-color:#00b050"><span></span></td>\n        <td style="background-color:#00b0f0"><span></span></td>\n        <td style="background-color:#0070c0"><span></span></td>\n        <td style="background-color:#002060"><span></span></td>\n        <td style="background-color:#7030a0"><span></span></td>\n      </tr>\n      <tr>\n      <th colspan="10" class="ui-widget-content">Custom Font Colors</th>\n    </tr>\n    <tr>\n      <td style="background-color:${t.settings.custom_fc1}"><span></span></td>\n      <td style="background-color:${t.settings.custom_fc2}"><span></span></td>\n      <td style="background-color:${t.settings.custom_fc3}"><span></span></td>\n      <td style="background-color:${t.settings.custom_fc4}"><span></span></td>\n      <td style="background-color:${t.settings.custom_fc5}"><span></span></td>\n    </tr>\n    </tbody>\n  </table>\n</div>\n</div>`;
                                })(i)),
                                    s.buttonEl.insertAdjacentElement("afterbegin", r),
                                    cl(e, i, "x-color-picker-table");
                                let n = r.querySelector(".x-color-picker-wrapper");
                                new t.ButtonComponent(n)
                                    .setIcon("paintbrush")
                                    .setTooltip(Wr("Format Brush"))
                                    .onClick(() => {
                                        dl(i), i.setEN_FontColor_Format_Brush(!0), (i.Temp_Notice = new t.Notice(Wr("Font-Color formatting brush ON!"), 0));
                                    }),
                                    new t.ButtonComponent(n)
                                        .setIcon("palette")
                                        .setTooltip(Wr("Custom Font Color"))
                                        .onClick(() => {
                                            e.setting.open(),
                                                e.setting.openTabById("editing-toolbar"),
                                                setTimeout(() => {
                                                    const t = e.setting.activeTab.containerEl.querySelector(".editing-toolbar-tabs");
                                                    if (t) {
                                                        const i = t.children[1];
                                                        null == i || i.click(),
                                                            setTimeout(() => {
                                                                var t;
                                                                let i = e.setting.activeTab.containerEl.querySelector(".custom_font");
                                                                i && (null === (t = i.addClass) || void 0 === t || t.call(i, "toolbar-cta"));
                                                            }, 100);
                                                    }
                                                }, 200);
                                        });
                            }
                        } else if ("editing-toolbar:change-background-color" == o.id) {
                            let s = new t.ButtonComponent(h);
                            s
                                .setClass("editingToolbarCommandsubItem-font-color")
                                .setTooltip(Wr("Background color"))
                                .onClick(() => {
                                    e.commands.executeCommandById(o.id);
                                    const t = i.commandsManager.getActiveEditor(),
                                        s = t && t.somethingSelected();
                                    0 == n.cMenuVisibility ? (h.style.visibility = "hidden") : "following" == i.positionStyle ? s || (h.style.visibility = "hidden") : (h.style.visibility = "visible");
                                }),
                                al(o.icon) ? (s.buttonEl.innerHTML = o.icon) : s.setIcon(o.icon),
                                (l += c);
                            let r = createEl("div");
                            if ((r.addClass("subitem"), r)) {
                                (r.innerHTML = (function (t) {
                                    return `<div class='x-color-picker-wrapper'>\n<div class='x-color-picker' >\n  <table class="x-color-picker-table" id='x-backgroundcolor-picker-table'>\n    <tbody>\n      <tr>\n        <th colspan="5" class="ui-widget-content">Translucent Colors</th>\n      </tr>\n      <tr class="top">\n        <td style="background-color:rgba(140, 140, 140, 0.12)"><span></span></td>\n        <td style="background-color:rgba(92, 92, 92, 0.2)"><span></span></td>\n        <td style="background-color:rgba(163, 67, 31, 0.2)"><span></span></td>\n        <td style="background-color:rgba(240, 107, 5, 0.2)"><span></span></td>\n        <td style="background-color:rgba(240, 200, 0, 0.2)"><span></span></td>\n        </tr>\n        <tr class="bottom">\n        <td style="background-color:rgba(3, 135, 102, 0.2)"><span></span></td>\n        <td style="background-color:rgba(3, 135, 102, 0.2)"><span></span></td>\n        <td style="background-color:rgba(5, 117, 197, 0.2)"><span></span></td>\n        <td style="background-color:rgba(74, 82, 199, 0.2)"><span></span></td>\n        <td style="background-color:rgba(136, 49, 204, 0.2)"><span></span></td>\n      </tr>\n\n      <tr>\n      <th colspan="5" class="ui-widget-content">Highlighter Colors</th>\n    </tr>\n    \n    <tr class="top">\n      <td style="background-color:rgb(255, 248, 143)"><span></span></td>\n      <td style="background-color:rgb(211, 248, 182)"><span></span></td>\n      <td style="background-color:rgb(175, 250, 209)"><span></span></td>\n      <td style="background-color:rgb(177, 255, 255)"><span></span></td>\n      <td style="background-color:rgb(253, 191, 255)"><span></span></td>\n      </tr>\n      <tr class="bottom">\n      <td style="background-color:rgb(210, 203, 255);"><span></span></td>\n      <td style="background-color:rgb(64, 169, 255);"><span></span></td>\n      <td style="background-color:rgb(255, 77, 79);"><span></span></td>\n      <td style="background-color:rgb(212, 177, 6);"><span></span></td>\n      <td style="background-color:rgb(146, 84, 222);"><span></span></td>\n    </tr>\n    <tr>\n    <th colspan="5" class="ui-widget-content">Custom Colors</th>\n  </tr>\n    <tr class="bottom">\n    <td style="background-color: ${t.settings.custom_bg1};"><span></span></td>\n    <td style="background-color:${t.settings.custom_bg2};"><span></span></td>\n    <td style="background-color:${t.settings.custom_bg3};"><span></span></td>\n    <td style="background-color:${t.settings.custom_bg4};"><span></span></td>\n    <td style="background-color:${t.settings.custom_bg5};"><span></span></td>\n  </tr>\n    </tbody>\n  </table>\n</div>\n</div>`;
                                })(i)),
                                    s.buttonEl.insertAdjacentElement("afterbegin", r),
                                    cl(e, i, "x-backgroundcolor-picker-table");
                                let n = r.querySelector(".x-color-picker-wrapper");
                                new t.ButtonComponent(n)
                                    .setIcon("paintbrush")
                                    .setTooltip(Wr("Format Brush"))
                                    .onClick(() => {
                                        dl(i), i.setEN_BG_Format_Brush(!0), (i.Temp_Notice = new t.Notice(Wr("Font-Color formatting brush ON!"), 0));
                                    }),
                                    new t.ButtonComponent(n)
                                        .setIcon("palette")
                                        .setTooltip(Wr("Custom Backgroud Color"))
                                        .onClick(() => {
                                            e.setting.open(),
                                                e.setting.openTabById("editing-toolbar"),
                                                setTimeout(() => {
                                                    const t = e.setting.activeTab.containerEl.querySelector(".editing-toolbar-tabs");
                                                    if (t) {
                                                        const i = t.children[1];
                                                        null == i || i.click(),
                                                            setTimeout(() => {
                                                                var t;
                                                                let i = e.setting.activeTab.containerEl.querySelector(".custom_bg");
                                                                i && (null === (t = i.addClass) || void 0 === t || t.call(i, "toolbar-cta"));
                                                            }, 100);
                                                    }
                                                }, 200);
                                        });
                            }
                        } else {
                            let d;
                            l >= a - 4 * c && a > 100 ? (i.setIS_MORE_Button(!0), (d = new t.ButtonComponent(u))) : (d = new t.ButtonComponent(h));
                            let p = ll(e, o.id);
                            (r = "–" == p ? o.name : o.name + "(" + p + ")"),
                                d.setTooltip(r).onClick(() => {
                                    e.commands.executeCommandById(o.id);
                                    const t = i.commandsManager.getActiveEditor(),
                                        s = t && t.somethingSelected();
                                    0 == n.cMenuVisibility ? (h.style.visibility = "hidden") : "following" == i.positionStyle ? s || (h.style.visibility = "hidden") : (h.style.visibility = "visible");
                                }),
                                d.setClass("editingToolbarCommandItem"),
                                s >= n.cMenuNumRows ? d.setClass("editingToolbarSecond") : "top" != i.positionStyle && d.buttonEl.setAttribute("aria-label-position", "top"),
                                "editingToolbar-Divider-Line" == o.id && d.setClass("editingToolbar-Divider-Line"),
                                al(o.icon) ? (d.buttonEl.innerHTML = o.icon) : d.setIcon(o.icon),
                                (l += c);
                        }
                    }),
                        (function (e, i, n) {
                            const o = e.workspace.getActiveViewOfType(t.ItemView);
                            if (!tl.isAllowedViewType(o)) return;
                            let s = o.containerEl.querySelector("#editingToolbarPopoverBar");
                            if (!i.IS_MORE_Button) return;
                            let r = n.createEl("span");
                            r.addClass("more-menu");
                            let l = new t.ButtonComponent(r);
                            l
                                .setClass("editingToolbarCommandItem")
                                .setTooltip(Wr("More"))
                                .onClick(() => {
                                    "hidden" == s.style.visibility ? ((s.style.visibility = "visible"), (s.style.height = "32px")) : ((s.style.visibility = "hidden"), (s.style.height = "0"));
                                }),
                                (l.buttonEl.innerHTML =
                                    '<svg  width="14" height="14"  version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" enable-background="new 0 0 1024 1024" xml:space="preserve"><path fill="#666" d="M510.29 14.13 q17.09 -15.07 40.2 -14.07 q23.12 1 39.2 18.08 l334.66 385.92 q25.12 30.15 34.16 66.83 q9.04 36.68 0.5 73.87 q-8.54 37.19 -32.66 67.34 l-335.67 390.94 q-15.07 18.09 -38.69 20.1 q-23.62 2.01 -41.71 -13.07 q-18.08 -15.08 -20.09 -38.19 q-2.01 -23.12 13.06 -41.21 l334.66 -390.94 q11.06 -13.06 11.56 -29.65 q0.5 -16.58 -10.55 -29.64 l-334.67 -386.92 q-15.07 -17.09 -13.56 -40.7 q1.51 -23.62 19.59 -38.7 ZM81.17 14.13 q17.08 -15.07 40.19 -14.07 q23.11 1 39.2 18.08 l334.66 385.92 q25.12 30.15 34.16 66.83 q9.04 36.68 0.5 73.87 q-8.54 37.19 -32.66 67.34 l-335.67 390.94 q-15.07 18.09 -38.69 20.6 q-23.61 2.51 -41.7 -12.57 q-18.09 -15.08 -20.1 -38.69 q-2.01 -23.62 13.06 -41.71 l334.66 -390.94 q11.06 -13.06 11.56 -29.65 q0.5 -16.58 -10.55 -29.64 l-334.66 -386.92 q-15.08 -17.09 -13.57 -40.7 q1.51 -23.62 19.6 -38.7 Z"/></svg>'),
                                i.setIS_MORE_Button(!1);
                        })(e, i, h),
                        Math.abs(i.settings.cMenuWidth - Number(l)) > l + 4 &&
                        ((i.settings.cMenuWidth = Number(l)),
                            setTimeout(() => {
                                i.saveSettings();
                            }, 100));
                })(),
                    Fr(i.settings),
                    _r(i.settings),
                    (function (e, i) {
                        el = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
                        let n = el.querySelectorAll("#change-font-color-icon");
                        n &&
                            n.forEach((t) => {
                                t.style.fill = e;
                            });
                        let o = el.querySelectorAll("#change-background-color-icon");
                        o &&
                            o.forEach((t) => {
                                t.style.fill = i;
                            });
                    })(
                    /**!
                     * Sortable 1.15.6
                     * @author	RubaXa   <trash@rubaxa.org>
                     * @author	owenm    <owen23355@gmail.com>
                     * @license MIT
                     */ n.cMenuFontColor,
                        n.cMenuBackgroundColor
                    )));
    })();
}
function gl(t, e) {
    var i = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        e &&
            (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            i.push.apply(i, n);
    }
    return i;
}
function fl(t) {
    for (var e = 1; e < arguments.length; e++) {
        var i = null != arguments[e] ? arguments[e] : {};
        e % 2
            ? gl(Object(i), !0).forEach(function (e) {
                vl(t, e, i[e]);
            })
            : Object.getOwnPropertyDescriptors
                ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i))
                : gl(Object(i)).forEach(function (e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e));
                });
    }
    return t;
}
function bl(t) {
    return (
        (bl =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (t) {
                    return typeof t;
                }
                : function (t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
                }),
        bl(t)
    );
}
function vl(t, e, i) {
    return e in t ? Object.defineProperty(t, e, { value: i, enumerable: !0, configurable: !0, writable: !0 }) : (t[e] = i), t;
}
function yl() {
    return (
        (yl =
            Object.assign ||
            function (t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i = arguments[e];
                    for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (t[n] = i[n]);
                }
                return t;
            }),
        yl.apply(this, arguments)
    );
}
function wl(t, e) {
    if (null == t) return {};
    var i,
        n,
        o = (function (t, e) {
            if (null == t) return {};
            var i,
                n,
                o = {},
                s = Object.keys(t);
            for (n = 0; n < s.length; n++) (i = s[n]), e.indexOf(i) >= 0 || (o[i] = t[i]);
            return o;
        })(t, e);
    if (Object.getOwnPropertySymbols) {
        var s = Object.getOwnPropertySymbols(t);
        for (n = 0; n < s.length; n++) (i = s[n]), e.indexOf(i) >= 0 || (Object.prototype.propertyIsEnumerable.call(t, i) && (o[i] = t[i]));
    }
    return o;
}
function xl(t) {
    if ("undefined" != typeof window && window.navigator) return !!navigator.userAgent.match(t);
}
var Cl = xl(/(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i),
    kl = xl(/Edge/i),
    Sl = xl(/firefox/i),
    Tl = xl(/safari/i) && !xl(/chrome/i) && !xl(/android/i),
    El = xl(/iP(ad|od|hone)/i),
    Ml = xl(/chrome/i) && xl(/android/i),
    Al = { capture: !1, passive: !1 };
function Dl(t, e, i) {
    t.addEventListener(e, i, !Cl && Al);
}
function Il(t, e, i) {
    t.removeEventListener(e, i, !Cl && Al);
}
function Ol(t, e) {
    if (e) {
        if ((">" === e[0] && (e = e.substring(1)), t))
            try {
                if (t.matches) return t.matches(e);
                if (t.msMatchesSelector) return t.msMatchesSelector(e);
                if (t.webkitMatchesSelector) return t.webkitMatchesSelector(e);
            } catch (t) {
                return !1;
            }
        return !1;
    }
}
function Bl(t) {
    return t.host && t !== document && t.host.nodeType ? t.host : t.parentNode;
}
function ql(t, e, i, n) {
    if (t) {
        i = i || document;
        do {
            if ((null != e && (">" === e[0] ? t.parentNode === i && Ol(t, e) : Ol(t, e))) || (n && t === i)) return t;
            if (t === i) break;
        } while ((t = Bl(t)));
    }
    return null;
}
var Nl,
    Ll = /\s+/g;
function Rl(t, e, i) {
    if (t && e)
        if (t.classList) t.classList[i ? "add" : "remove"](e);
        else {
            var n = (" " + t.className + " ").replace(Ll, " ").replace(" " + e + " ", " ");
            t.className = (n + (i ? " " + e : "")).replace(Ll, " ");
        }
}
function Pl(t, e, i) {
    var n = t && t.style;
    if (n) {
        if (void 0 === i) return document.defaultView && document.defaultView.getComputedStyle ? (i = document.defaultView.getComputedStyle(t, "")) : t.currentStyle && (i = t.currentStyle), void 0 === e ? i : i[e];
        e in n || -1 !== e.indexOf("webkit") || (e = "-webkit-" + e), (n[e] = i + ("string" == typeof i ? "" : "px"));
    }
}
function _l(t, e) {
    var i = "";
    if ("string" == typeof t) i = t;
    else
        do {
            var n = Pl(t, "transform");
            n && "none" !== n && (i = n + " " + i);
        } while (!e && (t = t.parentNode));
    var o = window.DOMMatrix || window.WebKitCSSMatrix || window.CSSMatrix || window.MSCSSMatrix;
    return o && new o(i);
}
function Fl(t, e, i) {
    if (t) {
        var n = t.getElementsByTagName(e),
            o = 0,
            s = n.length;
        if (i) for (; o < s; o++) i(n[o], o);
        return n;
    }
    return [];
}
function Vl() {
    return document.scrollingElement || document.documentElement;
}
function Hl(t, e, i, n, o) {
    if (t.getBoundingClientRect || t === window) {
        var s, r, l, a, c, h, d;
        if (
            (t !== window && t.parentNode && t !== Vl()
                ? ((r = (s = t.getBoundingClientRect()).top), (l = s.left), (a = s.bottom), (c = s.right), (h = s.height), (d = s.width))
                : ((r = 0), (l = 0), (a = window.innerHeight), (c = window.innerWidth), (h = window.innerHeight), (d = window.innerWidth)),
                (e || i) && t !== window && ((o = o || t.parentNode), !Cl))
        )
            do {
                if (o && o.getBoundingClientRect && ("none" !== Pl(o, "transform") || (i && "static" !== Pl(o, "position")))) {
                    var u = o.getBoundingClientRect();
                    (r -= u.top + parseInt(Pl(o, "border-top-width"))), (l -= u.left + parseInt(Pl(o, "border-left-width"))), (a = r + s.height), (c = l + s.width);
                    break;
                }
            } while ((o = o.parentNode));
        if (n && t !== window) {
            var p = _l(o || t),
                m = p && p.a,
                g = p && p.d;
            p && ((a = (r /= g) + (h /= g)), (c = (l /= m) + (d /= m)));
        }
        return { top: r, left: l, bottom: a, right: c, width: d, height: h };
    }
}
function zl(t, e, i) {
    for (var n = Yl(t, !0), o = Hl(t)[e]; n;) {
        var s = Hl(n)[i];
        if (!("top" === i || "left" === i ? o >= s : o <= s)) return n;
        if (n === Vl()) break;
        n = Yl(n, !1);
    }
    return !1;
}
function $l(t, e, i, n) {
    for (var o = 0, s = 0, r = t.children; s < r.length;) {
        if ("none" !== r[s].style.display && r[s] !== Xa.ghost && (n || r[s] !== Xa.dragged) && ql(r[s], i.draggable, t, !1)) {
            if (o === e) return r[s];
            o++;
        }
        s++;
    }
    return null;
}
function Wl(t, e) {
    for (var i = t.lastElementChild; i && (i === Xa.ghost || "none" === Pl(i, "display") || (e && !Ol(i, e)));) i = i.previousElementSibling;
    return i || null;
}
function Ul(t, e) {
    var i = 0;
    if (!t || !t.parentNode) return -1;
    for (; (t = t.previousElementSibling);) "TEMPLATE" === t.nodeName.toUpperCase() || t === Xa.clone || (e && !Ol(t, e)) || i++;
    return i;
}
function jl(t) {
    var e = 0,
        i = 0,
        n = Vl();
    if (t)
        do {
            var o = _l(t),
                s = o.a,
                r = o.d;
            (e += t.scrollLeft * s), (i += t.scrollTop * r);
        } while (t !== n && (t = t.parentNode));
    return [e, i];
}
function Yl(t, e) {
    if (!t || !t.getBoundingClientRect) return Vl();
    var i = t,
        n = !1;
    do {
        if (i.clientWidth < i.scrollWidth || i.clientHeight < i.scrollHeight) {
            var o = Pl(i);
            if ((i.clientWidth < i.scrollWidth && ("auto" == o.overflowX || "scroll" == o.overflowX)) || (i.clientHeight < i.scrollHeight && ("auto" == o.overflowY || "scroll" == o.overflowY))) {
                if (!i.getBoundingClientRect || i === document.body) return Vl();
                if (n || e) return i;
                n = !0;
            }
        }
    } while ((i = i.parentNode));
    return Vl();
}
function Gl(t, e) {
    return Math.round(t.top) === Math.round(e.top) && Math.round(t.left) === Math.round(e.left) && Math.round(t.height) === Math.round(e.height) && Math.round(t.width) === Math.round(e.width);
}
function Zl(t, e) {
    return function () {
        if (!Nl) {
            var i = arguments;
            1 === i.length ? t.call(this, i[0]) : t.apply(this, i),
                (Nl = setTimeout(function () {
                    Nl = void 0;
                }, e));
        }
    };
}
function Kl(t, e, i) {
    (t.scrollLeft += e), (t.scrollTop += i);
}
function Xl(t) {
    var e = window.Polymer,
        i = window.jQuery || window.Zepto;
    return e && e.dom ? e.dom(t).cloneNode(!0) : i ? i(t).clone(!0)[0] : t.cloneNode(!0);
}
function Jl(t, e, i) {
    var n = {};
    return (
        Array.from(t.children).forEach(function (o) {
            var s, r, l, a;
            if (ql(o, e.draggable, t, !1) && !o.animated && o !== i) {
                var c = Hl(o);
                (n.left = Math.min(null !== (s = n.left) && void 0 !== s ? s : 1 / 0, c.left)),
                    (n.top = Math.min(null !== (r = n.top) && void 0 !== r ? r : 1 / 0, c.top)),
                    (n.right = Math.max(null !== (l = n.right) && void 0 !== l ? l : -1 / 0, c.right)),
                    (n.bottom = Math.max(null !== (a = n.bottom) && void 0 !== a ? a : -1 / 0, c.bottom));
            }
        }),
        (n.width = n.right - n.left),
        (n.height = n.bottom - n.top),
        (n.x = n.left),
        (n.y = n.top),
        n
    );
}
var Ql = "Sortable" + new Date().getTime();
function ta() {
    var t,
        e = [];
    return {
        captureAnimationState: function () {
            (e = []),
                this.options.animation &&
                [].slice.call(this.el.children).forEach(function (t) {
                    if ("none" !== Pl(t, "display") && t !== Xa.ghost) {
                        e.push({ target: t, rect: Hl(t) });
                        var i = fl({}, e[e.length - 1].rect);
                        if (t.thisAnimationDuration) {
                            var n = _l(t, !0);
                            n && ((i.top -= n.f), (i.left -= n.e));
                        }
                        t.fromRect = i;
                    }
                });
        },
        addAnimationState: function (t) {
            e.push(t);
        },
        removeAnimationState: function (t) {
            e.splice(
                (function (t, e) {
                    for (var i in t) if (t.hasOwnProperty(i)) for (var n in e) if (e.hasOwnProperty(n) && e[n] === t[i][n]) return Number(i);
                    return -1;
                })(e, { target: t }),
                1
            );
        },
        animateAll: function (i) {
            var n = this;
            if (!this.options.animation) return clearTimeout(t), void ("function" == typeof i && i());
            var o = !1,
                s = 0;
            e.forEach(function (t) {
                var e = 0,
                    i = t.target,
                    r = i.fromRect,
                    l = Hl(i),
                    a = i.prevFromRect,
                    c = i.prevToRect,
                    h = t.rect,
                    d = _l(i, !0);
                d && ((l.top -= d.f), (l.left -= d.e)),
                    (i.toRect = l),
                    i.thisAnimationDuration &&
                    Gl(a, l) &&
                    !Gl(r, l) &&
                    (h.top - l.top) / (h.left - l.left) == (r.top - l.top) / (r.left - l.left) &&
                    (e = (function (t, e, i, n) {
                        return (Math.sqrt(Math.pow(e.top - t.top, 2) + Math.pow(e.left - t.left, 2)) / Math.sqrt(Math.pow(e.top - i.top, 2) + Math.pow(e.left - i.left, 2))) * n.animation;
                    })(h, a, c, n.options)),
                    Gl(l, r) || ((i.prevFromRect = r), (i.prevToRect = l), e || (e = n.options.animation), n.animate(i, h, l, e)),
                    e &&
                    ((o = !0),
                        (s = Math.max(s, e)),
                        clearTimeout(i.animationResetTimer),
                        (i.animationResetTimer = setTimeout(function () {
                            (i.animationTime = 0), (i.prevFromRect = null), (i.fromRect = null), (i.prevToRect = null), (i.thisAnimationDuration = null);
                        }, e)),
                        (i.thisAnimationDuration = e));
            }),
                clearTimeout(t),
                o
                    ? (t = setTimeout(function () {
                        "function" == typeof i && i();
                    }, s))
                    : "function" == typeof i && i(),
                (e = []);
        },
        animate: function (t, e, i, n) {
            if (n) {
                Pl(t, "transition", ""), Pl(t, "transform", "");
                var o = _l(this.el),
                    s = o && o.a,
                    r = o && o.d,
                    l = (e.left - i.left) / (s || 1),
                    a = (e.top - i.top) / (r || 1);
                (t.animatingX = !!l),
                    (t.animatingY = !!a),
                    Pl(t, "transform", "translate3d(" + l + "px," + a + "px,0)"),
                    (this.forRepaintDummy = (function (t) {
                        return t.offsetWidth;
                    })(t)),
                    Pl(t, "transition", "transform " + n + "ms" + (this.options.easing ? " " + this.options.easing : "")),
                    Pl(t, "transform", "translate3d(0,0,0)"),
                    "number" == typeof t.animated && clearTimeout(t.animated),
                    (t.animated = setTimeout(function () {
                        Pl(t, "transition", ""), Pl(t, "transform", ""), (t.animated = !1), (t.animatingX = !1), (t.animatingY = !1);
                    }, n));
            }
        },
    };
}
var ea = [],
    ia = { initializeByDefault: !0 },
    na = {
        mount: function (t) {
            for (var e in ia) ia.hasOwnProperty(e) && !(e in t) && (t[e] = ia[e]);
            ea.forEach(function (e) {
                if (e.pluginName === t.pluginName) throw "Sortable: Cannot mount plugin ".concat(t.pluginName, " more than once");
            }),
                ea.push(t);
        },
        pluginEvent: function (t, e, i) {
            var n = this;
            (this.eventCanceled = !1),
                (i.cancel = function () {
                    n.eventCanceled = !0;
                });
            var o = t + "Global";
            ea.forEach(function (n) {
                e[n.pluginName] && (e[n.pluginName][o] && e[n.pluginName][o](fl({ sortable: e }, i)), e.options[n.pluginName] && e[n.pluginName][t] && e[n.pluginName][t](fl({ sortable: e }, i)));
            });
        },
        initializePlugins: function (t, e, i, n) {
            for (var o in (ea.forEach(function (n) {
                var o = n.pluginName;
                if (t.options[o] || n.initializeByDefault) {
                    var s = new n(t, e, t.options);
                    (s.sortable = t), (s.options = t.options), (t[o] = s), yl(i, s.defaults);
                }
            }),
                t.options))
                if (t.options.hasOwnProperty(o)) {
                    var s = this.modifyOption(t, o, t.options[o]);
                    void 0 !== s && (t.options[o] = s);
                }
        },
        getEventProperties: function (t, e) {
            var i = {};
            return (
                ea.forEach(function (n) {
                    "function" == typeof n.eventProperties && yl(i, n.eventProperties.call(e[n.pluginName], t));
                }),
                i
            );
        },
        modifyOption: function (t, e, i) {
            var n;
            return (
                ea.forEach(function (o) {
                    t[o.pluginName] && o.optionListeners && "function" == typeof o.optionListeners[e] && (n = o.optionListeners[e].call(t[o.pluginName], i));
                }),
                n
            );
        },
    },
    oa = ["evt"],
    sa = function (t, e) {
        var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            n = i.evt,
            o = wl(i, oa);
        na.pluginEvent.bind(Xa)(
            t,
            e,
            fl(
                {
                    dragEl: la,
                    parentEl: aa,
                    ghostEl: ca,
                    rootEl: ha,
                    nextEl: da,
                    lastDownEl: ua,
                    cloneEl: pa,
                    cloneHidden: ma,
                    dragStarted: Ma,
                    putSortable: wa,
                    activeSortable: Xa.active,
                    originalEvent: n,
                    oldIndex: ga,
                    oldDraggableIndex: ba,
                    newIndex: fa,
                    newDraggableIndex: va,
                    hideGhostForTarget: Ya,
                    unhideGhostForTarget: Ga,
                    cloneNowHidden: function () {
                        ma = !0;
                    },
                    cloneNowShown: function () {
                        ma = !1;
                    },
                    dispatchSortableEvent: function (t) {
                        ra({ sortable: e, name: t, originalEvent: n });
                    },
                },
                o
            )
        );
    };
function ra(t) {
    !(function (t) {
        var e = t.sortable,
            i = t.rootEl,
            n = t.name,
            o = t.targetEl,
            s = t.cloneEl,
            r = t.toEl,
            l = t.fromEl,
            a = t.oldIndex,
            c = t.newIndex,
            h = t.oldDraggableIndex,
            d = t.newDraggableIndex,
            u = t.originalEvent,
            p = t.putSortable,
            m = t.extraEventProperties;
        if ((e = e || (i && i[Ql]))) {
            var g,
                f = e.options,
                b = "on" + n.charAt(0).toUpperCase() + n.substr(1);
            !window.CustomEvent || Cl || kl ? (g = document.createEvent("Event")).initEvent(n, !0, !0) : (g = new CustomEvent(n, { bubbles: !0, cancelable: !0 })),
                (g.to = r || i),
                (g.from = l || i),
                (g.item = o || i),
                (g.clone = s),
                (g.oldIndex = a),
                (g.newIndex = c),
                (g.oldDraggableIndex = h),
                (g.newDraggableIndex = d),
                (g.originalEvent = u),
                (g.pullMode = p ? p.lastPutMode : void 0);
            var v = fl(fl({}, m), na.getEventProperties(n, e));
            for (var y in v) g[y] = v[y];
            i && i.dispatchEvent(g), f[b] && f[b].call(e, g);
        }
    })(fl({ putSortable: wa, cloneEl: pa, targetEl: la, rootEl: ha, oldIndex: ga, oldDraggableIndex: ba, newIndex: fa, newDraggableIndex: va }, t));
}
var la,
    aa,
    ca,
    ha,
    da,
    ua,
    pa,
    ma,
    ga,
    fa,
    ba,
    va,
    ya,
    wa,
    xa,
    Ca,
    ka,
    Sa,
    Ta,
    Ea,
    Ma,
    Aa,
    Da,
    Ia,
    Oa,
    Ba = !1,
    qa = !1,
    Na = [],
    La = !1,
    Ra = !1,
    Pa = [],
    _a = !1,
    Fa = [],
    Va = "undefined" != typeof document,
    Ha = El,
    za = kl || Cl ? "cssFloat" : "float",
    $a = Va && !Ml && !El && "draggable" in document.createElement("div"),
    Wa = (function () {
        if (Va) {
            if (Cl) return !1;
            var t = document.createElement("x");
            return (t.style.cssText = "pointer-events:auto"), "auto" === t.style.pointerEvents;
        }
    })(),
    Ua = function (t, e) {
        var i = Pl(t),
            n = parseInt(i.width) - parseInt(i.paddingLeft) - parseInt(i.paddingRight) - parseInt(i.borderLeftWidth) - parseInt(i.borderRightWidth),
            o = $l(t, 0, e),
            s = $l(t, 1, e),
            r = o && Pl(o),
            l = s && Pl(s),
            a = r && parseInt(r.marginLeft) + parseInt(r.marginRight) + Hl(o).width,
            c = l && parseInt(l.marginLeft) + parseInt(l.marginRight) + Hl(s).width;
        if ("flex" === i.display) return "column" === i.flexDirection || "column-reverse" === i.flexDirection ? "vertical" : "horizontal";
        if ("grid" === i.display) return i.gridTemplateColumns.split(" ").length <= 1 ? "vertical" : "horizontal";
        if (o && r.float && "none" !== r.float) {
            var h = "left" === r.float ? "left" : "right";
            return !s || ("both" !== l.clear && l.clear !== h) ? "horizontal" : "vertical";
        }
        return o && ("block" === r.display || "flex" === r.display || "table" === r.display || "grid" === r.display || (a >= n && "none" === i[za]) || (s && "none" === i[za] && a + c > n)) ? "vertical" : "horizontal";
    },
    ja = function (t) {
        function e(t, i) {
            return function (n, o, s, r) {
                var l = n.options.group.name && o.options.group.name && n.options.group.name === o.options.group.name;
                if (null == t && (i || l)) return !0;
                if (null == t || !1 === t) return !1;
                if (i && "clone" === t) return t;
                if ("function" == typeof t) return e(t(n, o, s, r), i)(n, o, s, r);
                var a = (i ? n : o).options.group.name;
                return !0 === t || ("string" == typeof t && t === a) || (t.join && t.indexOf(a) > -1);
            };
        }
        var i = {},
            n = t.group;
        (n && "object" == bl(n)) || (n = { name: n }), (i.name = n.name), (i.checkPull = e(n.pull, !0)), (i.checkPut = e(n.put)), (i.revertClone = n.revertClone), (t.group = i);
    },
    Ya = function () {
        !Wa && ca && Pl(ca, "display", "none");
    },
    Ga = function () {
        !Wa && ca && Pl(ca, "display", "");
    };
Va &&
    !Ml &&
    document.addEventListener(
        "click",
        function (t) {
            if (qa) return t.preventDefault(), t.stopPropagation && t.stopPropagation(), t.stopImmediatePropagation && t.stopImmediatePropagation(), (qa = !1), !1;
        },
        !0
    );
var Za = function (t) {
    if (la) {
        t = t.touches ? t.touches[0] : t;
        var e =
            ((o = t.clientX),
                (s = t.clientY),
                Na.some(function (t) {
                    var e = t[Ql].options.emptyInsertThreshold;
                    if (e && !Wl(t)) {
                        var i = Hl(t),
                            n = o >= i.left - e && o <= i.right + e,
                            l = s >= i.top - e && s <= i.bottom + e;
                        return n && l ? (r = t) : void 0;
                    }
                }),
                r);
        if (e) {
            var i = {};
            for (var n in t) t.hasOwnProperty(n) && (i[n] = t[n]);
            (i.target = i.rootEl = e), (i.preventDefault = void 0), (i.stopPropagation = void 0), e[Ql]._onDragOver(i);
        }
    }
    var o, s, r;
},
    Ka = function (t) {
        la && la.parentNode[Ql]._isOutsideThisEl(t.target);
    };
function Xa(t, e) {
    if (!t || !t.nodeType || 1 !== t.nodeType) throw "Sortable: `el` must be an HTMLElement, not ".concat({}.toString.call(t));
    (this.el = t), (this.options = e = yl({}, e)), (t[Ql] = this);
    var i = {
        group: null,
        sort: !0,
        disabled: !1,
        store: null,
        handle: null,
        draggable: /^[uo]l$/i.test(t.nodeName) ? ">li" : ">*",
        swapThreshold: 1,
        invertSwap: !1,
        invertedSwapThreshold: null,
        removeCloneOnHide: !0,
        direction: function () {
            return Ua(t, this.options);
        },
        ghostClass: "sortable-ghost",
        chosenClass: "sortable-chosen",
        dragClass: "sortable-drag",
        ignore: "a, img",
        filter: null,
        preventOnFilter: !0,
        animation: 0,
        easing: null,
        setData: function (t, e) {
            t.setData("Text", e.textContent);
        },
        dropBubble: !1,
        dragoverBubble: !1,
        dataIdAttr: "data-id",
        delay: 0,
        delayOnTouchOnly: !1,
        touchStartThreshold: (Number.parseInt ? Number : window).parseInt(window.devicePixelRatio, 10) || 1,
        forceFallback: !1,
        fallbackClass: "sortable-fallback",
        fallbackOnBody: !1,
        fallbackTolerance: 0,
        fallbackOffset: { x: 0, y: 0 },
        supportPointer: !1 !== Xa.supportPointer && "PointerEvent" in window && (!Tl || El),
        emptyInsertThreshold: 5,
    };
    for (var n in (na.initializePlugins(this, t, i), i)) !(n in e) && (e[n] = i[n]);
    for (var o in (ja(e), this)) "_" === o.charAt(0) && "function" == typeof this[o] && (this[o] = this[o].bind(this));
    (this.nativeDraggable = !e.forceFallback && $a),
        this.nativeDraggable && (this.options.touchStartThreshold = 1),
        e.supportPointer ? Dl(t, "pointerdown", this._onTapStart) : (Dl(t, "mousedown", this._onTapStart), Dl(t, "touchstart", this._onTapStart)),
        this.nativeDraggable && (Dl(t, "dragover", this), Dl(t, "dragenter", this)),
        Na.push(this.el),
        e.store && e.store.get && this.sort(e.store.get(this) || []),
        yl(this, ta());
}
function Ja(t, e, i, n, o, s, r, l) {
    var a,
        c,
        h = t[Ql],
        d = h.options.onMove;
    return (
        !window.CustomEvent || Cl || kl ? (a = document.createEvent("Event")).initEvent("move", !0, !0) : (a = new CustomEvent("move", { bubbles: !0, cancelable: !0 })),
        (a.to = e),
        (a.from = t),
        (a.dragged = i),
        (a.draggedRect = n),
        (a.related = o || e),
        (a.relatedRect = s || Hl(e)),
        (a.willInsertAfter = l),
        (a.originalEvent = r),
        t.dispatchEvent(a),
        d && (c = d.call(h, a, r)),
        c
    );
}
function Qa(t) {
    t.draggable = !1;
}
function tc() {
    _a = !1;
}
function ec(t) {
    for (var e = t.tagName + t.className + t.src + t.href + t.textContent, i = e.length, n = 0; i--;) n += e.charCodeAt(i);
    return n.toString(36);
}
function ic(t) {
    return setTimeout(t, 0);
}
function nc(t) {
    return clearTimeout(t);
}
(Xa.prototype = {
    constructor: Xa,
    _isOutsideThisEl: function (t) {
        this.el.contains(t) || t === this.el || (Aa = null);
    },
    _getDirection: function (t, e) {
        return "function" == typeof this.options.direction ? this.options.direction.call(this, t, e, la) : this.options.direction;
    },
    _onTapStart: function (t) {
        if (t.cancelable) {
            var e = this,
                i = this.el,
                n = this.options,
                o = n.preventOnFilter,
                s = t.type,
                r = (t.touches && t.touches[0]) || (t.pointerType && "touch" === t.pointerType && t),
                l = (r || t).target,
                a = (t.target.shadowRoot && ((t.path && t.path[0]) || (t.composedPath && t.composedPath()[0]))) || l,
                c = n.filter;
            if (
                ((function (t) {
                    Fa.length = 0;
                    for (var e = t.getElementsByTagName("input"), i = e.length; i--;) {
                        var n = e[i];
                        n.checked && Fa.push(n);
                    }
                })(i),
                    !la &&
                    !((/mousedown|pointerdown/.test(s) && 0 !== t.button) || n.disabled) &&
                    !a.isContentEditable &&
                    (this.nativeDraggable || !Tl || !l || "SELECT" !== l.tagName.toUpperCase()) &&
                    !(((l = ql(l, n.draggable, i, !1)) && l.animated) || ua === l))
            ) {
                if (((ga = Ul(l)), (ba = Ul(l, n.draggable)), "function" == typeof c)) {
                    if (c.call(this, t, l, this)) return ra({ sortable: e, rootEl: a, name: "filter", targetEl: l, toEl: i, fromEl: i }), sa("filter", e, { evt: t }), void (o && t.preventDefault());
                } else if (
                    c &&
                    (c = c.split(",").some(function (n) {
                        if ((n = ql(a, n.trim(), i, !1))) return ra({ sortable: e, rootEl: n, name: "filter", targetEl: l, fromEl: i, toEl: i }), sa("filter", e, { evt: t }), !0;
                    }))
                )
                    return void (o && t.preventDefault());
                (n.handle && !ql(a, n.handle, i, !1)) || this._prepareDragStart(t, r, l);
            }
        }
    },
    _prepareDragStart: function (t, e, i) {
        var n,
            o = this,
            s = o.el,
            r = o.options,
            l = s.ownerDocument;
        if (i && !la && i.parentNode === s) {
            var a = Hl(i);
            if (
                ((ha = s),
                    (aa = (la = i).parentNode),
                    (da = la.nextSibling),
                    (ua = i),
                    (ya = r.group),
                    (Xa.dragged = la),
                    (xa = { target: la, clientX: (e || t).clientX, clientY: (e || t).clientY }),
                    (Ta = xa.clientX - a.left),
                    (Ea = xa.clientY - a.top),
                    (this._lastX = (e || t).clientX),
                    (this._lastY = (e || t).clientY),
                    (la.style["will-change"] = "all"),
                    (n = function () {
                        sa("delayEnded", o, { evt: t }),
                            Xa.eventCanceled
                                ? o._onDrop()
                                : (o._disableDelayedDragEvents(), !Sl && o.nativeDraggable && (la.draggable = !0), o._triggerDragStart(t, e), ra({ sortable: o, name: "choose", originalEvent: t }), Rl(la, r.chosenClass, !0));
                    }),
                    r.ignore.split(",").forEach(function (t) {
                        Fl(la, t.trim(), Qa);
                    }),
                    Dl(l, "dragover", Za),
                    Dl(l, "mousemove", Za),
                    Dl(l, "touchmove", Za),
                    r.supportPointer ? (Dl(l, "pointerup", o._onDrop), !this.nativeDraggable && Dl(l, "pointercancel", o._onDrop)) : (Dl(l, "mouseup", o._onDrop), Dl(l, "touchend", o._onDrop), Dl(l, "touchcancel", o._onDrop)),
                    Sl && this.nativeDraggable && ((this.options.touchStartThreshold = 4), (la.draggable = !0)),
                    sa("delayStart", this, { evt: t }),
                    !r.delay || (r.delayOnTouchOnly && !e) || (this.nativeDraggable && (kl || Cl)))
            )
                n();
            else {
                if (Xa.eventCanceled) return void this._onDrop();
                r.supportPointer
                    ? (Dl(l, "pointerup", o._disableDelayedDrag), Dl(l, "pointercancel", o._disableDelayedDrag))
                    : (Dl(l, "mouseup", o._disableDelayedDrag), Dl(l, "touchend", o._disableDelayedDrag), Dl(l, "touchcancel", o._disableDelayedDrag)),
                    Dl(l, "mousemove", o._delayedDragTouchMoveHandler),
                    Dl(l, "touchmove", o._delayedDragTouchMoveHandler),
                    r.supportPointer && Dl(l, "pointermove", o._delayedDragTouchMoveHandler),
                    (o._dragStartTimer = setTimeout(n, r.delay));
            }
        }
    },
    _delayedDragTouchMoveHandler: function (t) {
        var e = t.touches ? t.touches[0] : t;
        Math.max(Math.abs(e.clientX - this._lastX), Math.abs(e.clientY - this._lastY)) >= Math.floor(this.options.touchStartThreshold / ((this.nativeDraggable && window.devicePixelRatio) || 1)) && this._disableDelayedDrag();
    },
    _disableDelayedDrag: function () {
        la && Qa(la), clearTimeout(this._dragStartTimer), this._disableDelayedDragEvents();
    },
    _disableDelayedDragEvents: function () {
        var t = this.el.ownerDocument;
        Il(t, "mouseup", this._disableDelayedDrag),
            Il(t, "touchend", this._disableDelayedDrag),
            Il(t, "touchcancel", this._disableDelayedDrag),
            Il(t, "pointerup", this._disableDelayedDrag),
            Il(t, "pointercancel", this._disableDelayedDrag),
            Il(t, "mousemove", this._delayedDragTouchMoveHandler),
            Il(t, "touchmove", this._delayedDragTouchMoveHandler),
            Il(t, "pointermove", this._delayedDragTouchMoveHandler);
    },
    _triggerDragStart: function (t, e) {
        (e = e || ("touch" == t.pointerType && t)),
            !this.nativeDraggable || e
                ? this.options.supportPointer
                    ? Dl(document, "pointermove", this._onTouchMove)
                    : Dl(document, e ? "touchmove" : "mousemove", this._onTouchMove)
                : (Dl(la, "dragend", this), Dl(ha, "dragstart", this._onDragStart));
        try {
            document.selection
                ? ic(function () {
                    document.selection.empty();
                })
                : window.getSelection().removeAllRanges();
        } catch (t) { }
    },
    _dragStarted: function (t, e) {
        if (((Ba = !1), ha && la)) {
            sa("dragStarted", this, { evt: e }), this.nativeDraggable && Dl(document, "dragover", Ka);
            var i = this.options;
            !t && Rl(la, i.dragClass, !1), Rl(la, i.ghostClass, !0), (Xa.active = this), t && this._appendGhost(), ra({ sortable: this, name: "start", originalEvent: e });
        } else this._nulling();
    },
    _emulateDragOver: function () {
        if (Ca) {
            (this._lastX = Ca.clientX), (this._lastY = Ca.clientY), Ya();
            for (var t = document.elementFromPoint(Ca.clientX, Ca.clientY), e = t; t && t.shadowRoot && (t = t.shadowRoot.elementFromPoint(Ca.clientX, Ca.clientY)) !== e;) e = t;
            if ((la.parentNode[Ql]._isOutsideThisEl(t), e))
                do {
                    if (e[Ql] && e[Ql]._onDragOver({ clientX: Ca.clientX, clientY: Ca.clientY, target: t, rootEl: e }) && !this.options.dragoverBubble) break;
                    t = e;
                } while ((e = Bl(e)));
            Ga();
        }
    },
    _onTouchMove: function (t) {
        if (xa) {
            var e = this.options,
                i = e.fallbackTolerance,
                n = e.fallbackOffset,
                o = t.touches ? t.touches[0] : t,
                s = ca && _l(ca, !0),
                r = ca && s && s.a,
                l = ca && s && s.d,
                a = Ha && Oa && jl(Oa),
                c = (o.clientX - xa.clientX + n.x) / (r || 1) + (a ? a[0] - Pa[0] : 0) / (r || 1),
                h = (o.clientY - xa.clientY + n.y) / (l || 1) + (a ? a[1] - Pa[1] : 0) / (l || 1);
            if (!Xa.active && !Ba) {
                if (i && Math.max(Math.abs(o.clientX - this._lastX), Math.abs(o.clientY - this._lastY)) < i) return;
                this._onDragStart(t, !0);
            }
            if (ca) {
                s ? ((s.e += c - (ka || 0)), (s.f += h - (Sa || 0))) : (s = { a: 1, b: 0, c: 0, d: 1, e: c, f: h });
                var d = "matrix(".concat(s.a, ",").concat(s.b, ",").concat(s.c, ",").concat(s.d, ",").concat(s.e, ",").concat(s.f, ")");
                Pl(ca, "webkitTransform", d), Pl(ca, "mozTransform", d), Pl(ca, "msTransform", d), Pl(ca, "transform", d), (ka = c), (Sa = h), (Ca = o);
            }
            t.cancelable && t.preventDefault();
        }
    },
    _appendGhost: function () {
        if (!ca) {
            var t = this.options.fallbackOnBody ? document.body : ha,
                e = Hl(la, !0, Ha, !0, t),
                i = this.options;
            if (Ha) {
                for (Oa = t; "static" === Pl(Oa, "position") && "none" === Pl(Oa, "transform") && Oa !== document;) Oa = Oa.parentNode;
                Oa !== document.body && Oa !== document.documentElement ? (Oa === document && (Oa = Vl()), (e.top += Oa.scrollTop), (e.left += Oa.scrollLeft)) : (Oa = Vl()), (Pa = jl(Oa));
            }
            Rl((ca = la.cloneNode(!0)), i.ghostClass, !1),
                Rl(ca, i.fallbackClass, !0),
                Rl(ca, i.dragClass, !0),
                Pl(ca, "transition", ""),
                Pl(ca, "transform", ""),
                Pl(ca, "box-sizing", "border-box"),
                Pl(ca, "margin", 0),
                Pl(ca, "top", e.top),
                Pl(ca, "left", e.left),
                Pl(ca, "width", e.width),
                Pl(ca, "height", e.height),
                Pl(ca, "opacity", "0.8"),
                Pl(ca, "position", Ha ? "absolute" : "fixed"),
                Pl(ca, "zIndex", "100000"),
                Pl(ca, "pointerEvents", "none"),
                (Xa.ghost = ca),
                t.appendChild(ca),
                Pl(ca, "transform-origin", (Ta / parseInt(ca.style.width)) * 100 + "% " + (Ea / parseInt(ca.style.height)) * 100 + "%");
        }
    },
    _onDragStart: function (t, e) {
        var i = this,
            n = t.dataTransfer,
            o = i.options;
        sa("dragStart", this, { evt: t }),
            Xa.eventCanceled
                ? this._onDrop()
                : (sa("setupClone", this),
                    Xa.eventCanceled || ((pa = Xl(la)).removeAttribute("id"), (pa.draggable = !1), (pa.style["will-change"] = ""), this._hideClone(), Rl(pa, this.options.chosenClass, !1), (Xa.clone = pa)),
                    (i.cloneId = ic(function () {
                        sa("clone", i), Xa.eventCanceled || (i.options.removeCloneOnHide || ha.insertBefore(pa, la), i._hideClone(), ra({ sortable: i, name: "clone" }));
                    })),
                    !e && Rl(la, o.dragClass, !0),
                    e
                        ? ((qa = !0), (i._loopId = setInterval(i._emulateDragOver, 50)))
                        : (Il(document, "mouseup", i._onDrop),
                            Il(document, "touchend", i._onDrop),
                            Il(document, "touchcancel", i._onDrop),
                            n && ((n.effectAllowed = "move"), o.setData && o.setData.call(i, n, la)),
                            Dl(document, "drop", i),
                            Pl(la, "transform", "translateZ(0)")),
                    (Ba = !0),
                    (i._dragStartId = ic(i._dragStarted.bind(i, e, t))),
                    Dl(document, "selectstart", i),
                    (Ma = !0),
                    window.getSelection().removeAllRanges(),
                    Tl && Pl(document.body, "user-select", "none"));
    },
    _onDragOver: function (t) {
        var e,
            i,
            n,
            o,
            s = this.el,
            r = t.target,
            l = this.options,
            a = l.group,
            c = Xa.active,
            h = ya === a,
            d = l.sort,
            u = wa || c,
            p = this,
            m = !1;
        if (!_a) {
            if ((void 0 !== t.preventDefault && t.cancelable && t.preventDefault(), (r = ql(r, l.draggable, s, !0)), D("dragOver"), Xa.eventCanceled)) return m;
            if (la.contains(t.target) || (r.animated && r.animatingX && r.animatingY) || p._ignoreWhileAnimating === r) return O(!1);
            if (((qa = !1), c && !l.disabled && (h ? d || (n = aa !== ha) : wa === this || ((this.lastPutMode = ya.checkPull(this, c, la, t)) && a.checkPut(this, c, la, t))))) {
                if (((o = "vertical" === this._getDirection(t, r)), (e = Hl(la)), D("dragOverValid"), Xa.eventCanceled)) return m;
                if (n) return (aa = ha), I(), this._hideClone(), D("revert"), Xa.eventCanceled || (da ? ha.insertBefore(la, da) : ha.appendChild(la)), O(!0);
                var g = Wl(s, l.draggable);
                if (
                    !g ||
                    ((function (t, e, i) {
                        var n = Hl(Wl(i.el, i.options.draggable)),
                            o = Jl(i.el, i.options, ca);
                        return e ? t.clientX > o.right + 10 || (t.clientY > n.bottom && t.clientX > n.left) : t.clientY > o.bottom + 10 || (t.clientX > n.right && t.clientY > n.top);
                    })(t, o, this) &&
                        !g.animated)
                ) {
                    if (g === la) return O(!1);
                    if ((g && s === t.target && (r = g), r && (i = Hl(r)), !1 !== Ja(ha, s, la, e, r, i, t, !!r))) return I(), g && g.nextSibling ? s.insertBefore(la, g.nextSibling) : s.appendChild(la), (aa = s), B(), O(!0);
                } else if (
                    g &&
                    (function (t, e, i) {
                        var n = Hl($l(i.el, 0, i.options, !0)),
                            o = Jl(i.el, i.options, ca);
                        return e ? t.clientX < o.left - 10 || (t.clientY < n.top && t.clientX < n.right) : t.clientY < o.top - 10 || (t.clientY < n.bottom && t.clientX < n.left);
                    })(t, o, this)
                ) {
                    var f = $l(s, 0, l, !0);
                    if (f === la) return O(!1);
                    if (((i = Hl((r = f))), !1 !== Ja(ha, s, la, e, r, i, t, !1))) return I(), s.insertBefore(la, f), (aa = s), B(), O(!0);
                } else if (r.parentNode === s) {
                    i = Hl(r);
                    var b,
                        v,
                        y,
                        w = la.parentNode !== s,
                        C = !(function (t, e, i) {
                            var n = i ? t.left : t.top,
                                o = i ? t.right : t.bottom,
                                s = i ? t.width : t.height,
                                r = i ? e.left : e.top,
                                l = i ? e.right : e.bottom,
                                a = i ? e.width : e.height;
                            return n === r || o === l || n + s / 2 === r + a / 2;
                        })((la.animated && la.toRect) || e, (r.animated && r.toRect) || i, o),
                        x = o ? "top" : "left",
                        k = zl(r, "top", "top") || zl(la, "top", "top"),
                        S = k ? k.scrollTop : void 0;
                    if (
                        (Aa !== r && ((v = i[x]), (La = !1), (Ra = (!C && l.invertSwap) || w)),
                            (b = (function (t, e, i, n, o, s, r, l) {
                                var a = n ? t.clientY : t.clientX,
                                    c = n ? i.height : i.width,
                                    h = n ? i.top : i.left,
                                    d = n ? i.bottom : i.right,
                                    u = !1;
                                if (!r)
                                    if (l && Ia < c * o) {
                                        if ((!La && (1 === Da ? a > h + (c * s) / 2 : a < d - (c * s) / 2) && (La = !0), La)) u = !0;
                                        else if (1 === Da ? a < h + Ia : a > d - Ia) return -Da;
                                    } else if (a > h + (c * (1 - o)) / 2 && a < d - (c * (1 - o)) / 2)
                                        return (function (t) {
                                            return Ul(la) < Ul(t) ? 1 : -1;
                                        })(e);
                                return (u = u || r) && (a < h + (c * s) / 2 || a > d - (c * s) / 2) ? (a > h + c / 2 ? 1 : -1) : 0;
                            })(t, r, i, o, C ? 1 : l.swapThreshold, null == l.invertedSwapThreshold ? l.swapThreshold : l.invertedSwapThreshold, Ra, Aa === r)),
                            0 !== b)
                    ) {
                        var T = Ul(la);
                        do {
                            (T -= b), (y = aa.children[T]);
                        } while (y && ("none" === Pl(y, "display") || y === ca));
                    }
                    if (0 === b || y === r) return O(!1);
                    (Aa = r), (Da = b);
                    var E = r.nextElementSibling,
                        M = !1,
                        A = Ja(ha, s, la, e, r, i, t, (M = 1 === b));
                    if (!1 !== A)
                        return (
                            (1 !== A && -1 !== A) || (M = 1 === A),
                            (_a = !0),
                            setTimeout(tc, 30),
                            I(),
                            M && !E ? s.appendChild(la) : r.parentNode.insertBefore(la, M ? E : r),
                            k && Kl(k, 0, S - k.scrollTop),
                            (aa = la.parentNode),
                            void 0 === v || Ra || (Ia = Math.abs(v - Hl(r)[x])),
                            B(),
                            O(!0)
                        );
                }
                if (s.contains(la)) return O(!1);
            }
            return !1;
        }
        function D(l, a) {
            sa(
                l,
                p,
                fl(
                    {
                        evt: t,
                        isOwner: h,
                        axis: o ? "vertical" : "horizontal",
                        revert: n,
                        dragRect: e,
                        targetRect: i,
                        canSort: d,
                        fromSortable: u,
                        target: r,
                        completed: O,
                        onMove: function (i, n) {
                            return Ja(ha, s, la, e, i, Hl(i), t, n);
                        },
                        changed: B,
                    },
                    a
                )
            );
        }
        function I() {
            D("dragOverAnimationCapture"), p.captureAnimationState(), p !== u && u.captureAnimationState();
        }
        function O(e) {
            return (
                D("dragOverCompleted", { insertion: e }),
                e &&
                (h ? c._hideClone() : c._showClone(p),
                    p !== u && (Rl(la, wa ? wa.options.ghostClass : c.options.ghostClass, !1), Rl(la, l.ghostClass, !0)),
                    wa !== p && p !== Xa.active ? (wa = p) : p === Xa.active && wa && (wa = null),
                    u === p && (p._ignoreWhileAnimating = r),
                    p.animateAll(function () {
                        D("dragOverAnimationComplete"), (p._ignoreWhileAnimating = null);
                    }),
                    p !== u && (u.animateAll(), (u._ignoreWhileAnimating = null))),
                ((r === la && !la.animated) || (r === s && !r.animated)) && (Aa = null),
                l.dragoverBubble || t.rootEl || r === document || (la.parentNode[Ql]._isOutsideThisEl(t.target), !e && Za(t)),
                !l.dragoverBubble && t.stopPropagation && t.stopPropagation(),
                (m = !0)
            );
        }
        function B() {
            (fa = Ul(la)), (va = Ul(la, l.draggable)), ra({ sortable: p, name: "change", toEl: s, newIndex: fa, newDraggableIndex: va, originalEvent: t });
        }
    },
    _ignoreWhileAnimating: null,
    _offMoveEvents: function () {
        Il(document, "mousemove", this._onTouchMove), Il(document, "touchmove", this._onTouchMove), Il(document, "pointermove", this._onTouchMove), Il(document, "dragover", Za), Il(document, "mousemove", Za), Il(document, "touchmove", Za);
    },
    _offUpEvents: function () {
        var t = this.el.ownerDocument;
        Il(t, "mouseup", this._onDrop), Il(t, "touchend", this._onDrop), Il(t, "pointerup", this._onDrop), Il(t, "pointercancel", this._onDrop), Il(t, "touchcancel", this._onDrop), Il(document, "selectstart", this);
    },
    _onDrop: function (t) {
        var e = this.el,
            i = this.options;
        (fa = Ul(la)),
            (va = Ul(la, i.draggable)),
            sa("drop", this, { evt: t }),
            (aa = la && la.parentNode),
            (fa = Ul(la)),
            (va = Ul(la, i.draggable)),
            Xa.eventCanceled ||
            ((Ba = !1),
                (Ra = !1),
                (La = !1),
                clearInterval(this._loopId),
                clearTimeout(this._dragStartTimer),
                nc(this.cloneId),
                nc(this._dragStartId),
                this.nativeDraggable && (Il(document, "drop", this), Il(e, "dragstart", this._onDragStart)),
                this._offMoveEvents(),
                this._offUpEvents(),
                Tl && Pl(document.body, "user-select", ""),
                Pl(la, "transform", ""),
                t &&
                (Ma && (t.cancelable && t.preventDefault(), !i.dropBubble && t.stopPropagation()),
                    ca && ca.parentNode && ca.parentNode.removeChild(ca),
                    (ha === aa || (wa && "clone" !== wa.lastPutMode)) && pa && pa.parentNode && pa.parentNode.removeChild(pa),
                    la &&
                    (this.nativeDraggable && Il(la, "dragend", this),
                        Qa(la),
                        (la.style["will-change"] = ""),
                        Ma && !Ba && Rl(la, wa ? wa.options.ghostClass : this.options.ghostClass, !1),
                        Rl(la, this.options.chosenClass, !1),
                        ra({ sortable: this, name: "unchoose", toEl: aa, newIndex: null, newDraggableIndex: null, originalEvent: t }),
                        ha !== aa
                            ? (fa >= 0 &&
                                (ra({ rootEl: aa, name: "add", toEl: aa, fromEl: ha, originalEvent: t }),
                                    ra({ sortable: this, name: "remove", toEl: aa, originalEvent: t }),
                                    ra({ rootEl: aa, name: "sort", toEl: aa, fromEl: ha, originalEvent: t }),
                                    ra({ sortable: this, name: "sort", toEl: aa, originalEvent: t })),
                                wa && wa.save())
                            : fa !== ga && fa >= 0 && (ra({ sortable: this, name: "update", toEl: aa, originalEvent: t }), ra({ sortable: this, name: "sort", toEl: aa, originalEvent: t })),
                        Xa.active && ((null != fa && -1 !== fa) || ((fa = ga), (va = ba)), ra({ sortable: this, name: "end", toEl: aa, originalEvent: t }), this.save())))),
            this._nulling();
    },
    _nulling: function () {
        sa("nulling", this),
            (ha = la = aa = ca = da = pa = ua = ma = xa = Ca = Ma = fa = va = ga = ba = Aa = Da = wa = ya = Xa.dragged = Xa.ghost = Xa.clone = Xa.active = null),
            Fa.forEach(function (t) {
                t.checked = !0;
            }),
            (Fa.length = ka = Sa = 0);
    },
    handleEvent: function (t) {
        switch (t.type) {
            case "drop":
            case "dragend":
                this._onDrop(t);
                break;
            case "dragenter":
            case "dragover":
                la &&
                    (this._onDragOver(t),
                        (function (t) {
                            t.dataTransfer && (t.dataTransfer.dropEffect = "move"), t.cancelable && t.preventDefault();
                        })(t));
                break;
            case "selectstart":
                t.preventDefault();
        }
    },
    toArray: function () {
        for (var t, e = [], i = this.el.children, n = 0, o = i.length, s = this.options; n < o; n++) ql((t = i[n]), s.draggable, this.el, !1) && e.push(t.getAttribute(s.dataIdAttr) || ec(t));
        return e;
    },
    sort: function (t, e) {
        var i = {},
            n = this.el;
        this.toArray().forEach(function (t, e) {
            var o = n.children[e];
            ql(o, this.options.draggable, n, !1) && (i[t] = o);
        }, this),
            e && this.captureAnimationState(),
            t.forEach(function (t) {
                i[t] && (n.removeChild(i[t]), n.appendChild(i[t]));
            }),
            e && this.animateAll();
    },
    save: function () {
        var t = this.options.store;
        t && t.set && t.set(this);
    },
    closest: function (t, e) {
        return ql(t, e || this.options.draggable, this.el, !1);
    },
    option: function (t, e) {
        var i = this.options;
        if (void 0 === e) return i[t];
        var n = na.modifyOption(this, t, e);
        (i[t] = void 0 !== n ? n : e), "group" === t && ja(i);
    },
    destroy: function () {
        sa("destroy", this);
        var t = this.el;
        (t[Ql] = null),
            Il(t, "mousedown", this._onTapStart),
            Il(t, "touchstart", this._onTapStart),
            Il(t, "pointerdown", this._onTapStart),
            this.nativeDraggable && (Il(t, "dragover", this), Il(t, "dragenter", this)),
            Array.prototype.forEach.call(t.querySelectorAll("[draggable]"), function (t) {
                t.removeAttribute("draggable");
            }),
            this._onDrop(),
            this._disableDelayedDragEvents(),
            Na.splice(Na.indexOf(this.el), 1),
            (this.el = t = null);
    },
    _hideClone: function () {
        if (!ma) {
            if ((sa("hideClone", this), Xa.eventCanceled)) return;
            Pl(pa, "display", "none"), this.options.removeCloneOnHide && pa.parentNode && pa.parentNode.removeChild(pa), (ma = !0);
        }
    },
    _showClone: function (t) {
        if ("clone" === t.lastPutMode) {
            if (ma) {
                if ((sa("showClone", this), Xa.eventCanceled)) return;
                la.parentNode != ha || this.options.group.revertClone ? (da ? ha.insertBefore(pa, da) : ha.appendChild(pa)) : ha.insertBefore(pa, la), this.options.group.revertClone && this.animate(la, pa), Pl(pa, "display", ""), (ma = !1);
            }
        } else this._hideClone();
    },
}),
    Va &&
    Dl(document, "touchmove", function (t) {
        (Xa.active || Ba) && t.cancelable && t.preventDefault();
    }),
    (Xa.utils = {
        on: Dl,
        off: Il,
        css: Pl,
        find: Fl,
        is: function (t, e) {
            return !!ql(t, e, t, !1);
        },
        extend: function (t, e) {
            if (t && e) for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
            return t;
        },
        throttle: Zl,
        closest: ql,
        toggleClass: Rl,
        clone: Xl,
        index: Ul,
        nextTick: ic,
        cancelNextTick: nc,
        detectDirection: Ua,
        getChild: $l,
        expando: Ql,
    }),
    (Xa.get = function (t) {
        return t[Ql];
    }),
    (Xa.mount = function () {
        for (var t = arguments.length, e = new Array(t), i = 0; i < t; i++) e[i] = arguments[i];
        e[0].constructor === Array && (e = e[0]),
            e.forEach(function (t) {
                if (!t.prototype || !t.prototype.constructor) throw "Sortable: Mounted plugin must be a constructor function, not ".concat({}.toString.call(t));
                t.utils && (Xa.utils = fl(fl({}, Xa.utils), t.utils)), na.mount(t);
            });
    }),
    (Xa.create = function (t, e) {
        return new Xa(t, e);
    }),
    (Xa.version = "1.15.6");
var oc,
    sc,
    rc,
    lc,
    ac,
    cc,
    hc = [],
    dc = !1;
function uc() {
    hc.forEach(function (t) {
        clearInterval(t.pid);
    }),
        (hc = []);
}
function pc() {
    clearInterval(cc);
}
var mc = Zl(function (t, e, i, n) {
    if (e.scroll) {
        var o,
            s = (t.touches ? t.touches[0] : t).clientX,
            r = (t.touches ? t.touches[0] : t).clientY,
            l = e.scrollSensitivity,
            a = e.scrollSpeed,
            c = Vl(),
            h = !1;
        sc !== i && ((sc = i), uc(), (oc = e.scroll), (o = e.scrollFn), !0 === oc && (oc = Yl(i, !0)));
        var d = 0,
            u = oc;
        do {
            var p = u,
                m = Hl(p),
                g = m.top,
                f = m.bottom,
                b = m.left,
                v = m.right,
                y = m.width,
                w = m.height,
                C = void 0,
                x = void 0,
                k = p.scrollWidth,
                S = p.scrollHeight,
                T = Pl(p),
                E = p.scrollLeft,
                M = p.scrollTop;
            p === c
                ? ((C = y < k && ("auto" === T.overflowX || "scroll" === T.overflowX || "visible" === T.overflowX)), (x = w < S && ("auto" === T.overflowY || "scroll" === T.overflowY || "visible" === T.overflowY)))
                : ((C = y < k && ("auto" === T.overflowX || "scroll" === T.overflowX)), (x = w < S && ("auto" === T.overflowY || "scroll" === T.overflowY)));
            var A = C && (Math.abs(v - s) <= l && E + y < k) - (Math.abs(b - s) <= l && !!E),
                D = x && (Math.abs(f - r) <= l && M + w < S) - (Math.abs(g - r) <= l && !!M);
            if (!hc[d]) for (var I = 0; I <= d; I++) hc[I] || (hc[I] = {});
            (hc[d].vx == A && hc[d].vy == D && hc[d].el === p) ||
                ((hc[d].el = p),
                    (hc[d].vx = A),
                    (hc[d].vy = D),
                    clearInterval(hc[d].pid),
                    (0 == A && 0 == D) ||
                    ((h = !0),
                        (hc[d].pid = setInterval(
                            function () {
                                n && 0 === this.layer && Xa.active._onTouchMove(ac);
                                var e = hc[this.layer].vy ? hc[this.layer].vy * a : 0,
                                    i = hc[this.layer].vx ? hc[this.layer].vx * a : 0;
                                ("function" == typeof o && "continue" !== o.call(Xa.dragged.parentNode[Ql], i, e, t, ac, hc[this.layer].el)) || Kl(hc[this.layer].el, i, e);
                            }.bind({ layer: d }),
                            24
                        )))),
                d++;
        } while (e.bubbleScroll && u !== c && (u = Yl(u, !1)));
        dc = h;
    }
}, 30),
    gc = function (t) {
        var e = t.originalEvent,
            i = t.putSortable,
            n = t.dragEl,
            o = t.activeSortable,
            s = t.dispatchSortableEvent,
            r = t.hideGhostForTarget,
            l = t.unhideGhostForTarget;
        if (e) {
            var a = i || o;
            r();
            var c = e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : e,
                h = document.elementFromPoint(c.clientX, c.clientY);
            l(), a && !a.el.contains(h) && (s("spill"), this.onSpill({ dragEl: n, putSortable: i }));
        }
    };
function fc() { }
function bc() { }
(fc.prototype = {
    startIndex: null,
    dragStart: function (t) {
        var e = t.oldDraggableIndex;
        this.startIndex = e;
    },
    onSpill: function (t) {
        var e = t.dragEl,
            i = t.putSortable;
        this.sortable.captureAnimationState(), i && i.captureAnimationState();
        var n = $l(this.sortable.el, this.startIndex, this.options);
        n ? this.sortable.el.insertBefore(e, n) : this.sortable.el.appendChild(e), this.sortable.animateAll(), i && i.animateAll();
    },
    drop: gc,
}),
    yl(fc, { pluginName: "revertOnSpill" }),
    (bc.prototype = {
        onSpill: function (t) {
            var e = t.dragEl,
                i = t.putSortable || this.sortable;
            i.captureAnimationState(), e.parentNode && e.parentNode.removeChild(e), i.animateAll();
        },
        drop: gc,
    }),
    yl(bc, { pluginName: "removeOnSpill" }),
    Xa.mount(
        new (function () {
            function t() {
                for (var t in ((this.defaults = { scroll: !0, forceAutoScrollFallback: !1, scrollSensitivity: 30, scrollSpeed: 10, bubbleScroll: !0 }), this))
                    "_" === t.charAt(0) && "function" == typeof this[t] && (this[t] = this[t].bind(this));
            }
            return (
                (t.prototype = {
                    dragStarted: function (t) {
                        var e = t.originalEvent;
                        this.sortable.nativeDraggable
                            ? Dl(document, "dragover", this._handleAutoScroll)
                            : this.options.supportPointer
                                ? Dl(document, "pointermove", this._handleFallbackAutoScroll)
                                : e.touches
                                    ? Dl(document, "touchmove", this._handleFallbackAutoScroll)
                                    : Dl(document, "mousemove", this._handleFallbackAutoScroll);
                    },
                    dragOverCompleted: function (t) {
                        var e = t.originalEvent;
                        this.options.dragOverBubble || e.rootEl || this._handleAutoScroll(e);
                    },
                    drop: function () {
                        this.sortable.nativeDraggable
                            ? Il(document, "dragover", this._handleAutoScroll)
                            : (Il(document, "pointermove", this._handleFallbackAutoScroll), Il(document, "touchmove", this._handleFallbackAutoScroll), Il(document, "mousemove", this._handleFallbackAutoScroll)),
                            pc(),
                            uc(),
                            clearTimeout(Nl),
                            (Nl = void 0);
                    },
                    nulling: function () {
                        (ac = sc = oc = dc = cc = rc = lc = null), (hc.length = 0);
                    },
                    _handleFallbackAutoScroll: function (t) {
                        this._handleAutoScroll(t, !0);
                    },
                    _handleAutoScroll: function (t, e) {
                        var i = this,
                            n = (t.touches ? t.touches[0] : t).clientX,
                            o = (t.touches ? t.touches[0] : t).clientY,
                            s = document.elementFromPoint(n, o);
                        if (((ac = t), e || this.options.forceAutoScrollFallback || kl || Cl || Tl)) {
                            mc(t, this.options, s, e);
                            var r = Yl(s, !0);
                            !dc ||
                                (cc && n === rc && o === lc) ||
                                (cc && pc(),
                                    (cc = setInterval(function () {
                                        var s = Yl(document.elementFromPoint(n, o), !0);
                                        s !== r && ((r = s), uc()), mc(t, i.options, s, e);
                                    }, 10)),
                                    (rc = n),
                                    (lc = o));
                        } else {
                            if (!this.options.bubbleScroll || Yl(s, !0) === Vl()) return void uc();
                            mc(t, this.options, Yl(s, !1), !1);
                        }
                    },
                }),
                yl(t, { pluginName: "scroll", initializeByDefault: !0 })
            );
        })()
    ),
    Xa.mount(bc, fc);
class vc extends t.Modal {
    constructor(t, e) {
        super(t), (this.options = Object.assign({ title: Wr("Confirm"), confirmText: Wr("Confirm"), cancelText: Wr("Cancel") }, e));
    }
    onOpen() {
        const { contentEl: i } = this;
        i.addClass("confirm-modal"),
            i.createEl("h2", { text: this.options.title }),
            this.options.message.split("\n").forEach((t) => {
                i.createEl("p", { text: t });
            });
        const n = i.createDiv("confirm-modal-buttons");
        new t.ButtonComponent(n).setButtonText(this.options.cancelText).onClick(() => this.close()),
            new t.ButtonComponent(n)
                .setButtonText(this.options.confirmText)
                .setCta()
                .onClick(() =>
                    e(this, void 0, void 0, function* () {
                        yield this.options.onConfirm(), this.close();
                    })
                );
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty();
    }
    static show(t, e) {
        new vc(t, e).open();
    }
}
class yc extends t.Modal {
    constructor(t, e) {
        super(t), (this.changelogContent = ""), (this.changelogLoaded = !1), (this.plugin = e);
    }
    loadChangelog() {
        return e(this, void 0, void 0, function* () {
            try {
                const e = yield t.request({ url: "https://raw.githubusercontent.com/PKM-er/obsidian-editing-toolbar/master/CHANGELOG.md", method: "GET" });
                if (!e) throw new Error("无法获取 Changelog 内容");
                {
                    const t = e.split("\n");
                    let i = "",
                        n = [],
                        o = !1;
                    for (const e of t)
                        if (e.startsWith("## ") && !i) (i = e.substring(3).trim()), (o = !0), n.push(e);
                        else {
                            if (e.startsWith("## ") && o) break;
                            o && n.push(e);
                        }
                    this.changelogContent = n.join("\n");
                }
            } catch (t) {
                this.changelogContent = "### 无法加载更新说明\n\n请[点击此处查看最新更新说明](https://github.com/PKM-er/obsidian-editing-toolbar/blob/master/CHANGELOG.md)";
            }
            (this.changelogLoaded = !0), this.updateChangelogDisplay();
        });
    }
    updateChangelogDisplay() {
        this.changelogContainer && this.changelogContentEl && this.changelogLoaded && (this.changelogContentEl.empty(), t.MarkdownRenderer.renderMarkdown(this.changelogContent, this.changelogContentEl, "", this.plugin));
    }
    fixCommandIds() {
        return e(this, void 0, void 0, function* () {
            try {
                const e = {
                    "editor:toggle-numbered-list": "editing-toolbar:toggle-numbered-list",
                    "editor:toggle-bullet-list": "editing-toolbar:toggle-bullet-list",
                    "editor:toggle-highlight": "editing-toolbar:toggle-highlight",
                    "toggle-highlight": "editing-toolbar:toggle-highlight",
                    "editing-toolbar:editor:toggle-bold": "editing-toolbar:toggle-bold",
                    "editing-toolbar:editor:toggle-italics": "editing-toolbar:toggle-italics",
                    "editing-toolbar:editor:toggle-strikethrough": "editing-toolbar:toggle-strikethrough",
                    "editing-toolbar:editor:toggle-inline-math": "editing-toolbar:toggle-inline-math",
                    "editing-toolbar:editor:insert-callout": "editing-toolbar:insert-callout",
                    "editing-toolbar:editor:insert-link": "editing-toolbar:insert-link",
                    "cMenuToolbar-Divider-Line": "editingToolbar-Divider-Line",
                };
                let i = !1;
                const n = this.plugin.settings,
                    o = (t) => {
                        t &&
                            Array.isArray(t) &&
                            t.forEach((t) => {
                                t.id && e[t.id] && ((t.id = e[t.id]), (i = !0)),
                                    "editing-toolbar:format-eraser" === t.id && ((t.icon = "eraser"), (i = !0)),
                                    "editing-toolbar:change-font-color" === t.id &&
                                    ((t.icon =
                                        '<svg width="24" height="24" viewBox="0 0 24 24" focusable="false" fill="currentColor"><g fill-rule="evenodd"><path id="change-font-color-icon" d="M3 18h18v3H3z" style="fill:#2DC26B"></path><path d="M8.7 16h-.8a.5.5 0 01-.5-.6l2.7-9c.1-.3.3-.4.5-.4h2.8c.2 0 .4.1.5.4l2.7 9a.5.5 0 01-.5.6h-.8a.5.5 0 01-.4-.4l-.7-2.2c0-.3-.3-.4-.5-.4h-3.4c-.2 0-.4.1-.5.4l-.7 2.2c0 .3-.2.4-.4.4zm2.6-7.6l-.6 2a.5.5 0 00.5.6h1.6a.5.5 0 00.5-.6l-.6-2c0-.3-.3-.4-.5-.4h-.4c-.2 0-.4.1-.5.4z"></path></g></svg>'),
                                        (i = !0)),
                                    t.SubmenuCommands && o(t.SubmenuCommands);
                            });
                    },
                    s = (t) => {
                        if (!t || !Array.isArray(t)) return !1;
                        for (const e of t) {
                            if ("editing-toolbar:toggle-format-brush" === e.id) return !0;
                            if (e.SubmenuCommands && s(e.SubmenuCommands)) return !0;
                        }
                        return !1;
                    },
                    r = (t) => {
                        if (!t || !Array.isArray(t)) return !1;
                        if (!s(t) && t.length >= 2) {
                            const e = { id: "editing-toolbar:toggle-format-brush", name: "Format Brush", icon: "paintbrush" };
                            return t.splice(2, 0, e), !0;
                        }
                        return !1;
                    };
                n.menuCommands && (o(n.menuCommands), r(n.menuCommands) && (i = !0)),
                    n.enableMultipleConfig &&
                    (n.followingCommands && (o(n.followingCommands), r(n.followingCommands) && (i = !0)),
                        n.topCommands && (o(n.topCommands), r(n.topCommands) && (i = !0)),
                        n.fixedCommands && (o(n.fixedCommands), r(n.fixedCommands) && (i = !0)),
                        n.mobileCommands && (o(n.mobileCommands), r(n.mobileCommands) && (i = !0))),
                    i ? (yield this.plugin.saveSettings(), new t.Notice(Wr("Command IDs have been successfully repaired!")), dispatchEvent(new Event("editingToolbar-NewCommand"))) : new t.Notice(Wr("No command IDs need to be repaired"));
            } catch (e) {
                new t.Notice(Wr("Error repairing command IDs, please check the console for details"));
            }
        });
    }
    reloadPlugin(t) {
        return e(this, void 0, void 0, function* () {
            const { plugins: e } = this.app;
            try {
                yield e.disablePlugin(t), yield e.enablePlugin(t);
            } catch (t) { }
        });
    }
    restoreDefaultSettings() {
        return e(this, void 0, void 0, function* () {
            try {
                const e = this.plugin.settings.lastVersion,
                    i = this.plugin.settings.customCommands;
                (this.plugin.settings = Object.assign(Object.assign({}, Qr), { lastVersion: e, customCommands: i })),
                    yield this.plugin.saveSettings(),
                    new t.Notice(Wr("Successfully restored default settings! (Custom commands preserved)")),
                    this.reloadPlugin(this.plugin.manifest.id),
                    this.close();
            } catch (e) {
                new t.Notice(Wr("Error restoring default settings, please check the console for details"));
            }
        });
    }
    onOpen() {
        const { contentEl: i } = this;
        i.createEl("h2", { text: this.plugin.manifest.version + "⚡Tips" }), i.createEl("p", { text: Wr("Notice:") });
        const n = i.createEl("ul");
        n.createEl("li", { text: Wr("⚠️This update is not compatible with 2.x version command ids, please click [Repair command] to be compatible") }),
            n.createEl("li", { text: Wr("⚠️If you want to restore the default settings, please click [Restore default settings]") }),
            (this.changelogContainer = i.createDiv({ cls: "changelog-container" })),
            this.changelogContainer.createEl("h3", { text: Wr("Latest Changes") }),
            (this.changelogContentEl = this.changelogContainer.createDiv({ cls: "changelog-content" })),
            this.changelogContentEl.setText(Wr("Loading changelog...")),
            setTimeout(() => {
                this.loadChangelog();
            }, 100),
            new t.Setting(i)
                .setName(Wr("🔧Data repair"))
                .setDesc(Wr("This update changed the ID of some commands, please click this button to repair the commands to ensure the toolbar works properly"))
                .addButton((t) =>
                    t.setButtonText(Wr("Repair command ID")).onClick(() =>
                        e(this, void 0, void 0, function* () {
                            yield this.fixCommandIds();
                        })
                    )
                ),
            new t.Setting(i)
                .setName(Wr("🔄Restore default settings"))
                .setDesc(Wr("This will reset all your custom configurations, but custom commands will be preserved"))
                .addButton((t) =>
                    t.setButtonText(Wr("Restore default")).onClick(() =>
                        e(this, void 0, void 0, function* () {
                            vc.show(this.app, {
                                message: Wr("Are you sure you want to restore all settings to default? But custom commands will be preserved."),
                                onConfirm: () =>
                                    e(this, void 0, void 0, function* () {
                                        yield this.restoreDefaultSettings();
                                    }),
                            });
                        })
                    )
                ),
            new t.Setting(i)
                .setName(Wr("📋View full changelog"))
                .setDesc(Wr("Open the complete changelog in your browser"))
                .addButton((t) =>
                    t.setButtonText(Wr("Open changelog")).onClick(() => {
                        window.open("https://github.com/PKM-er/obsidian-editing-toolbar/blob/master/CHANGELOG.md", "_blank");
                    })
                ),
            new t.Setting(i).addButton((t) =>
                t.setButtonText(Wr("Close")).onClick(() => {
                    this.close();
                })
            ),
            i.createEl("style", {
                text:
                    "\n            .changelog-container {\n                margin-top: 20px;\n                margin-bottom: 20px;\n                padding: 10px;\n                border: 1px solid var(--background-modifier-border);\n                border-radius: 5px;\n                max-height: 200px;\n                overflow-y: auto;\n            }\n            .changelog-content {\n                padding: 0 10px;\n            }\n            .changelog-content a {\n                text-decoration: underline;\n            }\n            ",
            });
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty();
    }
}
function wc(t) {
    return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
/*! Pickr 1.8.4 MIT | https://github.com/Simonwep/pickr */ var xc = (function (t) {
    var e = { exports: {} };
    return (
        (function (t, e) {
            self,
                (t.exports = (() => {
                    var t = {
                        d: (e, i) => {
                            for (var n in i) t.o(i, n) && !t.o(e, n) && Object.defineProperty(e, n, { enumerable: !0, get: i[n] });
                        },
                        o: (t, e) => Object.prototype.hasOwnProperty.call(t, e),
                        r: (t) => {
                            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t, "__esModule", { value: !0 });
                        },
                    },
                        e = {};
                    t.d(e, { default: () => O });
                    var i = {};
                    function n(t, e, i, n) {
                        let o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
                        e instanceof HTMLCollection || e instanceof NodeList ? (e = Array.from(e)) : Array.isArray(e) || (e = [e]), Array.isArray(i) || (i = [i]);
                        for (const s of e) for (const e of i) s[t](e, n, { capture: !1, ...o });
                        return Array.prototype.slice.call(arguments, 1);
                    }
                    t.r(i), t.d(i, { adjustableInputNumbers: () => h, createElementFromString: () => r, createFromTemplate: () => l, eventPath: () => a, off: () => s, on: () => o, resolveElement: () => c });
                    const o = n.bind(null, "addEventListener"),
                        s = n.bind(null, "removeEventListener");
                    function r(t) {
                        const e = document.createElement("div");
                        return (e.innerHTML = t.trim()), e.firstElementChild;
                    }
                    function l(t) {
                        const e = (t, e) => {
                            const i = t.getAttribute(e);
                            return t.removeAttribute(e), i;
                        },
                            i = function (t) {
                                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                                const o = e(t, ":obj"),
                                    s = e(t, ":ref"),
                                    r = o ? (n[o] = {}) : n;
                                s && (n[s] = t);
                                for (const n of Array.from(t.children)) {
                                    const t = e(n, ":arr"),
                                        o = i(n, t ? {} : r);
                                    t && (r[t] || (r[t] = [])).push(Object.keys(o).length ? o : n);
                                }
                                return n;
                            };
                        return i(r(t));
                    }
                    function a(t) {
                        let e = t.path || (t.composedPath && t.composedPath());
                        if (e) return e;
                        let i = t.target.parentElement;
                        for (e = [t.target, i]; (i = i.parentElement);) e.push(i);
                        return e.push(document, window), e;
                    }
                    function c(t) {
                        return t instanceof Element ? t : "string" == typeof t ? t.split(/>>/g).reduce((t, e, i, n) => ((t = t.querySelector(e)), i < n.length - 1 ? t.shadowRoot : t), document) : null;
                    }
                    function h(t) {
                        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (t) => t;
                        function i(i) {
                            const n = [0.001, 0.01, 0.1][Number(i.shiftKey || 2 * i.ctrlKey)] * (i.deltaY < 0 ? 1 : -1);
                            let o = 0,
                                s = t.selectionStart;
                            (t.value = t.value.replace(/[\d.]+/g, (t, i) => (i <= s && i + t.length >= s ? ((s = i), e(Number(t), n, o)) : (o++, t)))),
                                t.focus(),
                                t.setSelectionRange(s, s),
                                i.preventDefault(),
                                t.dispatchEvent(new Event("input"));
                        }
                        o(t, "focus", () => o(window, "wheel", i, { passive: !1 })), o(t, "blur", () => s(window, "wheel", i));
                    }
                    const { min: d, max: u, floor: p, round: m } = Math;
                    function g(t, e, i) {
                        (e /= 100), (i /= 100);
                        const n = p((t = (t / 360) * 6)),
                            o = t - n,
                            s = i * (1 - e),
                            r = i * (1 - o * e),
                            l = i * (1 - (1 - o) * e),
                            a = n % 6;
                        return [255 * [i, r, s, s, l, i][a], 255 * [l, i, i, r, s, s][a], 255 * [s, s, l, i, i, r][a]];
                    }
                    function f(t, e, i) {
                        return g(t, e, i).map((t) => m(t).toString(16).padStart(2, "0"));
                    }
                    function b(t, e, i) {
                        const n = g(t, e, i),
                            o = n[0] / 255,
                            s = n[1] / 255,
                            r = n[2] / 255,
                            l = d(1 - o, 1 - s, 1 - r);
                        return [100 * (1 === l ? 0 : (1 - o - l) / (1 - l)), 100 * (1 === l ? 0 : (1 - s - l) / (1 - l)), 100 * (1 === l ? 0 : (1 - r - l) / (1 - l)), 100 * l];
                    }
                    function v(t, e, i) {
                        const n = ((2 - (e /= 100)) * (i /= 100)) / 2;
                        return 0 !== n && (e = 1 === n ? 0 : n < 0.5 ? (e * i) / (2 * n) : (e * i) / (2 - 2 * n)), [t, 100 * e, 100 * n];
                    }
                    function y(t, e, i) {
                        const n = d((t /= 255), (e /= 255), (i /= 255)),
                            o = u(t, e, i),
                            s = o - n;
                        let r, l;
                        if (0 === s) r = l = 0;
                        else {
                            l = s / o;
                            const n = ((o - t) / 6 + s / 2) / s,
                                a = ((o - e) / 6 + s / 2) / s,
                                c = ((o - i) / 6 + s / 2) / s;
                            t === o ? (r = c - a) : e === o ? (r = 1 / 3 + n - c) : i === o && (r = 2 / 3 + a - n), r < 0 ? (r += 1) : r > 1 && (r -= 1);
                        }
                        return [360 * r, 100 * l, 100 * o];
                    }
                    function w(t, e, i, n) {
                        return (e /= 100), (i /= 100), [...y(255 * (1 - d(1, (t /= 100) * (1 - (n /= 100)) + n)), 255 * (1 - d(1, e * (1 - n) + n)), 255 * (1 - d(1, i * (1 - n) + n)))];
                    }
                    function C(t, e, i) {
                        e /= 100;
                        const n = ((2 * (e *= (i /= 100) < 0.5 ? i : 1 - i)) / (i + e)) * 100,
                            o = 100 * (i + e);
                        return [t, isNaN(n) ? 0 : n, o];
                    }
                    function x(t) {
                        return y(...t.match(/.{2}/g).map((t) => parseInt(t, 16)));
                    }
                    function k(t) {
                        t = t.match(/^[a-zA-Z]+$/)
                            ? (function (t) {
                                if ("black" === t.toLowerCase()) return "#000";
                                const e = document.createElement("canvas").getContext("2d");
                                return (e.fillStyle = t), "#000" === e.fillStyle ? null : e.fillStyle;
                            })(t)
                            : t;
                        const e = {
                            cmyk: /^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i,
                            rgba: /^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,
                            hsla: /^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,
                            hsva: /^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,
                            hexa: /^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i,
                        },
                            i = (t) => t.map((t) => (/^(|\d+)\.\d+|\d+$/.test(t) ? Number(t) : void 0));
                        let n;
                        t: for (const o in e) {
                            if (!(n = e[o].exec(t))) continue;
                            const s = (t) => !!n[2] == ("number" == typeof t);
                            switch (o) {
                                case "cmyk": {
                                    const [, t, e, s, r] = i(n);
                                    if (t > 100 || e > 100 || s > 100 || r > 100) break t;
                                    return { values: w(t, e, s, r), type: o };
                                }
                                case "rgba": {
                                    const [, , , t, e, r, l] = i(n);
                                    if (t > 255 || e > 255 || r > 255 || l < 0 || l > 1 || !s(l)) break t;
                                    return { values: [...y(t, e, r), l], a: l, type: o };
                                }
                                case "hexa": {
                                    let [, t] = n;
                                    (4 !== t.length && 3 !== t.length) ||
                                        (t = t
                                            .split("")
                                            .map((t) => t + t)
                                            .join(""));
                                    const e = t.substring(0, 6);
                                    let i = t.substring(6);
                                    return (i = i ? parseInt(i, 16) / 255 : void 0), { values: [...x(e), i], a: i, type: o };
                                }
                                case "hsla": {
                                    const [, , , t, e, r, l] = i(n);
                                    if (t > 360 || e > 100 || r > 100 || l < 0 || l > 1 || !s(l)) break t;
                                    return { values: [...C(t, e, r), l], a: l, type: o };
                                }
                                case "hsva": {
                                    const [, , , t, e, r, l] = i(n);
                                    if (t > 360 || e > 100 || r > 100 || l < 0 || l > 1 || !s(l)) break t;
                                    return { values: [t, e, r, l], a: l, type: o };
                                }
                            }
                        }
                        return { values: null, type: null };
                    }
                    function S() {
                        const t = (t, e) =>
                            function () {
                                let i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1;
                                return e(~i ? t.map((t) => Number(t.toFixed(i))) : t);
                            },
                            e = {
                                h: arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                                s: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                                v: arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                                a: arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
                                toHSVA() {
                                    const i = [e.h, e.s, e.v, e.a];
                                    return (i.toString = t(i, (t) => `hsva(${t[0]}, ${t[1]}%, ${t[2]}%, ${e.a})`)), i;
                                },
                                toHSLA() {
                                    const i = [...v(e.h, e.s, e.v), e.a];
                                    return (i.toString = t(i, (t) => `hsla(${t[0]}, ${t[1]}%, ${t[2]}%, ${e.a})`)), i;
                                },
                                toRGBA() {
                                    const i = [...g(e.h, e.s, e.v), e.a];
                                    return (i.toString = t(i, (t) => `rgba(${t[0]}, ${t[1]}, ${t[2]}, ${e.a})`)), i;
                                },
                                toCMYK() {
                                    const i = b(e.h, e.s, e.v);
                                    return (i.toString = t(i, (t) => `cmyk(${t[0]}%, ${t[1]}%, ${t[2]}%, ${t[3]}%)`)), i;
                                },
                                toHEXA() {
                                    const t = f(e.h, e.s, e.v),
                                        i =
                                            e.a >= 1
                                                ? ""
                                                : Number((255 * e.a).toFixed(0))
                                                    .toString(16)
                                                    .toUpperCase()
                                                    .padStart(2, "0");
                                    return i && t.push(i), (t.toString = () => `#${t.join("").toUpperCase()}`), t;
                                },
                                clone: () => S(e.h, e.s, e.v, e.a),
                            };
                        return e;
                    }
                    const T = (t) => Math.max(Math.min(t, 1), 0);
                    function E(t) {
                        const e = {
                            options: Object.assign({ lock: null, onchange: () => 0, onstop: () => 0 }, t),
                            _keyboard(t) {
                                const { options: i } = e,
                                    { type: n, key: o } = t;
                                if (document.activeElement === i.wrapper) {
                                    const { lock: i } = e.options,
                                        s = "ArrowUp" === o,
                                        r = "ArrowRight" === o,
                                        l = "ArrowDown" === o,
                                        a = "ArrowLeft" === o;
                                    if ("keydown" === n && (s || r || l || a)) {
                                        let n = 0,
                                            o = 0;
                                        "v" === i ? (n = s || r ? 1 : -1) : "h" === i ? (n = s || r ? -1 : 1) : ((o = s ? -1 : l ? 1 : 0), (n = a ? -1 : r ? 1 : 0)),
                                            e.update(T(e.cache.x + 0.01 * n), T(e.cache.y + 0.01 * o)),
                                            t.preventDefault();
                                    } else o.startsWith("Arrow") && (e.options.onstop(), t.preventDefault());
                                }
                            },
                            _tapstart(t) {
                                o(document, ["mouseup", "touchend", "touchcancel"], e._tapstop), o(document, ["mousemove", "touchmove"], e._tapmove), t.cancelable && t.preventDefault(), e._tapmove(t);
                            },
                            _tapmove(t) {
                                const { options: i, cache: n } = e,
                                    { lock: o, element: s, wrapper: r } = i,
                                    l = r.getBoundingClientRect();
                                let a = 0,
                                    c = 0;
                                if (t) {
                                    const e = t && t.touches && t.touches[0];
                                    (a = t ? (e || t).clientX : 0),
                                        (c = t ? (e || t).clientY : 0),
                                        a < l.left ? (a = l.left) : a > l.left + l.width && (a = l.left + l.width),
                                        c < l.top ? (c = l.top) : c > l.top + l.height && (c = l.top + l.height),
                                        (a -= l.left),
                                        (c -= l.top);
                                } else n && ((a = n.x * l.width), (c = n.y * l.height));
                                "h" !== o && (s.style.left = `calc(${(a / l.width) * 100}% - ${s.offsetWidth / 2}px)`),
                                    "v" !== o && (s.style.top = `calc(${(c / l.height) * 100}% - ${s.offsetHeight / 2}px)`),
                                    (e.cache = { x: a / l.width, y: c / l.height });
                                const h = T(a / l.width),
                                    d = T(c / l.height);
                                switch (o) {
                                    case "v":
                                        return i.onchange(h);
                                    case "h":
                                        return i.onchange(d);
                                    default:
                                        return i.onchange(h, d);
                                }
                            },
                            _tapstop() {
                                e.options.onstop(), s(document, ["mouseup", "touchend", "touchcancel"], e._tapstop), s(document, ["mousemove", "touchmove"], e._tapmove);
                            },
                            trigger() {
                                e._tapmove();
                            },
                            update() {
                                let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                                    i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                                const { left: n, top: o, width: s, height: r } = e.options.wrapper.getBoundingClientRect();
                                "h" === e.options.lock && (i = t), e._tapmove({ clientX: n + s * t, clientY: o + r * i });
                            },
                            destroy() {
                                const { options: t, _tapstart: i, _keyboard: n } = e;
                                s(document, ["keydown", "keyup"], n), s([t.wrapper, t.element], "mousedown", i), s([t.wrapper, t.element], "touchstart", i, { passive: !1 });
                            },
                        },
                            { options: i, _tapstart: n, _keyboard: r } = e;
                        return o([i.wrapper, i.element], "mousedown", n), o([i.wrapper, i.element], "touchstart", n, { passive: !1 }), o(document, ["keydown", "keyup"], r), e;
                    }
                    function M() {
                        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        t = Object.assign({ onchange: () => 0, className: "", elements: [] }, t);
                        const e = o(t.elements, "click", (e) => {
                            t.elements.forEach((i) => i.classList[e.target === i ? "add" : "remove"](t.className)), t.onchange(e), e.stopPropagation();
                        });
                        return { destroy: () => s(...e) };
                    }
                    const A = { variantFlipOrder: { start: "sme", middle: "mse", end: "ems" }, positionFlipOrder: { top: "tbrl", right: "rltb", bottom: "btrl", left: "lrbt" }, position: "bottom", margin: 8 },
                        D = (t, e, i) => {
                            const { container: n, margin: o, position: s, variantFlipOrder: r, positionFlipOrder: l } = { container: document.documentElement.getBoundingClientRect(), ...A, ...i },
                                { left: a, top: c } = e.style;
                            (e.style.left = "0"), (e.style.top = "0");
                            const h = t.getBoundingClientRect(),
                                d = e.getBoundingClientRect(),
                                u = { t: h.top - d.height - o, b: h.bottom + o, r: h.right + o, l: h.left - d.width - o },
                                p = { vs: h.left, vm: h.left + h.width / 2 + -d.width / 2, ve: h.left + h.width - d.width, hs: h.top, hm: h.bottom - h.height / 2 - d.height / 2, he: h.bottom - d.height },
                                [m, g = "middle"] = s.split("-"),
                                f = l[m],
                                b = r[g],
                                { top: v, left: y, bottom: w, right: C } = n;
                            for (const t of f) {
                                const i = "t" === t || "b" === t,
                                    n = u[t],
                                    [o, s] = i ? ["top", "left"] : ["left", "top"],
                                    [r, l] = i ? [d.height, d.width] : [d.width, d.height],
                                    [a, c] = i ? [w, C] : [C, w],
                                    [h, m] = i ? [v, y] : [y, v];
                                if (!(n < h || n + r > a))
                                    for (const r of b) {
                                        const a = p[(i ? "v" : "h") + r];
                                        if (!(a < m || a + l > c)) return (e.style[s] = a - d[s] + "px"), (e.style[o] = n - d[o] + "px"), t + r;
                                    }
                            }
                            return (e.style.left = a), (e.style.top = c), null;
                        };
                    function I(t, e, i) {
                        return e in t ? Object.defineProperty(t, e, { value: i, enumerable: !0, configurable: !0, writable: !0 }) : (t[e] = i), t;
                    }
                    class O {
                        constructor(t) {
                            I(this, "_initializingActive", !0),
                                I(this, "_recalc", !0),
                                I(this, "_nanopop", null),
                                I(this, "_root", null),
                                I(this, "_color", S()),
                                I(this, "_lastColor", S()),
                                I(this, "_swatchColors", []),
                                I(this, "_setupAnimationFrame", null),
                                I(this, "_eventListener", { init: [], save: [], hide: [], show: [], clear: [], change: [], changestop: [], cancel: [], swatchselect: [] }),
                                (this.options = t = Object.assign({ ...O.DEFAULT_OPTIONS }, t));
                            const { swatches: e, components: i, theme: n, sliders: o, lockOpacity: s, padding: r } = t;
                            ["nano", "monolith"].includes(n) && !o && (t.sliders = "h"), i.interaction || (i.interaction = {});
                            const { preview: l, opacity: a, hue: c, palette: h } = i;
                            (i.opacity = !s && a), (i.palette = h || l || a || c), this._preBuild(), this._buildComponents(), this._bindEvents(), this._finalBuild(), e && e.length && e.forEach((t) => this.addSwatch(t));
                            const { button: d, app: u } = this._root;
                            (this._nanopop = ((t, e, i) => {
                                const n = "object" != typeof t || t instanceof HTMLElement ? { reference: t, popper: e, ...i } : t;
                                return {
                                    update() {
                                        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n;
                                        const { reference: e, popper: i } = Object.assign(n, t);
                                        if (!i || !e) throw new Error("Popper- or reference-element missing.");
                                        return D(e, i, n);
                                    },
                                };
                            })(d, u, { margin: r })),
                                d.setAttribute("role", "button"),
                                d.setAttribute("aria-label", this._t("btn:toggle"));
                            const p = this;
                            this._setupAnimationFrame = requestAnimationFrame(function e() {
                                if (!u.offsetWidth) return (p._setupAnimationFrame = requestAnimationFrame(e));
                                p.setColor(t.default),
                                    p._rePositioningPicker(),
                                    t.defaultRepresentation && ((p._representation = t.defaultRepresentation), p.setColorRepresentation(p._representation)),
                                    t.showAlways && p.show(),
                                    (p._initializingActive = !1),
                                    p._emit("init");
                            });
                        }
                        _preBuild() {
                            const { options: t } = this;
                            for (const e of ["el", "container"]) t[e] = c(t[e]);
                            (this._root = ((t) => {
                                const { components: e, useAsButton: i, inline: n, appClass: o, theme: s, lockOpacity: r } = t.options,
                                    a = (t) => (t ? "" : 'style="display:none" hidden'),
                                    c = (e) => t._t(e),
                                    h = l(
                                        `\n      <div :ref="root" class="pickr">\n\n        ${i ? "" : '<button type="button" :ref="button" class="pcr-button"></button>'}\n\n        <div :ref="app" class="pcr-app ${o || ""
                                        }" data-theme="${s}" ${n ? 'style="position: unset"' : ""} aria-label="${c("ui:dialog")}" role="window">\n          <div class="pcr-selection" ${a(
                                            e.palette
                                        )}>\n            <div :obj="preview" class="pcr-color-preview" ${a(e.preview)}>\n              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c(
                                            "btn:last-color"
                                        )}"></button>\n              <div :ref="currentColor" class="pcr-current-color"></div>\n            </div>\n\n            <div :obj="palette" class="pcr-color-palette">\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c(
                                            "aria:palette"
                                        )}" role="listbox"></div>\n            </div>\n\n            <div :obj="hue" class="pcr-color-chooser" ${a(
                                            e.hue
                                        )}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c(
                                            "aria:hue"
                                        )}" role="slider"></div>\n            </div>\n\n            <div :obj="opacity" class="pcr-color-opacity" ${a(
                                            e.opacity
                                        )}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c(
                                            "aria:opacity"
                                        )}" role="slider"></div>\n            </div>\n          </div>\n\n          <div class="pcr-swatches ${e.palette ? "" : "pcr-last"
                                        }" :ref="swatches"></div>\n\n          <div :obj="interaction" class="pcr-interaction" ${a(
                                            Object.keys(e.interaction).length
                                        )}>\n            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${a(e.interaction.input)} aria-label="${c(
                                            "aria:input"
                                        )}">\n\n            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r ? "HEX" : "HEXA"}" type="button" ${a(
                                            e.interaction.hex
                                        )}>\n            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r ? "RGB" : "RGBA"}" type="button" ${a(
                                            e.interaction.rgba
                                        )}>\n            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r ? "HSL" : "HSLA"}" type="button" ${a(
                                            e.interaction.hsla
                                        )}>\n            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r ? "HSV" : "HSVA"}" type="button" ${a(
                                            e.interaction.hsva
                                        )}>\n            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${a(e.interaction.cmyk)}>\n\n            <input :ref="save" class="pcr-save" value="${c(
                                            "btn:save"
                                        )}" type="button" ${a(e.interaction.save)} aria-label="${c("aria:btn:save")}">\n            <input :ref="cancel" class="pcr-cancel" value="${c("btn:cancel")}" type="button" ${a(
                                            e.interaction.cancel
                                        )} aria-label="${c("aria:btn:cancel")}">\n            <input :ref="clear" class="pcr-clear" value="${c("btn:clear")}" type="button" ${a(e.interaction.clear)} aria-label="${c(
                                            "aria:btn:clear"
                                        )}">\n          </div>\n        </div>\n      </div>\n    `
                                    ),
                                    d = h.interaction;
                                return d.options.find((t) => !t.hidden && !t.classList.add("active")), (d.type = () => d.options.find((t) => t.classList.contains("active"))), h;
                            })(this)),
                                t.useAsButton && (this._root.button = t.el),
                                t.container.appendChild(this._root.root);
                        }
                        _finalBuild() {
                            const t = this.options,
                                e = this._root;
                            if ((t.container.removeChild(e.root), t.inline)) {
                                const i = t.el.parentElement;
                                t.el.nextSibling ? i.insertBefore(e.app, t.el.nextSibling) : i.appendChild(e.app);
                            } else t.container.appendChild(e.app);
                            t.useAsButton ? t.inline && t.el.remove() : t.el.parentNode.replaceChild(e.root, t.el),
                                t.disabled && this.disable(),
                                t.comparison || ((e.button.style.transition = "none"), t.useAsButton || (e.preview.lastColor.style.transition = "none")),
                                this.hide();
                        }
                        _buildComponents() {
                            const t = this,
                                e = this.options.components,
                                i = (t.options.sliders || "v").repeat(2),
                                [n, o] = i.match(/^[vh]+$/g) ? i : [],
                                s = () => this._color || (this._color = this._lastColor.clone()),
                                r = {
                                    palette: E({
                                        element: t._root.palette.picker,
                                        wrapper: t._root.palette.palette,
                                        onstop: () => t._emit("changestop", "slider", t),
                                        onchange(i, n) {
                                            if (!e.palette) return;
                                            const o = s(),
                                                { _root: r, options: l } = t,
                                                { lastColor: a, currentColor: c } = r.preview;
                                            t._recalc && ((o.s = 100 * i), (o.v = 100 - 100 * n), o.v < 0 && (o.v = 0), t._updateOutput("slider"));
                                            const h = o.toRGBA().toString(0);
                                            (this.element.style.background = h),
                                                (this.wrapper.style.background = `\n                        linear-gradient(to top, rgba(0, 0, 0, ${o.a}), transparent),\n                        linear-gradient(to left, hsla(${o.h}, 100%, 50%, ${o.a}), rgba(255, 255, 255, ${o.a}))\n                    `),
                                                l.comparison ? l.useAsButton || t._lastColor || a.style.setProperty("--pcr-color", h) : (r.button.style.setProperty("--pcr-color", h), r.button.classList.remove("clear"));
                                            const d = o.toHEXA().toString();
                                            for (const { el: e, color: i } of t._swatchColors) e.classList[d === i.toHEXA().toString() ? "add" : "remove"]("pcr-active");
                                            c.style.setProperty("--pcr-color", h);
                                        },
                                    }),
                                    hue: E({
                                        lock: "v" === o ? "h" : "v",
                                        element: t._root.hue.picker,
                                        wrapper: t._root.hue.slider,
                                        onstop: () => t._emit("changestop", "slider", t),
                                        onchange(i) {
                                            if (!e.hue || !e.palette) return;
                                            const n = s();
                                            t._recalc && (n.h = 360 * i), (this.element.style.backgroundColor = `hsl(${n.h}, 100%, 50%)`), r.palette.trigger();
                                        },
                                    }),
                                    opacity: E({
                                        lock: "v" === n ? "h" : "v",
                                        element: t._root.opacity.picker,
                                        wrapper: t._root.opacity.slider,
                                        onstop: () => t._emit("changestop", "slider", t),
                                        onchange(i) {
                                            if (!e.opacity || !e.palette) return;
                                            const n = s();
                                            t._recalc && (n.a = Math.round(100 * i) / 100), (this.element.style.background = `rgba(0, 0, 0, ${n.a})`), r.palette.trigger();
                                        },
                                    }),
                                    selectable: M({
                                        elements: t._root.interaction.options,
                                        className: "active",
                                        onchange(e) {
                                            (t._representation = e.target.getAttribute("data-type").toUpperCase()), t._recalc && t._updateOutput("swatch");
                                        },
                                    }),
                                };
                            this._components = r;
                        }
                        _bindEvents() {
                            const { _root: t, options: e } = this,
                                i = [
                                    o(t.interaction.clear, "click", () => this._clearColor()),
                                    o([t.interaction.cancel, t.preview.lastColor], "click", () => {
                                        this.setHSVA(...(this._lastColor || this._color).toHSVA(), !0), this._emit("cancel");
                                    }),
                                    o(t.interaction.save, "click", () => {
                                        !this.applyColor() && !e.showAlways && this.hide();
                                    }),
                                    o(t.interaction.result, ["keyup", "input"], (t) => {
                                        this.setColor(t.target.value, !0) && !this._initializingActive && (this._emit("change", this._color, "input", this), this._emit("changestop", "input", this)), t.stopImmediatePropagation();
                                    }),
                                    o(t.interaction.result, ["focus", "blur"], (t) => {
                                        (this._recalc = "blur" === t.type), this._recalc && this._updateOutput(null);
                                    }),
                                    o([t.palette.palette, t.palette.picker, t.hue.slider, t.hue.picker, t.opacity.slider, t.opacity.picker], ["mousedown", "touchstart"], () => (this._recalc = !0), { passive: !0 }),
                                ];
                            if (!e.showAlways) {
                                const n = e.closeWithKey;
                                i.push(
                                    o(t.button, "click", () => (this.isOpen() ? this.hide() : this.show())),
                                    o(document, "keyup", (t) => this.isOpen() && (t.key === n || t.code === n) && this.hide()),
                                    o(
                                        document,
                                        ["touchstart", "mousedown"],
                                        (e) => {
                                            this.isOpen() && !a(e).some((e) => e === t.app || e === t.button) && this.hide();
                                        },
                                        { capture: !0 }
                                    )
                                );
                            }
                            if (e.adjustableNumbers) {
                                const e = { rgba: [255, 255, 255, 1], hsva: [360, 100, 100, 1], hsla: [360, 100, 100, 1], cmyk: [100, 100, 100, 100] };
                                h(t.interaction.result, (t, i, n) => {
                                    const o = e[this.getColorRepresentation().toLowerCase()];
                                    if (o) {
                                        const e = o[n],
                                            s = t + (e >= 100 ? 1e3 * i : i);
                                        return s <= 0 ? 0 : Number((s < e ? s : e).toPrecision(3));
                                    }
                                    return t;
                                });
                            }
                            if (e.autoReposition && !e.inline) {
                                let t = null;
                                const n = this;
                                i.push(
                                    o(
                                        window,
                                        ["scroll", "resize"],
                                        () => {
                                            n.isOpen() &&
                                                (e.closeOnScroll && n.hide(),
                                                    null === t
                                                        ? ((t = setTimeout(() => (t = null), 100)),
                                                            requestAnimationFrame(function e() {
                                                                n._rePositioningPicker(), null !== t && requestAnimationFrame(e);
                                                            }))
                                                        : (clearTimeout(t), (t = setTimeout(() => (t = null), 100))));
                                        },
                                        { capture: !0 }
                                    )
                                );
                            }
                            this._eventBindings = i;
                        }
                        _rePositioningPicker() {
                            const { options: t } = this;
                            if (!t.inline && !this._nanopop.update({ container: document.body.getBoundingClientRect(), position: t.position })) {
                                const t = this._root.app,
                                    e = t.getBoundingClientRect();
                                (t.style.top = (window.innerHeight - e.height) / 2 + "px"), (t.style.left = (window.innerWidth - e.width) / 2 + "px");
                            }
                        }
                        _updateOutput(t) {
                            const { _root: e, _color: i, options: n } = this;
                            if (e.interaction.type()) {
                                const t = `to${e.interaction.type().getAttribute("data-type")}`;
                                e.interaction.result.value = "function" == typeof i[t] ? i[t]().toString(n.outputPrecision) : "";
                            }
                            !this._initializingActive && this._recalc && this._emit("change", i, t, this);
                        }
                        _clearColor() {
                            let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                            const { _root: e, options: i } = this;
                            i.useAsButton || e.button.style.setProperty("--pcr-color", "rgba(0, 0, 0, 0.15)"),
                                e.button.classList.add("clear"),
                                i.showAlways || this.hide(),
                                (this._lastColor = null),
                                this._initializingActive || t || (this._emit("save", null), this._emit("clear"));
                        }
                        _parseLocalColor(t) {
                            const { values: e, type: i, a: n } = k(t),
                                { lockOpacity: o } = this.options,
                                s = void 0 !== n && 1 !== n;
                            return e && 3 === e.length && (e[3] = void 0), { values: !e || (o && s) ? null : e, type: i };
                        }
                        _t(t) {
                            return this.options.i18n[t] || O.I18N_DEFAULTS[t];
                        }
                        _emit(t) {
                            for (var e = arguments.length, i = new Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) i[n - 1] = arguments[n];
                            this._eventListener[t].forEach((t) => t(...i, this));
                        }
                        on(t, e) {
                            return this._eventListener[t].push(e), this;
                        }
                        off(t, e) {
                            const i = this._eventListener[t] || [],
                                n = i.indexOf(e);
                            return ~n && i.splice(n, 1), this;
                        }
                        addSwatch(t) {
                            const { values: e } = this._parseLocalColor(t);
                            if (e) {
                                const { _swatchColors: t, _root: i } = this,
                                    n = S(...e),
                                    s = r(`<button type="button" style="--pcr-color: ${n.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`);
                                return (
                                    i.swatches.appendChild(s),
                                    t.push({ el: s, color: n }),
                                    this._eventBindings.push(
                                        o(s, "click", () => {
                                            this.setHSVA(...n.toHSVA(), !0), this._emit("swatchselect", n), this._emit("change", n, "swatch", this);
                                        })
                                    ),
                                    !0
                                );
                            }
                            return !1;
                        }
                        removeSwatch(t) {
                            const e = this._swatchColors[t];
                            if (e) {
                                const { el: i } = e;
                                return this._root.swatches.removeChild(i), this._swatchColors.splice(t, 1), !0;
                            }
                            return !1;
                        }
                        applyColor() {
                            let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                            const { preview: e, button: i } = this._root,
                                n = this._color.toRGBA().toString(0);
                            return (
                                e.lastColor.style.setProperty("--pcr-color", n),
                                this.options.useAsButton || i.style.setProperty("--pcr-color", n),
                                i.classList.remove("clear"),
                                (this._lastColor = this._color.clone()),
                                this._initializingActive || t || this._emit("save", this._color),
                                this
                            );
                        }
                        destroy() {
                            cancelAnimationFrame(this._setupAnimationFrame), this._eventBindings.forEach((t) => s(...t)), Object.keys(this._components).forEach((t) => this._components[t].destroy());
                        }
                        destroyAndRemove() {
                            this.destroy();
                            const { root: t, app: e } = this._root;
                            t.parentElement && t.parentElement.removeChild(t), e.parentElement.removeChild(e), Object.keys(this).forEach((t) => (this[t] = null));
                        }
                        hide() {
                            return !!this.isOpen() && (this._root.app.classList.remove("visible"), this._emit("hide"), !0);
                        }
                        show() {
                            return !this.options.disabled && !this.isOpen() && (this._root.app.classList.add("visible"), this._rePositioningPicker(), this._emit("show", this._color), this);
                        }
                        isOpen() {
                            return this._root.app.classList.contains("visible");
                        }
                        setHSVA() {
                            let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 360,
                                e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                                i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                                n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
                                o = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
                            const s = this._recalc;
                            if (((this._recalc = !1), t < 0 || t > 360 || e < 0 || e > 100 || i < 0 || i > 100 || n < 0 || n > 1)) return !1;
                            this._color = S(t, e, i, n);
                            const { hue: r, opacity: l, palette: a } = this._components;
                            return r.update(t / 360), l.update(n), a.update(e / 100, 1 - i / 100), o || this.applyColor(), s && this._updateOutput(), (this._recalc = s), !0;
                        }
                        setColor(t) {
                            let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                            if (null === t) return this._clearColor(e), !0;
                            const { values: i, type: n } = this._parseLocalColor(t);
                            if (i) {
                                const t = n.toUpperCase(),
                                    { options: o } = this._root.interaction,
                                    s = o.find((e) => e.getAttribute("data-type") === t);
                                if (s && !s.hidden) for (const t of o) t.classList[t === s ? "add" : "remove"]("active");
                                return !!this.setHSVA(...i, e) && this.setColorRepresentation(t);
                            }
                            return !1;
                        }
                        setColorRepresentation(t) {
                            return (t = t.toUpperCase()), !!this._root.interaction.options.find((e) => e.getAttribute("data-type").startsWith(t) && !e.click());
                        }
                        getColorRepresentation() {
                            return this._representation;
                        }
                        getColor() {
                            return this._color;
                        }
                        getSelectedColor() {
                            return this._lastColor;
                        }
                        getRoot() {
                            return this._root;
                        }
                        disable() {
                            return this.hide(), (this.options.disabled = !0), this._root.button.classList.add("disabled"), this;
                        }
                        enable() {
                            return (this.options.disabled = !1), this._root.button.classList.remove("disabled"), this;
                        }
                    }
                    return (
                        I(O, "utils", i),
                        I(O, "version", "1.8.4"),
                        I(O, "I18N_DEFAULTS", {
                            "ui:dialog": "color picker dialog",
                            "btn:toggle": "toggle color picker dialog",
                            "btn:swatch": "color swatch",
                            "btn:last-color": "use previous color",
                            "btn:save": "Save",
                            "btn:cancel": "Cancel",
                            "btn:clear": "Clear",
                            "aria:btn:save": "save and close",
                            "aria:btn:cancel": "cancel and close",
                            "aria:btn:clear": "clear and close",
                            "aria:input": "color input field",
                            "aria:palette": "color selection area",
                            "aria:hue": "hue selection slider",
                            "aria:opacity": "selection slider",
                        }),
                        I(O, "DEFAULT_OPTIONS", {
                            appClass: null,
                            theme: "classic",
                            useAsButton: !1,
                            padding: 8,
                            disabled: !1,
                            comparison: !0,
                            closeOnScroll: !1,
                            outputPrecision: 0,
                            lockOpacity: !1,
                            autoReposition: !0,
                            container: "body",
                            components: { interaction: {} },
                            i18n: {},
                            swatches: null,
                            inline: !1,
                            sliders: null,
                            default: "#42445a",
                            defaultRepresentation: null,
                            position: "bottom-middle",
                            adjustableNumbers: !0,
                            showAlways: !1,
                            closeWithKey: "Escape",
                        }),
                        I(O, "create", (t) => new O(t)),
                        e.default
                    );
                })());
        })(e),
        e.exports
    );
})(),
    Cc = wc(xc),
    kc = [],
    Sc = [];
!(function (t, e) {
    if (t && "undefined" != typeof document) {
        var i,
            n = !0 === e.prepend ? "prepend" : "append",
            o = !0 === e.singleTag,
            s = "string" == typeof e.container ? document.querySelector(e.container) : document.getElementsByTagName("head")[0];
        if (o) {
            var r = kc.indexOf(s);
            -1 === r && ((r = kc.push(s) - 1), (Sc[r] = {})), (i = Sc[r] && Sc[r][n] ? Sc[r][n] : (Sc[r][n] = l()));
        } else i = l();
        65279 === t.charCodeAt(0) && (t = t.substring(1)), i.styleSheet ? (i.styleSheet.cssText += t) : i.appendChild(document.createTextNode(t));
    }
    function l() {
        var t = document.createElement("style");
        if ((t.setAttribute("type", "text/css"), e.attributes)) for (var i = Object.keys(e.attributes), o = 0; o < i.length; o++) t.setAttribute(i[o], e.attributes[i[o]]);
        var r = "prepend" === n ? "afterbegin" : "beforeend";
        return s.insertAdjacentElement(r, t), t;
    }
})(
    '/*! Pickr 1.8.4 MIT | https://github.com/Simonwep/pickr */\n.pickr{position:relative;overflow:visible;transform:translateY(0)}.pickr *{box-sizing:border-box;outline:none;border:none;-webkit-appearance:none}.pickr .pcr-button{position:relative;height:2em;width:2em;padding:0.5em;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Roboto","Helvetica Neue",Arial,sans-serif;border-radius:.15em;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" stroke="%2342445A" stroke-width="5px" stroke-linecap="round"><path d="M45,45L5,5"></path><path d="M45,5L5,45"></path></svg>\') no-repeat center;background-size:0;transition:all 0.3s}.pickr .pcr-button::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:.5em;border-radius:.15em;z-index:-1}.pickr .pcr-button::before{z-index:initial}.pickr .pcr-button::after{position:absolute;content:\'\';top:0;left:0;height:100%;width:100%;transition:background 0.3s;background:var(--pcr-color);border-radius:.15em}.pickr .pcr-button.clear{background-size:70%}.pickr .pcr-button.clear::before{opacity:0}.pickr .pcr-button.clear:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px var(--pcr-color)}.pickr .pcr-button.disabled{cursor:not-allowed}.pickr *,.pcr-app *{box-sizing:border-box;outline:none;border:none;-webkit-appearance:none}.pickr input:focus,.pickr input.pcr-active,.pickr button:focus,.pickr button.pcr-active,.pcr-app input:focus,.pcr-app input.pcr-active,.pcr-app button:focus,.pcr-app button.pcr-active{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px var(--pcr-color)}.pickr .pcr-palette,.pickr .pcr-slider,.pcr-app .pcr-palette,.pcr-app .pcr-slider{transition:box-shadow 0.3s}.pickr .pcr-palette:focus,.pickr .pcr-slider:focus,.pcr-app .pcr-palette:focus,.pcr-app .pcr-slider:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px rgba(0,0,0,0.25)}.pcr-app{position:fixed;display:flex;flex-direction:column;z-index:10000;border-radius:0.1em;background:#fff;opacity:0;visibility:hidden;transition:opacity 0.3s, visibility 0s 0.3s;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Roboto","Helvetica Neue",Arial,sans-serif;box-shadow:0 0.15em 1.5em 0 rgba(0,0,0,0.1),0 0 1em 0 rgba(0,0,0,0.03);left:0;top:0}.pcr-app.visible{transition:opacity 0.3s;visibility:visible;opacity:1}.pcr-app .pcr-swatches{display:flex;flex-wrap:wrap;margin-top:0.75em}.pcr-app .pcr-swatches.pcr-last{margin:0}@supports (display: grid){.pcr-app .pcr-swatches{display:grid;align-items:center;grid-template-columns:repeat(auto-fit, 1.75em)}}.pcr-app .pcr-swatches>button{font-size:1em;position:relative;width:calc(1.75em - 5px);height:calc(1.75em - 5px);border-radius:0.15em;cursor:pointer;margin:2.5px;flex-shrink:0;justify-self:center;transition:all 0.15s;overflow:hidden;background:transparent;z-index:1}.pcr-app .pcr-swatches>button::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:6px;border-radius:.15em;z-index:-1}.pcr-app .pcr-swatches>button::after{content:\'\';position:absolute;top:0;left:0;width:100%;height:100%;background:var(--pcr-color);border:1px solid rgba(0,0,0,0.05);border-radius:0.15em;box-sizing:border-box}.pcr-app .pcr-swatches>button:hover{filter:brightness(1.05)}.pcr-app .pcr-swatches>button:not(.pcr-active){box-shadow:none}.pcr-app .pcr-interaction{display:flex;flex-wrap:wrap;align-items:center;margin:0 -0.2em 0 -0.2em}.pcr-app .pcr-interaction>*{margin:0 0.2em}.pcr-app .pcr-interaction input{letter-spacing:0.07em;font-size:0.75em;text-align:center;cursor:pointer;color:#75797e;background:#f1f3f4;border-radius:.15em;transition:all 0.15s;padding:0.45em 0.5em;margin-top:0.75em}.pcr-app .pcr-interaction input:hover{filter:brightness(0.975)}.pcr-app .pcr-interaction input:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px rgba(66,133,244,0.75)}.pcr-app .pcr-interaction .pcr-result{color:#75797e;text-align:left;flex:1 1 8em;min-width:8em;transition:all 0.2s;border-radius:.15em;background:#f1f3f4;cursor:text}.pcr-app .pcr-interaction .pcr-result::-moz-selection{background:#4285f4;color:#fff}.pcr-app .pcr-interaction .pcr-result::selection{background:#4285f4;color:#fff}.pcr-app .pcr-interaction .pcr-type.active{color:#fff;background:#4285f4}.pcr-app .pcr-interaction .pcr-save,.pcr-app .pcr-interaction .pcr-cancel,.pcr-app .pcr-interaction .pcr-clear{color:#fff;width:auto}.pcr-app .pcr-interaction .pcr-save,.pcr-app .pcr-interaction .pcr-cancel,.pcr-app .pcr-interaction .pcr-clear{color:#fff}.pcr-app .pcr-interaction .pcr-save:hover,.pcr-app .pcr-interaction .pcr-cancel:hover,.pcr-app .pcr-interaction .pcr-clear:hover{filter:brightness(0.925)}.pcr-app .pcr-interaction .pcr-save{background:#4285f4}.pcr-app .pcr-interaction .pcr-clear,.pcr-app .pcr-interaction .pcr-cancel{background:#f44250}.pcr-app .pcr-interaction .pcr-clear:focus,.pcr-app .pcr-interaction .pcr-cancel:focus{box-shadow:0 0 0 1px rgba(255,255,255,0.85),0 0 0 3px rgba(244,66,80,0.75)}.pcr-app .pcr-selection .pcr-picker{position:absolute;height:18px;width:18px;border:2px solid #fff;border-radius:100%;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.pcr-app .pcr-selection .pcr-color-palette,.pcr-app .pcr-selection .pcr-color-chooser,.pcr-app .pcr-selection .pcr-color-opacity{position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:flex;flex-direction:column;cursor:grab;cursor:-webkit-grab}.pcr-app .pcr-selection .pcr-color-palette:active,.pcr-app .pcr-selection .pcr-color-chooser:active,.pcr-app .pcr-selection .pcr-color-opacity:active{cursor:grabbing;cursor:-webkit-grabbing}.pcr-app[data-theme=\'nano\']{width:14.25em;max-width:95vw}.pcr-app[data-theme=\'nano\'] .pcr-swatches{margin-top:.6em;padding:0 .6em}.pcr-app[data-theme=\'nano\'] .pcr-interaction{padding:0 .6em .6em .6em}.pcr-app[data-theme=\'nano\'] .pcr-selection{display:grid;grid-gap:.6em;grid-template-columns:1fr 4fr;grid-template-rows:5fr auto auto;align-items:center;height:10.5em;width:100%;align-self:flex-start}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview{grid-area:2 / 1 / 4 / 1;height:100%;width:100%;display:flex;flex-direction:row;justify-content:center;margin-left:.6em}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview .pcr-last-color{display:none}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview .pcr-current-color{position:relative;background:var(--pcr-color);width:2em;height:2em;border-radius:50em;overflow:hidden}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-preview .pcr-current-color::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:.5em;border-radius:.15em;z-index:-1}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-palette{grid-area:1 / 1 / 2 / 3;width:100%;height:100%;z-index:1}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-palette .pcr-palette{border-radius:.15em;width:100%;height:100%}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-palette .pcr-palette::before{position:absolute;content:\'\';top:0;left:0;width:100%;height:100%;background:url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:.5em;border-radius:.15em;z-index:-1}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser{grid-area:2 / 2 / 2 / 2}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity{grid-area:3 / 2 / 3 / 2}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser,.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity{height:0.5em;margin:0 .6em}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser .pcr-picker,.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity .pcr-picker{top:50%;transform:translateY(-50%)}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser .pcr-slider,.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity .pcr-slider{flex-grow:1;border-radius:50em}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-chooser .pcr-slider{background:linear-gradient(to right, red, #ff0, lime, cyan, blue, #f0f, red)}.pcr-app[data-theme=\'nano\'] .pcr-selection .pcr-color-opacity .pcr-slider{background:linear-gradient(to right, transparent, black),url(\'data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2 2"><path fill="white" d="M1,0H2V1H1V0ZM0,1H1V2H0V1Z"/><path fill="gray" d="M0,0H1V1H0V0ZM1,1H2V2H1V1Z"/></svg>\');background-size:100%, 0.25em}\n\n',
    {}
);
class Tc extends t.Modal {
    constructor(t, e, i) {
        if ((super(t), (this.plugin = e), (this.commandIndex = i), null !== i)) {
            const t = e.settings.customCommands[i];
            (this.commandId = t.id),
                (this.commandName = t.name),
                (this.icon = t.icon || ""),
                (this.regexPattern = t.regexPattern || ""),
                (this.regexReplacement = t.regexReplacement || ""),
                (this.regexCaseInsensitive = t.regexCaseInsensitive || !1),
                (this.regexGlobal = !1 !== t.regexGlobal),
                (this.regexMultiline = t.regexMultiline || !1),
                (this.useCondition = t.useCondition || !1),
                (this.conditionPattern = t.conditionPattern || "");
        } else
            (this.commandId = ""),
                (this.commandName = ""),
                (this.icon = ""),
                (this.regexPattern = ""),
                (this.regexReplacement = ""),
                (this.regexCaseInsensitive = !1),
                (this.regexGlobal = !0),
                (this.regexMultiline = !1),
                (this.useCondition = !1),
                (this.conditionPattern = "");
    }
    onOpen() {
        const { contentEl: e } = this;
        this.modalEl.addClass("custom-commands-modal"), e.empty(), e.createEl("h2", { text: null !== this.commandIndex ? Wr("Edit regular expression command") : Wr("Add regular expression command") });
        const i = e.createDiv("basic-settings-container");
        new t.Setting(i)
            .setName(Wr("Command ID"))
            .setDesc(Wr('Unique identifier, no spaces, e.g.: "my-custom-format"'))
            .addText(
                (t) => (
                    t.setValue(this.commandId),
                    null !== this.commandIndex
                        ? (t.setDisabled(!0), t.inputEl.addClass("id-is-disabled"))
                        : t.onChange((t) => {
                            this.commandId = t;
                            const i = e.querySelector(".setting-item:nth-child(2) input");
                            i instanceof HTMLInputElement && ((i.value = t), (this.commandName = t));
                        }),
                    t
                )
            ),
            new t.Setting(i)
                .setName(Wr("Command Name"))
                .setDesc(Wr("Displayed name in toolbar and menu"))
                .addText((t) => t.setValue(this.commandName).onChange((t) => (this.commandName = t)));
        const n = e.createDiv("regex-settings");
        (n.style.border = "1px solid var(--background-modifier-border)"), (n.style.padding = "10px"), (n.style.borderRadius = "5px"), (n.style.marginBottom = "10px");
        const o = n.createEl("details", { cls: "ai-help-container" });
        (o.style.marginBottom = "10px"), (o.style.borderRadius = "5px"), (o.style.overflow = "hidden");
        const s = o.createEl("summary", { text: Wr("How to use AI to get regular expressions?") });
        (s.style.padding = "8px 12px"), (s.style.backgroundColor = "var(--background-secondary)"), (s.style.cursor = "pointer"), (s.style.fontWeight = "bold"), (s.style.borderRadius = "4px"), (s.style.userSelect = "none");
        const r = o.createDiv("ai-help-content");
        (r.style.padding = "6px"),
            (r.style.backgroundColor = "var(--background-secondary-alt)"),
            (r.style.borderBottomLeftRadius = "5px"),
            (r.style.borderBottomRightRadius = "5px"),
            (r.style.marginTop = "1px"),
            r.setAttribute("contenteditable", "false"),
            (r.style.userSelect = "text"),
            (r.innerHTML = `\n      <p><strong>${Wr("AI question template:")}</strong><br>\n    ${Wr("[Description]")}:\n      ${Wr("I need to convert the url to a markdown format link")}\n    <br>\n    ${Wr("[Example]")}: \n      ${Wr(
                "For example, convert https://example.com to [https://example.com](https://example.com)"
            )}\n    <br>\n    ${Wr("[Requirements]")}:  \n      ${Wr("Use js regular expression to implement, and output the parameters in the following format (the result does not need to be escaped with json)")}\n    <br>\n    ${Wr(
                "[Output]"
            )}:\n    <br>\n      "name": "[Descriptive Name]", <br>\n      "pattern": "[Regex Pattern]", <br>\n      "replacement": "[Replacement Pattern, if applicable]", <br>\n      "flags": "[Regex Flags]" <br>\n    </p>\n    `),
            new t.Setting(n)
                .setName(Wr("Matching pattern"))
                .setDesc(Wr("Regex pattern to match"))
                .addText(
                    (t) =>
                    (this.regexPatternInput = t.setValue(this.regexPattern).onChange((t) => {
                        (this.regexPattern = t), this.updatePreview();
                    }))
                ),
            new t.Setting(n)
                .setName(Wr("Replacement pattern"))
                .setDesc(Wr("Replacement pattern (use $1, $2, etc. to reference capture groups)") + Wr("Use \\n to represent line breaks"))
                .addText(
                    (t) =>
                    (this.regexReplacementInput = t.setValue(this.regexReplacement.replace(/\n/g, "\\n")).onChange((t) => {
                        (this.regexReplacement = t.replace(/\\n/g, "\n")), this.updatePreview();
                    }))
                );
        const l = n.createDiv("regex-options");
        (l.style.display = "flex"),
            (l.style.gap = "8px"),
            new t.Setting(l)
                .setName(Wr("Ignore case"))
                .setDesc(Wr("Match case-insensitive"))
                .addToggle((t) =>
                    t.setValue(this.regexCaseInsensitive).onChange((t) => {
                        (this.regexCaseInsensitive = t), this.updatePreview();
                    })
                ),
            new t.Setting(l)
                .setName(Wr("Global replace"))
                .setDesc(Wr("Replace all matches"))
                .addToggle((t) =>
                    t.setValue(this.regexGlobal).onChange((t) => {
                        (this.regexGlobal = t), this.updatePreview();
                    })
                ),
            new t.Setting(l)
                .setName(Wr("Multiline mode"))
                .setDesc(Wr("^ and $ match the start and end of each line"))
                .addToggle(
                    (t) =>
                    (this.regexMultilineToggle = t.setValue(this.regexMultiline).onChange((t) => {
                        (this.regexMultiline = t), this.updatePreview();
                    }))
                );
        const a = n.createDiv("condition-container");
        new t.Setting(a)
            .setName(Wr("Use condition"))
            .setDesc(Wr("Only apply custom command when text matches the condition"))
            .addToggle(
                (t) =>
                (this.useConditionToggle = t.setValue(this.useCondition).onChange((t) => {
                    (this.useCondition = t), (c.style.display = t ? "block" : "none");
                }))
            );
        const c = a.createDiv("condition-settings");
        (c.style.display = this.useCondition ? "block" : "none"),
            (c.style.border = "1px solid var(--background-modifier-border)"),
            (c.style.padding = "10px"),
            (c.style.borderRadius = "5px"),
            (c.style.marginBottom = "15px"),
            new t.Setting(c)
                .setName(Wr("Condition pattern"))
                .setDesc(Wr("Must exist regular expression or text"))
                .addText(
                    (t) =>
                    (this.conditionPatternInput = t.setValue(this.conditionPattern).onChange((t) => {
                        this.conditionPattern = t;
                    }))
                );
        const h = new t.Setting(n).setName(Wr("Icon")).setDesc(Wr("Command icon (click to select)"));
        if (((this.iconDisplay = h.controlEl.createDiv("editingToolbarSettingsIcon")), this.icon))
            try {
                t.setIcon(this.iconDisplay, this.icon);
            } catch (t) {
                this.iconDisplay.setText(this.icon);
            }
        h.addButton((e) =>
            e.setButtonText(Wr("Choose icon")).onClick(() => {
                const e = { id: this.commandId, name: this.commandName, icon: this.icon };
                new Ur(this.plugin, e, !1, (e) => {
                    if (((this.icon = e), this.iconDisplay.empty(), this.icon))
                        try {
                            t.setIcon(this.iconDisplay, this.icon);
                        } catch (t) {
                            this.iconDisplay.setText(this.icon);
                        }
                    const i = h.controlEl.querySelector("input");
                    i && (i.value = this.icon);
                }).open();
            })
        ),
            n.createSpan("regex-help");
        const d = n.createEl("details", { cls: "regex-examples-container" });
        (d.style.marginTop = "15px"), (d.style.borderRadius = "5px"), (d.style.overflow = "hidden");
        const u = d.createEl("summary", { text: Wr("Regular expression examples") });
        (u.style.padding = "8px 12px"), (u.style.backgroundColor = "var(--background-secondary)"), (u.style.cursor = "pointer"), (u.style.fontWeight = "bold"), (u.style.borderRadius = "4px"), (u.style.userSelect = "none");
        const p = d.createDiv("examples-content");
        (p.style.padding = "10px"), (p.style.backgroundColor = "var(--background-secondary-alt)"), (p.style.borderBottomLeftRadius = "5px"), (p.style.borderBottomRightRadius = "5px"), (p.style.marginTop = "1px");
        const m = p.createEl("ul");
        (m.style.paddingLeft = "20px"),
            (m.style.margin = "0"),
            [
                { name: Wr("URL to Markdown link"), pattern: "(https?://\\S+)", replacement: "[$1]($1)" },
                { name: Wr("Convert MM/DD/YYYY to YYYY-MM-DD"), pattern: "(\\d{1,2})/(\\d{1,2})/(\\d{4})", replacement: "$3-$1-$2" },
                { name: Wr("Add bold to keywords"), pattern: "\\b(important|critical|urgent)\\b", replacement: "**$1**" },
                { name: Wr("Format phone number"), pattern: "(\\d{3})(\\d{3})(\\d{4})", replacement: "($1) $2-$3" },
                { name: Wr("Remove extra spaces"), pattern: "\\s{2,}", replacement: " " },
                { name: Wr("Convert HTML bold tags to Markdown format"), pattern: "<strong>(.*?)</strong>", replacement: "**$1**" },
                { name: Wr("Convert quoted text to quote block"), pattern: '"([^"]+)"', replacement: "> $1" },
                { name: Wr("Add uniform alias to Markdown links"), pattern: "\\[([^\\]]+)\\]\\(([^\\)]+)\\)", replacement: "[$1|alias]($2)" },
                { name: Wr("Delete empty lines (multiline mode)"), pattern: "^\\s*$\\n", replacement: "", toggleMultiline: !0 },
                { name: Wr("Add list symbol to each line (multiline mode)"), pattern: "^(.+)$", replacement: "- $1", toggleMultiline: !0 },
                { name: Wr("If the text contains important, set the text highlight (conditional format)"), pattern: "(.+)", replacement: "==$1==", useCondition: !0, conditionPattern: "important" },
            ].forEach((t) => {
                const e = m.createEl("li");
                e.style.marginBottom = "8px";
                const i = e.createEl("a", { text: t.name, href: "#" });
                (i.style.color = "var(--text-accent)"),
                    (i.style.textDecoration = "none"),
                    i.addEventListener("mouseenter", () => {
                        i.style.textDecoration = "underline";
                    }),
                    i.addEventListener("mouseleave", () => {
                        i.style.textDecoration = "none";
                    }),
                    i.addEventListener("click", (e) => {
                        e.preventDefault(),
                            (this.regexPattern = t.pattern),
                            (this.regexReplacement = t.replacement),
                            this.regexPatternInput.setValue(t.pattern),
                            this.regexReplacementInput.setValue(t.replacement),
                            t.useCondition
                                ? ((this.useCondition = !0), (this.conditionPattern = t.conditionPattern || ""), this.useConditionToggle.setValue(!0), this.conditionPatternInput.setValue(this.conditionPattern), (c.style.display = "block"))
                                : ((this.useCondition = !1), this.useConditionToggle.setValue(!1), this.conditionPatternInput.setValue(""), (c.style.display = "none")),
                            t.toggleMultiline ? this.regexMultilineToggle.setValue(!0) : this.regexMultilineToggle.setValue(!1),
                            this.updatePreview(),
                            d.removeAttribute("open");
                    });
            });
        const g = e.createDiv("preview-container");
        (g.style.marginTop = "20px"),
            (g.style.marginBottom = "20px"),
            (g.style.border = "1px solid var(--background-modifier-border)"),
            (g.style.padding = "10px"),
            (g.style.borderRadius = "5px"),
            g.createEl("label", { text: Wr("Preview") });
        const f = g.createDiv("preview-input-container");
        f.style.marginBottom = "10px";
        const b = f.createEl("label", { text: Wr("Example text:") });
        (b.style.display = "block"),
            (b.style.marginBottom = "5px"),
            (this.previewInput = f.createEl("textarea", { attr: { placeholder: Wr("Input example text to view the formatting effect of the command...") } })),
            (this.previewInput.style.height = "auto"),
            (this.previewInput.style.width = "100%"),
            (this.previewInput.style.padding = "8px"),
            (this.previewInput.style.borderRadius = "4px"),
            (this.previewInput.style.border = "1px solid var(--background-modifier-border)"),
            (this.previewInput.value = "Sample text https://example.com important text    1234567890"),
            this.previewInput.addEventListener("input", () => {
                this.updatePreview();
            });
        const v = g.createDiv("preview-output-container"),
            y = v.createEl("label", { text: Wr("Result:") });
        (y.style.display = "block"),
            (y.style.marginBottom = "5px"),
            (this.previewOutput = v.createDiv("preview-output")),
            (this.previewOutput.style.padding = "8px"),
            (this.previewOutput.style.borderRadius = "4px"),
            (this.previewOutput.style.border = "1px solid var(--background-modifier-border)"),
            (this.previewOutput.style.backgroundColor = "var(--background-secondary)"),
            (this.previewOutput.style.minHeight = "3em"),
            this.updatePreview(),
            new t.Setting(e)
                .addButton((e) =>
                    e
                        .setButtonText("保存")
                        .setCta()
                        .onClick(() => {
                            if (!this.commandId || !this.commandName) return void new t.Notice(Wr("Command ID and command name cannot be empty"));
                            if (this.commandId.includes(" ")) return void new t.Notice(Wr("Command ID cannot contain spaces"));
                            if (!this.regexPattern) return void new t.Notice(Wr("Regex pattern cannot be empty"));
                            const e = null === this.commandIndex ? `custom-${this.commandId}` : this.commandId;
                            if (null === this.commandIndex && this.plugin.settings.customCommands.findIndex((t) => t.id === e) >= 0) return void new t.Notice(Wr("Command") + " " + this.commandId + " " + Wr("already exists"), 8e3);
                            const i = {
                                id: e,
                                name: this.commandName,
                                icon: this.icon,
                                useRegex: !0,
                                regexPattern: this.regexPattern,
                                regexReplacement: this.regexReplacement.replace(/\\n/g, "\n"),
                                regexCaseInsensitive: this.regexCaseInsensitive,
                                regexGlobal: this.regexGlobal,
                                regexMultiline: this.regexMultiline,
                                useCondition: this.useCondition,
                                conditionPattern: this.conditionPattern,
                                prefix: "",
                                suffix: "",
                                char: 0,
                                line: 0,
                                islinehead: !1,
                            };
                            null !== this.commandIndex ? (this.plugin.settings.customCommands[this.commandIndex] = i) : this.plugin.settings.customCommands.push(i),
                                this.plugin.saveSettings().then(() => {
                                    this.close(),
                                        setTimeout(() => {
                                            dispatchEvent(new Event("editingToolbar-NewCommand")), this.plugin.reloadCustomCommands();
                                        }, 100);
                                });
                        })
                )
                .addButton((t) => t.setButtonText(Wr("Cancel")).onClick(() => this.close()));
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty();
    }
    updatePreview() {
        var t;
        const e = this.previewInput.value;
        let i = e;
        try {
            if (this.regexPattern) {
                let t = "";
                this.regexGlobal && (t += "g"), this.regexCaseInsensitive && (t += "i"), this.regexMultiline && (t += "m");
                const n = new RegExp(this.regexPattern, t),
                    o = this.regexReplacement.replace(/\\n/g, "\n");
                (i = e.replace(n, o)), this.showCompleteRegexCode(t);
            }
            this.previewOutput.empty(),
                i.split("\n").forEach((t, e, i) => {
                    this.previewOutput.createSpan({ text: t }), e < i.length - 1 && this.previewOutput.createEl("br");
                }),
                (this.previewOutput.style.color = "var(--text-normal)");
        } catch (e) {
            this.previewOutput.setText(Wr("Error: ") + e.message), (this.previewOutput.style.color = "var(--text-error)");
            const i = null === (t = this.previewOutput.parentElement) || void 0 === t ? void 0 : t.querySelector(".regex-code-container");
            i && i.remove();
        }
    }
    showCompleteRegexCode(t) {
        const e = this.previewOutput.parentElement;
        if (!e) return;
        let i = e.querySelector(".regex-code-container");
        if (i) {
            i.empty();
            const t = i.createEl("div", { text: Wr("Complete regular expression code (copy to AI for explanation)") });
            (t.style.marginBottom = "5px"), (t.style.fontWeight = "bold");
        } else {
            (i = e.createDiv("regex-code-container")), (i.style.marginTop = "15px"), (i.style.borderTop = "1px solid var(--background-modifier-border)"), (i.style.paddingTop = "10px");
            const t = i.createEl("div", { text: Wr("Complete regular expression code (copy to AI for explanation)") });
            (t.style.marginBottom = "5px"), (t.style.fontWeight = "bold");
        }
        const n = i.createEl("pre");
        (n.style.backgroundColor = "var(--background-code)"), (n.style.padding = "8px"), (n.style.borderRadius = "4px"), (n.style.overflowX = "auto"), (n.style.fontFamily = "monospace"), (n.style.fontSize = "var(--font-smaller)");
        let o = `//${Wr("Explain the syntax of JavaScript regular expressions")}\n`;
        (o += `const regex = /${this.escapeRegexForDisplay(this.regexPattern)}/${t};\n`),
            (o += `const result = text.replace(regex, "${this.escapeStringForDisplay(this.regexReplacement)}");\n`),
            this.useCondition &&
            this.conditionPattern &&
            ((o += `\n//${Wr("Conditional matching")}\n`),
                (o += `const condition = /${this.escapeRegexForDisplay(this.conditionPattern)}/;\n`),
                (o += "if (condition.test(text)) {\n"),
                (o += `  //${Wr("Apply regular expression replacement")}\n`),
                (o += `  const result = text.replace(regex, "${this.escapeStringForDisplay(this.regexReplacement)}");\n`),
                (o += "}")),
            (n.textContent = o);
        const s = i.createEl("button", { text: Wr("Copy code") });
        (s.style.marginTop = "5px"),
            (s.style.padding = "4px 8px"),
            (s.style.borderRadius = "4px"),
            (s.style.cursor = "pointer"),
            s.addEventListener("click", () => {
                navigator.clipboard.writeText(o).then(() => {
                    (s.textContent = Wr("Copied!")),
                        setTimeout(() => {
                            s.textContent = Wr("Copy code");
                        }, 2e3);
                });
            });
    }
    escapeRegexForDisplay(t) {
        return t.replace(/\\/g, "\\\\");
    }
    escapeStringForDisplay(t) {
        return t.replace(/"/g, '\\"');
    }
}
class Ec extends t.Modal {
    constructor(t, e, i) {
        if ((super(t), (this.plugin = e), (this.commandIndex = i), null !== i)) {
            const t = e.settings.customCommands[i];
            (this.commandId = t.id), (this.commandName = t.name), (this.prefix = t.prefix), (this.suffix = t.suffix), (this.char = t.char), (this.line = t.line), (this.islinehead = t.islinehead), (this.icon = t.icon || "");
        } else (this.commandId = ""), (this.commandName = ""), (this.prefix = ""), (this.suffix = ""), (this.char = 0), (this.line = 0), (this.islinehead = !1), (this.icon = "");
    }
    onOpen() {
        const { contentEl: e } = this;
        this.modalEl.addClass("custom-commands-modal"), e.empty(), e.createEl("h2", { text: null !== this.commandIndex ? Wr("Edit Custom Command") : Wr("Add Custom Command") });
        const i = e.createDiv("switch-to-regex-container");
        (i.style.marginBottom = "20px"), (i.style.textAlign = "center");
        const n = i.createEl("button", { text: Wr("Switch Regex Command Window") });
        n.addClass("mod-cta"),
            n.addEventListener("click", () => {
                this.close(), new Tc(this.app, this.plugin, null).open();
            }),
            new t.Setting(e)
                .setName(Wr("Command ID"))
                .setDesc(Wr('Unique identifier, no spaces, e.g.: "my-custom-format"'))
                .addText(
                    (t) => (
                        (this.commandIdInput = t),
                        t.setValue(this.commandId),
                        null !== this.commandIndex
                            ? (t.setDisabled(!0), t.inputEl.addClass("id-is-disabled"))
                            : t.onChange((t) => {
                                (this.commandId = t), this.commandNameInput && (this.commandNameInput.setValue(t), (this.commandName = t));
                            }),
                        t
                    )
                ),
            new t.Setting(e)
                .setName(Wr("Command Name"))
                .setDesc(Wr("Displayed name in toolbar and menu"))
                .addText((t) => (this.commandNameInput = t.setValue(this.commandName).onChange((t) => (this.commandName = t))));
        const o = { "\n": "↵", "\t": "⇥" },
            s = Object.fromEntries(Object.entries(o).map(([t, e]) => [e, t]));
        function r(t) {
            let e = t;
            for (const [t, i] of Object.entries(o)) e = e.replace(new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"), i);
            return e;
        }
        function l(t) {
            let e = t;
            for (const [t, i] of Object.entries(s)) e = e.replace(new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"), i);
            return e;
        }
        const a = Object.entries(o).map(([t, e]) => {
            let i = e;
            switch (t) {
                case "\n":
                    i += " (New Line)";
                    break;
                case "\t":
                    i += " (Tab)";
            }
            return { placeholder: e, label: i };
        });
        function c(t, e) {
            e.setAttribute("title", "点击可选择并复制文本");
            const i = t.controlEl.createDiv({ cls: "special-char-buttons" });
            (i.style.display = "flex"),
                (i.style.flexWrap = "wrap"),
                (i.style.gap = "5px"),
                (i.style.marginTop = "5px"),
                a.forEach(({ placeholder: t, label: e }) => {
                    const n = i.createDiv({ cls: "char-copy-container" });
                    (n.style.position = "relative"), (n.style.display = "inline-block");
                    const o = n.createEl("button", { text: e });
                    (o.style.padding = "2px 6px"),
                        (o.style.fontSize = "12px"),
                        (o.style.minWidth = "auto"),
                        (o.style.border = "1px solid var(--background-modifier-border)"),
                        (o.style.cursor = "pointer"),
                        o.setAttribute("data-char", t),
                        o.addEventListener("click", (e) => {
                            e.preventDefault(),
                                navigator.clipboard
                                    .writeText(t)
                                    .then(() => {
                                        const t = n.createDiv({ cls: "copy-tooltip" });
                                        (t.style.position = "absolute"),
                                            (t.style.bottom = "100%"),
                                            (t.style.left = "50%"),
                                            (t.style.transform = "translateX(-50%)"),
                                            (t.style.backgroundColor = "var(--background-modifier-success)"),
                                            (t.style.color = "white"),
                                            (t.style.padding = "2px 6px"),
                                            (t.style.borderRadius = "4px"),
                                            (t.style.fontSize = "12px"),
                                            (t.style.pointerEvents = "none"),
                                            (t.style.whiteSpace = "nowrap"),
                                            (t.style.zIndex = "100"),
                                            (t.textContent = "已复制!"),
                                            setTimeout(() => {
                                                t.remove();
                                            }, 2e3);
                                    })
                                    .catch((t) => { });
                        }),
                        o.addEventListener("mouseenter", () => {
                            (o.style.backgroundColor = "var(--interactive-accent)"), (o.style.color = "var(--text-on-accent)");
                        }),
                        o.addEventListener("mouseleave", () => {
                            (o.style.backgroundColor = ""), (o.style.color = "");
                        });
                });
        }
        const h = new t.Setting(e)
            .setName(Wr("Prefix"))
            .setDesc(Wr("Add content before selected text") + Wr("Use ↵ to represent line breaks"))
            .addText((t) =>
                t.setValue(r(this.prefix)).onChange((t) => {
                    this.prefix = l(t);
                    const e = this.getMirrorText(t);
                    e && ((this.suffix = l(e)), this.suffixInput.setValue(e));
                })
            );
        c(h, h.controlEl.querySelector("input"));
        const d = new t.Setting(e)
            .setName(Wr("Suffix"))
            .setDesc(Wr("Add content after selected text"))
            .addText((t) => {
                (this.suffixInput = t),
                    t.setValue(r(this.suffix)).onChange((t) => {
                        this.suffix = l(t);
                    });
            });
        c(d, d.controlEl.querySelector("input")),
            new t.Setting(e)
                .setName(Wr("Cursor Position Offset"))
                .setDesc(Wr("Default 0, format will keep the text selected"))
                .addText((t) => t.setValue(this.char.toString()).onChange((t) => (this.char = parseInt(t) || 0))),
            new t.Setting(e)
                .setName(Wr("Line Offset"))
                .setDesc(Wr("Line offset of cursor after formatting"))
                .addText((t) => t.setValue(this.line.toString()).onChange((t) => (this.line = parseInt(t) || 0))),
            new t.Setting(e)
                .setName(Wr("Line Head Format"))
                .setDesc(Wr("Whether to insert at the beginning of the next line"))
                .addToggle((t) => t.setValue(this.islinehead).onChange((t) => (this.islinehead = t)));
        const u = new t.Setting(e).setName(Wr("Icon")).setDesc(Wr("Command icon (click to select)"));
        if (((this.iconDisplay = u.controlEl.createDiv("editingToolbarSettingsIcon")), this.icon))
            try {
                t.setIcon(this.iconDisplay, this.icon);
            } catch (t) {
                this.iconDisplay.setText(this.icon);
            }
        u.addButton((e) =>
            e.setButtonText(Wr("Choose Icon")).onClick(() => {
                const e = { id: this.commandId, name: this.commandName, icon: this.icon };
                new Ur(this.plugin, e, !1, (e) => {
                    if (((this.icon = e), this.iconDisplay.empty(), this.icon))
                        try {
                            t.setIcon(this.iconDisplay, this.icon);
                        } catch (t) {
                            this.iconDisplay.setText(this.icon);
                        }
                    const i = u.controlEl.querySelector("input");
                    i && (i.value = this.icon);
                }).open();
            })
        ),
            new t.Setting(e)
                .addButton((e) =>
                    e
                        .setButtonText(Wr("Save"))
                        .setCta()
                        .onClick(() => {
                            if (!this.commandId || !this.commandName) return void new t.Notice(Wr("Command ID and command name cannot be empty"));
                            if (this.commandId.includes(" ")) return void new t.Notice(Wr("Command ID cannot contain spaces"));
                            const e = null === this.commandIndex ? `custom-${this.commandId}` : this.commandId;
                            if (null === this.commandIndex && this.plugin.settings.customCommands.findIndex((t) => t.id === e) >= 0) return void new t.Notice(Wr("The command") + this.commandId + Wr("already exists"), 8e3);
                            const i = { id: e, name: this.commandName, prefix: this.prefix, suffix: this.suffix, char: this.char, line: this.line, islinehead: this.islinehead, icon: this.icon };
                            if (null !== this.commandIndex) {
                                if (this.plugin.settings.customCommands[this.commandIndex].icon !== this.icon) {
                                    const t = `editing-toolbar:${e}`;
                                    this.updateCommandIcon(this.plugin.settings.menuCommands, t),
                                        this.plugin.settings.enableMultipleConfig &&
                                        (this.updateCommandIcon(this.plugin.settings.followingCommands, t),
                                            this.updateCommandIcon(this.plugin.settings.topCommands, t),
                                            this.updateCommandIcon(this.plugin.settings.fixedCommands, t),
                                            this.plugin.settings.isLoadOnMobile && this.updateCommandIcon(this.plugin.settings.mobileCommands, t));
                                }
                                this.plugin.settings.customCommands[this.commandIndex] = i;
                            } else this.plugin.settings.customCommands.push(i);
                            this.plugin.saveSettings().then(() => {
                                this.close(),
                                    setTimeout(() => {
                                        dispatchEvent(new Event("editingToolbar-NewCommand")), this.plugin.reloadCustomCommands();
                                    }, 100);
                            });
                        })
                )
                .addButton((t) => t.setButtonText(Wr("Cancel")).onClick(() => this.close())),
            setTimeout(() => {
                this.commandIndex ? this.commandIdInput.inputEl.focus() : this.commandNameInput.inputEl.focus();
            }, 10);
    }
    updateCommandIcon(t, e) {
        t &&
            t.forEach((t) => {
                t.id === e && (t.icon = this.icon), t.SubmenuCommands && this.updateCommandIcon(t.SubmenuCommands, e);
            });
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty();
    }
    getMirrorText(t) {
        const e = { "**": "**", "*": "*", __: "__", _: "_", "~~": "~~", "`": "`", "```": "```", $: "$", $$: "$$", "(": ")", "[": "]", "{": "}", "<": ">", "==": "==", "*==": "==*", "**==": "==**", "***==": "==***" };
        if (!t) return "";
        if (t in e) return e[t];
        const i = t.match(/^<(\w+)([^>]*)>$/);
        return i ? `</${i[1]}>` : "";
    }
}
class Mc extends t.Modal {
    constructor(t, e, i) {
        super(t),
            (this.deployOptions = []),
            (this.plugin = e),
            (this.command = i),
            (this.deployOptions = [
                { id: "following", name: Wr("Following Style"), enabled: !0 },
                { id: "top", name: Wr("Top Style"), enabled: !0 },
                { id: "fixed", name: Wr("Fixed Style"), enabled: !0 },
            ]),
            this.plugin.settings.isLoadOnMobile && this.deployOptions.push({ id: "mobile", name: Wr("Mobile Style"), enabled: !0 });
    }
    onOpen() {
        const { contentEl: e } = this;
        e.empty(), e.createEl("h3", { text: Wr("Deploy command to configurations") }), e.createDiv("deploy-option");
        const i = e.createDiv("deploy-options");
        this.deployOptions.forEach((e) => {
            new t.Setting(i)
                .setName(e.name)
                .addToggle((t) =>
                    t.setValue(e.enabled).onChange((t) => {
                        e.enabled = t;
                    })
                )
                .settingEl.addClass("deploy-option");
        });
        const n = e.createDiv("deploy-buttons");
        new t.Setting(n)
            .addButton((t) =>
                t
                    .setButtonText(Wr("Deploy"))
                    .setCta()
                    .onClick(() => {
                        this.deployCommand(), this.close();
                    })
            )
            .addButton((t) =>
                t.setButtonText(Wr("Cancel")).onClick(() => {
                    this.close();
                })
            );
    }
    deployCommand() {
        const e = { id: `editing-toolbar:${this.command.id}`, name: this.command.name, icon: this.command.icon || "obsidian-new" };
        this.plugin.settings.menuCommands.some((t) => t.id === e.id) || this.plugin.settings.menuCommands.push(Object.assign({}, e));
        let i = 0;
        this.deployOptions.forEach((t) => {
            if (t.enabled) {
                let n;
                switch (t.id) {
                    case "mobile":
                        n = this.plugin.settings.mobileCommands;
                        break;
                    case "following":
                        n = this.plugin.settings.followingCommands;
                        break;
                    case "top":
                        n = this.plugin.settings.topCommands;
                        break;
                    case "fixed":
                        n = this.plugin.settings.fixedCommands;
                }
                n && !n.some((t) => t.id === e.id) && (n.push(Object.assign({}, e)), i++);
            }
        }),
            this.plugin.saveSettings().then(() => {
                let e = "";
                if (i > 0) {
                    const t = this.deployOptions
                        .filter((t) => t.enabled)
                        .map((t) => t.name)
                        .join(", ");
                    e = Wr("Command deployed to: ") + t;
                } else e = Wr("Command already exists in selected configurations");
                new t.Notice(e), dispatchEvent(new Event("editingToolbar-NewCommand")), this.plugin.reloadCustomCommands();
            });
    }
}
class Ac extends t.Modal {
    constructor(t, e, i) {
        super(t), (this.plugin = e), (this.mode = i), (this.exportType = "all"), (this.importMode = "update");
    }
    onOpen() {
        const { contentEl: e } = this;
        if ((e.addClass("editing-toolbar-import-export-modal"), e.createEl("h2", { text: "import" === this.mode ? Wr("Import Configuration") : Wr("Export Configuration"), cls: "import-export-title" }), "export" === this.mode)) {
            new t.Setting(e)
                .setName(Wr("Export Type"))
                .setDesc(Wr("Choose what to export"))
                .addDropdown((t) => {
                    t.addOption("all", Wr("All Settings")).addOption("All commands", Wr("All Toolbar Commands")).addOption("custom", Wr("Custom Commands Only")),
                        this.plugin.settings.enableMultipleConfig &&
                        t.addOption("following", Wr("Following Style Only")).addOption("top", Wr("Top Style Only")).addOption("fixed", Wr("Fixed Style Only")).addOption("mobile", Wr("Mobile Style Only")),
                        t.setValue(this.exportType).onChange((t) => {
                            (this.exportType = t), this.updateExportContent();
                        });
                });
            const i = e.createDiv("export-container");
            (i.style.border = "1px solid var(--background-modifier-border)"),
                (i.style.padding = "10px"),
                (i.style.borderRadius = "5px"),
                (this.textArea = new t.TextAreaComponent(i)),
                this.textArea
                    .setValue("")
                    .setPlaceholder(Wr("Loading..."))
                    .then((t) => {
                        (t.inputEl.style.width = "100%"),
                            (t.inputEl.style.height = "200px"),
                            (t.inputEl.style.fontFamily = "monospace"),
                            (t.inputEl.style.fontSize = "12px"),
                            (t.inputEl.style.padding = "8px"),
                            (t.inputEl.style.border = "1px solid var(--background-modifier-border)"),
                            (t.inputEl.style.borderRadius = "4px");
                    }),
                this.updateExportContent();
            const n = e.createDiv("import-export-button-container");
            (n.style.display = "flex"),
                (n.style.justifyContent = "flex-end"),
                (n.style.marginTop = "16px"),
                n.createEl("button", { text: Wr("Copy to Clipboard"), cls: "mod-cta" }).addEventListener("click", () => {
                    navigator.clipboard
                        .writeText(this.textArea.getValue())
                        .then(() => {
                            new t.Notice(Wr("Configuration copied to clipboard"));
                        })
                        .catch((e) => {
                            new t.Notice(Wr("Failed to copy configuration"));
                        });
                });
        } else {
            new t.Setting(e)
                .setName(Wr("Import Mode"))
                .setDesc(Wr("Choose how to import the configuration"))
                .addDropdown((t) => {
                    t.addOption("update", Wr("Update Mode (Add new items and update existing ones)"))
                        .addOption("overwrite", Wr("Overwrite Mode (Replace settings with imported ones)"))
                        .setValue(this.importMode)
                        .onChange((t) => {
                            (this.importMode = t),
                                this.importButton.setButtonText("overwrite" === this.importMode ? Wr("Overwrite Import") : Wr("Update Import")),
                                this.warningContent.setText(
                                    "overwrite" === this.importMode ? Wr("Warning: Overwrite mode will replace existing settings with imported ones.") : Wr("Warning: Update mode will add new items and update existing ones.")
                                );
                        });
                });
            const i = e.createDiv("import-container");
            (i.style.border = "1px solid var(--background-modifier-border)"),
                (i.style.padding = "10px"),
                (i.style.borderRadius = "5px"),
                (this.textArea = new t.TextAreaComponent(i)),
                this.textArea
                    .setValue("")
                    .setPlaceholder(Wr("Paste configuration here..."))
                    .then((t) => {
                        (t.inputEl.style.width = "100%"),
                            (t.inputEl.style.height = "200px"),
                            (t.inputEl.style.fontFamily = "monospace"),
                            (t.inputEl.style.fontSize = "12px"),
                            (t.inputEl.style.padding = "8px"),
                            (t.inputEl.style.border = "1px solid var(--background-modifier-border)"),
                            (t.inputEl.style.borderRadius = "4px");
                    });
            const n = e.createDiv("import-export-button-container");
            (n.style.display = "flex"),
                (n.style.justifyContent = "flex-end"),
                (n.style.marginTop = "16px"),
                new t.Setting(n).addButton((t) => {
                    this.importButton = t
                        .setIcon("import")
                        .setButtonText(Wr("Import Configuration"))
                        .onClick(() => {
                            this.importConfiguration();
                        });
                });
            const o = e.createDiv("import-export-warning");
            (o.style.marginTop = "16px"), (o.style.padding = "8px 12px"), (o.style.backgroundColor = "rgba(var(--color-red-rgb), 0.1)"), (o.style.borderRadius = "4px"), (o.style.border = "1px solid rgba(var(--color-red-rgb), 0.3)");
            const s = o.createEl("p", { text: Wr("Warning: Update mode will add new items and update existing ones."), cls: "warning-text" });
            (s.style.margin = "0"), (this.warningContent = s);
        }
    }
    updateExportContent() {
        let t = { _exportInfo: { version: this.plugin.manifest.version, exportType: this.exportType, exportTime: new Date().toISOString(), pluginId: this.plugin.manifest.id } };
        switch (this.exportType) {
            case "all":
                t = Object.assign(Object.assign({}, t), {
                    menuCommands: this.plugin.settings.menuCommands || [],
                    followingCommands: this.plugin.settings.followingCommands || [],
                    topCommands: this.plugin.settings.topCommands || [],
                    fixedCommands: this.plugin.settings.fixedCommands || [],
                    mobileCommands: this.plugin.settings.mobileCommands || [],
                    customCommands: this.plugin.settings.customCommands || [],
                    enableMultipleConfig: this.plugin.settings.enableMultipleConfig,
                    positionStyle: this.plugin.settings.positionStyle,
                    aestheticStyle: this.plugin.settings.aestheticStyle,
                    appendMethod: this.plugin.settings.appendMethod,
                    autohide: this.plugin.settings.autohide,
                    isLoadOnMobile: this.plugin.settings.isLoadOnMobile,
                    cMenuNumRows: this.plugin.settings.cMenuNumRows,
                    custom_bg1: this.plugin.settings.custom_bg1,
                    custom_bg2: this.plugin.settings.custom_bg2,
                    custom_bg3: this.plugin.settings.custom_bg3,
                    custom_bg4: this.plugin.settings.custom_bg4,
                    custom_bg5: this.plugin.settings.custom_bg5,
                    custom_fc1: this.plugin.settings.custom_fc1,
                    custom_fc2: this.plugin.settings.custom_fc2,
                    custom_fc3: this.plugin.settings.custom_fc3,
                    custom_fc4: this.plugin.settings.custom_fc4,
                    custom_fc5: this.plugin.settings.custom_fc5,
                    toolbarBackgroundColor: this.plugin.settings.toolbarBackgroundColor,
                    toolbarIconColor: this.plugin.settings.toolbarIconColor,
                    toolbarIconSize: this.plugin.settings.toolbarIconSize,
                });
                break;
            case "All commands":
                t = Object.assign(Object.assign({}, t), {
                    menuCommands: this.plugin.settings.menuCommands || [],
                    followingCommands: this.plugin.settings.followingCommands || [],
                    topCommands: this.plugin.settings.topCommands || [],
                    fixedCommands: this.plugin.settings.fixedCommands || [],
                    mobileCommands: this.plugin.settings.mobileCommands || [],
                    enableMultipleConfig: this.plugin.settings.enableMultipleConfig,
                });
                break;
            case "custom":
                t = Object.assign(Object.assign({}, t), { customCommands: this.plugin.settings.customCommands || [] });
                break;
            case "following":
                t = Object.assign(Object.assign({}, t), { followingCommands: this.plugin.settings.followingCommands || [] });
                break;
            case "top":
                t = Object.assign(Object.assign({}, t), { topCommands: this.plugin.settings.topCommands || [] });
                break;
            case "fixed":
                t = Object.assign(Object.assign({}, t), { fixedCommands: this.plugin.settings.fixedCommands || [] });
                break;
            case "mobile":
                t = Object.assign(Object.assign({}, t), { mobileCommands: this.plugin.settings.mobileCommands || [] });
        }
        this.validateExportContent(t), this.textArea.setValue(JSON.stringify(t, null, 2));
    }
    validateExportContent(t) {
        ["menuCommands", "followingCommands", "topCommands", "fixedCommands", "mobileCommands", "customCommands"].forEach((e) => {
            e in t && !t[e] && (t[e] = []);
        }),
            "enableMultipleConfig" in t && void 0 === t.enableMultipleConfig && (t.enableMultipleConfig = !1),
            "autohide" in t && void 0 === t.autohide && (t.autohide = !1),
            "Iscentered" in t && void 0 === t.Iscentered && (t.Iscentered = !1),
            "isLoadOnMobile" in t && void 0 === t.isLoadOnMobile && (t.isLoadOnMobile = !0),
            "positionStyle" in t && !t.positionStyle && (t.positionStyle = "top"),
            "aestheticStyle" in t && !t.aestheticStyle && (t.aestheticStyle = "default"),
            "appendMethod" in t && !t.appendMethod && (t.appendMethod = "workspace"),
            "cMenuNumRows" in t && void 0 === t.cMenuNumRows && (t.cMenuNumRows = 1);
    }
    importConfiguration() {
        return e(this, void 0, void 0, function* () {
            try {
                const i = this.textArea.getValue();
                if (!i.trim()) return void new t.Notice(Wr("Please paste configuration data first"));
                const n = JSON.parse(i);
                if (!n || "object" != typeof n) return void new t.Notice(Wr("Invalid import data format"));
                const o = "menuCommands" in n,
                    s = "customCommands" in n,
                    r = "followingCommands" in n,
                    l = "topCommands" in n,
                    a = "fixedCommands" in n,
                    c = "mobileCommands" in n,
                    h = "positionStyle" in n || "aestheticStyle" in n,
                    d = "enableMultipleConfig" in n,
                    u = n.positionStyle,
                    p = o && Array.isArray(n.menuCommands) && n.menuCommands.length > 0,
                    m = s && Array.isArray(n.customCommands) && n.customCommands.length > 0,
                    g = r && Array.isArray(n.followingCommands) && n.followingCommands.length > 0,
                    f = l && Array.isArray(n.topCommands) && n.topCommands.length > 0,
                    b = a && Array.isArray(n.fixedCommands) && n.fixedCommands.length > 0,
                    v = c && Array.isArray(n.mobileCommands) && n.mobileCommands.length > 0,
                    y = o && (!Array.isArray(n.menuCommands) || 0 === n.menuCommands.length),
                    w = s && (!Array.isArray(n.customCommands) || 0 === n.customCommands.length),
                    C = r && (!Array.isArray(n.followingCommands) || 0 === n.followingCommands.length),
                    x = l && (!Array.isArray(n.topCommands) || 0 === n.topCommands.length),
                    k = a && (!Array.isArray(n.fixedCommands) || 0 === n.fixedCommands.length),
                    S = c && (!Array.isArray(n.mobileCommands) || 0 === n.mobileCommands.length);
                let T = Wr("This import will:") + "\n";
                if (
                    (h && (T += "• " + Wr("Update general settings") + "\n"),
                        p && (T += "• " + Wr("Update Main Menu Commands") + " (" + n.menuCommands.length + " )\n"),
                        m && (T += "• " + Wr("Update Custom Commands") + " (" + n.customCommands.length + " )\n"),
                        g && (T += "• " + Wr("Update Following Style Commands") + " (" + n.followingCommands.length + " )\n"),
                        f && (T += "• " + Wr("Update Top Style Commands") + " (" + n.topCommands.length + " )\n"),
                        b && (T += "• " + Wr("Update Fixed Style Commands") + " (" + n.fixedCommands.length + " )\n"),
                        v && (T += "• " + Wr("Update Mobile Style Commands") + " (" + n.mobileCommands.length + " )\n"),
                        "overwrite" === this.importMode &&
                        (y && (T += "• " + Wr("Clear all Main Menu Commands") + " ⚠️\n"),
                            w && (T += "• " + Wr("Clear all Custom Commands") + " ⚠️\n"),
                            C && (T += "• " + Wr("Clear all Following Style Commands") + " ⚠️\n"),
                            x && (T += "• " + Wr("Clear all Top Style Commands") + " ⚠️\n"),
                            k && (T += "• " + Wr("Clear all Fixed Style Commands") + " ⚠️\n"),
                            S && (T += "• " + Wr("Clear all Mobile Style Commands") + " ⚠️\n")),
                        d)
                ) {
                    const t = n.enableMultipleConfig ? Wr("Enable") : Wr("Disable");
                    T += "• " + Wr("Set Multiple Config to:") + " " + t + "\n";
                }
                if ((u && (T += "• " + Wr("Set Position Style to:") + " " + this.getPositionStyleName(u) + "\n"), !(p || m || g || f || b || v || y || w || C || x || k || S || h || d)))
                    return void new t.Notice(Wr("No valid configuration found in import data"));
                "overwrite" === this.importMode ? (T += "\n" + Wr("⚠️ Overwrite mode will replace existing settings with imported ones.")) : (T += "\n" + Wr("ℹ️ Update mode will merge imported settings with existing ones.")),
                    vc.show(this.app, {
                        message: T + "\n" + Wr("Do you want to continue?"),
                        onConfirm: () =>
                            e(this, void 0, void 0, function* () {
                                const e = {
                                    positionStyle: this.plugin.settings.positionStyle,
                                    menuCommands: [...this.plugin.settings.menuCommands],
                                    customCommands: [...this.plugin.settings.customCommands],
                                    followingCommands: [...this.plugin.settings.followingCommands],
                                    topCommands: [...this.plugin.settings.topCommands],
                                    fixedCommands: [...this.plugin.settings.fixedCommands],
                                    mobileCommands: [...this.plugin.settings.mobileCommands],
                                };
                                try {
                                    "overwrite" === this.importMode ? this.performOverwriteImport(n) : this.performUpdateImport(n),
                                        this.fixImportedCommandIds(),
                                        yield this.plugin.saveSettings(),
                                        this.plugin.reloadCustomCommands(),
                                        dispatchEvent(new Event("editingToolbar-NewCommand")),
                                        new t.Notice(Wr("Configuration imported successfully")),
                                        this.close();
                                } catch (t) {
                                    throw (this.restoreBackup(e), t);
                                }
                            }),
                    });
            } catch (e) {
                new t.Notice(Wr("Error:") + " " + e.message);
            }
        });
    }
    performOverwriteImport(t) {
        this.importGeneralSettings(t),
            t.menuCommands && (this.plugin.settings.menuCommands = t.menuCommands),
            t.customCommands && (this.plugin.settings.customCommands = t.customCommands),
            t.followingCommands && (this.plugin.settings.followingCommands = t.followingCommands),
            t.topCommands && (this.plugin.settings.topCommands = t.topCommands),
            t.fixedCommands && (this.plugin.settings.fixedCommands = t.fixedCommands),
            t.mobileCommands && (this.plugin.settings.mobileCommands = t.mobileCommands);
    }
    performUpdateImport(t) {
        this.importGeneralSettings(t),
            t.menuCommands && this.updateCommandArray(this.plugin.settings.menuCommands, t.menuCommands),
            t.customCommands && this.updateCommandArray(this.plugin.settings.customCommands, t.customCommands),
            t.followingCommands && this.updateCommandArray(this.plugin.settings.followingCommands, t.followingCommands),
            t.topCommands && this.updateCommandArray(this.plugin.settings.topCommands, t.topCommands),
            t.fixedCommands && this.updateCommandArray(this.plugin.settings.fixedCommands, t.fixedCommands),
            t.mobileCommands && this.updateCommandArray(this.plugin.settings.mobileCommands, t.mobileCommands);
    }
    updateCommandArray(t, e) {
        return t
            ? (e.forEach((e) => {
                var i;
                const n = t.findIndex((t) => t.id === e.id);
                n >= 0 ? (t[n] = e) : t.push(e), e.SubmenuCommands && (null === (i = t[n]) || void 0 === i ? void 0 : i.SubmenuCommands) && this.updateCommandArray(t[n].SubmenuCommands, e.SubmenuCommands);
            }),
                t)
            : e.slice();
    }
    importGeneralSettings(t) {
        [
            "positionStyle",
            "aestheticStyle",
            "appendMethod",
            "autohide",
            "Iscentered",
            "isLoadOnMobile",
            "cMenuNumRows",
            "enableMultipleConfig",
            "custom_bg1",
            "custom_bg2",
            "custom_bg3",
            "custom_bg4",
            "custom_bg5",
            "custom_fc1",
            "custom_fc2",
            "custom_fc3",
            "custom_fc4",
            "custom_fc5",
            "toolbarBackgroundColor",
            "toolbarIconColor",
            "toolbarIconSize",
        ].forEach((e) => {
            void 0 !== t[e] && (this.plugin.settings[e] = t[e]);
        });
    }
    fixImportedCommandIds() {
        const t = {
            "editor:toggle-numbered-list": "editing-toolbar:toggle-numbered-list",
            "editor:toggle-bullet-list": "editing-toolbar:toggle-bullet-list",
            "editor:toggle-highlight": "editing-toolbar:toggle-highlight",
            "toggle-highlight": "editing-toolbar:toggle-highlight",
            "editing-toolbar:editor:toggle-bold": "editing-toolbar:toggle-bold",
            "editing-toolbar:editor:toggle-italics": "editing-toolbar:toggle-italics",
            "editing-toolbar:editor:toggle-strikethrough": "editing-toolbar:toggle-strikethrough",
            "editing-toolbar:editor:toggle-inline-math": "editing-toolbar:toggle-inline-math",
            "editing-toolbar:editor:insert-callout": "editing-toolbar:insert-callout",
            "editing-toolbar:editor:insert-link": "editing-toolbar:insert-link",
            "cMenuToolbar-Divider-Line": "editingToolbar-Divider-Line",
        },
            e = (i) => {
                i &&
                    Array.isArray(i) &&
                    i.forEach((i) => {
                        i.id && t[i.id] && (i.id = t[i.id]), i.SubmenuCommands && Array.isArray(i.SubmenuCommands) && e(i.SubmenuCommands);
                    });
            };
        e(this.plugin.settings.menuCommands),
            e(this.plugin.settings.customCommands),
            e(this.plugin.settings.followingCommands),
            e(this.plugin.settings.topCommands),
            e(this.plugin.settings.fixedCommands),
            e(this.plugin.settings.mobileCommands);
    }
    restoreBackup(t) {
        (this.plugin.settings.positionStyle = t.positionStyle),
            (this.plugin.settings.menuCommands = t.menuCommands),
            (this.plugin.settings.customCommands = t.customCommands),
            (this.plugin.settings.followingCommands = t.followingCommands),
            (this.plugin.settings.topCommands = t.topCommands),
            (this.plugin.settings.fixedCommands = t.fixedCommands),
            (this.plugin.settings.mobileCommands = t.mobileCommands);
    }
    onClose() {
        const { contentEl: t } = this;
        t.empty();
    }
    getPositionStyleName(t) {
        switch (t) {
            case "following":
                return Wr("Following Style");
            case "top":
                return Wr("Top Style");
            case "fixed":
                return Wr("Fixed Style");
            default:
                return t;
        }
    }
}
const Dc = [
    { id: "general", name: Wr("General"), icon: "gear" },
    { id: "appearance", name: Wr("Appearance"), icon: "brush" },
    { id: "customcommands", name: Wr("Custom Commands"), icon: "lucide-rectangle-ellipsis" },
    { id: "commands", name: Wr("Toolbar Commands"), icon: "lucide-command" },
    { id: "importexport", name: Wr("Import/Export"), icon: "lucide-import" },
];
function Ic(t) {
    const { el: e, containerEl: i, swatches: n, opacity: o, defaultColor: s } = t;
    return {
        el: e,
        container: i,
        theme: "nano",
        swatches: n,
        lockOpacity: !o,
        default: s,
        position: "left-middle",
        components: { preview: !0, hue: !0, opacity: !!o, interaction: { hex: !0, rgba: !1, hsla: !1, input: !0, cancel: !0, save: !0 } },
    };
}
function Oc(t, e) {
    let i;
    return (
        e.forEach((e, n) => {
            e.id === t && (i = n);
        }),
        i
    );
}
class Bc extends t.PluginSettingTab {
    constructor(t, e) {
        super(t, e),
            (this.pickrs = []),
            (this.activeTab = "general"),
            (this.aestheticStyleMap = {
                default: "editingToolbarDefaultAesthetic",
                tiny: "editingToolbarTinyAesthetic",
                glass: "editingToolbarGlassAesthetic",
                custom: "editingToolbarCustomAesthetic",
                top: "top",
                following: "editingToolbarFlex",
                fixed: "fixed",
            }),
            (this.plugin = e),
            (this.currentEditingConfig = this.plugin.settings.positionStyle),
            addEventListener("editingToolbar-NewCommand", () => {
                nl(), ml(t, this.plugin), this.display();
            });
    }
    display() {
        this.destroyPickrs();
        const { containerEl: e } = this;
        e.empty(), this.createHeader(e);
        const i = e.createEl("div", { cls: "editing-toolbar-tabs" });
        Dc.forEach((e) => {
            const n = i.createEl("div", { cls: "editing-toolbar-tab " + (this.activeTab === e.id ? "active" : "") });
            t.setIcon(n, e.icon),
                n.createEl("span", { text: e.name }),
                n.addEventListener("click", () => {
                    (this.activeTab = e.id), this.display();
                });
        });
        const n = e.createEl("div", { cls: "editing-toolbar-content" });
        switch (this.activeTab) {
            case "general":
                this.displayGeneralSettings(n);
                break;
            case "appearance":
                this.displayAppearanceSettings(n);
                break;
            case "customcommands":
                this.displayCustomCommandSettings(n);
                break;
            case "commands":
                this.displayCommandSettings(n);
                break;
            case "importexport":
                this.displayImportExportSettings(n);
        }
    }
    createDeleteButton(t, i, n = Wr("Delete")) {
        let o,
            s = !1;
        t.setIcon("editingToolbarDelete")
            .setTooltip(n)
            .onClick(() =>
                e(this, void 0, void 0, function* () {
                    s
                        ? (clearTimeout(o), t.setIcon("editingToolbarDelete").setTooltip(n), t.buttonEl.removeClass("mod-warning"), (s = !1), yield i())
                        : ((s = !0),
                            t.setTooltip(Wr("Confirm delete?")).setButtonText(Wr("Confirm delete?")),
                            t.buttonEl.addClass("mod-warning"),
                            (o = setTimeout(() => {
                                t.setIcon("editingToolbarDelete").setTooltip(n), t.buttonEl.removeClass("mod-warning"), (s = !1);
                            }, 3500)));
                })
            );
    }
    displayGeneralSettings(i) {
        const n = i.createDiv("generalSetting-container");
        (n.style.padding = "16px"),
            (n.style.borderRadius = "8px"),
            (n.style.backgroundColor = "var(--background-secondary)"),
            (n.style.marginBottom = "20px"),
            new t.Setting(n)
                .setName(Wr("Editing Toolbar append method"))
                .setDesc(Wr("Choose where Editing Toolbar will append upon regeneration."))
                .addDropdown((t) => {
                    let e = {};
                    Kr.map((t) => (e[t] = t)),
                        t.addOptions(e),
                        t.setValue(this.plugin.settings.appendMethod).onChange((t) => {
                            (this.plugin.settings.appendMethod = t), this.plugin.saveSettings();
                        });
                }),
            new t.Setting(n)
                .setName(Wr("Enable multiple configurations"))
                .setDesc(Wr("Enable different command configurations for each position style (following, top, fixed)"))
                .addToggle((t) =>
                    t.setValue(this.plugin.settings.enableMultipleConfig || !1).onChange((t) =>
                        e(this, void 0, void 0, function* () {
                            (this.plugin.settings.enableMultipleConfig = t), this.plugin.onPositionStyleChange(this.plugin.positionStyle), yield this.plugin.saveSettings(), this.display();
                        })
                    )
                ),
            new t.Setting(n)
                .setName(Wr("Mobile enabled or not"))
                .setDesc(Wr("Whether to enable on mobile devices with device width less than 768px"))
                .addToggle((t) => {
                    var e, i;
                    return t.setValue(null !== (i = null === (e = this.plugin.settings) || void 0 === e ? void 0 : e.isLoadOnMobile) && void 0 !== i && i).onChange((t) => {
                        (this.plugin.settings.isLoadOnMobile = t), this.plugin.saveSettings(), this.triggerRefresh();
                    });
                });
    }
    displayAppearanceSettings(i) {
        const n = i.createDiv("appearanceSetting-container");
        (n.style.padding = "16px"),
            (n.style.borderRadius = "8px"),
            (n.style.backgroundColor = "var(--background-secondary)"),
            (n.style.marginBottom = "20px"),
            new t.Setting(n)
                .setName(Wr("Editing Toolbar position"))
                .setDesc(Wr("Choose between fixed position or cursor following mode"))
                .addDropdown((t) => {
                    let i = {};
                    Jr.map((t) => (i[t] = t)),
                        t
                            .addOptions(i)
                            .setValue(this.plugin.settings.positionStyle)
                            .onChange((t) =>
                                e(this, void 0, void 0, function* () {
                                    (this.plugin.settings.positionStyle = t), yield this.plugin.saveSettings(), this.plugin.onPositionStyleChange(t), this.display();
                                })
                            );
                }),
            "top" == this.plugin.positionStyle &&
            (new t.Setting(n)
                .setName(Wr("Editing Toolbar Auto-hide"))
                .setDesc(Wr("The toolbar is displayed when the mouse moves over it, otherwise it is automatically hidden"))
                .addToggle((t) => {
                    var e;
                    return t.setValue(null === (e = this.plugin.settings) || void 0 === e ? void 0 : e.autohide).onChange((t) => {
                        (this.plugin.settings.autohide = t), this.plugin.saveSettings(), this.triggerRefresh();
                    });
                }),
                new t.Setting(n)
                    .setName(Wr("Editing Toolbar Centred Display"))
                    .setDesc(Wr("Whether the toolbar is centred or full-width, the default is full-width."))
                    .addToggle((t) => {
                        var e;
                        return t.setValue(null === (e = this.plugin.settings) || void 0 === e ? void 0 : e.Iscentered).onChange((t) => {
                            (this.plugin.settings.Iscentered = t), this.plugin.saveSettings(), this.triggerRefresh();
                        });
                    })),
            "fixed" == this.plugin.positionStyle &&
            (new t.Setting(n)
                .setName(Wr("Editing Toolbar columns"))
                .setDesc(Wr("Choose the number of columns per row to display on Editing Toolbar."))
                .addSlider((i) => {
                    i.setLimits(1, 32, 1)
                        .setValue(this.plugin.settings.cMenuNumRows)
                        .onChange(
                            t.debounce(
                                (t) =>
                                    e(this, void 0, void 0, function* () {
                                        (this.plugin.settings.cMenuNumRows = t), yield this.plugin.saveSettings(), this.triggerRefresh();
                                    }),
                                100,
                                !0
                            )
                        )
                        .setDynamicTooltip();
                }),
                new t.Setting(n)
                    .setName(Wr("Fixed position offset"))
                    .setDesc(Wr("Choose the offset of the Editing Toolbar in the fixed position."))
                    .addButton((t) =>
                        t.setButtonText(Wr("Settings")).onClick(() => {
                            new Zr(this.app, this.plugin).open();
                        })
                    )),
            this.createColorSettings(i);
    }
    displayCommandSettings(i) {
        const n = i.createDiv("commandSetting-container");
        if (
            ((n.style.padding = "16px"),
                (n.style.borderRadius = "8px"),
                (n.style.backgroundColor = "var(--background-secondary)"),
                (n.style.marginBottom = "20px"),
                this.plugin.settings.enableMultipleConfig &&
                new t.Setting(n)
                    .setName(Wr("Current Configuration"))
                    .setDesc(Wr("Switch between different command configurations"))
                    .addDropdown((t) => {
                        t.addOption("top", Wr("Top Style")),
                            t.addOption("fixed", Wr("Fixed Style")),
                            t.addOption("following", Wr("Following Style")),
                            this.plugin.settings.isLoadOnMobile && t.addOption("mobile", Wr("Mobile Style")),
                            t.setValue(this.currentEditingConfig),
                            t.onChange((t) =>
                                e(this, void 0, void 0, function* () {
                                    (this.currentEditingConfig = t), this.display();
                                })
                            );
                    }),
                this.plugin.settings.enableMultipleConfig)
        ) {
            const n = this.currentEditingConfig;
            this.getCommandsArrayByType(n);
            const o = i.createDiv("command-buttons-container");
            (o.style.display = "flex"), (o.style.flexDirection = "column"), (o.style.gap = "10px"), (o.style.padding = "16px"), (o.style.borderRadius = "8px"), (o.style.backgroundColor = "var(--background-secondary)");
            const s = new t.Setting(o).setName(Wr("Import From")).setDesc(Wr("Copy commands from another style configuration"));
            let r = "Main menu";
            const l = new t.Setting(o);
            l.addDropdown((t) => {
                t.addOption("Main menu", "Main Menu Commands"),
                    "following" !== n && this.plugin.settings.followingCommands && t.addOption("following", Wr("Following Style")),
                    "top" !== n && this.plugin.settings.topCommands && t.addOption("top", Wr("Top Style")),
                    "fixed" !== n && this.plugin.settings.fixedCommands && t.addOption("fixed", Wr("Fixed Style")),
                    "mobile" !== n && this.plugin.settings.mobileCommands && t.addOption("mobile", Wr("Mobile Style")),
                    t.setValue(r).onChange((t) => {
                        r = t;
                    });
            }),
                l.addExtraButton((t) => t.setIcon("arrow-right")),
                l.addButton((i) =>
                    i
                        .setButtonText(this.currentEditingConfig + " " + Wr("Import"))
                        .setTooltip("Copy commands from selected style")
                        .onClick(() =>
                            e(this, void 0, void 0, function* () {
                                const i = this.getCommandsArrayByType(r);
                                if (!i || 0 === i.length) return void new t.Notice("The selected style has no commands to import");
                                const o = `Import commands from "${r}" to "${this.currentEditingConfig}" ` + Wr("configuration") + "?";
                                vc.show(this.app, {
                                    message: o,
                                    onConfirm: () =>
                                        e(this, void 0, void 0, function* () {
                                            switch (n) {
                                                case "Main menu":
                                                    this.plugin.settings.menuCommands = [...i];
                                                    break;
                                                case "following":
                                                    this.plugin.settings.followingCommands = [...i];
                                                    break;
                                                case "top":
                                                    this.plugin.settings.topCommands = [...i];
                                                    break;
                                                case "fixed":
                                                    this.plugin.settings.fixedCommands = [...i];
                                                    break;
                                                case "mobile":
                                                    this.plugin.settings.mobileCommands = [...i];
                                            }
                                            yield this.plugin.saveSettings(), new t.Notice(`Commands imported successfully from "${r}" to "${this.currentEditingConfig}" ` + Wr("configuration")), this.display();
                                        }),
                                });
                            })
                        )
                ),
                s.addButton((i) =>
                    i
                        .setButtonText(Wr("Clear") + " " + `${this.currentEditingConfig}`)
                        .setTooltip(Wr("Remove all commands from this configuration"))
                        .setWarning()
                        .onClick(() =>
                            e(this, void 0, void 0, function* () {
                                vc.show(this.app, {
                                    message: Wr("Are you sure you want to clear all commands under the current style?"),
                                    onConfirm: () =>
                                        e(this, void 0, void 0, function* () {
                                            switch (n) {
                                                case "following":
                                                    this.plugin.settings.followingCommands = [];
                                                    break;
                                                case "top":
                                                    this.plugin.settings.topCommands = [];
                                                    break;
                                                case "fixed":
                                                    this.plugin.settings.fixedCommands = [];
                                                    break;
                                                case "mobile":
                                                    this.plugin.settings.mobileCommands = [];
                                            }
                                            yield this.plugin.saveSettings(), new t.Notice("All commands have been removed"), this.display();
                                        }),
                                });
                            })
                        )
                );
        } else
            n.createDiv("command-buttons-container")
                .createEl("button", { text: Wr("One-click clear"), cls: "mod-warning" })
                .addEventListener("click", () =>
                    e(this, void 0, void 0, function* () {
                        vc.show(this.app, {
                            message: Wr("Are you sure you want to clear all commands under the current style?"),
                            onConfirm: () =>
                                e(this, void 0, void 0, function* () {
                                    (this.plugin.settings.menuCommands = []), yield this.plugin.saveSettings(), new t.Notice(Wr("All commands have been removed")), this.display();
                                }),
                        });
                    })
                );
        const o = i.createDiv("command-lists-container");
        (o.style.padding = "16px"),
            (o.style.borderRadius = "8px"),
            o.addClass(`${this.currentEditingConfig}`),
            this.plugin.settings.enableMultipleConfig &&
            o.createEl("div", { cls: `position-style-info ${this.currentEditingConfig}`, text: Wr("Currently editing commands for") + ` "${this.currentEditingConfig} Style" ` + Wr("configuration") }),
            new t.Setting(o)
                .setName(Wr("Editing Toolbar commands"))
                .setDesc(
                    Wr(
                        "Add a command onto Editing Toolbar from Obsidian's commands library. To reorder the commands, drag and drop the command items. To delete them, use the delete buttom to the right of the command item. Editing Toolbar will not automaticaly refresh after reordering commands. Use the refresh button above."
                    )
                )
                .addButton((t) => {
                    t.setIcon("plus")
                        .setTooltip(Wr("Add"))
                        .onClick(() => {
                            new Yr(this.plugin, this.currentEditingConfig).open(), this.triggerRefresh();
                        });
                }),
            this.createCommandList(o);
    }
    displayCustomCommandSettings(i) {
        i.empty();
        const n = i.createDiv("custom-commands-container");
        n.createEl("p", { text: Wr("Add, edit or delete custom format commands") });
        const o = n.createDiv("command-list-container");
        (o.style.padding = "16px"), (o.style.borderRadius = "8px"), (o.style.backgroundColor = "var(--background-secondary)"), (o.style.marginBottom = "20px"), (o.style.marginTop = "20px");
        const s = n.createDiv("add-command-button-container");
        (s.style.padding = "16px"),
            (s.style.borderRadius = "8px"),
            (s.style.backgroundColor = "var(--background-secondary)"),
            (s.style.marginBottom = "20px"),
            (s.style.marginTop = "20px"),
            (s.style.display = "flex"),
            (s.style.gap = "10px");
        const r = s.createEl("button", { text: Wr("Add Format Command") });
        r.addClass("mod-cta"),
            r.addEventListener("click", () => {
                new Ec(this.app, this.plugin, null).open();
            });
        const l = s.createEl("button", { text: Wr("Add Regex Command") });
        l.addClass("mod-cta"),
            l.addEventListener("click", () => {
                new Tc(this.app, this.plugin, null).open();
            }),
            this.plugin.settings.customCommands.forEach((i, n) => {
                const s = new t.Setting(o).setName(i.name),
                    r = createFragment();
                let l = `${Wr("ID")}: ${i.id}`;
                i.useRegex ? (l += `, ${Wr("Pattern")}: ${i.regexPattern}`) : (l += `, ${Wr("Prefix")}: ${i.prefix}, ${Wr("Suffix")}: ${i.suffix}`), r.createSpan({ text: l });
                const a = r.createSpan({ cls: "command-type-badge" });
                if (
                    (i.useRegex ? (a.addClass("regex"), a.setText(Wr("Regex"))) : a.setText(Wr("Prefix/Suffix")),
                        s.descEl.appendChild(r),
                        s
                            .addButton((e) =>
                                e
                                    .setButtonText(Wr("Add to Toolbar"))
                                    .setTooltip(Wr("Add this command to the toolbar"))
                                    .setButtonText(Wr("Add to Toolbar"))
                                    .setTooltip(Wr("Add this command to the toolbar"))
                                    .onClick(() => {
                                        if (this.plugin.settings.enableMultipleConfig) new Mc(this.app, this.plugin, i).open();
                                        else {
                                            if (this.plugin.settings.menuCommands.some((t) => t.id === `editing-toolbar:${i.id}`)) return void new t.Notice(Wr("This command is already in the toolbar"));
                                            const e = { id: `editing-toolbar:${i.id}`, name: i.name, icon: i.icon || "obsidian-new" };
                                            this.plugin.settings.menuCommands.push(e),
                                                this.plugin.saveSettings().then(() => {
                                                    new t.Notice(Wr("Command added to toolbar")), dispatchEvent(new Event("editingToolbar-NewCommand")), this.plugin.reloadCustomCommands();
                                                });
                                        }
                                    })
                            )
                            .addExtraButton((t) => {
                                t.setIcon("pencil")
                                    .setTooltip(Wr("Edit"))
                                    .onClick(() => {
                                        i.useRegex ? new Tc(this.app, this.plugin, n).open() : new Ec(this.app, this.plugin, n).open();
                                    });
                            })
                            .addButton((i) =>
                                this.createDeleteButton(i, () =>
                                    e(this, void 0, void 0, function* () {
                                        const e = `editing-toolbar:${this.plugin.settings.customCommands[n].id}`;
                                        this.removeCommandFromConfig(this.plugin.settings.menuCommands, e),
                                            this.plugin.settings.enableMultipleConfig &&
                                            (this.removeCommandFromConfig(this.plugin.settings.followingCommands, e),
                                                this.removeCommandFromConfig(this.plugin.settings.topCommands, e),
                                                this.removeCommandFromConfig(this.plugin.settings.fixedCommands, e),
                                                this.plugin.settings.isLoadOnMobile && this.removeCommandFromConfig(this.plugin.settings.mobileCommands, e)),
                                            this.plugin.settings.customCommands.splice(n, 1),
                                            yield this.plugin.saveSettings(),
                                            this.plugin.reloadCustomCommands(),
                                            this.display(),
                                            new t.Notice(Wr("Command deleted"));
                                    })
                                )
                            ),
                        i.icon)
                )
                    try {
                        const e = s.nameEl.createSpan({ cls: "editingToolbarSettingsIcon" });
                        (e.style.marginRight = "8px"), al(i.icon) ? (e.innerHTML = i.icon) : t.setIcon(e, i.icon);
                    } catch (t) { }
            });
    }
    triggerRefresh() {
        setTimeout(() => {
            dispatchEvent(new Event("editingToolbar-NewCommand"));
        }, 100);
    }
    createHeader(e) {
        const i = e.createEl("div", { cls: "editing-toolbar-header" });
        i.createEl("div", { cls: "editing-toolbar-title-container" }).createEl("h1", { text: "Obsidian Editing Toolbar:" + this.plugin.manifest.version, cls: "editing-toolbar-title" });
        const n = i.createEl("div", { cls: "editing-toolbar-info" });
        n.createEl("span", { text: "作者：" }).createEl("a", { text: "Cuman ✨", href: "https://github.com/cumany" }),
            n.createEl("span", { text: "  教程：" }).createEl("a", { text: "pkmer.cn", href: "https://pkmer.cn/show/20230329145815" }),
            new t.Setting(n).setClass("editing-toolbar-fix-button").addButton((t) => {
                t.setIcon("wrench")
                    .setTooltip(Wr("Fix"))
                    .onClick(() => {
                        new yc(this.app, this.plugin).open();
                    });
            });
    }
    createColorSettings(i) {
        const n = i.createDiv("custom-paintbrush-container");
        (n.style.padding = "16px"),
            (n.style.borderRadius = "8px"),
            (n.style.backgroundColor = "var(--background-secondary)"),
            (n.style.marginBottom = "20px"),
            new t.Setting(n)
                .setName(Wr("🎨 Set custom background"))
                .setDesc(Wr("Click on the picker to adjust the colour"))
                .setClass("custom_bg")
                .then((t) => {
                    const e = t.controlEl.createDiv({ cls: "pickr-container" });
                    for (let t = 0; t < 5; t++) {
                        const i = e.createDiv({ cls: "picker" }),
                            n = Cc.create(
                                Ic({ isView: !1, el: i, containerEl: e, swatches: ["#FFB78B8C", "#CDF4698C", "#A0CCF68C", "#F0A7D88C", "#ADEFEF8C"], opacity: !0, defaultColor: this.plugin.settings[`custom_bg${t + 1}`] || "#000000" })
                            );
                        this.setupPickrEvents(n, `custom_bg${t + 1}`, "background-color"), this.pickrs.push(n);
                    }
                }),
            new t.Setting(n)
                .setName(Wr("🖌️ Set custom font color"))
                .setDesc(Wr("Click on the picker to adjust the colour"))
                .setClass("custom_font")
                .then((t) => {
                    const e = t.controlEl.createDiv({ cls: "pickr-container" });
                    for (let t = 0; t < 5; t++) {
                        const i = e.createDiv({ cls: "picker" }),
                            n = Cc.create(Ic({ isView: !1, el: i, containerEl: e, swatches: ["#D83931", "#DE7802", "#245BDB", "#6425D0", "#646A73"], opacity: !0, defaultColor: this.plugin.settings[`custom_fc${t + 1}`] || "#000000" }));
                        this.setupPickrEvents(n, `custom_fc${t + 1}`, "color"), this.pickrs.push(n);
                    }
                });
        const o = i.createDiv("custom-toolbar-container");
        (o.style.padding = "16px"),
            (o.style.borderRadius = "8px"),
            (o.style.backgroundColor = "var(--background-secondary)"),
            new t.Setting(o)
                .setName(Wr("Toolbar theme"))
                .setDesc(Wr("Select a preset toolbar theme, automatically setting the background color, icon color, and size"))
                .addDropdown((t) => {
                    let i = {};
                    Xr.map((t) => (i[t] = "custom" == t ? Wr("Custom theme") : t)),
                        t.addOptions(i),
                        (t.selectEl.options[3].disabled = !0),
                        t.addOption("light", "┌ Light"),
                        t.addOption("dark", "├ Dark"),
                        t.addOption("vibrant", "├ Vibrant"),
                        t.addOption("minimal", "├ Minimal"),
                        t.addOption("elegant", "└ Elegant"),
                        t.setValue(this.plugin.settings.aestheticStyle),
                        t.onChange((t) =>
                            e(this, void 0, void 0, function* () {
                                switch ((t in i ? ((this.plugin.settings.aestheticStyle = t), (this.plugin.settings.toolbarIconSize = 18)) : (this.plugin.settings.aestheticStyle = "custom"), t)) {
                                    case "light":
                                        (this.plugin.settings.toolbarBackgroundColor = "#F5F8FA"), (this.plugin.settings.toolbarIconColor = "#4A5568"), (this.plugin.settings.toolbarIconSize = 18);
                                        break;
                                    case "dark":
                                        (this.plugin.settings.toolbarBackgroundColor = "#2D3033"), (this.plugin.settings.toolbarIconColor = "#E2E8F0"), (this.plugin.settings.toolbarIconSize = 18);
                                        break;
                                    case "vibrant":
                                        (this.plugin.settings.toolbarBackgroundColor = "#7E57C2"), (this.plugin.settings.toolbarIconColor = "#FFFFFF"), (this.plugin.settings.toolbarIconSize = 20);
                                        break;
                                    case "minimal":
                                        (this.plugin.settings.toolbarBackgroundColor = "#F8F9FA"), (this.plugin.settings.toolbarIconColor = "#6B7280"), (this.plugin.settings.toolbarIconSize = 16);
                                        break;
                                    case "elegant":
                                        (this.plugin.settings.toolbarBackgroundColor = "#1A2F28"), (this.plugin.settings.toolbarIconColor = "#D4AF37"), (this.plugin.settings.toolbarIconSize = 19);
                                }
                                (this.plugin.toolbarIconSize = this.plugin.settings.toolbarIconSize),
                                    document.documentElement.style.setProperty("--editing-toolbar-background-color", this.plugin.settings.toolbarBackgroundColor),
                                    document.documentElement.style.setProperty("--editing-toolbar-icon-color", this.plugin.settings.toolbarIconColor),
                                    document.documentElement.style.setProperty("--toolbar-icon-size", `${this.plugin.settings.toolbarIconSize}px`),
                                    this.destroyPickrs(),
                                    this.display(),
                                    yield this.plugin.saveSettings(),
                                    this.triggerRefresh();
                            })
                        );
                }),
            new t.Setting(o)
                .setName(Wr("Toolbar background color"))
                .setDesc(Wr("Set the background color of the toolbar"))
                .setClass("toolbar_background")
                .then((t) => {
                    const e = t.controlEl.createDiv({ cls: "pickr-container" }),
                        i = e.createDiv({ cls: "picker" }),
                        n = Cc.create(Ic({ isView: !1, el: i, containerEl: e, swatches: ["#F5F8FA", "#F4F1E8", "#2D3033", "#1A2F28", "#2A1D3B"], opacity: !0, defaultColor: this.plugin.settings.toolbarBackgroundColor }));
                    this.setupPickrEvents(n, "toolbarBackgroundColor", "background-color"), this.pickrs.push(n);
                }),
            new t.Setting(o)
                .setName(Wr("Toolbar icon color"))
                .setDesc(Wr("Set the color of the toolbar icon"))
                .setClass("toolbar_icon")
                .then((t) => {
                    const e = t.controlEl.createDiv({ cls: "pickr-container" }),
                        i = e.createDiv({ cls: "picker" }),
                        n = Cc.create(Ic({ isView: !1, el: i, containerEl: e, swatches: ["#4A5568", "#D4AF37", "#2D3033", "#6D5846", "#4C2A55"], opacity: !1, defaultColor: this.plugin.settings.toolbarIconColor }));
                    this.pickrs.push(n), this.setupPickrEvents(n, "toolbarIconColor", "icon-color");
                }),
            new t.Setting(o)
                .setName(Wr("Toolbar icon size"))
                .setDesc(Wr("Set the size of the toolbar icon (px) default 18px"))
                .addSlider((t) => {
                    t.setValue(this.plugin.settings.toolbarIconSize)
                        .setLimits(12, 32, 1)
                        .setDynamicTooltip()
                        .onChange((t) =>
                            e(this, void 0, void 0, function* () {
                                (this.plugin.settings.toolbarIconSize = t),
                                    (this.plugin.toolbarIconSize = t),
                                    document.documentElement.style.setProperty("--toolbar-icon-size", `${t}px`),
                                    (this.plugin.settings.aestheticStyle = "custom"),
                                    yield this.plugin.saveSettings();
                            })
                        );
                });
        const s = o.createDiv("toolbar-preview-container");
        s.addClass("toolbar-preview-section"), (s.style.marginTop = "20px"), (s.createEl("h3", { text: Wr("Toolbar preview") }).style.marginBottom = "10px");
        const r = s.createDiv();
        if ((r.setAttribute("id", "editingToolbarModalBar"), this.applyAestheticStyle(r, this.plugin.settings.aestheticStyle, this.plugin.positionStyle), "fixed" == this.plugin.positionStyle)) {
            let t = this.plugin.settings.toolbarIconSize || 18;
            r.setAttribute(
                "style",
                `left: calc(50% - calc(${this.plugin.settings.cMenuNumRows * (t + 10)}px / 2));\n   bottom: 4.25em; \n   grid-template-columns: repeat(${this.plugin.settings.cMenuNumRows}, ${t + 10}px);\n   gap: ${(t - 18) / 4
                }px;\n   position:absolute;`
            );
        }
        [
            { id: "bold", name: "Bold", icon: "bold" },
            { id: "italics", name: "Italics", icon: "italic" },
            { id: "trikethrough", name: "Strikethrough", icon: "strikethrough" },
            { id: "code", name: "Code", icon: "code" },
            { id: "blockquote", name: "Blockquote", icon: "quote-glyph" },
            { id: "insert-link", name: "Link", icon: "link" },
            { id: "left-sidebar", name: "Left sidebar", icon: "lucide-panel-left" },
            { id: "editor:insert-embed", name: "Add embed", icon: "note-glyph" },
            { id: "editor:insert-link", name: "Insert markdown link", icon: "link-glyph" },
            { id: "editor:insert-tag", name: "Add tag", icon: "price-tag-glyph" },
            { id: "editor:insert-wikilink", name: "Add internal link", icon: "bracket-glyph" },
            { id: "editor:toggle-code", name: "Code", icon: "code-glyph" },
            { id: "editor:toggle-blockquote", name: "Blockquote", icon: "lucide-text-quote" },
            { id: "editor:toggle-checklist-status", name: "Checklist status", icon: "checkbox-glyph" },
            { id: "editor:toggle-comments", name: "Comment", icon: "percent-sign-glyph" },
            { id: "editor:insert-callout", name: "Insert Callout", icon: "lucide-quote" },
            { id: "editor:insert-mathblock", name: "MathBlock", icon: "lucide-sigma-square" },
            { id: "editor:insert-table", name: "Insert Table", icon: "lucide-table" },
        ].forEach((e) => {
            const i = new t.ButtonComponent(r);
            i.setClass("editingToolbarCommandItem"), i.setTooltip(e.name), e.icon && t.setIcon(i.buttonEl, e.icon);
        });
    }
    createCommandList(i) {
        let n = [];
        if (this.plugin.settings.enableMultipleConfig)
            switch (this.currentEditingConfig) {
                case "mobile":
                    n = this.plugin.settings.mobileCommands;
                    break;
                case "following":
                    n = this.plugin.settings.followingCommands;
                    break;
                case "top":
                    n = this.plugin.settings.topCommands;
                    break;
                case "fixed":
                    n = this.plugin.settings.fixedCommands;
                    break;
                default:
                    n = this.plugin.settings.menuCommands;
            }
        else n = this.plugin.settings.menuCommands;
        const o = i.createEl("div", { cls: "editingToolbarSettingsTabsContainer" });
        let s = "";
        Xa.create(o, {
            group: "item",
            animation: 500,
            draggable: ".setting-item",
            ghostClass: "sortable-ghost",
            chosenClass: "sortable-chosen",
            dragClass: "sortable-drag",
            dragoverBubble: !1,
            forceFallback: !0,
            fallbackOnBody: !0,
            swapThreshold: 0.7,
            fallbackClass: "sortable-fallback",
            easing: "cubic-bezier(1, 0, 0, 1)",
            delay: 800,
            delayOnTouchOnly: !0,
            touchStartThreshold: 5,
            filter: ".setting-item-control button",
            onChoose: function (t) {
                t.item.classList.add("sortable-chosen-feedback");
            },
            onUnchoose: function (t) {
                t.item.classList.remove("sortable-chosen-feedback");
            },
            onSort: (t) => {
                if (t.from.className === t.to.className) {
                    const e = n,
                        [i] = e.splice(t.oldIndex, 1);
                    if ((e.splice(t.newIndex, 0, i), this.plugin.settings.enableMultipleConfig))
                        switch (this.currentEditingConfig) {
                            case "mobile":
                                this.plugin.settings.mobileCommands = e;
                                break;
                            case "following":
                                this.plugin.settings.followingCommands = e;
                                break;
                            case "top":
                                this.plugin.settings.topCommands = e;
                                break;
                            case "fixed":
                                this.plugin.settings.fixedCommands = e;
                        }
                    else this.plugin.settings.menuCommands = e;
                    this.plugin.saveSettings();
                }
                this.triggerRefresh();
            },
            onStart: function (t) {
                s = t.item.className;
            },
        });
        const r = n;
        r.forEach((i, l) => {
            const a = new t.Setting(o);
            if ("SubmenuCommands" in i) {
                if (
                    (a.settingEl.setAttribute("data-id", i.id),
                        a
                            .setClass("editingToolbarCommandItem")
                            .setClass("editingToolbarCommandsubItem")
                            .setName(i.name)
                            .addButton((t) => {
                                t.setClass("editingToolbarSettingsIcon").onClick(() =>
                                    e(this, void 0, void 0, function* () {
                                        new Ur(this.plugin, i, !1, null, this.currentEditingConfig).open();
                                    })
                                ),
                                    al(i.icon) ? (t.buttonEl.innerHTML = i.icon) : t.setIcon(i.icon);
                            })
                            .addButton((t) =>
                                this.createDeleteButton(t, () =>
                                    e(this, void 0, void 0, function* () {
                                        r.remove(i), this.plugin.updateCurrentCommands(r), yield this.plugin.saveSettings(), this.display(), this.triggerRefresh();
                                    })
                                )
                            ),
                        "editingToolbar-plugin:change-font-color" == i.id)
                )
                    return;
                if ("editingToolbar-plugin:change-background-color" == i.id) return;
                const o = a.settingEl.createEl("div", { cls: "editingToolbarSettingsTabsContainer_sub" });
                Xa.create(o, {
                    group: {
                        name: "item",
                        pull: !0,
                        put: function () {
                            return !s.includes("editingToolbarCommandsubItem");
                        },
                    },
                    draggable: ".setting-item",
                    animation: 150,
                    ghostClass: "sortable-ghost",
                    chosenClass: "sortable-chosen",
                    dragClass: "sortable-drag",
                    dragoverBubble: !1,
                    fallbackOnBody: !0,
                    swapThreshold: 0.7,
                    forceFallback: !0,
                    delay: 800,
                    delayOnTouchOnly: !0,
                    touchStartThreshold: 5,
                    fallbackClass: "sortable-fallback",
                    easing: "cubic-bezier(1, 0, 0, 1)",
                    onStart: function () { },
                    onSort: (t) => {
                        var e, i, o;
                        if (t.from.className === t.to.className) {
                            const i = n,
                                o = null === (e = i[l]) || void 0 === e ? void 0 : e.SubmenuCommands;
                            if (o) {
                                const [e] = o.splice(t.oldIndex, 1);
                                o.splice(t.newIndex, 0, e), this.plugin.updateCurrentCommands(i), this.plugin.saveSettings();
                            }
                        } else if ("editingToolbarSettingsTabsContainer" === t.to.className) {
                            const e = n,
                                o = null === (i = e[Oc(t.target.parentElement.dataset.id, e)]) || void 0 === i ? void 0 : i.SubmenuCommands;
                            if (o) {
                                const [i] = o.splice(t.oldIndex, 1);
                                e.splice(t.newIndex, 0, i), this.plugin.updateCurrentCommands(e), this.plugin.saveSettings();
                            }
                        } else if ("editingToolbarSettingsTabsContainer" === t.from.className) {
                            const e = n,
                                i = null === (o = e[Oc(t.target.parentElement.dataset.id, e)]) || void 0 === o ? void 0 : o.SubmenuCommands;
                            if (i) {
                                const [n] = e.splice(t.oldIndex, 1);
                                i.splice(t.newIndex, 0, n), this.plugin.updateCurrentCommands(e), this.plugin.saveSettings();
                            }
                        }
                        this.triggerRefresh();
                    },
                }),
                    i.SubmenuCommands.forEach((n) => {
                        const s = new t.Setting(o);
                        s
                            .setClass("editingToolbarCommandItem")
                            .addButton((t) => {
                                t.setClass("editingToolbarSettingsIcon").onClick(() =>
                                    e(this, void 0, void 0, function* () {
                                        new Ur(this.plugin, n, !0, null, this.currentEditingConfig).open();
                                    })
                                ),
                                    al(null == n ? void 0 : n.icon) ? (t.buttonEl.innerHTML = n.icon) : t.setIcon(n.icon);
                            })
                            .setName(n.name)
                            .addButton((t) => {
                                t.setIcon("pencil")
                                    .setTooltip(Wr("Change Command name"))
                                    .setClass("editingToolbarSettingsButton")
                                    .onClick(() =>
                                        e(this, void 0, void 0, function* () {
                                            new Gr(this.app, this.plugin, n, !0, this.currentEditingConfig).open();
                                        })
                                    );
                            })
                            .addButton((t) =>
                                this.createDeleteButton(t, () =>
                                    e(this, void 0, void 0, function* () {
                                        i.SubmenuCommands.remove(n), yield this.plugin.saveSettings(), this.display(), this.triggerRefresh();
                                    })
                                )
                            ),
                            s.nameEl;
                    });
            } else
                a.addButton((t) => {
                    t.setClass("editingToolbarSettingsIcon").onClick(() =>
                        e(this, void 0, void 0, function* () {
                            new Ur(this.plugin, i, !1, null, this.currentEditingConfig).open();
                        })
                    ),
                        al(i.icon) ? (t.buttonEl.innerHTML = i.icon) : t.setIcon(i.icon);
                }),
                    "editingToolbar-Divider-Line" == i.id && a.setClass("editingToolbar-Divider-Line"),
                    a
                        .setClass("editingToolbarCommandItem")
                        .setName(i.name)
                        .addButton((t) => {
                            t.setIcon("pencil")
                                .setTooltip(Wr("Change Command name"))
                                .setClass("editingToolbarSettingsButton")
                                .onClick(() =>
                                    e(this, void 0, void 0, function* () {
                                        new Gr(this.app, this.plugin, i, !1, this.currentEditingConfig).open();
                                    })
                                );
                        })
                        .addButton((t) => {
                            t.setIcon("editingToolbarSub")
                                .setTooltip(Wr("Add submenu"))
                                .setClass("editingToolbarSettingsButton")
                                .setClass("editingToolbarSettingsButtonaddsub")
                                .onClick(() =>
                                    e(this, void 0, void 0, function* () {
                                        const t = { id: "SubmenuCommands-" + Ar(1), name: "submenu", icon: "remix-Filter3Line", SubmenuCommands: [] },
                                            e = n;
                                        e.splice(l + 1, 0, t), this.plugin.updateCurrentCommands(e), yield this.plugin.saveSettings(), this.display(), this.triggerRefresh();
                                    })
                                );
                        })
                        .addButton((t) => {
                            t.setIcon("vertical-split")
                                .setTooltip(Wr("add hr"))
                                .setClass("editingToolbarSettingsButton")
                                .setClass("editingToolbarSettingsButtonaddsub")
                                .onClick(() =>
                                    e(this, void 0, void 0, function* () {
                                        const t = n;
                                        t.splice(l + 1, 0, { id: "editingToolbar-Divider-Line", name: "HR", icon: "vertical-split" }),
                                            this.plugin.updateCurrentCommands(t),
                                            yield this.plugin.saveSettings(),
                                            this.display(),
                                            this.triggerRefresh();
                                    })
                                );
                        })
                        .addButton((t) =>
                            this.createDeleteButton(t, () =>
                                e(this, void 0, void 0, function* () {
                                    r.remove(i), this.plugin.updateCurrentCommands(r), yield this.plugin.saveSettings(), this.display(), this.triggerRefresh();
                                })
                            )
                        );
        });
    }
    setupPickrEvents(t, e, i) {
        t.on("save", (t) => {
            const n = t.toHEXA().toString();
            (this.plugin.settings[e] = n),
                document.documentElement.style.setProperty(`--editing-toolbar-${i}`, n),
                this.plugin.saveSettings(),
                "custom" !== this.plugin.settings.aestheticStyle && ((this.plugin.settings.aestheticStyle = "custom"), this.plugin.saveSettings());
        });
    }
    destroyPickrs() {
        this.pickrs.forEach((t) => {
            t && t.destroyAndRemove();
        }),
            (this.pickrs = []);
    }
    hide() {
        this.destroyPickrs(), this.triggerRefresh();
    }
    removeCommandFromConfig(t, e) {
        if (t) for (let i = t.length - 1; i >= 0; i--) t[i].id !== e ? t[i].SubmenuCommands && this.removeCommandFromConfig(t[i].SubmenuCommands, e) : t.splice(i, 1);
    }
    displayImportExportSettings(e) {
        const i = e.createDiv("import-export-container");
        (i.style.padding = "16px"),
            (i.style.borderRadius = "8px"),
            (i.style.backgroundColor = "var(--background-secondary)"),
            (i.style.marginBottom = "20px"),
            new t.Setting(i)
                .setName(Wr("Export Configuration"))
                .setDesc(Wr("Export your toolbar configuration to share with others"))
                .addButton((t) =>
                    t
                        .setButtonText(Wr("Export"))
                        .setCta()
                        .onClick(() => {
                            new Ac(this.app, this.plugin, "export").open();
                        })
                ),
            new t.Setting(i)
                .setName(Wr("Import Configuration"))
                .setDesc(Wr("Import toolbar configuration from JSON"))
                .addButton((t) =>
                    t
                        .setButtonText(Wr("Import"))
                        .setCta()
                        .onClick(() => {
                            new Ac(this.app, this.plugin, "import").open();
                        })
                );
        const n = e.createDiv("import-export-info");
        (n.style.marginTop = "20px"),
            (n.style.padding = "16px"),
            (n.style.borderRadius = "8px"),
            (n.style.backgroundColor = "var(--background-secondary)"),
            (n.createEl("h3", { text: Wr("Usage Instructions"), cls: "import-export-heading" }).style.marginTop = "0");
        const o = n.createEl("ul");
        (o.style.paddingLeft = "20px"), o.createEl("li", { text: Wr("Export: Generate a JSON configuration that you can save or share") }), o.createEl("li", { text: Wr("Import: Paste a previously exported JSON configuration") });
        const s = e.createDiv("community-share-container");
        (s.style.marginTop = "20px"),
            (s.style.padding = "16px"),
            (s.style.borderRadius = "8px"),
            (s.style.backgroundColor = "rgba(var(--color-green-rgb), 0.1)"),
            (s.style.border = "1px solid rgba(var(--color-green-rgb), 0.3)"),
            (s.createEl("h3", { text: Wr("Join the Community"), cls: "community-heading" }).style.marginTop = "0"),
            (s.createEl("p").innerHTML =
                Wr("Share your toolbar settings and styles in our") + ' <a href="https://github.com/PKM-er/obsidian-editing-toolbar/discussions/categories/show-and-tell" target="_blank" rel="noopener noreferrer">Show and Tell</a> '),
            s.createEl("p", { text: Wr("Get inspired by what others have created or showcase your own customizations.") });
        const r = e.createDiv("import-export-warning");
        (r.style.marginTop = "20px"),
            (r.style.padding = "16px"),
            (r.style.borderRadius = "8px"),
            (r.style.backgroundColor = "rgba(var(--color-red-rgb), 0.1)"),
            (r.style.border = "1px solid rgba(var(--color-red-rgb), 0.3)"),
            (r.createEl("p", { text: Wr("Warning: Importing configuration will overwrite your current settings. Consider exporting your current configuration first as a backup."), cls: "warning-text" }).style.margin = "0");
    }
    applyAestheticStyle(t, e, i) {
        Object.values(this.aestheticStyleMap).forEach((e) => {
            t.removeClass(e);
        });
        const n = this.aestheticStyleMap[e] || this.aestheticStyleMap.default;
        t.addClass(n);
        const o = this.aestheticStyleMap[i] || this.aestheticStyleMap.top;
        t.addClass(o);
    }
    getCommandsArrayByType(t) {
        switch (t) {
            case "following":
                return this.plugin.settings.followingCommands;
            case "top":
                return this.plugin.settings.topCommands;
            case "fixed":
                return this.plugin.settings.fixedCommands;
            case "mobile":
                return this.plugin.settings.mobileCommands;
            default:
                return this.plugin.settings.menuCommands;
        }
    }
}
const qc = {
    editingToolbar:
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M19 10H5c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2zM5 20v-8h14l.002 8H5zM5 6h14v2H5zm2-4h10v2H7z" fill="currentColor"/></svg>',
    editingToolbarSub:
        '<svg t="1661526346488" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="16880"  ><path d="M597.333333 85.333333h-341.333333C187.733333 85.333333 128 140.8 128 213.333333v597.333334c0 72.533333 59.733333 128 128 128h426.666667c72.533333 0 128-55.466667 128-128V298.666667l-213.333334-213.333334z m170.666667 725.333334c0 46.933333-38.4 85.333333-85.333333 85.333333H256c-46.933333 0-85.333333-38.4-85.333333-85.333333V213.333333c0-46.933333 38.4-85.333333 85.333333-85.333333h298.666667v213.333333h213.333333v469.333334z m-320-234.666667h128c12.8 0 21.333333 8.533333 21.333333 21.333333s-8.533333 21.333333-21.333333 21.333334h-128v128c0 12.8-8.533333 21.333333-21.333333 21.333333s-21.333333-8.533333-21.333334-21.333333v-128h-128c-12.8 0-21.333333-8.533333-21.333333-21.333334s8.533333-21.333333 21.333333-21.333333h128v-128c0-12.8 8.533333-21.333333 21.333334-21.333333s21.333333 8.533333 21.333333 21.333333v128z" fill="#8a8a8a" p-id="16881"></path></svg>',
    editingToolbarAdd:
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="white" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4z" fill="currentColor"/><path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10s10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8s8 3.589 8 8s-3.589 8-8 8z" fill="currentColor"/></svg>',
    editingToolbarDelete:
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="white" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z" fill="var(--text-error)"/><path d="M9 10h2v8H9zm4 0h2v8h-2z" fill="var(--text-error)"/></svg>',
    editingToolbarReload:
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="white" stroke-width="0" stroke-linecap="round" stroke-linejoin="round"><path d="M19 10H5c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2zM5 20v-8h14l.002 8H5zM5 6h14v2H5zm2-4h10v2H7z" fill="currentColor"/></svg>',
    "codeblock-glyph":
        '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor" d="M20 3H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2zM4 19V7h16l.002 12H4z" fill="currentColor"/><path d="M9.293 9.293L5.586 13l3.707 3.707l1.414-1.414L8.414 13l2.293-2.293zm5.414 0l-1.414 1.414L15.586 13l-2.293 2.293l1.414 1.414L18.414 13z"/></svg>',
    "underline-glyph":
        '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 1024 1024"><path fill="currentColor" d="M824 804H200c-4.4 0-8 3.4-8 7.6v60.8c0 4.2 3.6 7.6 8 7.6h624c4.4 0 8-3.4 8-7.6v-60.8c0-4.2-3.6-7.6-8-7.6zm-312-76c69.4 0 134.6-27.1 183.8-76.2C745 602.7 772 537.4 772 468V156c0-6.6-5.4-12-12-12h-60c-6.6 0-12 5.4-12 12v312c0 97-79 176-176 176s-176-79-176-176V156c0-6.6-5.4-12-12-12h-60c-6.6 0-12 5.4-12 12v312c0 69.4 27.1 134.6 76.2 183.8C377.3 701 442.6 728 512 728z"/></svg>',
    "superscript-glyph":
        '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor"d="M16 7.41L11.41 12L16 16.59L14.59 18L10 13.41L5.41 18L4 16.59L8.59 12L4 7.41L5.41 6L10 10.59L14.59 6L16 7.41M21.85 9h-4.88V8l.89-.82c.76-.64 1.32-1.18 1.7-1.63c.37-.44.56-.85.57-1.23a.884.884 0 0 0-.27-.7c-.18-.19-.47-.28-.86-.29c-.31.01-.58.07-.84.17l-.66.39l-.45-1.17c.27-.22.59-.39.98-.53S18.85 2 19.32 2c.78 0 1.38.2 1.78.61c.4.39.62.93.62 1.57c-.01.56-.19 1.08-.54 1.55c-.34.48-.76.93-1.27 1.36l-.64.52v.02h2.58V9z"/></svg>',
    "subscript-glyph":
        '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor" d="M16 7.41L11.41 12L16 16.59L14.59 18L10 13.41L5.41 18L4 16.59L8.59 12L4 7.41L5.41 6L10 10.59L14.59 6L16 7.41m5.85 13.62h-4.88v-1l.89-.8c.76-.65 1.32-1.19 1.7-1.63c.37-.44.56-.85.57-1.24a.898.898 0 0 0-.27-.7c-.18-.16-.47-.28-.86-.28c-.31 0-.58.06-.84.18l-.66.38l-.45-1.17c.27-.21.59-.39.98-.53s.82-.24 1.29-.24c.78.04 1.38.25 1.78.66c.4.41.62.93.62 1.57c-.01.56-.19 1.08-.54 1.55c-.34.47-.76.92-1.27 1.36l-.64.52v.02h2.58v1.35z"/></svg>',
    "bot-glyph":
        '<svg xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path fill="currentColor" d="M21.928 11.607c-.202-.488-.635-.605-.928-.633V8c0-1.103-.897-2-2-2h-6V4.61c.305-.274.5-.668.5-1.11a1.5 1.5 0 0 0-3 0c0 .442.195.836.5 1.11V6H5c-1.103 0-2 .897-2 2v2.997l-.082.006A1 1 0 0 0 1.99 12v2a1 1 0 0 0 1 1H3v5c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-5a1 1 0 0 0 1-1v-1.938a1.006 1.006 0 0 0-.072-.455zM5 20V8h14l.001 3.996L19 12v2l.001.005l.001 5.995H5z" fill="currentColor"/><ellipse cx="8.5" cy="12" rx="1.5" ry="2" fill="currentColor"/><ellipse cx="15.5" cy="12" rx="1.5" ry="2" fill="currentColor"/><path d="M8 16h8v2H8z" fill="currentColor"/></svg>',
    "header-1":
        '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path fill="currentColor"  d="M835.626667 349.397333A42.666667 42.666667 0 0 1 853.333333 384v426.666667a42.666667 42.666667 0 0 1-85.333333 0v-367.488l-71.850667 23.978666a42.666667 42.666667 0 0 1-26.965333-80.981333l128-42.666667a42.666667 42.666667 0 0 1 38.4 5.888zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="1635"></path></svg>',
    "header-2":
        '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M768 426.666667a85.333333 85.333333 0 0 0-85.333333 85.333333v21.333333a42.666667 42.666667 0 1 1-85.333334 0V512a170.666667 170.666667 0 0 1 170.666667-170.666667h7.338667a163.328 163.328 0 0 1 115.498666 278.869334L742.997333 768H896a42.666667 42.666667 0 1 1 0 85.333333h-256a42.666667 42.666667 0 0 1-30.165333-72.832l220.672-220.672A77.994667 77.994667 0 0 0 775.338667 426.666667H768zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="1791"></path></svg>',
    "header-3":
        '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M597.333333 384a42.666667 42.666667 0 0 1 42.666667-42.666667h256a42.666667 42.666667 0 0 1 30.165333 72.832l-105.941333 105.984A170.752 170.752 0 0 1 768 853.333333a170.666667 170.666667 0 0 1-160.938667-113.877333 42.666667 42.666667 0 0 1 80.469334-28.373333A85.333333 85.333333 0 1 0 768 597.333333h-42.666667a42.666667 42.666667 0 0 1-30.165333-72.832L793.002667 426.666667H640a42.666667 42.666667 0 0 1-42.666667-42.666667zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="1949"></path></svg>',
    "header-4":
        '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M780.714667 343.296a42.666667 42.666667 0 0 1 28.032 53.418667L719.36 682.666667H896a42.666667 42.666667 0 1 1 0 85.333333h-234.666667a42.666667 42.666667 0 0 1-40.704-55.381333l106.666667-341.333334a42.666667 42.666667 0 0 1 53.418667-27.989333z" p-id="2107"></path><path d="M853.333333 554.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v213.333334a42.666667 42.666667 0 1 1-85.333333 0v-213.333334a42.666667 42.666667 0 0 1 42.666666-42.666666zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="2108"></path></svg>',
    "header-5":
        '\n  <svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M683.946667 373.674667A42.666667 42.666667 0 0 1 725.333333 341.333333h170.666667a42.666667 42.666667 0 1 1 0 85.333334h-137.301333l-22.016 88.234666A170.666667 170.666667 0 1 1 640 795.562667a42.666667 42.666667 0 1 1 64-56.448 85.333333 85.333333 0 1 0 0-112.896 42.666667 42.666667 0 0 1-73.386667-38.528l53.333334-214.016zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="2264"></path></svg>',
    "header-6":
        '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M831.274667 303.957333a42.666667 42.666667 0 0 1 16.725333 57.984l-83.498667 151.466667a170.453333 170.453333 0 0 1 88.746667 22.741333 169.557333 169.557333 0 0 1 62.506667 232.277334 171.093333 171.093333 0 0 1-232.96 62.165333 169.557333 169.557333 0 0 1-62.805334-231.850667l153.301334-278.016a42.666667 42.666667 0 0 1 57.984-16.768z m-20.48 306.176a85.76 85.76 0 0 0-116.736 31.018667 84.224 84.224 0 0 0 31.189333 115.456 85.76 85.76 0 0 0 116.736-31.018667 84.224 84.224 0 0 0-31.232-115.456zM128 170.666667a42.666667 42.666667 0 0 1 42.666667 42.666666v256h256V213.333333a42.666667 42.666667 0 1 1 85.333333 0v597.333334a42.666667 42.666667 0 1 1-85.333333 0v-256H170.666667v256a42.666667 42.666667 0 1 1-85.333334 0V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666z" p-id="2422"></path></svg>',
    "header-n":
        '<svg  viewBox="0 0 24 24" ><path d="M2 3a1 1 0 0 0-1 1v16a1 1 0 1 0 2 0v-7h9v7a1 1 0 1 0 2 0V4a1 1 0 1 0-2 0v7H3V4a1 1 0 0 0-1-1Zm14 9a1 1 0 0 1 1.984-.177 4.099 4.099 0 0 1 1.757-.576 3.447 3.447 0 0 1 3.759 3.432V20a1 1 0 1 1-2 0v-5.32c0-.851-.73-1.519-1.578-1.442A2.114 2.114 0 0 0 18 15.344V20a1 1 0 1 1-2 0v-8Z" fill="currentColor"></path></svg>',
    obsidian:
        '<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" class="logo-wireframe"><path d="M 30.91 17.52 L 34.43 35.7 M 61.44 14.41 L 62.61 0 M 34.43 35.7 L 37.57 90.47 M 81 26.39 L 61.44 14.41 L 34.43 35.7 L 65.35 100 M 62.61 0 L 30.91 17.52 L 18 45.45 L 37.57 90.47 L 65.35 100 L 70.44 89.8 L 81 26.39 L 62.61 0 Z"></path></svg>',
    "obsidian-new":
        '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="#A88BFA" d="m6.91927 14.5955c.64053-.1907 1.67255-.4839 2.85923-.5565-.71191-1.7968-.88376-3.3691-.74554-4.76905.15962-1.61678.72977-2.9662 1.28554-4.11442.1186-.24501.2326-.47313.3419-.69198.1549-.30984.3004-.60109.4365-.8953.2266-.48978.3948-.92231.4798-1.32416.0836-.39515.0841-.74806-.0148-1.08657-.099-.338982-.3093-.703864-.7093-1.1038132-.5222-.1353116-1.1017-.0165173-1.53613.3742922l-5.15591 4.638241c-.28758.25871-.47636.60929-.53406.99179l-.44455 2.94723c.69903.6179 2.42435 2.41414 3.47374 4.90644.09364.2224.1819.4505.26358.6838z"></path><path fill="#A88BFA" d="m2.97347 10.3512c-.02431.1037-.05852.205-.10221.3024l-2.724986 6.0735c-.279882.6238-.15095061 1.3552.325357 1.8457l4.288349 4.4163c2.1899-3.2306 1.87062-6.2699.87032-8.6457-.75846-1.8013-1.90801-3.2112-2.65683-3.9922z"></path><path fill="#A88BFA" d="m5.7507 23.5094c.07515.012.15135.0192.2281.0215.81383.0244 2.18251.0952 3.29249.2997.90551.1669 2.70051.6687 4.17761 1.1005 1.1271.3294 2.2886-.5707 2.4522-1.7336.1192-.8481.343-1.8075.7553-2.6869l-.0095.0033c-.6982-1.9471-1.5865-3.2044-2.5178-4.0073-.9284-.8004-1.928-1.1738-2.8932-1.3095-1.60474-.2257-3.07497.1961-4.00103.4682.55465 2.3107.38396 5.0295-1.48417 7.8441z"></path><path fill="#A88BFA" d="m17.3708 19.3102c.9267-1.3985 1.5868-2.4862 1.9352-3.0758.1742-.295.1427-.6648-.0638-.9383-.5377-.7126-1.5666-2.1607-2.1272-3.5015-.5764-1.3785-.6624-3.51876-.6673-4.56119-.0019-.39626-.1275-.78328-.3726-1.09465l-3.3311-4.23183c-.0117.19075-.0392.37998-.0788.56747-.1109.52394-.32 1.04552-.5585 1.56101-.1398.30214-.3014.62583-.4646.95284-.1086.21764-.218.4368-.3222.652-.5385 1.11265-1.0397 2.32011-1.1797 3.73901-.1299 1.31514.0478 2.84484.8484 4.67094.1333.0113.2675.0262.4023.0452 1.1488.1615 2.3546.6115 3.4647 1.5685.9541.8226 1.8163 2.0012 2.5152 3.6463z"></path></svg>',
};
class Nc {
    constructor(t) {
        this.plugin = t;
    }
    init() {
        (this.statusBarIcon = this.plugin.addStatusBarItem()), this.statusBarIcon.addClass("editingToolbar-statusbar-button"), t.setIcon(this.statusBarIcon, "editingToolbar"), this.registerClickEvent();
    }
    registerClickEvent() {
        this.plugin.registerDomEvent(this.statusBarIcon, "click", () => {
            const t = this.statusBarIcon.parentElement.getBoundingClientRect(),
                e = this.statusBarIcon.getBoundingClientRect();
            this.showMenu(e, t);
        });
    }
    showMenu(e, i) {
        const n = new t.Menu();
        n.addSections(["settings"]),
            this.addVisibilityToggle(n),
            this.addAestheticStyleToggle(n),
            n.addSections(["viewType"]),
            this.addViewTypeToggle(n),
            n.addSections(["controls"]),
            this.addToolbarControls(n),
            n.dom.addClass("editingToolbar-statusbar-menu"),
            n.showAtPosition({ x: e.right + 5, y: i.top - 5 });
    }
    addVisibilityToggle(i) {
        i.addItem((i) => {
            i.setTitle(Wr("Hide & Show")), !t.requireApiVersion("0.15.0") || i.setSection("settings");
            const n = i.dom,
                o = new t.ToggleComponent(n).setValue(this.plugin.settings.cMenuVisibility).setDisabled(!0),
                s = () =>
                    e(this, void 0, void 0, function* () {
                        (this.plugin.settings.cMenuVisibility = !this.plugin.settings.cMenuVisibility),
                            o.setValue(this.plugin.settings.cMenuVisibility),
                            1 == this.plugin.settings.cMenuVisibility
                                ? setTimeout(() => {
                                    dispatchEvent(new Event("editingToolbar-NewCommand"));
                                }, 100)
                                : Pr(this.plugin.settings.cMenuVisibility),
                            nl(),
                            yield this.plugin.saveSettings();
                    });
            i.onClick((t) => {
                t.preventDefault(), t.stopImmediatePropagation(), s();
            });
        }),
            i.addItem((i) => {
                i.setTitle(Wr("Toolbar Position")), !t.requireApiVersion("0.15.0") || i.setSection("settings"), i.setIcon("dock");
                const n = i.setSubmenu();
                ["top", "fixed", "following"].forEach((t) => {
                    n.addItem((i) => {
                        i.setTitle(t),
                            i.setIcon(this.plugin.positionStyle === t ? "check" : ""),
                            i.onClick(() =>
                                e(this, void 0, void 0, function* () {
                                    (this.plugin.settings.positionStyle = t), yield this.plugin.saveSettings(), this.plugin.onPositionStyleChange(t);
                                })
                            );
                    });
                });
            });
    }
    addViewTypeToggle(i) {
        const n = this.plugin.app.workspace.getActiveViewOfType(t.ItemView);
        if (!n) return;
        const o = n.getViewType();
        i.addItem((i) => {
            i.setTitle(Wr("Current View: ") + o), !t.requireApiVersion("0.15.0") || i.setSection("settings"), i.setIcon("layout-template");
            const s = i.setSubmenu(),
                r = tl.isAllowedViewType(n);
            s.addItem((t) => {
                t.setTitle(Wr(r ? "Disable toolbar for this view" : "Enable toolbar for this view")),
                    t.setIcon(r ? "eye-off" : "eye"),
                    t.onClick(() =>
                        e(this, void 0, void 0, function* () {
                            this.plugin.settings.viewTypeSettings || (this.plugin.settings.viewTypeSettings = {}),
                                (this.plugin.settings.viewTypeSettings[o] = !r),
                                yield this.plugin.saveSettings(),
                                nl(),
                                setTimeout(() => {
                                    dispatchEvent(new Event("editingToolbar-NewCommand"));
                                }, 100);
                        })
                    );
            }),
                s.addItem((t) => {
                    t.setTitle(Wr("Manage all view types")), t.setIcon("settings-2");
                    const i = t.setSubmenu(),
                        n = new Set(["markdown", "canvas", "thino_view", "meld-encrypted-view", ...Object.keys(this.plugin.settings.viewTypeSettings || {})]);
                    Array.from(n)
                        .sort()
                        .forEach((t) => {
                            const n = this.isViewTypeAllowed(t);
                            i.addItem((i) => {
                                i.setTitle(t),
                                    i.setIcon(n ? "check" : ""),
                                    i.onClick(() =>
                                        e(this, void 0, void 0, function* () {
                                            this.plugin.settings.viewTypeSettings || (this.plugin.settings.viewTypeSettings = {}),
                                                (this.plugin.settings.viewTypeSettings[t] = !n),
                                                o === t &&
                                                (nl(),
                                                    setTimeout(() => {
                                                        dispatchEvent(new Event("editingToolbar-NewCommand"));
                                                    }, 100)),
                                                yield this.plugin.saveSettings();
                                        })
                                    );
                            });
                        });
                });
        });
    }
    isViewTypeAllowed(t) {
        return this.plugin.settings.viewTypeSettings && void 0 !== this.plugin.settings.viewTypeSettings[t] ? this.plugin.settings.viewTypeSettings[t] : ["markdown", "canvas", "thino_view", "meld-encrypted-view"].includes(t);
    }
    addToolbarControls(e) {
        const i = [{ icon: "plus", title: Wr("Add Command"), click: () => new Yr(this.plugin).open() }];
        "fixed" === this.plugin.positionStyle && i.push({ icon: "file-sliders", title: Wr("Position Settings"), click: () => new Zr(this.plugin.app, this.plugin).open() }),
            i.forEach((i) => {
                e.addItem((e) => {
                    e.setIcon(i.icon), e.setTitle(i.title), e.onClick(i.click), t.requireApiVersion("0.15.0") && e.setSection("controls");
                });
            });
    }
    addAestheticStyleToggle(i) {
        i.addItem((i) => {
            i.setTitle(Wr("Appearance Style")), !t.requireApiVersion("0.15.0") || i.setSection("settings"), i.setIcon("cherry");
            const n = i.setSubmenu();
            Xr.forEach((t) => {
                n.addItem((i) => {
                    i.setTitle(t),
                        i.setIcon(this.plugin.settings.aestheticStyle === t ? "check" : ""),
                        i.onClick(() =>
                            e(this, void 0, void 0, function* () {
                                (this.plugin.settings.aestheticStyle = t),
                                    yield this.plugin.saveSettings(),
                                    nl(),
                                    setTimeout(() => {
                                        dispatchEvent(new Event("editingToolbar-NewCommand"));
                                    }, 100);
                            })
                        );
                });
            });
        });
    }
}
let Lc, Rc;
class Pc extends t.Modal {
    constructor(t) {
        super(t.app),
            (this.plugin = t),
            (this.type = "note"),
            (this.title = ""),
            (this.content = ""),
            (this.collapse = "none"),
            (this.allCalloutOptions = []),
            (this.builtInCalloutTypes = [
                { type: "note", aliases: [], icon: "lucide-pencil", label: "Note", color: "var(--callout-default)" },
                { type: "abstract", aliases: ["summary", "tldr"], icon: "lucide-clipboard-list", label: "Abstract", color: "var(--callout-summary)" },
                { type: "info", aliases: [], icon: "lucide-info", label: "Info", color: "var(--callout-info)" },
                { type: "todo", aliases: [], icon: "lucide-check-circle-2", label: "Todo", color: "var(--callout-todo)" },
                { type: "important", aliases: [], icon: "lucide-flame", label: "Important", color: "var(--callout-important)" },
                { type: "tip", aliases: ["hint"], icon: "lucide-flame", label: "Tip", color: "var(--callout-tip)" },
                { type: "success", aliases: ["check", "done"], icon: "lucide-check", label: "Success", color: "var(--callout-success)" },
                { type: "question", aliases: ["help", "faq"], icon: "lucide-help-circle", label: "Question", color: "var(--callout-question)" },
                { type: "warning", aliases: ["caution", "attention"], icon: "lucide-alert-triangle", label: "Warning", color: "var(--callout-warning)" },
                { type: "failure", aliases: ["fail", "missing"], icon: "lucide-x", label: "Failure", color: "var(--callout-fail)" },
                { type: "danger", aliases: ["error"], icon: "lucide-zap", label: "Danger", color: "var(--callout-error)" },
                { type: "bug", aliases: [], icon: "lucide-bug", label: "Bug", color: "var(--callout-bug)" },
                { type: "example", aliases: [], icon: "lucide-list", label: "Example", color: "var(--callout-example)" },
                { type: "quote", aliases: ["cite"], icon: "lucide-quote", label: "Quote", color: "var(--callout-quote)" },
            ]),
            this.containerEl.addClass("insert-callout-modal"),
            this.prepareCalloutOptions();
        const e = this.plugin.commandsManager.getActiveEditor();
        if (e) {
            const t = e.getSelection();
            t && (this.content = t);
        }
        this.allCalloutOptions.find((t) => t.type === this.type) || (this.type = this.allCalloutOptions.length > 0 ? this.allCalloutOptions[0].type : "note");
    }
    prepareCalloutOptions() {
        if (
            (this.builtInCalloutTypes.forEach((t) => {
                this.allCalloutOptions.push({ type: t.type, label: t.label, icon: t.icon, color: t.color, isAdmonition: !1 }),
                    t.aliases.forEach((e) => {
                        this.allCalloutOptions.push({ type: e, label: `${t.label} (${e})`, icon: t.icon, color: t.color, isAdmonition: !1 });
                    });
            }),
                this.plugin.admonitionDefinitions)
        ) {
            const t = Object.values(this.plugin.admonitionDefinitions);
            t.length > 0 &&
                t.forEach((t) => {
                    this.allCalloutOptions.some((e) => e.type === t.type) ||
                        this.allCalloutOptions.push({ type: t.type, label: t.title || t.type.charAt(0).toUpperCase() + t.type.slice(1), icon: t.icon, color: `rgb(${t.color})`, isAdmonition: !0, sourcePlugin: "Admonition" });
                });
        }
    }
    onOpen() {
        this.display();
    }
    display() {
        return e(this, void 0, void 0, function* () {
            const { contentEl: e } = this;
            e.empty(),
                e.addEventListener("keydown", (t) => {
                    "Enter" === t.key && (t.ctrlKey || t.metaKey) && (t.preventDefault(), this.insertButton && this.insertButton.click());
                });
            const i = e.createDiv("callout-type-container");
            (this.iconContainerEl = i.createDiv("callout-icon-container")),
                new t.Setting(i).setName(Wr("Callout Type")).addDropdown((t) => {
                    const e = this.allCalloutOptions.filter((t) => !t.isAdmonition),
                        i = this.allCalloutOptions.filter((t) => t.isAdmonition);
                    if (e.length > 0 && i.length > 0) {
                        t.addOption("---separator---", "---- Admonitions ----");
                        const e = t.selectEl.options[t.selectEl.options.length - 1];
                        e && (e.disabled = !0);
                    }
                    i.forEach((e) => {
                        t.addOption(e.type, `${e.label} (Admonition)`);
                    }),
                        t.addOption("---separator---", "---- Default ----"),
                        e.forEach((e) => {
                            t.addOption(e.type, e.label);
                        }),
                        this.allCalloutOptions.some((t) => t.type === this.type) || (this.type = this.allCalloutOptions.length > 0 ? this.allCalloutOptions[0].type : "note"),
                        t.setValue(this.type),
                        t.onChange((e) => {
                            "---separator---" !== e ? ((this.type = e), this.updateIconAndColor(this.iconContainerEl, e)) : t.setValue(this.type);
                        });
                }),
                this.updateIconAndColor(this.iconContainerEl, this.type),
                new t.Setting(e)
                    .setName(Wr("Title"))
                    .setDesc(Wr("Optional, leave blank for default title"))
                    .addText((t) => {
                        t.setPlaceholder(Wr("Input title"))
                            .setValue(this.title)
                            .onChange((t) => {
                                this.title = t;
                            });
                    }),
                new t.Setting(e).setName(Wr("Collapse State")).addDropdown((t) => {
                    t.addOption("none", Wr("Default"))
                        .addOption("open", Wr("Open"))
                        .addOption("closed", Wr("Closed"))
                        .setValue(this.collapse)
                        .onChange((t) => {
                            this.collapse = t;
                        });
                }),
                new t.Setting(e).setName(Wr("Content")).addTextArea((t) => {
                    t
                        .setPlaceholder(Wr("Input content"))
                        .setValue(this.content)
                        .onChange((t) => {
                            this.content = t;
                        }),
                        (t.inputEl.rows = 5),
                        (t.inputEl.cols = 40),
                        (this.contentTextArea = t.inputEl);
                });
            const n = e.createDiv("shortcut-hint");
            n.setText(`${t.Platform.isMacOS ? "⌘" : "Ctrl"} + Enter ${Wr("to insert")}`),
                (n.style.textAlign = "right"),
                (n.style.fontSize = "0.8em"),
                (n.style.opacity = "0.7"),
                (n.style.marginTop = "5px"),
                new t.Setting(e)
                    .addButton(
                        (t) => (
                            t
                                .setButtonText(Wr("Insert"))
                                .setCta()
                                .onClick(() => {
                                    this.insertCallout(), this.close();
                                }),
                            (this.insertButton = t.buttonEl),
                            t
                        )
                    )
                    .addButton(
                        (t) => (
                            t
                                .setButtonText(Wr("Cancel"))
                                .setTooltip(Wr("Cancel"))
                                .onClick(() => this.close()),
                            t
                        )
                    ),
                setTimeout(() => {
                    this.contentTextArea && this.contentTextArea.focus();
                }, 10);
        });
    }
    updateIconAndColor(e, i) {
        if (!e) return;
        const n = this.allCalloutOptions.find((t) => t.type === i);
        if ((e.empty(), n))
            if (n.isAdmonition) {
                const i = n.icon;
                if ("custom" === i.type && i.svg) {
                    e.innerHTML = i.svg;
                    const t = e.querySelector("svg");
                    t && ((t.style.fill = n.color), (t.style.width = "var(--icon-size)"), (t.style.height = "var(--icon-size)"));
                } else i.name.startsWith("lucide-") || "default" === i.type ? (t.setIcon(e, i.name), e.style.setProperty("--callout-color", n.color)) : (t.setIcon(e, "lucide-box"), e.style.setProperty("--callout-color", n.color));
            } else t.setIcon(e, n.icon), e.style.setProperty("--callout-color", n.color);
        else t.setIcon(e, "lucide-alert-circle"), e.style.removeProperty("--callout-color");
    }
    insertCallout() {
        const t = this.plugin.commandsManager.getActiveEditor();
        if (!t) return;
        let e = `> [!${this.type}]`;
        "none" !== this.collapse && (e += "open" === this.collapse ? "+" : "-"), this.title && (e += ` ${this.title}`), (e += `\n> ${this.content.replace(/\n/g, "\n> ")}`);
        const i = t.getCursor(),
            n = t.getLine(i.line),
            o = 0 === i.ch;
        let s;
        if (t.getSelection()) {
            !o && n.trim().length > 0 && (e = "\n" + e);
            const i = t.getCursor("from");
            t.replaceSelection(e);
            const r = e.split("\n").length;
            s = { line: i.line + r, ch: 0 };
        } else {
            !o && n.trim().length > 0 && (e = "\n" + e), t.replaceRange(e, i);
            const r = e.split("\n").length;
            s = { line: i.line + r, ch: 0 };
        }
        setTimeout(() => {
            t.replaceRange("\n", s), t.setCursor({ line: s.line + 1, ch: 0 }), t.focus();
        }, 0);
    }
}
class _c {
    static isValidUrl(t) {
        try {
            return new URL(t), !0;
        } catch (t) {
            return !1;
        }
    }
    static parseTitle(t, e) {
        const i = [t.includes("mp.weixin.qq.com") ? this.wxTitlePattern : null, this.htmlTitlePattern, /<title [^>]*>(.*?)<\/title>/i, /<meta name="title" content="([^<]*)" \/>/im].filter(Boolean);
        for (const t of i) {
            const i = e.match(t);
            if (i && "string" == typeof i[1]) return i[1].trim();
        }
        throw new Error("Unable to parse the title tag");
    }
    static getFallbackTitle(t) {
        const e = t.match(/[^/\\]+$/);
        return e
            ? e[0]
                .replace(/\.[^/.]+$/, "")
                .replace(/[-_]/g, " ")
                .trim()
            : t;
    }
    static fetchRemoteTitle(i) {
        return e(this, void 0, void 0, function* () {
            if (!this.isValidUrl(i) || !i.match(/^https?:\/\//)) return this.getFallbackTitle(i);
            try {
                const e = yield t.requestUrl({ url: i, method: "GET", headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36" }, throw: !0 });
                if (200 !== e.status) throw new Error(`Status code ${e.status}`);
                const n = e.text,
                    o = this.parseTitle(i, n);
                return !o || o.length > 100 ? this.getFallbackTitle(i) : o;
            } catch (t) {
                return this.getFallbackTitle(i);
            }
        });
    }
}
(_c.htmlTitlePattern = /<title>([^<]*)<\/title>/im), (_c.wxTitlePattern = /<meta property="og:title" content="([^<]*)" \/>/im);
class Fc extends t.Modal {
    constructor(t) {
        super(t.app),
            (this.plugin = t),
            (this.linkText = ""),
            (this.linkUrl = ""),
            (this.linkAlias = ""),
            (this.isEmbed = !1),
            (this.insertNewLine = !1),
            (this.imageWidth = ""),
            (this.imageHeight = ""),
            (this.prefixText = ""),
            (this.suffixText = ""),
            (this.selectedText = "");
        const e = this.plugin.commandsManager.getActiveEditor();
        if (e) {
            const t = e.getSelection() || "";
            t ? this.handleSelectedText(e, t) : this.handleCursorPosition(e);
        } else this.parseClipboard();
        this.updateHeader();
    }
    handleSelectedText(t, e) {
        const i = this.tryExpandSelection(t, e);
        if (i) {
            const e = this.formatTargetText(i);
            t.setSelection(i.from, i.to), (this.selectedText = e), this.parseSelectedText(e);
        } else (this.selectedText = e), this.parseSelectedText(e);
    }
    handleCursorPosition(t) {
        const e = t.getCursor(),
            i = this.findLinkAtCursor(t, e);
        if (i) {
            const e = this.formatTargetText(i);
            t.setSelection(i.from, i.to), (this.selectedText = e), this.parseSelectedText(e);
        } else this.parseClipboard();
    }
    tryExpandSelection(t, e) {
        const i = t.getCursor("from"),
            n = t.getLine(i.line),
            o = i.ch,
            s = t.getCursor("to").ch;
        return this.matchLinkInLine(n, o, s, i.line);
    }
    findLinkAtCursor(t, e) {
        const i = t.getLine(e.line),
            n = e.ch;
        return this.matchLinkInLine(i, n, n, e.line);
    }
    matchLinkInLine(t, e, i, n) {
        const o = /(!)?\[([^\]]+)\]\(([^\s)]+)(?:\s+["']([^"']*)["'])?\)/g;
        let s;
        for (; null !== (s = o.exec(t));) {
            const t = !!s[1],
                o = s.index,
                r = s.index + s[0].length,
                l = s[2],
                a = s[3],
                c = s[4] || "";
            if (e <= r && i >= o) return { isImage: t, text: l, url: a, title: c, from: { line: n, ch: o }, to: { line: n, ch: r } };
        }
        const r = /(?:^|\s)([a-zA-Z][a-zA-Z\d+\-.]*:\/\/\S+|\S+\.[a-zA-Z]{2,}(?:\/\S*)?)/g;
        for (; null !== (s = r.exec(t));) {
            const t = s[1],
                o = s.index + (s[0].startsWith(" ") ? 1 : 0),
                r = o + t.length;
            if (e <= r && i >= o) return { isImage: /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(t), text: t, url: t, title: "", from: { line: n, ch: o }, to: { line: n, ch: r } };
        }
        return null;
    }
    formatTargetText(t) {
        return t.isImage ? `![${t.text}](${t.url}${t.title ? ` "${t.title}"` : ""})` : t.title ? `[${t.text}](${t.url} "${t.title}")` : `[${t.text}](${t.url})`;
    }
    parseSelectedText(t) {
        const e = t.match(/!\[.*?\]\(.*?\)/);
        if (e) {
            const i = t.substring(0, e.index),
                n = t.substring(e.index + e[0].length),
                o = this.parseMarkdownImageLink(t);
            if (o)
                return (
                    (this.linkText = o.title),
                    (this.linkUrl = o.url),
                    (this.linkAlias = o.quotedTitle || ""),
                    (this.imageWidth = o.width || ""),
                    (this.imageHeight = o.height || ""),
                    (this.isEmbed = !0),
                    (this.prefixText = i),
                    void (this.suffixText = n)
                );
        }
        const i = t.match(/\[([^\]]+)\]\(([a-zA-Z]+:\/\/[^\s)]+)(?:\s+["']([^"']*)["'])?\)/);
        if (i) {
            const e = i[0],
                n = t.substring(0, i.index),
                o = t.substring(i.index + e.length),
                s = this.parseMarkdownLink(e);
            s && ((this.linkText = s.text), (this.linkUrl = s.url), (this.linkAlias = s.title || ""), (this.isEmbed = !1)), (this.prefixText = n), (this.suffixText = o);
        } else {
            const e = this.parseMixedContent(t);
            e && ((this.linkText = e.title), (this.linkUrl = e.url));
        }
    }
    parseMixedContent(t) {
        let e;
        return (e = t.match(/^\[(.*?)\]\((.*?)\)$/))
            ? { title: e[1].trim(), url: e[2].trim() }
            : (e = t.match(/<a[^>]+href=["']([^"']+)["'][^>]*>([^<]+)<\/a>/i))
                ? { title: e[2].trim(), url: e[1].trim() }
                : (e = t.match(/^(.*?)\s*((?:https?:\/\/|www\.)\S+)$/i)) && e[1].trim()
                    ? { title: e[1].trim(), url: e[2].trim() }
                    : this.isValidUrl(t.trim())
                        ? { title: this.extractTitleFromUrl(t.trim()), url: t.trim() }
                        : { title: t.trim(), url: "" };
    }
    extractTitleFromUrl(t) {
        const e = t.match(/^([a-zA-Z]+):\/\/(.+)$/);
        if (e) {
            const [, t, i] = e,
                n = i.split(/[/\\]/),
                o = n[n.length - 1];
            return o ? decodeURIComponent(o).trim() : t.toUpperCase();
        }
        const i = t.match(/^\[\[(.*?)\]\]$/);
        if (i) return i[1];
        const n = t.match(/[^/\\]+$/);
        return n
            ? n[0]
                .replace(/\.[^/.]+$/, "")
                .replace(/[-_]/g, " ")
                .trim()
            : t;
    }
    isValidUrl(t) {
        if (!t || t.includes("\n") || /\s/.test(t)) return !1;
        if (["obsidian://", "zotero://", "evernote://", "notion://", "bear://", "things://", "drafts://", "x-devonthink-item://", "file://", "ftp://", "ftps://", "http://", "https://", "tel:", "mailto:"].some((e) => t.startsWith(e)))
            return !0;
        if (t.match(/^\[\[.*?\]\]$/)) return !0;
        if (t.match(/^[./\\]/) || t.match(/^[a-zA-Z]:\\/) || t.match(/^\/[^/]/) || t.match(/^[a-zA-Z]+:\/\//)) return !0;
        try {
            return new URL(t), !0;
        } catch (t) {
            return !1;
        }
    }
    parseMarkdownImageLink(t) {
        const e = t.match(/!\[(.*?)(?:\|(\d+)(?:x(\d+))?)?\]\(\s*([^\s)]+)(?:\s+["']([^"']*)["'])?\s*\)/);
        if (e) {
            const [, t, i, n, o, s] = e;
            if (((this.isEmbed = !0), this.embedToggle)) {
                this.embedToggle.setValue(!0);
                const t = this.contentEl.querySelector(".image-size-setting");
                t && (t.style.display = "block");
            }
            return { title: t.trim(), url: o.trim(), width: i, height: n, quotedTitle: null == s ? void 0 : s.trim() };
        }
        return null;
    }
    parseMarkdownLink(t) {
        const e = t.match(/\[([^\]]+)\]\(([a-zA-Z]+:\/\/[^\s)]+)(?:\s+["']([^"']*)["'])?\)/);
        if (e) {
            const [, t, i, n] = e;
            return { text: t.trim(), url: i.trim(), title: null == n ? void 0 : n.trim() };
        }
        return null;
    }
    parseClipboard() {
        return e(this, void 0, void 0, function* () {
            try {
                const t = yield this.readClipboard(),
                    e = t["text/plain"];
                if (e) {
                    const t = this.parseMarkdownImageLink(e);
                    if (t)
                        return (
                            (this.linkText = t.title),
                            (this.linkUrl = t.url),
                            (this.linkAlias = t.quotedTitle || ""),
                            (t.width || t.height) && ((this.isEmbed = !0), (this.imageWidth = t.width || ""), (this.imageHeight = t.height || "")),
                            void this.updateUI()
                        );
                    const i = this.parseMarkdownLink(e);
                    if (i) return (this.linkText = i.text), (this.linkUrl = i.url), (this.linkAlias = i.title || ""), (this.isEmbed = !1), void this.updateUI();
                }
                if (t["text/html"]) {
                    const e = this.parseHtmlContent(t["text/html"]);
                    e && ((this.linkText = this.linkText || e.title), (this.linkUrl = e.url));
                } else if (t["text/markdown"]) {
                    const e = this.parseMarkdownContent(t["text/markdown"]);
                    e && ((this.linkText = this.linkText || e.title), (this.linkUrl = e.url));
                } else if (t["text/plain"]) {
                    const e = this.parseMixedContent(t["text/plain"]);
                    e && ((this.linkText = this.linkText || e.title), (this.linkUrl = e.url));
                }
                this.updateUI();
            } catch (t) { }
        });
    }
    readClipboard() {
        return e(this, void 0, void 0, function* () {
            const t = {};
            try {
                const e = yield navigator.clipboard.read();
                for (const i of e) {
                    const e = i.types;
                    for (const n of e)
                        if ("text/html" === n || "text/plain" === n || "text/markdown" === n) {
                            const e = yield i.getType(n);
                            t[n] = yield e.text();
                        }
                }
            } catch (e) {
                try {
                    const e = yield navigator.clipboard.readText();
                    t["text/plain"] = e;
                } catch (t) { }
            }
            return t;
        });
    }
    parseHtmlContent(t) {
        var e;
        const i = new DOMParser().parseFromString(t, "text/html"),
            n = i.querySelector("a");
        if (n) return { title: (null === (e = n.textContent) || void 0 === e ? void 0 : e.trim()) || "", url: n.href };
        const o = i.body.textContent || "";
        return this.parseMixedContent(o);
    }
    parseMarkdownContent(t) {
        const e = t.match(/\[([^\]]+)\]\(([^)]+)\)/);
        return e ? { title: e[1].trim(), url: e[2].trim() } : this.parseMixedContent(t);
    }
    onOpen() {
        this.display();
    }
    updateHeader() {
        const t = this.getPreviewText();
        this.previewSetting && (this.previewSetting.controlEl.querySelector("input").value = t);
    }
    getPreviewText() {
        const t = this.linkText || "",
            e = this.linkUrl;
        let i = this.isEmbed ? "!" : "";
        return (
            (i += `[${t}`),
            this.isEmbed &&
            (this.imageWidth || this.imageHeight) &&
            ((i += "|"), this.imageWidth && this.imageHeight ? (i += `${this.imageWidth}x${this.imageHeight}`) : this.imageWidth ? (i += this.imageWidth) : this.imageHeight && (i += `x${this.imageHeight}`)),
            (i += `](${e}`),
            this.linkAlias && (i += ` "${this.linkAlias}"`),
            (i += ")"),
            i
        );
    }
    display() {
        return e(this, void 0, void 0, function* () {
            const { contentEl: i } = this;
            i.empty(),
                i.addClass("insert-link-modal"),
                (this.titleEl.textContent = ""),
                this.titleEl.addClass("insert-link-modal-title"),
                i.addEventListener("keydown", (t) => {
                    "Enter" === t.key && (t.ctrlKey || t.metaKey) && (t.preventDefault(), this.insertButton && this.insertButton.click());
                }),
                new t.Setting(i)
                    .addButton((i) => {
                        i.setIcon("lucide-globe")
                            .setTooltip(Wr("Fetch Remote Title"))
                            .onClick(() =>
                                e(this, void 0, void 0, function* () {
                                    if (this.linkUrl) {
                                        i.setDisabled(!0), i.setIcon("lucide-loader");
                                        const t = yield this.fetchRemoteTitle(this.linkUrl);
                                        i.setIcon("lucide-globe"), i.setDisabled(!1), (this.linkText = t), this.linkTextInput.setValue(t), this.updateHeader();
                                    } else new t.Notice(Wr("Please enter a URL first"));
                                })
                            );
                    })
                    .setName(Wr("Link Text"))
                    .addText((t) => {
                        (this.linkTextInput = t),
                            t
                                .setPlaceholder(Wr("Link Text"))
                                .setValue(this.linkText)
                                .onChange((t) => {
                                    (this.linkText = t), this.updateHeader();
                                });
                    });
            const n = new t.Setting(i).setName(Wr("Title")).addText((t) => {
                (this.linkAliasInput = t),
                    t
                        .setPlaceholder(Wr("Link Title (optional)"))
                        .setValue(this.linkAlias)
                        .onChange((t) => {
                            (this.linkAlias = t), this.updateHeader();
                        });
            }),
                o = new t.Setting(i)
                    .setName(Wr("Link URL"))
                    .setClass("link-url-setting")
                    .addText((t) => {
                        (this.linkUrlInput = t),
                            t
                                .setPlaceholder(Wr("Link URL"))
                                .setValue(this.linkUrl)
                                .onChange((t) => {
                                    (this.linkUrl = t.trim()), this.validateUrl(this.linkUrl), this.updateHeader();
                                });
                    })
                    .addButton((t) => {
                        t.setIcon("lucide-clipboard")
                            .setTooltip(Wr("Paste and Parse"))
                            .onClick(() =>
                                e(this, void 0, void 0, function* () {
                                    yield this.parseClipboard(), this.updateHeader();
                                })
                            );
                    });
            (this.urlErrorMsg = o.descEl.createDiv("url-error")), (this.urlErrorMsg.style.color = "var(--text-error)"), (this.urlErrorMsg.style.display = "none");
            const s = new t.Setting(i).setName(Wr("Embed Content")).setDesc(Wr("If it is an image, turn on"));
            (this.embedToggle = new t.ToggleComponent(s.controlEl)),
                this.embedToggle.setValue(this.isEmbed).onChange((t) => {
                    this.isEmbed = t;
                    const e = i.querySelector(".image-size-setting");
                    n.settingEl, e && (e.style.display = t ? "flex" : "none"), this.updateHeader();
                });
            const r = new t.Setting(i).addButton((t) => {
                t.setIcon("lucide-maximize")
                    .setTooltip(Wr("Fit Editor Width"))
                    .onClick(() => {
                        var t;
                        const e = this.getImageDimensions();
                        e &&
                            ((this.imageWidth = e.width.toString()),
                                (this.imageHeight = null === (t = e.height) || void 0 === t ? void 0 : t.toString()),
                                r.components[1].setValue(this.imageWidth),
                                this.imageHeight && r.components[2].setValue(this.imageHeight),
                                this.updateHeader());
                    });
            });
            r.setClass("image-size-setting")
                .setName(Wr("Image Size"))
                .addText((t) => {
                    t.inputEl.addClass("image-width-input"),
                        t
                            .setPlaceholder(Wr("Image Width"))
                            .setValue(this.imageWidth)
                            .onChange((e) => {
                                (this.imageWidth = e.replace(/[^\d]/g, "")), t.setValue(this.imageWidth), this.updateHeader();
                            });
                });
            const l = r.controlEl.createDiv("image-size-icon");
            t.setIcon(l, "lucide-x"),
                r.addText((t) => {
                    t.inputEl.addClass("image-height-input"),
                        t
                            .setPlaceholder(Wr("Image Height"))
                            .setValue(this.imageHeight)
                            .onChange((e) => {
                                (this.imageHeight = e.replace(/[^\d]/g, "")), t.setValue(this.imageHeight), this.updateHeader();
                            });
                }),
                (r.settingEl.style.display = this.isEmbed ? "block" : "none"),
                new t.Setting(i)
                    .setName(Wr("Insert New Line"))
                    .setDesc(Wr("Insert a link on the next line"))
                    .addToggle((t) => {
                        t.setValue(this.insertNewLine).onChange((t) => {
                            (this.insertNewLine = t), this.updateHeader();
                        });
                    }),
                (this.previewSetting = new t.Setting(i)
                    .setClass("preview-setting")
                    .setTooltip(this.getPreviewText())
                    .addText((t) => {
                        t.setValue(this.getPreviewText()).inputEl.setAttribute("readonly", "true");
                    }));
            const a = i.createDiv("shortcut-hint");
            a.setText(`${t.Platform.isMacOS ? "⌘" : "Ctrl"} + Enter ${Wr("to insert")}`),
                (a.style.textAlign = "right"),
                (a.style.fontSize = "0.8em"),
                (a.style.opacity = "0.7"),
                (a.style.marginTop = "5px"),
                new t.Setting(i)
                    .addButton((t) => {
                        t
                            .setButtonText(Wr("Insert"))
                            .setCta()
                            .onClick(() => {
                                this.insertLink(), this.close();
                            }),
                            (this.insertButton = t.buttonEl);
                    })
                    .addButton((t) =>
                        t.setButtonText(Wr("Cancel")).onClick(() => {
                            this.close();
                        })
                    ),
                setTimeout(() => {
                    this.linkText || this.linkUrl
                        ? !this.linkText && this.linkUrl
                            ? this.linkTextInput.inputEl.focus()
                            : this.linkText && !this.linkUrl
                                ? this.linkUrlInput.inputEl.focus()
                                : this.linkAliasInput.inputEl.focus()
                        : this.linkTextInput.inputEl.focus();
                }, 10);
        });
    }
    fetchRemoteTitle(t) {
        return e(this, void 0, void 0, function* () {
            return _c.fetchRemoteTitle(t);
        });
    }
    getImageDimensions() {
        const e = this.app.workspace.getActiveViewOfType(t.MarkdownView);
        if (!e) return null;
        const i = e.contentEl.querySelector(".markdown-source-view .cm-content"),
            n = e.contentEl;
        if (!i || !n) return null;
        const o = i.offsetWidth,
            s = n.offsetHeight,
            r = Math.floor(s / 2);
        if ("preview" === e.getMode() || "source" === e.getMode()) {
            const t = i.querySelectorAll("img");
            if (t.length > 0) {
                let e = null;
                if (
                    (this.linkUrl &&
                        t.forEach((t) => {
                            t.src === this.linkUrl && t.complete && t.naturalWidth > 0 && (e = t);
                        }),
                        e)
                ) {
                    const t = e.naturalWidth,
                        i = t / e.naturalHeight;
                    let n = Math.min(t, Math.floor(0.65 * o)),
                        s = Math.floor(n / i);
                    return s > r && ((s = r), (n = Math.floor(s * i))), { width: n, height: s };
                }
            }
        }
        const l = Math.floor(r * (4 / 3));
        return { width: Math.min(Math.floor(0.65 * o), l), height: null };
    }
    validateUrl(t) {
        return t
            ? this.isValidUrl(t)
                ? ((this.urlErrorMsg.style.display = "none"), !0)
                : ((this.urlErrorMsg.textContent = Wr("URL Format Error")), (this.urlErrorMsg.style.display = "block"), !1)
            : ((this.urlErrorMsg.style.display = "none"), !0);
    }
    insertLink() {
        if (!this.validateUrl(this.linkUrl)) return;
        const t = this.plugin.commandsManager.getActiveEditor();
        if (!t) return;
        let e = this.linkText || this.linkUrl;
        const i = this.linkUrl;
        let n,
            o = this.isEmbed ? "!" : "";
        if (
            ((o += `[${e}`),
                this.isEmbed &&
                (this.imageWidth || this.imageHeight) &&
                ((o += "|"), this.imageWidth && this.imageHeight ? (o += `${this.imageWidth}x${this.imageHeight}`) : this.imageWidth ? (o += this.imageWidth) : this.imageHeight && (o += `x${this.imageHeight}`)),
                (o += `](${i}`),
                this.linkAlias && (o += ` "${this.linkAlias}"`),
                (o += ")"),
                t.somethingSelected())
        ) {
            const e = t.getCursor("from"),
                i = t.getCursor("to");
            if (this.insertNewLine) t.replaceRange("\n" + o, { line: i.line, ch: t.getLine(i.line).length }), (n = { line: i.line + 1, ch: o.length });
            else {
                const s = this.prefixText + o + this.suffixText;
                t.replaceRange(s, { line: e.line, ch: e.ch }, i), (n = { line: e.line, ch: this.prefixText.length + o.length });
            }
        } else {
            const e = t.getCursor(),
                i = t.getLine(e.line);
            if (this.insertNewLine) {
                const s = e.line + 1;
                t.replaceRange("\n", { line: e.line, ch: i.length }), t.setCursor({ line: s, ch: 0 }), t.replaceRange(o, { line: s, ch: 0 }), (n = { line: s, ch: o.length });
            } else t.replaceRange(o, e), (n = { line: e.line, ch: e.ch + o.length });
        }
        setTimeout(() => {
            n && t.setCursor(n), t.focus();
        }, 0);
    }
    updateUI() {
        this.linkTextInput && this.linkTextInput.setValue(this.linkText), this.linkUrlInput && (this.linkUrlInput.setValue(this.linkUrl), this.validateUrl(this.linkUrl));
        const t = this.contentEl.querySelector(".image-width-input"),
            e = this.contentEl.querySelector(".image-height-input");
        t && (t.value = this.imageWidth), e && (e.value = this.imageHeight), this.linkAliasInput && this.linkAliasInput.setValue(this.linkAlias);
        const i = this.contentEl.querySelector(".setting-item:nth-child(2)");
        i && (i.style.display = "flex"), this.updateHeader();
    }
}
class Vc {
    constructor(t) {
        (this.executeCommandWithoutBlur = (t, i) =>
            e(this, void 0, void 0, function* () {
                t && (yield i(), t.focus());
            })),
            (this._commandsMap = {
                hrline: { char: 5, line: 1, prefix: "\n---", suffix: "\n", islinehead: !0 },
                justify: { char: 0, line: 0, prefix: '<p align="justify">', suffix: "</p>", islinehead: !1 },
                left: { char: 0, line: 0, prefix: '<p align="left">', suffix: "</p>", islinehead: !1 },
                right: { char: 0, line: 0, prefix: '<p align="right">', suffix: "</p>", islinehead: !1 },
                center: { char: 0, line: 0, prefix: "<center>", suffix: "</center>", islinehead: !1 },
                underline: { char: 0, line: 0, prefix: "<u>", suffix: "</u>", islinehead: !1 },
                superscript: { char: 0, line: 0, prefix: "<sup>", suffix: "</sup>", islinehead: !1 },
                subscript: { char: 0, line: 0, prefix: "<sub>", suffix: "</sub>", islinehead: !1 },
                codeblock: { char: 4, line: 0, prefix: "\n```\n", suffix: "\n```\n", islinehead: !1 },
            }),
            (this.modCommands = [
                { id: "editor:insert-embed", name: "Add embed", icon: "note-glyph" },
                { id: "editor:insert-link", name: "Insert markdown link", icon: "link-glyph" },
                { id: "editor:insert-tag", name: "Add tag", icon: "price-tag-glyph" },
                { id: "editor:insert-wikilink", name: "Add internal link", icon: "bracket-glyph" },
                { id: "editor:toggle-code", name: "Code", icon: "code-glyph" },
                { id: "editor:toggle-blockquote", name: "Blockquote", icon: "lucide-text-quote" },
                { id: "editor:toggle-checklist-status", name: "Checklist status", icon: "checkbox-glyph" },
                { id: "editor:toggle-comments", name: "Comment", icon: "percent-sign-glyph" },
                { id: "editor:insert-callout", name: "Insert Callout", icon: "lucide-quote" },
                { id: "editor:insert-mathblock", name: "MathBlock", icon: "lucide-sigma-square" },
                { id: "editor:insert-table", name: "Insert Table", icon: "lucide-table" },
                { id: "editor:swap-line-up", name: "Swap line up", icon: "lucide-corner-right-up" },
                { id: "editor:swap-line-down", name: "Swap line down", icon: "lucide-corner-right-down" },
                { id: "editor:attach-file", name: "Attach file", icon: "lucide-paperclip" },
                { id: "editor:clear-formatting", name: "Clear formatting", icon: "lucide-eraser" },
            ]),
            (this.applyCommand = (t, e) => {
                const i = e.getSelection(),
                    n = e.getCursor("from"),
                    o = e.getCursor("to");
                let s = t.prefix;
                t.islinehead && n.ch > 0 && (s = "\n" + s);
                const r = t.suffix,
                    l = { line: n.line - t.line, ch: n.ch - s.length };
                if (e.getRange(l, n) == s) {
                    const a = { line: n.line + t.line, ch: o.ch + r.length };
                    if (e.getRange(o, a) == r) {
                        e.replaceRange(i, l, a), e.setCursor(n.line - t.line, n.ch);
                        const o = { line: n.line, ch: n.ch - s.length },
                            r = { line: n.line, ch: o.ch + i.length };
                        return void e.setSelection(o, r);
                    }
                }
                if ((e.replaceSelection(`${s}${i}${r}`), t.char > 0)) e.setCursor(n.line + t.line, n.ch + t.char + i.length);
                else {
                    const t = n,
                        o = { line: t.line, ch: t.ch + s.length },
                        r = { line: t.line, ch: o.ch + i.length };
                    e.setSelection(o, r);
                }
            }),
            (this.plugin = t);
    }
    applyRegexCommand(i, n) {
        return e(this, void 0, void 0, function* () {
            try {
                let e = i.getSelection();
                const o = i.getCursor("from");
                if ((i.getCursor("to"), !e))
                    try {
                        const n = yield this.readClipboard();
                        if (((e = n["text/html"] ? t.htmlToMarkdown(n["text/html"]) : n["text/markdown"] || n["text/plain"]), !e)) return void new t.Notice(Wr("Please select text or copy text to clipboard first"));
                        i.replaceRange(e, o, o);
                        const s = i.offsetToPos(i.posToOffset(o) + e.length);
                        i.setSelection(o, s);
                    } catch (e) {
                        return void new t.Notice(Wr("Please select text first"));
                    }
                if (n.useCondition && n.conditionPattern && !new RegExp(n.conditionPattern).test(e)) return void new t.Notice(Wr("The selected text does not meet the condition requirements"));
                let s = "";
                !1 !== n.regexGlobal && (s += "g"), n.regexCaseInsensitive && (s += "i"), n.regexMultiline && (s += "m");
                const r = new RegExp(n.regexPattern, s),
                    l = i.getCursor("from"),
                    a = i.getCursor("to");
                i.transaction({ changes: [{ from: l, to: a, text: e.replace(r, n.regexReplacement) }] });
                const c = i.getSelection(),
                    h = i.offsetToPos(i.posToOffset(l)),
                    d = i.offsetToPos(i.posToOffset(l) + c.length);
                i.setSelection(h, d);
            } catch (e) {
                new t.Notice(Wr("Regex command execution error:") + e.message);
            }
        });
    }
    readClipboard() {
        return e(this, void 0, void 0, function* () {
            const t = {};
            try {
                const e = yield navigator.clipboard.read();
                for (const i of e) {
                    const e = i.types;
                    for (const n of e)
                        if ("text/html" === n || "text/plain" === n || "text/markdown" === n) {
                            const e = yield i.getType(n);
                            t[n] = yield e.text();
                        }
                }
            } catch (e) {
                try {
                    const e = yield navigator.clipboard.readText();
                    t["text/plain"] = e;
                } catch (t) { }
            }
            return t;
        });
    }
    getActiveEditor() {
        var t, e, i;
        const n = null === (t = this.plugin.app.workspace) || void 0 === t ? void 0 : t.activeEditor;
        if (n && n.editor) return n.editor;
        return (null === (i = null === (e = this.plugin.app.workspace.activeLeaf) || void 0 === e ? void 0 : e.view) || void 0 === i ? void 0 : i.editor) || null;
    }
    registerCommands() {
        this.plugin.addCommand({
            id: "renumber-ordered-list",
            name: "Renumber ordered list",
            editorCallback: (t) => {
                t && this.executeCommandWithoutBlur(t, () => qr(t));
            },
        }),
            this.plugin.addCommand({
                id: "hide-show-menu",
                name: "Hide/show ",
                icon: "editingToolbar",
                callback: () =>
                    e(this, void 0, void 0, function* () {
                        (this.plugin.settings.cMenuVisibility = !this.plugin.settings.cMenuVisibility),
                            this.plugin.settings.cMenuVisibility
                                ? setTimeout(() => {
                                    dispatchEvent(new Event("editingToolbar-NewCommand"));
                                }, 100)
                                : Pr(this.plugin.settings.cMenuVisibility),
                            nl(),
                            yield this.plugin.saveSettings();
                    }),
            }),
            this.plugin.addCommand({
                id: "format-eraser",
                name: "Format Eraser",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => ul(this.plugin, t));
                },
                icon: "eraser",
            }),
            this.plugin.addCommand({
                id: "change-font-color",
                name: "Change font color[html]",
                callback: () => {
                    const t = this.getActiveEditor();
                    t &&
                        this.executeCommandWithoutBlur(t, () => {
                            var e;
                            return Or(null !== (e = this.plugin.settings.cMenuFontColor) && void 0 !== e ? e : "#2DC26B", t);
                        });
                },
                icon:
                    '<svg width="24" height="24" focusable="false" fill="currentColor"><g fill-rule="evenodd"><path id="change-font-color-icon" d="M3 18h18v3H3z" style="fill:#2DC26B"></path><path d="M8.7 16h-.8a.5.5 0 01-.5-.6l2.7-9c.1-.3.3-.4.5-.4h2.8c.2 0 .4.1.5.4l2.7 9a.5.5 0 01-.5.6h-.8a.5.5 0 01-.4-.4l-.7-2.2c0-.3-.3-.4-.5-.4h-3.4c-.2 0-.4.1-.5.4l-.7 2.2c0 .3-.2.4-.4.4zm2.6-7.6l-.6 2a.5.5 0 00.5.6h1.6a.5.5 0 00.5-.6l-.6-2c0-.3-.3-.4-.5-.4h-.4c-.2 0-.4.1-.5.4z"></path></g></svg>',
            }),
            this.plugin.addCommand({
                id: "change-background-color",
                name: "Change Backgroundcolor[html]",
                callback: () => {
                    const t = this.getActiveEditor();
                    t &&
                        this.executeCommandWithoutBlur(t, () => {
                            var e;
                            return Br(null !== (e = this.plugin.settings.cMenuBackgroundColor) && void 0 !== e ? e : "#FA541C", t);
                        });
                },
                icon:
                    '<svg width="18" height="24" viewBox="0 0 256 256" version="1.1" xmlns="http://www.w3.org/2000/svg"><g   stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd"><g  ><g fill="currentColor"><g transform="translate(119.502295, 137.878331) rotate(-135.000000) translate(-119.502295, -137.878331) translate(48.002295, 31.757731)" ><path d="M100.946943,60.8084699 L43.7469427,60.8084699 C37.2852111,60.8084699 32.0469427,66.0467383 32.0469427,72.5084699 L32.0469427,118.70847 C32.0469427,125.170201 37.2852111,130.40847 43.7469427,130.40847 L100.946943,130.40847 C107.408674,130.40847 112.646943,125.170201 112.646943,118.70847 L112.646943,72.5084699 C112.646943,66.0467383 107.408674,60.8084699 100.946943,60.8084699 Z M93.646,79.808 L93.646,111.408 L51.046,111.408 L51.046,79.808 L93.646,79.808 Z" fill-rule="nonzero"></path><path d="M87.9366521,16.90916 L87.9194966,68.2000001 C87.9183543,69.4147389 86.9334998,70.399264 85.7187607,70.4 L56.9423078,70.4 C55.7272813,70.4 54.7423078,69.4150264 54.7423078,68.2 L54.7423078,39.4621057 C54.7423078,37.2523513 55.5736632,35.1234748 57.0711706,33.4985176 L76.4832996,12.4342613 C78.9534987,9.75382857 83.1289108,9.5834005 85.8093436,12.0535996 C87.1658473,13.303709 87.9372691,15.0644715 87.9366521,16.90916 Z" fill-rule="evenodd"></path><path d="M131.3,111.241199 L11.7,111.241199 C5.23826843,111.241199 0,116.479467 0,122.941199 L0,200.541199 C0,207.002931 5.23826843,212.241199 11.7,212.241199 L131.3,212.241199 C137.761732,212.241199 143,207.002931 143,200.541199 L143,122.941199 C143,116.479467 137.761732,111.241199 131.3,111.241199 Z M124,130.241 L124,193.241 L19,193.241 L19,130.241 L124,130.241 Z" fill-rule="nonzero"></path></g></g><path d="M51,218 L205,218 C211.075132,218 216,222.924868 216,229 C216,235.075132 211.075132,240 205,240 L51,240 C44.9248678,240 40,235.075132 40,229 C40,222.924868 44.9248678,218 51,218 Z" id="change-background-color-icon" style="fill:#FA541C"></path></g></g></svg>',
            }),
            this.plugin.addCommand({
                id: "indent-list",
                name: "Indent list",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.indentList()));
                },
                icon: "indent-glyph",
            }),
            this.plugin.addCommand({
                id: "undent-list",
                name: "Unindent list",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.unindentList()));
                },
                icon: "unindent-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-numbered-list",
                name: "Numbered list",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleNumberList()));
                },
                icon: "number-list-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-bullet-list",
                name: "bullet list",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleBulletList()));
                },
                icon: "bullet-list-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-highlight",
                name: "highlight",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleMarkdownFormatting("highlight")));
                },
                icon: "highlight-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-bold",
                name: "Bold",
                callback: () => {
                    const t = this.getActiveEditor();
                    t &&
                        this.executeCommandWithoutBlur(t, () => {
                            t.toggleMarkdownFormatting("bold");
                        });
                },
                icon: "bold-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-italics",
                name: "Italics",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleMarkdownFormatting("italic")));
                },
                icon: "italic-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-strikethrough",
                name: "Strikethrough",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleMarkdownFormatting("strikethrough")));
                },
                icon: "strikethrough-glyph",
            }),
            this.plugin.addCommand({
                id: "toggle-inline-math",
                name: "Inline math",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleMarkdownFormatting("math")));
                },
                icon: "lucide-sigma",
            }),
            this.plugin.addCommand({
                id: "editor:cycle-list-checklist",
                name: "Cycle list checklist",
                icon: "lucide-check-square",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.toggleCheckList(!0)));
                },
            }),
            this.plugin.addCommand({
                id: "editor-undo",
                name: "Undo editor",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.undo()));
                },
                icon: "undo-glyph",
            }),
            this.plugin.addCommand({
                id: "editor-redo",
                name: "Redo editor",
                callback: () => {
                    const t = this.getActiveEditor();
                    t && this.executeCommandWithoutBlur(t, () => (null == t ? void 0 : t.redo()));
                },
                icon: "redo-glyph",
            }),
            this.plugin.addCommand({
                id: "editor-copy",
                name: "Copy editor",
                callback: () => {
                    const t = this.getActiveEditor();
                    t &&
                        this.executeCommandWithoutBlur(t, () =>
                            e(this, void 0, void 0, function* () {
                                try {
                                    yield window.navigator.clipboard.writeText(t.getSelection()), this.plugin.app.commands.executeCommandById("editor:focus");
                                } catch (t) { }
                            })
                        );
                },
                icon: "lucide-copy",
            }),
            this.plugin.addCommand({
                id: "editor-paste",
                name: "Paste editor",
                callback: () => {
                    const t = this.getActiveEditor();
                    t &&
                        this.executeCommandWithoutBlur(t, () =>
                            e(this, void 0, void 0, function* () {
                                try {
                                    const e = yield window.navigator.clipboard.readText();
                                    e && t.replaceSelection(e), this.plugin.app.commands.executeCommandById("editor:focus");
                                } catch (t) { }
                            })
                        );
                },
                icon: "lucide-clipboard-type",
            }),
            this.plugin.addCommand({
                id: "editor-cut",
                name: "Cut editor",
                callback: () => {
                    const t = this.getActiveEditor();
                    t &&
                        this.executeCommandWithoutBlur(t, () =>
                            e(this, void 0, void 0, function* () {
                                try {
                                    yield window.navigator.clipboard.writeText(t.getSelection()), t.replaceSelection(""), this.plugin.app.commands.executeCommandById("editor:focus");
                                } catch (t) { }
                            })
                        );
                },
                icon: "lucide-scissors",
            }),
            this.plugin.addCommand({
                id: "insert-callout",
                name: "Insert Callout(Modal)",
                icon: "lucide-quote",
                callback: () => {
                    new Pc(this.plugin).open();
                },
            }),
            this.plugin.addCommand({
                id: "insert-link",
                name: "Insert Link(Modal)",
                icon: "lucide-link",
                callback: () => {
                    new Fc(this.plugin).open();
                },
            }),
            this.plugin.addCommand({
                id: "fullscreen-focus",
                name: "Fullscreen focus mode",
                hotkeys: [{ modifiers: ["Mod", "Shift"], key: "F11" }],
                callback: () =>
                    (function (e) {
                        var i;
                        Object.defineProperty(exports, "__esModule", { value: !0 }), (exports.toggleFull = exports.isFull = exports.exitFull = exports.beFull = void 0);
                        let n = document.documentElement,
                            o = n.querySelector("head"),
                            s = document.createElement("style"),
                            r = "requestFullscreen",
                            l = "exitFullscreen",
                            a = "fullscreenElement";
                        "webkitRequestFullScreen" in n
                            ? ((r = "webkitRequestFullScreen"), (l = "webkitExitFullscreen"), (a = "webkitFullscreenElement"))
                            : "msRequestFullscreen" in n
                                ? ((r = "msRequestFullscreen"), (l = "msExitFullscreen"), (a = "msFullscreenElement"))
                                : "mozRequestFullScreen" in n && ((r = "mozRequestFullScreen"), (l = "mozCancelFullScreen"), (a = "mozFullScreenElement"));
                        const c = e.workspace.getActiveViewOfType(t.MarkdownView);
                        if (!c) return;
                        let h,
                            d = c.containerEl,
                            u = null === (i = document.body) || void 0 === i ? void 0 : i.querySelector(".mod-vertical.mod-root .workspace-tab-container");
                        function p(t) {
                            return t[r]();
                        }
                        function m() {
                            return n.contains(s) && (null == o || o.removeChild(s)), document[l]();
                        }
                        function g(t) {
                            return t === document[a];
                        }
                        (h = new MutationObserver(function (t) {
                            t.forEach(function (t) {
                                t.addedNodes.forEach(function (t) {
                                    if (g(u))
                                        try {
                                            document.body.removeChild(t), d.appendChild(t);
                                        } catch (t) { }
                                });
                            });
                        })),
                            u.addEventListener("fullscreenchange", function () {
                                g(u) || h.disconnect();
                            }),
                            g(u) ? (h.disconnect(), m()) : (p(u), h.observe(document.body, { childList: !0 })),
                            (exports.beFull = p),
                            (exports.exitFull = m),
                            (exports.isFull = g),
                            (exports.toggleFull = function (t) {
                                return g(t) ? (m(), !1) : (p(t), !0);
                            });
                    })(app),
                icon: "fullscreen",
            }),
            this.plugin.addCommand({
                id: "workplace-fullscreen-focus",
                name: "Workplace Fullscreen Focus",
                callback: () =>
                    (function (e) {
                        Lc = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
                        let i = Lc;
                        e.workspace.leftSplit.collapsed && e.workspace.rightSplit.collapsed
                            ? (e.commands.executeCommandById("app:toggle-right-sidebar"),
                                e.commands.executeCommandById("app:toggle-left-sidebar"),
                                e.workspace.leftRibbon.show(),
                                i.body.classList.contains("auto-hide-header") && i.body.classList.remove("auto-hide-header"))
                            : (i.body.classList.contains("auto-hide-header") || i.body.classList.add("auto-hide-header"),
                                e.workspace.leftRibbon.hide(),
                                e.workspace.leftSplit.collapsed || e.commands.executeCommandById("app:toggle-left-sidebar"),
                                e.workspace.rightSplit.collapsed || e.commands.executeCommandById("app:toggle-right-sidebar"));
                    })(app),
                hotkeys: [{ modifiers: ["Mod"], key: "F11" }],
                icon: "remix-SplitCellsHorizontal",
            });
        for (let t = 0; t <= 6; t++)
            this.plugin.addCommand({
                id: `header${t}-text`,
                name: 0 === t ? "Remove header level" : `Header ${t}`,
                callback: () => {
                    const e = this.getActiveEditor();
                    e && this.executeCommandWithoutBlur(e, () => Ir("#".repeat(t), e));
                },
                icon: 0 === t ? "heading-glyph" : `header-${t}`,
            });
        Object.keys(this._commandsMap).forEach((t) => {
            this.plugin.addCommand({
                id: `${t}`,
                name: `Toggle ${t}`,
                icon: `${t}-glyph`,
                callback: () => {
                    const e = this.getActiveEditor();
                    e &&
                        this.executeCommandWithoutBlur(e, () => {
                            this.applyCommand(this._commandsMap[t], e);
                        });
                },
            });
        }),
            this.modCommands.forEach((t) => {
                this.plugin.addCommand({
                    id: `${t.id}`,
                    name: `${t.name}`,
                    icon: `${t.icon}`,
                    callback: () => {
                        const i = this.getActiveEditor();
                        i &&
                            this.executeCommandWithoutBlur(i, () =>
                                e(this, void 0, void 0, function* () {
                                    const e = i.getCursor("to");
                                    let n = this.getCharacterOffset(t.id);
                                    yield this.plugin.app.commands.executeCommandById(`${t.id}`), 0 != n && i.setCursor(e.line, e.ch + n);
                                })
                            );
                    },
                });
            }),
            this.plugin.addCommand({
                id: "toggle-format-brush",
                name: "Toggle Format Brush",
                icon: "paintbrush",
                editorCallback: (t) => {
                    this.plugin.toggleFormatBrush();
                },
            }),
            this.registerCustomCommands(),
            [
                "toggle-bold",
                "toggle-italics",
                "toggle-strikethrough",
                "toggle-highlight",
                "toggle-code",
                "toggle-blockquote",
                "header0-text",
                "header1-text",
                "header2-text",
                "header3-text",
                "header4-text",
                "header5-text",
                "header6-text",
                "toggle-numbered-list",
                "toggle-bullet-list",
                "format-eraser",
                "indent-list",
                "undent-list",
                "change-font-color",
                "change-background-color",
                ...this.plugin.settings.customCommands.map((t) => `${t.id}`),
                ...Object.keys(this._commandsMap),
            ].forEach((t) => {
                const e = this.plugin.app.commands.commands[`editing-toolbar:${t}`];
                if (e && e.callback) {
                    const i = e.callback;
                    e.callback = () => {
                        i(), this.plugin.setLastExecutedCommand(`editing-toolbar:${t}`);
                    };
                }
            });
    }
    getCharacterOffset(t) {
        switch (t) {
            case "editor:insert-tag":
                return 1;
            case "editor:insert-callout":
                return 11;
            default:
                return 0;
        }
    }
    reloadCustomCommands() {
        this.plugin.settings.customCommands.forEach((t) => {
            const e = `${t.id}`;
            this.plugin.app.commands.commands[`editing-toolbar:${e}`] && delete this.plugin.app.commands.commands[`editing-toolbar:${e}`];
        }),
            this.registerCustomCommands();
    }
    registerCustomCommands() {
        this.plugin.settings.customCommands.forEach((t) => {
            const e = `${t.id}`;
            this.plugin.addCommand({
                id: e,
                name: t.name,
                icon: t.icon,
                editorCallback: (i) => {
                    if (t.useRegex && t.regexPattern)
                        i &&
                            this.executeCommandWithoutBlur(i, () => {
                                this.applyRegexCommand(i, t), this.plugin.setLastExecutedCommand(`editing-toolbar:${e}`);
                            });
                    else {
                        const n = { prefix: t.prefix, suffix: t.suffix, char: t.char, line: t.line, islinehead: t.islinehead };
                        (this._commandsMap[t.id] = n),
                            i &&
                            this.executeCommandWithoutBlur(i, () => {
                                this.applyCommand(n, i), this.plugin.setLastExecutedCommand(`editing-toolbar:${e}`);
                            });
                    }
                },
            });
        });
    }
    get commandsMap() {
        return this._commandsMap;
    }
}
class Hc extends t.Plugin {
    constructor() {
        super(...arguments),
            (this.admonitionDefinitions = null),
            (this.lastExecutedCommand = null),
            (this.formatBrushActive = !1),
            (this.formatBrushNotice = null),
            (this.lastCalloutType = null),
            (this.lastExecutedCommandName = null),
            (this.handleeditingToolbar = () => {
                if ((this.formatBrushActive || Rc.body.classList.remove("format-brush-cursor"), 1 == this.settings.cMenuVisibility)) {
                    const e = this.app.workspace.getActiveViewOfType(t.ItemView);
                    let i = ol(this.app, this);
                    if (!tl.isAllowedViewType(e) && i) return void (i.style.visibility = "hidden");
                    "markdown" === (null == e ? void 0 : e.getViewType())
                        ? tl.isSourceMode(e)
                            ? "following" === this.positionStyle
                                ? i && (i.style.visibility = "hidden")
                                : i && (i.style.visibility = "visible")
                            : i && (i.style.visibility = "hidden")
                        : i && (i.style.visibility = "visible"),
                        i ||
                        setTimeout(() => {
                            ml(this.app, this);
                        }, 100);
                }
            }),
            (this.handleeditingToolbar_layout = () => {
                if (!this.settings.cMenuVisibility) return !1;
                const e = this.app.workspace.getActiveViewOfType(t.ItemView);
                let i = ol(this.app, this);
                tl.isAllowedViewType(e)
                    ? ("markdown" === (null == e ? void 0 : e.getViewType())
                        ? tl.isSourceMode(e)
                            ? "following" === this.positionStyle
                                ? i && (i.style.visibility = "hidden")
                                : i && (i.style.visibility = "visible")
                            : i && (i.style.visibility = "hidden")
                        : i && (i.style.visibility = "visible"),
                        i ||
                        setTimeout(() => {
                            ml(this.app, this);
                        }, 100))
                    : i && (i.style.visibility = "hidden");
            }),
            (this.handleeditingToolbar_resize = () => {
                var e;
                if (1 != this.settings.cMenuVisibility || "top" != this.positionStyle) return !1;
                {
                    const i = app.workspace.getActiveViewOfType(t.ItemView);
                    if (tl.isSourceMode(i)) {
                        let i = null !== (e = this.app.workspace.activeLeaf.view.leaf.width) && void 0 !== e ? e : 0;
                        if (this.Leaf_Width == i) return !1;
                        if (i > 0 && ((this.Leaf_Width = i), this.settings.cMenuWidth && i)) {
                            if (i - this.settings.cMenuWidth < 78 && i > this.settings.cMenuWidth) return;
                            setTimeout(() => {
                                (function () {
                                    el = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document;
                                    let e = el,
                                        i = e.querySelectorAll("#editingToolbarModalBar"),
                                        n = e.querySelectorAll("#editingToolbarPopoverBar");
                                    i.forEach((t) => {
                                        t && (t.firstChild && t.removeChild(t.firstChild), t.remove());
                                    }),
                                        n.forEach((t) => {
                                            t && (t.firstChild && t.removeChild(t.firstChild), t.remove());
                                        });
                                })(),
                                    ml(app, this);
                            }, 200);
                        }
                    }
                }
            }),
            (this.handleKeyboardSelection = (t) => {
                this.commandsManager.getActiveEditor(),
                    ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Home", "End", "PageUp", "PageDown", "ShiftLeft", "ShiftRight"].includes(t.code) || t.shiftKey
                        ? this.handleTextSelection()
                        : t.shiftKey || "following" !== this.positionStyle || this.hideToolbarIfNotSelected();
            });
    }
    onload() {
        var i;
        return e(this, void 0, void 0, function* () {
            const n = this.manifest.version;
            (Rc = t.requireApiVersion("0.15.0") ? activeWindow.document : window.document),
                yield this.loadSettings(),
                (this.settingTab = new Bc(this.app, this)),
                this.addSettingTab(this.settingTab),
                (this.commandsManager = new Vc(this)),
                this.commandsManager.registerCommands();
            const o = this.commandsManager.getActiveEditor();
            this.app.workspace.onLayoutReady(() => {
                (this.statusBar = new Nc(this)), this.statusBar.init();
            }),
                this.init_evt(Rc, o),
                t.requireApiVersion("0.15.0") &&
                this.app.workspace.on("window-open", (t) => {
                    this.init_evt(t.doc, o);
                });
            const s = (null === (i = this.settings) || void 0 === i ? void 0 : i.lastVersion) || "0.0.0",
                r = (t) => {
                    const e = t.split(".").map((t) => parseInt(t));
                    return { major: e[0] || 0, minor: e[1] || 0, patch: e[2] || 0 };
                },
                l = r(s);
            r(n);
            const a = new yc(this.app, this),
                c = "0.0.0" === s;
            c && a.fixCommandIds(),
                !c &&
                (l.major < 3 || (3 === l.major && l.minor < 1)) &&
                setTimeout(() => {
                    a.open();
                }, 3e3),
                (this.settings.lastVersion = n),
                yield this.saveSettings(),
                app.plugins.enabledPlugins.has("obsidian-memos") && this.registerEvent(this.app.workspace.on("thino-editor-created", this.handleeditingToolbar)),
                this.registerEvent(this.app.workspace.on("active-leaf-change", this.handleeditingToolbar)),
                this.registerEvent(this.app.workspace.on("layout-change", this.handleeditingToolbar_layout)),
                this.registerEvent(this.app.workspace.on("resize", this.handleeditingToolbar_resize)),
                1 == this.settings.cMenuVisibility &&
                setTimeout(() => {
                    dispatchEvent(new Event("editingToolbar-NewCommand"));
                }, 100),
                this.registerDomEvent(Rc, "contextmenu", (e) => {
                    if (this.settings.isLoadOnMobile && t.Platform.isMobile && "following" == this.positionStyle) {
                        const { target: t } = e;
                        t instanceof HTMLElement && null !== t.closest(".cm-editor") && e.preventDefault();
                    }
                }),
                this.app.workspace.onLayoutReady(() =>
                    e(this, void 0, void 0, function* () {
                        yield this.tryGetAdmonitionTypes();
                    })
                ),
                this.registerEvent(
                    this.app.workspace.on("editor-menu", (t, e, i) => {
                        const n = e.getCursor(),
                            o = e.getLine(n.line);
                        /^\d+\.\s/.test(o) &&
                            t.addItem((t) =>
                                t
                                    .setSection("info")
                                    .setTitle(Wr("Renumber List"))
                                    .setIcon("list-restart")
                                    .onClick(() => qr(e))
                            );
                    })
                ),
                this.registerEvent(
                    this.app.workspace.on("url-menu", (t, e, i) => {
                        t.addItem((t) =>
                            t
                                .setTitle("Edit Link(Modal)")
                                .setSection("info")
                                .setIcon("link")
                                .onClick(() => {
                                    new Fc(this).open();
                                })
                        );
                    })
                ),
                Object.keys(qc).forEach((e) => {
                    t.addIcon(e, qc[e]);
                }),
                (this.toolbarIconSize = this.settings.toolbarIconSize),
                (this.positionStyle = this.settings.positionStyle),
                Rc.documentElement.style.setProperty("--editing-toolbar-background-color", this.settings.toolbarBackgroundColor),
                Rc.documentElement.style.setProperty("--editing-toolbar-icon-color", this.settings.toolbarIconColor),
                Rc.documentElement.style.setProperty("--toolbar-icon-size", `${this.settings.toolbarIconSize}px`);
        });
    }
    tryGetAdmonitionTypes(t = 0) {
        var i;
        return e(this, void 0, void 0, function* () {
            const t = null === (i = this.app.plugins) || void 0 === i ? void 0 : i.getPlugin("obsidian-admonition");
            t && this.processAdmonitionTypes(t);
        });
    }
    processAdmonitionTypes(t) {
        const e = t;
        e.admonitions && "object" == typeof e.admonitions && !Array.isArray(e.admonitions) && Object.keys(e.admonitions).length > 0
            ? (Object.keys(e.admonitions), (this.admonitionDefinitions = e.admonitions))
            : (this.admonitionDefinitions = null);
    }
    isLoadMobile() {
        var e;
        let i = window.innerWidth > 0 ? window.innerWidth : screen.width,
            n = !!(null === (e = this.settings) || void 0 === e ? void 0 : e.isLoadOnMobile) && this.settings.isLoadOnMobile;
        return !(t.Platform.isMobileApp && !n && i <= 768);
    }
    onunload() {
        this.app.workspace.off("active-leaf-change", this.handleeditingToolbar),
            this.app.workspace.off("layout-change", this.handleeditingToolbar_layout),
            this.app.workspace.off("resize", this.handleeditingToolbar_resize),
            this.formatBrushNotice && (this.formatBrushNotice.hide(), (this.formatBrushNotice = null)),
            this.quiteAllFormatBrushes(),
            nl();
    }
    isView() {
        const e = this.app.workspace.getActiveViewOfType(t.ItemView);
        return tl.isAllowedViewType(e);
    }
    setIS_MORE_Button(t) {
        this.IS_MORE_Button = t;
    }
    setEN_BG_Format_Brush(t) {
        this.EN_BG_Format_Brush = t;
    }
    setEN_FontColor_Format_Brush(t) {
        this.EN_FontColor_Format_Brush = t;
    }
    setEN_Text_Format_Brush(t) {
        this.EN_Text_Format_Brush = t;
    }
    setTemp_Notice(t) {
        this.Temp_Notice = t;
    }
    loadSettings() {
        return e(this, void 0, void 0, function* () {
            this.settings = Object.assign({}, Qr, yield this.loadData());
        });
    }
    getCurrentCommands(e) {
        if (!this.settings.enableMultipleConfig) return this.settings.menuCommands;
        let i = e || this.positionStyle;
        if (this.settings.isLoadOnMobile && t.Platform.isMobileApp) return this.settings.mobileCommands;
        switch (i) {
            case "following":
                return this.settings.followingCommands;
            case "top":
                return this.settings.topCommands;
            case "fixed":
                return this.settings.fixedCommands;
            default:
                return this.settings.menuCommands;
        }
    }
    updateCurrentCommands(e) {
        if (this.settings.enableMultipleConfig)
            if (this.settings.isLoadOnMobile && t.Platform.isMobileApp) this.settings.mobileCommands = e;
            else
                switch (this.positionStyle) {
                    case "following":
                        this.settings.followingCommands = e;
                        break;
                    case "top":
                        this.settings.topCommands = e;
                        break;
                    case "fixed":
                        this.settings.fixedCommands = e;
                        break;
                    default:
                        this.settings.menuCommands = e;
                }
        else this.settings.menuCommands = e;
    }
    saveSettings() {
        return e(this, void 0, void 0, function* () {
            yield this.saveData(this.settings);
        });
    }
    setLastExecutedCommand(t) {
        this.lastExecutedCommand = t;
        const e = this.app.commands.commands[t];
        if (e && e.name) this.lastExecutedCommandName = e.name;
        else {
            const e = t.split(":");
            this.lastExecutedCommandName = e[e.length - 1].replace(/-/g, " ");
        }
    }
    toggleFormatBrush() {
        const e = this.commandsManager.getActiveEditor();
        let i = !1,
            n = "";
        if (e)
            if (e.somethingSelected()) {
                const t = e.getSelection();
                if (/^\*\*.*\*\*$/.test(t)) (this.lastExecutedCommand = "editor:toggle-bold"), (this.lastExecutedCommandName = "Bold"), (i = !0);
                else if (/^\*.*\*$/.test(t) || /^_.*_$/.test(t)) (this.lastExecutedCommand = "editor:toggle-italics"), (this.lastExecutedCommandName = "Italic"), (i = !0);
                else if (/^~~.*~~$/.test(t)) (this.lastExecutedCommand = "editor:toggle-strikethrough"), (this.lastExecutedCommandName = "Strikethrough"), (i = !0);
                else if (/^==.*==$/.test(t)) (this.lastExecutedCommand = "editor:toggle-highlight"), (this.lastExecutedCommandName = "Highlight"), (i = !0);
                else if (/^`.*`$/.test(t)) (this.lastExecutedCommand = "editor:toggle-code"), (this.lastExecutedCommandName = "Code"), (i = !0);
                else if (/^<font color=".*">.*<\/font>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:change-font-color"), (this.lastExecutedCommandName = "Font Color"), (i = !0);
                else if (/^<span style="background:.*">.*<\/span>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:change-background-color"), (this.lastExecutedCommandName = "Background Color"), (i = !0);
                else if (/^<u>([^<]+)<\/u>$/.test(t)) (this.lastExecutedCommand = "editor:toggle-underline"), (this.lastExecutedCommandName = "Underline"), (i = !0);
                else if (/^<center>([^<]+)<\/center>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:center"), (this.lastExecutedCommandName = "Center"), (i = !0);
                else if (/^<p align="left">(.*?)<\/p>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:left"), (this.lastExecutedCommandName = "Left Align"), (i = !0);
                else if (/^<p align="right">(.*?)<\/p>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:right"), (this.lastExecutedCommandName = "Right Align"), (i = !0);
                else if (/^<p align="justify">(.*?)<\/p>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:justify"), (this.lastExecutedCommandName = "Justify"), (i = !0);
                else if (/^<sup>(.*?)<\/sup>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:superscript"), (this.lastExecutedCommandName = "Superscript"), (i = !0);
                else if (/^<sub>(.*?)<\/sub>$/.test(t)) (this.lastExecutedCommand = "editing-toolbar:subscript"), (this.lastExecutedCommandName = "Subscript"), (i = !0);
                else if (/^> \[!(note|tip|warning|danger|info|success|question|quote)\]/i.test(t)) {
                    const e = t.match(/^> \[!(note|tip|warning|danger|info|success|question|quote)\]/i);
                    e && ((this.lastExecutedCommand = "editor:insert-callout"), (this.lastExecutedCommandName = "Callout-" + e[1].toLowerCase()), (i = !0), (n = e[1].toLowerCase()));
                } else
                    /^# /.test(t)
                        ? ((this.lastExecutedCommand = "editor:set-heading-1"), (this.lastExecutedCommandName = "Heading 1"), (i = !0))
                        : /^## /.test(t)
                            ? ((this.lastExecutedCommand = "editor:set-heading-2"), (this.lastExecutedCommandName = "Heading 2"), (i = !0))
                            : /^### /.test(t)
                                ? ((this.lastExecutedCommand = "editor:set-heading-3"), (this.lastExecutedCommandName = "Heading 3"), (i = !0))
                                : /^#### /.test(t)
                                    ? ((this.lastExecutedCommand = "editor:set-heading-4"), (this.lastExecutedCommandName = "Heading 4"), (i = !0))
                                    : /^##### /.test(t)
                                        ? ((this.lastExecutedCommand = "editor:set-heading-5"), (this.lastExecutedCommandName = "Heading 5"), (i = !0))
                                        : /^###### /.test(t) && ((this.lastExecutedCommand = "editor:set-heading-6"), (this.lastExecutedCommandName = "Heading 6"), (i = !0));
            } else {
                const t = e.getCursor(),
                    n = e.getLine(t.line),
                    o = t.ch,
                    s = [],
                    r = /<u>([^<]+)<\/u>/g;
                let l;
                for (; null !== (l = r.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:toggle-underline", name: "Underline", distance: Math.min(o - t, e - o) });
                }
                const a = /<center>([^<]+)<\/center>/g;
                for (; null !== (l = a.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:center", name: "Center", distance: Math.min(o - t, e - o) });
                }
                const c = /<p align="left">([^<]+)<\/p>/g;
                for (; null !== (l = c.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:left", name: "Left Align", distance: Math.min(o - t, e - o) });
                }
                const h = /<p align="right">([^<]+)<\/p>/g;
                for (; null !== (l = h.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:right", name: "Right Align", distance: Math.min(o - t, e - o) });
                }
                const d = /<p align="justify">([^<]+)<\/p>/g;
                for (; null !== (l = d.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:justify", name: "Justify", distance: Math.min(o - t, e - o) });
                }
                const u = /<sup>([^<]+)<\/sup>/g;
                for (; null !== (l = u.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:superscript", name: "Superscript", distance: Math.min(o - t, e - o) });
                }
                const p = /<sub>([^<]+)<\/sub>/g;
                for (; null !== (l = p.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:subscript", name: "Subscript", distance: Math.min(o - t, e - o) });
                }
                const m = /\*\*([^*]+)\*\*/g;
                for (; null !== (l = m.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editor:toggle-bold", name: "Bold", distance: Math.min(o - t, e - o) });
                }
                const g = /~~([^~]+)~~/g;
                for (; null !== (l = g.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editor:toggle-strikethrough", name: "Strikethrough", distance: Math.min(o - t, e - o) });
                }
                const f = /==([^=]+)==/g;
                for (; null !== (l = f.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editor:toggle-highlight", name: "Highlight", distance: Math.min(o - t, e - o) });
                }
                const b = /`([^`]+)`/g;
                for (; null !== (l = b.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editor:toggle-code", name: "Code", distance: Math.min(o - t, e - o) });
                }
                const v = /<font color="([^"]+)">([^<]+)<\/font>/g;
                for (; null !== (l = v.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:change-font-color", name: "Font Color", distance: Math.min(o - t, e - o) });
                }
                const y = /<span style="background:([^"]+)">([^<]+)<\/span>/g;
                for (; null !== (l = y.exec(n));) {
                    const t = l.index,
                        e = l.index + l[0].length;
                    o > t && o < e && s.push({ command: "editing-toolbar:change-background-color", name: "Background Color", distance: Math.min(o - t, e - o) });
                }
                if (s.length > 0) {
                    s.sort((t, e) => t.distance - e.distance);
                    const t = s[0];
                    (this.lastExecutedCommand = t.command), (this.lastExecutedCommandName = t.name), (i = !0);
                }
                if (!i) {
                    const t = /(\*|_)([^*_]+)(\*|_)/g;
                    for (; null !== (l = t.exec(n));) (this.lastExecutedCommand = "editor:toggle-italics"), (this.lastExecutedCommandName = "Italic"), (i = !0);
                }
                i ||
                    (/^# /.test(n) && o > 0
                        ? ((this.lastExecutedCommand = "editor:set-heading-1"), (this.lastExecutedCommandName = "Heading 1"), (i = !0))
                        : /^## /.test(n) && o > 1
                            ? ((this.lastExecutedCommand = "editor:set-heading-2"), (this.lastExecutedCommandName = "Heading 2"), (i = !0))
                            : /^### /.test(n) && o > 2
                                ? ((this.lastExecutedCommand = "editor:set-heading-3"), (this.lastExecutedCommandName = "Heading 3"), (i = !0))
                                : /^#### /.test(n) && o > 3
                                    ? ((this.lastExecutedCommand = "editor:set-heading-4"), (this.lastExecutedCommandName = "Heading 4"), (i = !0))
                                    : /^##### /.test(n) && o > 4
                                        ? ((this.lastExecutedCommand = "editor:set-heading-5"), (this.lastExecutedCommandName = "Heading 5"), (i = !0))
                                        : /^###### /.test(n) && o > 5 && ((this.lastExecutedCommand = "editor:set-heading-6"), (this.lastExecutedCommandName = "Heading 6"), (i = !0)));
            }
        i || this.lastExecutedCommand
            ? ((this.formatBrushActive = !this.formatBrushActive),
                this.formatBrushActive
                    ? (Rc.body.classList.add("format-brush-cursor"),
                        (this.EN_FontColor_Format_Brush = !1),
                        (this.EN_BG_Format_Brush = !1),
                        (this.EN_Text_Format_Brush = !1),
                        (this.lastCalloutType = n),
                        this.formatBrushNotice && this.formatBrushNotice.hide(),
                        (this.formatBrushNotice = new t.Notice(Wr("Format brush ON! Select text to apply【") + this.lastExecutedCommandName + Wr("】format"), 0)))
                    : (Rc.body.classList.remove("format-brush-cursor"), this.formatBrushNotice && (this.formatBrushNotice.hide(), (this.formatBrushNotice = null))))
            : new t.Notice(Wr("Please execute a format command or select format text first, then enable the format brush"));
    }
    applyCalloutFormat(t, e, i) {
        const n = `> [!${i}]\n> ${e
            .replace(/^> \[!(note|tip|warning|danger|info|success|question|quote)\] ?/i, "")
            .trim()
            .split("\n")
            .map((t, e) => t.replace(/^\s*>\s*/, ""))
            .join("\n> ")}`;
        t.replaceSelection(n);
    }
    applyFormatBrush(e) {
        if (!this.lastExecutedCommand || !this.formatBrushActive) return;
        const i = this.app.commands.commands[this.lastExecutedCommand];
        i && i.callback && i.callback(), i && i.editorCallback && i.editorCallback(e, this.app.workspace.getActiveViewOfType(t.MarkdownView));
    }
    quiteAllFormatBrushes() {
        (this.EN_FontColor_Format_Brush = !1),
            (this.EN_BG_Format_Brush = !1),
            (this.EN_Text_Format_Brush = !1),
            Rc.body.classList.remove("format-brush-cursor"),
            this.formatBrushActive && ((this.formatBrushActive = !1), this.formatBrushNotice && (this.formatBrushNotice.hide(), (this.formatBrushNotice = null))),
            this.Temp_Notice && (this.Temp_Notice.hide(), (this.Temp_Notice = null));
    }
    getCommandsManager() {
        return this.commandsManager;
    }
    reloadCustomCommands() {
        this.commandsManager.reloadCustomCommands();
    }
    init_evt(e, i) {
        this.resetFormatBrushStates();
        const n = t.debounce(() => {
            this.handleTextSelection();
        }, 100);
        let o = 0;
        this.registerDomEvent(e, "mousedown", (t) => {
            if (this.isView() && this.commandsManager.getActiveEditor()) {
                if (1 === t.button) {
                    const e = new Date().getTime();
                    e - o < 300 && this.handleMiddleClickToolbar(t), (o = e);
                }
                this.resetFormatBrushIfActive(t);
            }
        }),
            t.Platform.isMobileApp
                ? this.registerDomEvent(e, "selectionchange", () => {
                    n();
                })
                : this.registerDomEvent(e, "mouseup", (t) => {
                    1 !== t.button && n();
                }),
            this.registerDomEvent(e, "keyup", this.handleKeyboardSelection),
            this.registerScrollAndBlurEvents(e);
    }
    resetFormatBrushStates() {
        (this.EN_FontColor_Format_Brush = !1), (this.EN_BG_Format_Brush = !1), (this.EN_Text_Format_Brush = !1), (this.formatBrushActive = !1);
    }
    handleMiddleClickToolbar(t) {
        const e = this.commandsManager.getActiveEditor();
        "following" === this.positionStyle && (null == e ? void 0 : e.hasFocus()) && this.showFollowingToolbar(e);
    }
    resetFormatBrushIfActive(t) {
        t.button && this.isFormatBrushActive() && dl(this);
    }
    isFormatBrushActive() {
        return this.EN_FontColor_Format_Brush || this.EN_BG_Format_Brush || this.EN_Text_Format_Brush || this.formatBrushActive;
    }
    registerScrollAndBlurEvents(t) {
        const e = this.throttle(() => {
            "following" === this.positionStyle && this.hideToolbarIfNotSelected();
        }, 200);
        this.registerDomEvent(Rc, "wheel", e),
            this.registerDomEvent(t, "blur", () => {
                this.hideToolbarIfNotSelected();
            });
    }
    hideToolbarIfNotSelected() {
        const t = ol(this.app, this);
        t && "following" == this.positionStyle && (t.style.visibility = "hidden");
    }
    handleTextSelection() {
        if (!this.isView()) return;
        const t = this.commandsManager.getActiveEditor();
        (null == t ? void 0 : t.hasFocus()) && (t.somethingSelected() ? this.handleSelectedText(t) : this.hideToolbarIfNotSelected());
    }
    handleSelectedText(t) {
        this.EN_FontColor_Format_Brush
            ? Or(this.settings.cMenuFontColor, t)
            : this.EN_BG_Format_Brush
                ? Br(this.settings.cMenuBackgroundColor, t)
                : this.EN_Text_Format_Brush
                    ? ul(0, t)
                    : this.formatBrushActive && this.lastCalloutType
                        ? this.applyCalloutFormat(t, t.getSelection(), this.lastCalloutType)
                        : this.formatBrushActive && this.lastExecutedCommand
                            ? this.applyFormatBrush(t)
                            : "following" === this.positionStyle && this.showFollowingToolbar(t);
    }
    throttle(t, e = 100) {
        let i;
        return function (...n) {
            i || (t.apply(this, n), (i = !0), setTimeout(() => (i = !1), e));
        };
    }
    showFollowingToolbar(t) {
        const e = ol(this.app, this);
        e ? ((e.style.visibility = "visible"), e.classList.add("editingToolbarFlex"), e.classList.remove("editingToolbarGrid"), pl(this.app, this.toolbarIconSize, this, t, !0)) : pl(this.app, this.toolbarIconSize, this, t, !0);
    }
    onPositionStyleChange(e) {
        if (((this.positionStyle = e), this.settings.enableMultipleConfig))
            switch (e) {
                case "following":
                    (this.settings.followingCommands && 0 !== this.settings.followingCommands.length) ||
                        ((this.settings.followingCommands = [...this.settings.menuCommands]), this.saveSettings(), new t.Notice(Wr("Following style commands successfully initialized")));
                    break;
                case "top":
                    (this.settings.topCommands && 0 !== this.settings.topCommands.length) ||
                        ((this.settings.topCommands = [...this.settings.menuCommands]), this.saveSettings(), new t.Notice(Wr("Top style commands successfully initialized")));
                    break;
                case "fixed":
                    (this.settings.fixedCommands && 0 !== this.settings.fixedCommands.length) ||
                        ((this.settings.fixedCommands = [...this.settings.menuCommands]), this.saveSettings(), new t.Notice(Wr("Fixed style commands successfully initialized")));
                    break;
                case "mobile":
                    (this.settings.mobileCommands && 0 !== this.settings.mobileCommands.length) ||
                        ((this.settings.mobileCommands = [...this.settings.menuCommands]), this.saveSettings(), new t.Notice(Wr("Mobile style commands successfully initialized")));
            }
        dispatchEvent(new Event("editingToolbar-NewCommand"));
    }
}
module.exports = Hc;
