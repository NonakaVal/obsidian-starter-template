
> [!rainbow] ARC » [[Adicionar]] | **[[Relacionar]]** | [[Comunicar]] 

Esta nota é um lugar de alegria, sem expectativas ou obrigações, o que será um desafio para uma cultura obcecada por tarefas—mas quando você começa a dar aos seus pensamentos a honra que merecem, seus pensamentos se tornam mais ricos e significativos.

Aqui é onde a metáfora do jardim nos dá uma forma de abordar o relacionamento de ideias: