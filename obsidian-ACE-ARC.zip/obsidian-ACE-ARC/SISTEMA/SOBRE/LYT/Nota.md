Pelo botão : `BUTTON[new_note]` ou pelo atalho

`ctrl + N` 



```meta-bind-button
label: Criar Nota
icon: plus
hidden: true
class: ""
id: new_note
style: primary
actions:
  - type: command
    command: quickadd:choice:9dd5d65e-dae6-4ada-8590-069c6fedb6c2
```