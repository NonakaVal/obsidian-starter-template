
```dataview
table without id file.link as Nota,  created as Criada
from "ATLAS"
```
