Pelo botão : `BUTTON[Área]`     ou nas opções de `ctrl + N` 

```meta-bind-button
label: Nova Área ou Projeto
hidden: true
icon: plus
class: ""
id: Área
style: default
actions:
  - type: command
    command: quickadd:choice:ebc3941c-ed51-4da4-abb4-bf15c72eb683
```

