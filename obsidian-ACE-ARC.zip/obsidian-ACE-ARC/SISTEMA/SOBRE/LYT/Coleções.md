
> [!waypoints] **Básico** »  [[Obsidian e PKM]]  |[[Markdown]]| [[Metadados]]  | **[[Coleções]]** | [[Atalhos]]   

Coleções são notas especiais que tem como objetivo te ajudar a organizar e classificar suas notas, funcionam como categorias que adicionamos para diferentes objetivos de uso.


![[_COLEÇÕES]]
