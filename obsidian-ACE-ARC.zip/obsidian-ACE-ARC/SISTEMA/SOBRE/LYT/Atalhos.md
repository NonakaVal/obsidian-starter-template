
| 🏚️ **Homepage**                        | Ctrl + Shift + H |
| --------------------------------------- | ---------------- |
| 🎛️ **Paleta de comandos**              | Ctrl + P         |
| ➡️ **Acessar Nota**                     | Ctrl + O         |
| 🗓️ **Nota Diária**                     | Ctrl + Shift + I |
| ➕ **Nova Nota**                         | Ctrl + N         |
| 📜 **Inserir Snippet Template**         | Alt + E          |
| 🔖 **Adicionar Propriedade do Arquivo** | Ctrl + ;         |
| 📑 **Mostrar Favoritos**                | Ctrl + Shift + B |
| ⭐ **Favoritar Todas as Abas**           | Alt + B          |
| 🗂️ **Explorador de Arquivos**          | Ctrl + Shift + P |
| 📦 **Mover Arquivo**                    | Alt + M          |
| 📄 **Mostrar Títulos**                  | Ctrl + Shift + O |
| 🔍 **Pesquisar nos Arquivos**           | Ctrl + Shift + F |
| 🚪 **Fechar Aba**                       | Alt + W          |
| 🚪 **Fechar Janela**                    | Ctrl + Shift + W |
| 🗑️ **Excluir Arquivo**                 | Ctrl + Shift + - |

