Para criar uma nova coleção, selecione 📁 Nova Coleção na criação de notas `ctrl + N` ou com `Alt + C` diretamente.

[[Coleções]]