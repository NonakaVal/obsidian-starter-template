```meta-bind-button
label: <% tp.file.title %>
hidden: false
class: ""
id: <% tp.file.title %>
style: default
actions:
  - type: open
    link: ""

```



