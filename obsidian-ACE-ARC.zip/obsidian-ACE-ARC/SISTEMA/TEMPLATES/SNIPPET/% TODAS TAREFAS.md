
# [[% TODAS TAREFAS]]

````tabs
tab: Calendário 
![[% TAREFAS DO CALENDÁRIO]]

tab: Efforts
![[% TAREFAS EFFORTS]]

````