<br>

> [!home] [[🏠Home| 🏠 Home]] | **[[🏠Home Pro]]** | [[Boas Vindas 🎉]] | [[Guias Práticos ❓]]

---

<br>
<br>

> [!waypoints] Gestão de conhecimento » [[Checklist Obsidian]] ✅ | [[Mapa de Gestão de Conhecimento]] 🧠  



---

> [!globe] **[[Como Atlas funciona|Atlas]]** » [Dashboard de Notas](obsidian://adv-uri?vault=obsidian-ACE-ARC&commandid=dashboard-navigator%3Adashboard) | [[Coleções]]  | [[Notas Recentemente Modificadas]] 

> [!calendar] **[[Como Calendário funciona|Calendário]]** » [Nota Diária](obsidian://adv-uri?vault=obsidian-ACE-ARC&commandid=periodic-notes%3Aopen-daily-note) | [Mensal](obsidian://adv-uri?vault=obsidian-ACE-ARC&commandid=periodic-notes%3Aopen-monthly-note) | [[Todas Tarefas|Tarefas]] 

> [!mountain] **[[Como Esforços funciona|Esforços]]** » [[Areas]] | [[Projetos Ativos]]  

---
<br>

> [!cog] **[[Como a pasta Sistema funciona|Sistema]]** » [[Templates]] | [[Custom Callouts]] | [[Atalhos]]
 
---

![[Pasted image 20251007195624.png]]

<br>

> [!rainbow] **[[ARC Framework|ARC]]** » [[Adicionar]] | [[Relacionar]] | [[Comunicar]] 

> [!trees] **[[Jardineiro]]** » [[Plante]] | [[Cultive]] | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  
