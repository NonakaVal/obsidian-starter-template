---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
Pelo botão :  `BUTTON[new-note]`      ou pelo atalho

`ctrl + N` 


> [!VIDEO]- Entendendo Fluxo de criação de notas na estrutura ARC-ACE
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://drive.google.com/file/d/1gOAEAKT_2kHUHJFvZ39ZLpdtMHISn4_V/preview" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="Ideaverse Pro Hangar"></iframe></div>




```meta-bind-button
label: Nova Nota
hidden: true
icon: plus
class: ""
id: new-note
style: primary
actions:
  - type: command
    command: quickadd:choice:3edf5ca1-598e-42e8-beec-fe2714a9a1f9
```

