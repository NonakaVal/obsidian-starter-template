
As **coleções** são um sistema de **agrupamento temático** que funciona através de **referências bidirecionais** no Obsidian. Uma coleção é uma **nota central no [[Como a pasta Sistema funciona|sistema]]**, vazia **ou** não, que automaticamente exibe todas as notas que fazem referência a ela através da propriedade `collection:`.

Ficam em `Sistema/Coleções/` e servem como "etiquetas inteligentes":