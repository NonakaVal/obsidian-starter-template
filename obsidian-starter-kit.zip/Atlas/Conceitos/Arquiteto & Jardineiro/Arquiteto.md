---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
> [!scale] [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tiver um **mapa de conteúdo que precisa de ajustes**, pode adicionar a tag `architect` nessa nota. Assim, através das **visões de Arquiteto** abaixo, você poderá encontrá-la no momento certo.

**Chave:** 🧱 Construir | 🪜 Renovar  
