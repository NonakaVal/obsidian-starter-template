---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
~ [[Jardineiro]]

> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/repot`, então você quer **refatorar essas notas dividindo ou reformatando-as.** Isso geralmente envolve cortar uma seção específica de uma nota diária e colar o conteúdo em uma nova nota com um título claro.
