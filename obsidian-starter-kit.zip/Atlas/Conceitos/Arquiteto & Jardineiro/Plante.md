---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
tags:
  - garden/revitalize
---
~ [[Jardineiro]]  

> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/plant`, provavelmente as criou com pressa, mas quer se lembrar de **conectar essas notas ao restante do seu ideaverse.**  
