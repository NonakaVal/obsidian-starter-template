---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/revitalize`, então você quer **revisar essas notas de uma forma que lhes dê nova vida.** Frequentemente é aquela sensação de que algo está preso na nota e, se você apenas reescrevê-la ou reestruturá-la, isso proporcionará mais clareza e valor.
