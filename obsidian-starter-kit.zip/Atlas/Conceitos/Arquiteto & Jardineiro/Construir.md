---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
~ [[Arquiteto]] 

> [!scale] [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tem um **mapa de conteúdo novo ou inacabado** que ainda precisa de atenção, atribua a tag `#architect/build`.  
A visualização abaixo mostra essas notas, ordenadas pelas **mais recentemente modificadas**:
