---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
~ [[Architect]]  

> [!scale] [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tem um mapa de conteúdo mais antigo ou que sente que precisa de algum tipo de atualização, você pode dar a ele a tag `architect/renovate`.  