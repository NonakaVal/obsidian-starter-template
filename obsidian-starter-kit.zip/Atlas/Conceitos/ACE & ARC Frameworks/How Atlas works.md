---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
O **Atlas** é a pasta que reúne mapas de conteúdo (MOCs), ideias, fontes e outros fragmentos de conhecimento. Ele serve tanto para **desenvolver ideias**, com o Framework ARC.

<div style="background: linear-gradient(135deg, #2c3e50 0%, #1a2530 100%); padding: 20px; border-radius: 16px; color: #ecf0f1; box-shadow: 0 8px 25px rgba(0,0,0,0.4); margin-bottom: 24px; border: 1px solid #34495e;">
  <h3 style="display: flex; align-items: center; gap: 10px; font-size: 1.4em; margin-top: 0; color: #3498db;">🌐 Atlas</h3>
  <ul style="padding-left: 20px; margin-top: 10px; margin-bottom: 0;">
	<li>📍 <strong>Espaço:</strong> Atlas</li>
	<li>🧠 <strong>Foco:</strong> Conhecimento</li>
	<li>♾️ <strong>Dimensão Temporal:</strong> Atemporal</li>
	<li>💡 <strong>Intenção:</strong> Compreender</li>
	<li>🗺️ <strong>Princípio Organizador:</strong> Espaço (relações)</li>
  </ul>
</div>

> [!rainbow] ARC » [[Adicionar]] | [[Relacionar]] | [[Comunicar]]
