---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
A pasta "Áreas" é para áreas de esforço. Quando uma área de esforço cresce o suficiente, começa a justificar uma pasta para manter as anotações aleatórias dedicadas a ela. Algumas áreas de esforço crescem o suficiente para ter sua própria nota de área dedicada a elas também.
