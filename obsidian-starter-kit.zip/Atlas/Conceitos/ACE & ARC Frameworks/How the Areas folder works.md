---
up: 
related: 
created: 2025-04-07
lesson: false
---

A pasta "Áreas" é para áreas de esforço. Quando uma área de esforço cresce o suficiente, começa a justificar uma pasta para manter as anotações aleatórias dedicadas a ela. Algumas áreas de esforço crescem o suficiente para ter sua própria nota de área dedicada a elas também.

Vamos explorar como isso funciona.

> [!video]- Vídeo
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://player.vimeo.com/video/1075676623?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="Como a pasta Área funciona"></iframe></div>

---

Voltar para [[+/ACE Pack/+ ACE Pack|ACE Pack]]