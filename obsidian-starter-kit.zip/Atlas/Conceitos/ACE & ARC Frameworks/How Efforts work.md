---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
O **Efforts** ajuda a manter suas prioridades em foco, ajustar seu ritmo conforme necessário e reunir os **trabalhos concluídos** que você compartilhou pelo caminho.


<div style="background: linear-gradient(135deg, #2c3e50 0%, #1a2530 100%); padding: 20px; border-radius: 16px; color: #ecf0f1; box-shadow: 0 8px 25px rgba(0,0,0,0.4); margin-bottom: 24px; border: 1px solid #34495e;">
  <h3 style="display: flex; align-items: center; gap: 10px; font-size: 1.4em; margin-top: 0; color: #2ecc71;">⚡ Efforts</h3>
  <ul style="padding-left: 20px; margin-top: 10px; margin-bottom: 0;">
	<li>🔥 <strong>Espaço:</strong> Efforts</li>
	<li>🏃 <strong>Foco:</strong> Ação</li>
	<li>❗ <strong>Dimensão Temporal:</strong> Oportuno</li>
	<li>▶️ <strong>Intenção:</strong> Agir</li>
	<li>🚩 <strong>Princípio Organizador:</strong> Prioridade / urgência</li>
  </ul>
</div>



Ele organiza suas ações e empreendimentos em três subpastas principais:

- **Areas** → responsabilidades contínuas.
- **Projetos** → objetivos com prazo definido.
- **Arquivados** → resultados ou entregas finalizadas.


