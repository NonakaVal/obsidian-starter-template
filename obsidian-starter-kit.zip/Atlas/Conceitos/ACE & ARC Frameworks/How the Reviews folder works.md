---
up: 
related: 
created: 2025-04-07
lesson: false
---
Revisões mensais, trimestrais e anuais—junto com entradas de diário mais reflexivas—são armazenadas na pasta "Revisões". Vamos explorar como isso funciona.

> [!vídeo]- Vídeo
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://player.vimeo.com/video/1075704071?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="Como a pasta Revisão funciona"></iframe></div>

---

Voltar para [[+/ACE Pack/+ ACE Pack|ACE Pack]]