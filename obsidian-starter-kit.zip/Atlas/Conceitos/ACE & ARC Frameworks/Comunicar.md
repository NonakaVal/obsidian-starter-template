---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
Mapas~ [[+ ARC Framework]] 

> [!tldr] [[+ ARC Framework]] » [[Adicionar]] | [[Relacionar]] | **[[Comunicar]]** 

Se você estiver se perdendo ou se perguntando "qual é o sentido", precisa avançar rapidamente para a etapa de **communicate** e imediatamente encontrar uma forma de compartilhar seus pensamentos. Se a sua motivação estiver baixa, geralmente é porque não há nada no final do ARC que faça as ideias avançarem. Isso é algo para o trabalho? É algo que você pode compartilhar com a família, amigos ou com a internet em geral? No mínimo, desafie-se a enviar por e-mail um rascunho compartilhável para si mesmo.

---

Como escrever com notas vinculadas é abordado no curso [Writing Original Works](https://www.linkingyourthinking.com/wow). 

---

Voltar para [[+ ARC Framework]]