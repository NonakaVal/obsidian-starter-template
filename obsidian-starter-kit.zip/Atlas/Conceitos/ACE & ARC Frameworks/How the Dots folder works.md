---
up: "[[++ Gestão de Conhecimento|++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
Dots são **qualquer pedaço de conhecimento**. Conectar os dots muitas vezes leva a saltos significativos de insights, avanços criativos e contribuições valiosas. Você pode pensar nos dots como conceitos ou citações, mas eles também incluem qualquer "coisa" e até "declarações sobre coisas".
