---
up: 
related: 
created: 2025-04-07
lesson: false
---
Dots são **qualquer pedaço de conhecimento**. Conectar os dots muitas vezes leva a saltos significativos de insights, avanços criativos e contribuições valiosas. Você pode pensar nos dots como conceitos ou citações, mas eles também incluem qualquer "coisa" e até "declarações sobre coisas".

Sim, a definição não é rígida, mas funciona.

> [!video]- Vídeo
> <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://player.vimeo.com/video/1075677609?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="Como a pasta Dots funciona"></iframe></div>

---
### Umami

A pasta Dots é um dos meus lugares favoritos porque tem *umami*. Aparentemente, umami é um dos cinco gostos básicos. Existem: Doçura, Acidez, Salinidade, Amargor — e aquele distinto Umami.

Umami é difícil de descrever, mas você sabe quando está presente. O mesmo é verdadeiro para o conteúdo desta pasta. É uma mistura de insights e ideias, conceitos e conexões, todos se misturando para criar aquela misteriosa plenitude que completa magnificamente qualquer refeição para a mente.
ormação que atravessa nosso filtro atencional se torna conhecimento]].

---

Voltar para [[+/ACE Pack/+ ACE Pack|ACE Pack]]