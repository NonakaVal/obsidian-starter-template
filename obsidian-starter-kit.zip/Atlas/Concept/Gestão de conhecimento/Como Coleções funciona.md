---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---

As **coleções** são um sistema de **agrupamento temático** que funciona através de **referências bidirecionais** no Obsidian. Uma coleção é uma **nota central no [[Como a pasta Sistema funciona|sistema]]**, vazia **ou** não, que automaticamente exibe todas as notas que fazem referência a ela através da propriedade `collection:`.

Ficam em `Sistema/Coleções/` e servem como "etiquetas inteligentes":

![[Coleções]]