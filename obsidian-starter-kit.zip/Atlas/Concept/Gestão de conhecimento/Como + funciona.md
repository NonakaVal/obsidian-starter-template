---
up: "[[Mapa de Gestão de Conhecimento|Mapa de Gestão de Conhecimento]]"
collection: "[[SISTEMA/COLEÇÕES/Gestão de Conhecimento.md|Gestão de Conhecimento]]"
---
A pasta **+** é sua **caixa de entrada** e **central de guias rápidos** — o ponto de partida para tudo que é novo ou precisa estar sempre acessível.