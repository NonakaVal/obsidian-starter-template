---
created: ["{{date: DD-MM-YYYY}} {{time}}"]
aliases: ["Código do Projeto"]
tags:
- Projeto/
---

# 🚀 Projeto -> 
___

## 🧾 Descrição do Projeto
- 

---
## 📢 Informações do Projeto
Criado em:: {{date: DD-MM-YYYY}} {{time}}  
Prazo Final::  
Em Hibernação::  
Data de Conclusão Prevista::  
Concluído em::  
Tipo::  
Etiquetas::  
Plataforma::  

___
## 🎯 Objetivo

1. 🟢 Resultado ideal do projeto  
	1. 
2. 🟠 Resultado aceitável  
	1. 

## ❓ Expectativas
1. 🟢 O que pode ajudar o projeto  
	1. 
2. 🟠 Obstáculos potenciais  
	1. 
3. 👶 Inexperiências / Suposições  
	1. 
4. 👨‍💻 Insights e aprendizados  
	1. 

## ✅ Tarefas  
- 

## 📦 Recursos  
- 

## 📂 Registros do Projeto  
- 
