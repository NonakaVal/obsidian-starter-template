---
tags:
  - book
aliases:
  - '"{{subtitle}}"'
year: "{{publishDate}}"
author:
  - "{{author}}"
series: 
series_part: 
started: ""
finished: 
genres:
  - "{{category}}"
volume: "{{totalPage}}"
timestamp: 0
units: 
status: queue
rate: 
cover: "{{coverUrl}}"
cssclasses:
---

![]({{coverUrl}})
# ANOTAÇÃO
>Uma bela anotação seria colocada aqui

# CITAÇÕES
1. Não se esqueça das suas citações

# NOTAS
>As notas são a chave para lembrar de tudo

# PERSONAGENS
1. Personagens são personagens


