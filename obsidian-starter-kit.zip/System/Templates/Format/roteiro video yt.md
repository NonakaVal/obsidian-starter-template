---
area:
  - "[[Youtube PKM Channel]]"
tags:
  - roteiro
type: area_note
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
subject:
  - "[[hub-work]]"
  - "[[hub-menagement]]"
status: to start
---
