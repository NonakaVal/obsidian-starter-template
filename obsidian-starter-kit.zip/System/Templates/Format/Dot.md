---
tags:
  - aboutMe
  - Dot
  - to-review-2
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
subject: <%tp.file.cursor()%>
---
