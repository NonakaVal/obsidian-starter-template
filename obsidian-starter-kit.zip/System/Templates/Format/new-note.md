---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - garden/seed
---
