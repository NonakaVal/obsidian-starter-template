---
created: <% tp.file.creation_date() %>
tags:
  - calendar/daily
daily-mood: 
---
<% tp.web.daily_quote() %>

---

📑 🔹 Mood  `INPUT[inlineSelect(option('🙂 – Neutral'), option('😄 – Happy'), option('😐 – Meh'), option('😞 – Sad'), option('😠 – Frustrated'), showcase):daily-mood]`

 
# Workbench

<%tp.file.cursor()%>


# Logs