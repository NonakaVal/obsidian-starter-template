---
tags:
  - garden/seed
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
---
