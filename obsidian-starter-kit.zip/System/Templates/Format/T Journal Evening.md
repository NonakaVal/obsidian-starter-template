---
created:
  - "{{date: DD-MM-YYYY}} {{time}}"
tags:
  - Journal
---

# Algo bom ✨
_Relembre e anote eventos positivos do seu dia — não importa o quão pequenos sejam._
- 

# Gratidão 🙏
_Identifique e expresse gratidão por algum aspecto da sua vida hoje._
- 

# Pequeno passo 🚶‍♂️
_Planeje uma pequena ação prática para amanhã que o ajude a progredir em alguma área que você identificou._
- 

# Melhorias 🌱
_Reflita sobre uma área em que o dia poderia ter sido melhor e como você pode evoluir. Tudo bem se não houver nada para colocar aqui. Não seja crítico consigo mesmo — cultive seu crescimento._
- 
