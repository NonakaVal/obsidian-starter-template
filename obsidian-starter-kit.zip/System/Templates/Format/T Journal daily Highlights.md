---
created:
  - "{{date: DD-MM-YYYY}} {{time}}"
tags:
  - Journal
---
