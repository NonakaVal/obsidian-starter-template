---
created: '[[2025-09-19]]'
---
````tabs
tab: Calendar tasks
![[@_dataview_Calendar-tasks]]

tab: Efforts Tasks
![[@_dataview-efforts-tasks]]

````
