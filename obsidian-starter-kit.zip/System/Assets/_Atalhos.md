---
created: "[[2025-05-30]]"
cssclasses:
  - hide-properties_reading
  - hide-properties_editing
---

| 🎛️ Paleta de comandos | `Ctrl + P`         |
| ---------------------- | ------------------ |
| ✔️ Show Task List      | `Ctrl + Shift + T` |
| ➕ New Note             | `Ctrl + N`         |
| ➕ New note `< >`       | `Ctrl + Shift + N` |
| ➡️ Quick Switcher      | `Ctrl + O`         |
| ⭐ Bookmark All Tabs    | `Alt + B`          |
| 📄 Show Outline        | `Ctrl + Shift + O` |
| 📑 Show Bookmarks      | `Ctrl + Shift + B` |
| 📜 Insert a Template   | `Alt + E`          |
| 📦 Move File           | `Alt + M`          |
| 🔍 Search in Files     | `Ctrl + Shift + F` |
| 🔖 Add File Property   | `Ctrl + ;`         |
| 🗂️ File Explorer      | `Ctrl + Shift + P` |
| 🗑️ Delete File        | `Ctrl + Shift + -` |
| 🗓️ Daily Note         | `Ctrl + Shift + D` |
| 🗓️ Weekly  Note       | `Ctrl + Shift + W` |
| 🗓️ Monthly Note       | `Ctrl + Shift + M` |
| 🧠 Show Local Graph    | `Ctrl + G`         |
| 🪟 Open Grid View      | `Alt + G`          |
| 🪧Open Dashboard       | `Alt + V`          |
| 🚪 Close Tab           | `Ctrl + W`         |
| 🚪 Close Window        | `Ctrl + Shift + W` |
