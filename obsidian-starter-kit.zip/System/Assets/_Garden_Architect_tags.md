---
created: "[[2025-10-08]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---

| Tag & Emoji              | Purpose                           |
| ------------------------ | --------------------------------- |
| 🌱 `#garden/plant`       | Quick seed notes                  |
| ☘️ `#garden/cultivate`   | Notes needing depth               |
| 🍄 `#garden/question`    | Notes with open questions         |
| 🪴 `#garden/repot`       | Notes to split or reorganize      |
| 💦 `#garden/revitalize`  | Notes that feel stuck             |
| 🍁 `#garden/revisit`     | Notes worth rereading             |
| 🧱 `#architect/build`    | New or unfinished maps of content |
| 🪜 `#architect/renovate` | Older maps that need updating     |
