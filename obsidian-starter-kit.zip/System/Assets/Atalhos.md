---
created: "[[2025-05-30]]"
cssclasses:
  - hide-properties_reading
  - hide-properties_editing
---

| 🎛️ Paleta de comandos | `Ctrl + P`         |
| ---------------------- | ------------------ |
| ➡️ Quick Switcher      | `Ctrl + O`         |
| 🗓️ Daily Note         | `Ctrl + Shift + D` |
| ➕ New Note             | `Ctrl + Shift + N` |
| ➕ New Area Note        | `Alt + N`          |
| 📜 Insert a Template   | `Ctrl + Alt + N`   |
| 🧠 Show Local Graph    | `Ctrl + G`         |
| 🔖 Add (Footnote)      | `Ctrl + Shift + V` |
| ✔️ Show Checklist      | `Ctrl + Shift + T` |
| 🔖 Add File Property   | `Ctrl + ;`         |
| 📑 Show Bookmarks      | `Ctrl + Shift + B` |
| ⭐ Bookmark All Tabs    | `Alt + B`          |
| 🗂️ File Explorer      | `Ctrl + Shift + E` |
| 📄 Show Outline        | `Ctrl + Shift + O` |
| 🔍 Search in Files     | `Ctrl + Shift + F` |
| 🚪 Close Tab           | `Ctrl + W`         |
| 🚪 Close Window        | `Ctrl + Shift + W` |
| 🗑️ Delete File        | `Ctrl + Shift + -` |
| 📦 Move File           | `Ctrl + Shift + M` |
| 🖨️ Export as PDF      | `Alt + P`          |
